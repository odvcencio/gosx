(function() {
  "use strict";

  var runtimeApi = window.__gosx_runtime_api || {};
  var setAttrValue = runtimeApi.setAttrValue || function() {};
  var setStyleValue = runtimeApi.setStyleValue || function() {};
  var gosxSubscribeSharedSignal = runtimeApi.gosxSubscribeSharedSignal || function() { return function() {}; };
  var setSharedSignalValue = runtimeApi.setSharedSignalValue || function() {};
  var gosxTextLayoutRevision = runtimeApi.gosxTextLayoutRevision || function() { return 0; };
  var normalizeTextLayoutOverflow = runtimeApi.normalizeTextLayoutOverflow || function() { return "ellipsis"; };
  var layoutBrowserText = runtimeApi.layoutBrowserText || function() { return null; };
  var applyTextLayoutPresentation = runtimeApi.applyTextLayoutPresentation || function() {};
  var onTextLayoutInvalidated = runtimeApi.onTextLayoutInvalidated || function() { return function() {}; };

  function sceneBool(value, fallback) {
    if (typeof value === "boolean") return value;
    if (typeof value === "string") {
      const lowered = value.trim().toLowerCase();
      if (lowered === "true") return true;
      if (lowered === "false") return false;
    }
    return fallback;
  }

  function clearChildren(node) {
    while (node && node.firstChild) {
      node.removeChild(node.firstChild);
    }
  }

  let pendingManifest = null;

  function runtimeReady() {
    return (
      typeof window.__gosx_hydrate === "function" ||
      typeof window.__gosx_action === "function" ||
      typeof window.__gosx_set_shared_signal === "function"
    );
  }

  function loadManifest() {
    const el = document.getElementById("gosx-manifest");
    if (!el) return null;

    try {
      return JSON.parse(el.textContent);
    } catch (e) {
      console.error("[gosx] failed to parse manifest:", e);
      if (window.__gosx && typeof window.__gosx.reportIssue === "function") {
        window.__gosx.reportIssue({
          scope: "bootstrap",
          type: "manifest",
          source: "gosx-manifest",
          element: el,
          message: "failed to parse gosx manifest",
          error: e,
          fallback: "server",
        });
      }
      return null;
    }
  }

  async function loadRuntime(runtimeRef) {
    if (typeof Go === "undefined") {
      console.error("[gosx] wasm_exec.js must be loaded before bootstrap.js");
      if (window.__gosx && typeof window.__gosx.reportIssue === "function") {
        window.__gosx.reportIssue({
          scope: "bootstrap",
          type: "runtime",
          source: runtimeRef && runtimeRef.path,
          ref: runtimeRef && runtimeRef.path,
          message: "wasm_exec.js must be loaded before bootstrap.js",
          fallback: "server",
        });
      }
      return;
    }

    const go = new Go();

    try {
      const response = await fetchRuntimeResponse(runtimeRef);
      const result = await instantiateRuntimeModule(response, go.importObject);
      go.run(result.instance);
    } catch (e) {
      console.error("[gosx] failed to load WASM runtime:", e);
      if (window.__gosx && typeof window.__gosx.reportIssue === "function") {
        window.__gosx.reportIssue({
          scope: "bootstrap",
          type: "runtime",
          source: runtimeRef && runtimeRef.path,
          ref: runtimeRef && runtimeRef.path,
          message: "failed to load wasm runtime",
          error: e,
          fallback: "server",
        });
      }
    }
  }

  async function fetchRuntimeResponse(runtimeRef) {
    const response = await fetch(runtimeRef.path);
    if (!response.ok) {
      throw new Error("runtime fetch failed with status " + response.status);
    }
    return response;
  }

  async function instantiateRuntimeModule(response, importObject) {
    if (supportsInstantiateStreaming()) {
      return instantiateRuntimeStreaming(response, importObject);
    }
    return instantiateRuntimeBytes(response, importObject);
  }

  function supportsInstantiateStreaming() {
    return typeof WebAssembly.instantiateStreaming === "function";
  }

  async function instantiateRuntimeStreaming(response, importObject) {
    try {
      return await WebAssembly.instantiateStreaming(response.clone(), importObject);
    } catch (streamErr) {
      return instantiateRuntimeBytes(response, importObject);
    }
  }

  async function instantiateRuntimeBytes(response, importObject) {
    const bytes = await response.arrayBuffer();
    return WebAssembly.instantiate(bytes, importObject);
  }

  async function fetchProgram(programRef, programFormat) {
    try {
      const resp = await fetch(programRef);
      if (!resp.ok) {
        console.error(`[gosx] failed to fetch program ${programRef}: ${resp.status}`);
        return null;
      }

      if (programFormat === "wasm" || programFormat === "bin") {
        return new Uint8Array(await resp.arrayBuffer());
      }
      return await resp.text();
    } catch (e) {
      console.error(`[gosx] error fetching program ${programRef}:`, e);
      return null;
    }
  }

  function inferProgramFormat(entry) {
    if (entry.programFormat) return entry.programFormat;
    if (typeof entry.programRef === "string" && entry.programRef.endsWith(".gxi")) {
      return "bin";
    }
    return "json";
  }

  const loadedScriptTags = new Map();

  function loadScriptTag(src) {
    if (!src) return Promise.resolve();
    if (loadedScriptTags.has(src)) {
      return loadedScriptTags.get(src);
    }
    const promise = new Promise(function(resolve, reject) {
      const script = document.createElement("script");
      script.src = src;
      script.onload = resolve;
      script.onerror = function() {
        reject(new Error("failed to load script: " + src));
      };
      (document.head || document.documentElement).appendChild(script);
    });
    loadedScriptTags.set(src, promise);
    return promise;
  }

  function engineFrame(callback) {
    if (typeof window.requestAnimationFrame === "function") {
      return window.requestAnimationFrame(callback);
    }
    return setTimeout(function() {
      callback(Date.now());
    }, 16);
  }

  function cancelEngineFrame(handle) {
    if (typeof window.cancelAnimationFrame === "function") {
      window.cancelAnimationFrame(handle);
      return;
    }
    clearTimeout(handle);
  }

  function gosxInputState() {
    if (!window.__gosx.input) {
      window.__gosx.input = {
        pending: null,
        frameHandle: 0,
        providers: Object.create(null),
      };
    }
    return window.__gosx.input;
  }

  function queueInputSignal(name, value) {
    if (!name) return;
    const state = gosxInputState();
    if (!state.pending) {
      state.pending = Object.create(null);
    }
    state.pending[name] = value;
    scheduleInputFlush();
  }

  function scheduleInputFlush() {
    const state = gosxInputState();
    if (state.frameHandle) return;
    state.frameHandle = engineFrame(function() {
      state.frameHandle = 0;
      flushInputSignals();
    });
  }

  function flushInputSignals() {
    const state = gosxInputState();
    const payload = state.pending;
    state.pending = null;
    if (!payload) return;

    const setInputBatch = window.__gosx_set_input_batch;
    if (typeof setInputBatch !== "function") {
      for (const [name, value] of Object.entries(payload)) {
        setSharedSignalValue(name, value);
      }
      return;
    }

    try {
      const result = setInputBatch(JSON.stringify(payload));
      if (typeof result === "string" && result !== "") {
        console.error("[gosx] input batch error:", result);
      }
    } catch (e) {
      console.error("[gosx] input batch error:", e);
    }
  }

  function capabilityList(entry) {
    return Array.isArray(entry && entry.capabilities) ? entry.capabilities : [];
  }

  const browserCapabilityCache = Object.create(null);

  function normalizeCapabilityName(value) {
    return String(value == null ? "" : value).trim().toLowerCase();
  }

  function appendCapabilityValues(value, append) {
    if (Array.isArray(value)) {
      for (const item of value) {
        append(item);
      }
      return;
    }
    if (typeof value === "string") {
      for (const item of value.replace(/[,|]/g, " ").split(/\s+/)) {
        append(item);
      }
      return;
    }
    if (value != null) {
      append(value);
    }
  }

  function requiredCapabilityList(entry) {
    const out = [];
    const seen = Object.create(null);
    const append = function(raw) {
      const capability = normalizeCapabilityName(raw);
      if (!capability || seen[capability]) {
        return;
      }
      seen[capability] = true;
      out.push(capability);
    };
    appendCapabilityValues(entry && entry.requiredCapabilities, append);
    appendCapabilityValues(entry && entry.requires, append);
    if (entry && (entry.runtime === "shared" || entry.programRef)) {
      append("wasm");
    }
    return out;
  }

  function runtimeCapabilityStatus(entry) {
    const required = requiredCapabilityList(entry);
    const supported = [];
    const missing = [];
    for (const capability of required) {
      if (browserCapabilitySupported(capability)) {
        supported.push(capability);
      } else {
        missing.push(capability);
      }
    }
    return {
      ok: missing.length === 0,
      requested: capabilityList(entry).slice(),
      required,
      supported,
      missing,
    };
  }

  function engineCapabilityStatus(entry) {
    return runtimeCapabilityStatus(entry);
  }

  function browserCapabilitySupported(capability) {
    const name = normalizeCapabilityName(capability);
    if (!name) {
      return true;
    }
    const dynamicWebGPUFeature = name.indexOf("webgpu:") === 0 || name.indexOf("webgpu-feature:") === 0;
    if (!dynamicWebGPUFeature && Object.prototype.hasOwnProperty.call(browserCapabilityCache, name)) {
      return browserCapabilityCache[name];
    }
    let supported = false;
    try {
      supported = detectBrowserCapability(name);
    } catch (_e) {
      supported = false;
    }
    if (dynamicWebGPUFeature) {
      return Boolean(supported);
    }
    browserCapabilityCache[name] = Boolean(supported);
    return browserCapabilityCache[name];
  }

  function detectBrowserCapability(name) {
    if (name.indexOf("webgpu:adapter-limit:") === 0) {
      return detectWebGPULimitCapability(name.slice("webgpu:adapter-limit:".length), "adapter");
    }
    if (name.indexOf("webgpu:device-limit:") === 0) {
      return detectWebGPULimitCapability(name.slice("webgpu:device-limit:".length), "device");
    }
    if (name.indexOf("webgpu:limit:") === 0) {
      return detectWebGPULimitCapability(name.slice("webgpu:limit:".length), "device");
    }
    if (name.indexOf("webgpu-limit:") === 0) {
      return detectWebGPULimitCapability(name.slice("webgpu-limit:".length), "device");
    }
    if (name.indexOf("webgpu:") === 0) {
      return detectWebGPUFeatureCapability(name.slice("webgpu:".length));
    }
    if (name.indexOf("webgpu-feature:") === 0) {
      return detectWebGPUFeatureCapability(name.slice("webgpu-feature:".length));
    }
    switch (name) {
      case "animation":
        return typeof requestAnimationFrame === "function";
      case "audio":
        return typeof AudioContext === "function" || typeof webkitAudioContext === "function" || canCreateElement("audio");
      case "canvas":
        return canCreateCanvas();
      case "canvas2d":
      case "pixel-surface":
        return canCreateCanvasContext("2d");
      case "compute":
        return browserCapabilitySupported("webgpu") || browserCapabilitySupported("webgl2");
      case "fetch":
        return typeof fetch === "function";
      case "gamepad":
        return Boolean(typeof navigator !== "undefined" && navigator && typeof navigator.getGamepads === "function");
      case "keyboard":
      case "pointer":
        return Boolean(document && typeof document.addEventListener === "function");
      case "pointer-lock":
        return Boolean(
          document &&
          (typeof document.exitPointerLock === "function" || "pointerLockElement" in document) &&
          typeof document.createElement === "function" &&
          typeof document.createElement("canvas").requestPointerLock === "function"
        );
      case "storage":
        return canUseLocalStorage();
      case "text-input":
        return canCreateTextInput();
      case "video":
        return canCreateVideo();
      case "wasm":
        return Boolean(typeof WebAssembly === "object" && WebAssembly && (
          typeof WebAssembly.instantiate === "function" ||
          typeof WebAssembly.instantiateStreaming === "function"
        ));
      case "webgl":
        return canCreateCanvasContext("webgl") || canCreateCanvasContext("experimental-webgl") || canCreateCanvasContext("webgl2");
      case "webgl2":
        return canCreateCanvasContext("webgl2");
      case "webgpu":
        return Boolean(typeof navigator !== "undefined" && navigator && navigator.gpu);
      case "worker":
        return typeof Worker === "function";
      default:
        return false;
    }
  }

  function detectWebGPUFeatureCapability(feature) {
    const normalized = normalizeCapabilityName(feature);
    if (!normalized || !browserCapabilitySupported("webgpu")) {
      return false;
    }
    const diagnostics = typeof window !== "undefined" && typeof window.__gosx_scene3d_webgpu_diagnostics === "function"
      ? window.__gosx_scene3d_webgpu_diagnostics()
      : null;
    if (!diagnostics || diagnostics.ready !== true) {
      return false;
    }
    const deviceFeatures = Array.isArray(diagnostics.deviceFeatures) ? diagnostics.deviceFeatures : [];
    const requestedFeatures = Array.isArray(diagnostics.requestedFeatures) ? diagnostics.requestedFeatures : [];
    return deviceFeatures.indexOf(normalized) >= 0 || requestedFeatures.indexOf(normalized) >= 0;
  }

  function detectWebGPULimitCapability(requirement, scope) {
    if (!browserCapabilitySupported("webgpu")) {
      return false;
    }
    const diagnostics = typeof window !== "undefined" && typeof window.__gosx_scene3d_webgpu_diagnostics === "function"
      ? window.__gosx_scene3d_webgpu_diagnostics()
      : null;
    if (!diagnostics || diagnostics.ready !== true) {
      return false;
    }
    const parsed = parseWebGPULimitRequirement(requirement);
    if (!parsed) {
      return false;
    }
    const primary = scope === "adapter" ? diagnostics.adapterLimits : diagnostics.deviceLimits;
    const fallback = scope === "adapter" ? diagnostics.deviceLimits : diagnostics.adapterLimits;
    let actual = lookupWebGPULimit(primary, parsed.name);
    if (!Number.isFinite(actual)) {
      actual = lookupWebGPULimit(fallback, parsed.name);
    }
    if (!Number.isFinite(actual)) {
      return false;
    }
    switch (parsed.operator) {
      case ">":
        return actual > parsed.value;
      case "<":
        return actual < parsed.value;
      case "<=":
        return actual <= parsed.value;
      case "=":
      case "==":
        return actual === parsed.value;
      case ">=":
      default:
        return actual >= parsed.value;
    }
  }

  function parseWebGPULimitRequirement(requirement) {
    const text = String(requirement || "").trim();
    const match = text.match(/^([a-z0-9_.:-]+)\s*(>=|<=|==|>|<|=|:)\s*([0-9]+(?:\.[0-9]+)?)$/i);
    if (!match) {
      return null;
    }
    const value = Number(match[3]);
    if (!Number.isFinite(value)) {
      return null;
    }
    return {
      name: match[1],
      operator: match[2] === ":" ? ">=" : match[2],
      value,
    };
  }

  function lookupWebGPULimit(limits, name) {
    if (!limits || typeof limits !== "object") {
      return NaN;
    }
    const wanted = normalizeWebGPULimitName(name);
    for (const key of Object.keys(limits)) {
      if (normalizeWebGPULimitName(key) !== wanted) {
        continue;
      }
      const value = Number(limits[key]);
      return Number.isFinite(value) ? value : NaN;
    }
    return NaN;
  }

  function normalizeWebGPULimitName(name) {
    return String(name || "").trim().toLowerCase().replace(/[^a-z0-9]/g, "");
  }

  function canCreateElement(tagName) {
    if (!document || typeof document.createElement !== "function") {
      return false;
    }
    return Boolean(document.createElement(tagName));
  }

  function canCreateCanvas() {
    if (!document || typeof document.createElement !== "function") {
      return false;
    }
    const canvas = document.createElement("canvas");
    return Boolean(canvas && typeof canvas.getContext === "function");
  }

  function canCreateCanvasContext(kind) {
    if (!document || typeof document.createElement !== "function") {
      return false;
    }
    const canvas = document.createElement("canvas");
    if (!canvas || typeof canvas.getContext !== "function") {
      return false;
    }
    return Boolean(canvas.getContext(kind));
  }

  function canCreateTextInput() {
    if (!document || typeof document.createElement !== "function") {
      return false;
    }
    const input = document.createElement("input");
    return Boolean(input && typeof input.focus === "function");
  }

  function canCreateVideo() {
    if (!document || typeof document.createElement !== "function") {
      return false;
    }
    const video = document.createElement("video");
    return Boolean(video && typeof video.canPlayType === "function");
  }

  function canUseLocalStorage() {
    try {
      if (!window || !window.localStorage) {
        return false;
      }
      const key = "__gosx_capability_probe__";
      window.localStorage.setItem(key, "1");
      window.localStorage.removeItem(key);
      return true;
    } catch (_e) {
      return false;
    }
  }

  function applyRuntimeCapabilityState(element, scope, status) {
    if (!element || !status) {
      return;
    }
    const prefix = "data-gosx-" + (scope || "runtime") + "-";
    element.setAttribute(prefix + "capability-state", status.ok ? "ready" : "unsupported");
    element.setAttribute(prefix + "required-capabilities", status.required.join(" "));
    element.setAttribute(prefix + "supported-capabilities", status.supported.join(" "));
    if (status.missing.length > 0) {
      element.setAttribute(prefix + "missing-capabilities", status.missing.join(" "));
    } else if (typeof element.removeAttribute === "function") {
      element.removeAttribute(prefix + "missing-capabilities");
    }
  }

  function activateInputProviders(entry) {
    for (const capability of capabilityList(entry)) {
      activateInputProvider(capability, entry);
    }
  }

  function activateInputProvider(capability, entry) {
    const state = gosxInputState();
    const current = state.providers[capability];
    if (current) {
      current.refCount += 1;
      return;
    }

    const provider = createInputProvider(capability, entry);
    if (!provider) {
      return;
    }

    provider.refCount = 1;
    state.providers[capability] = provider;
  }

  function releaseInputProviders(record) {
    for (const capability of capabilityList(record)) {
      releaseInputProvider(capability);
    }
  }

  function releaseInputProvider(capability) {
    const state = gosxInputState();
    const provider = state.providers[capability];
    if (!provider) return;

    provider.refCount -= 1;
    if (provider.refCount > 0) {
      return;
    }

    if (typeof provider.dispose === "function") {
      provider.dispose();
    }
    delete state.providers[capability];
  }

  function createInputProvider(capability, entry) {
    switch (capability) {
      case "keyboard":
        return createKeyboardInputProvider();
      case "pointer":
        return createPointerInputProvider();
      case "gamepad":
        return createGamepadInputProvider();
      case "text-input":
        return createTextInputProvider(entry);
      default:
        return null;
    }
  }

  function createKeyboardInputProvider() {
    const pressed = new Set();

    function onKey(event) {
      const key = normalizeKeyName(event);
      if (!key) return;
      const active = event.type === "keydown";
      if (active) {
        pressed.add(key);
      } else {
        pressed.delete(key);
      }
      queueInputSignal("$input.key." + key, active);
    }

    function onBlur() {
      for (const key of Array.from(pressed)) {
        queueInputSignal("$input.key." + key, false);
      }
      pressed.clear();
    }

    return bindInputProviderListeners([
      [document, "keydown", onKey],
      [document, "keyup", onKey],
      [window, "blur", onBlur],
    ]);
  }

  function createPointerInputProvider() {
    const state = { lastX: null, lastY: null };

    function publishPointer(event) {
      publishPointerSignals(resolvePointerSample(event, state), event);
    }

    function onBlur() {
      resetPointerSignals();
    }

    return bindInputProviderListeners([
      [document, "pointermove", publishPointer],
      [document, "pointerdown", publishPointer],
      [document, "pointerup", publishPointer],
      [window, "blur", onBlur],
    ]);
  }

  function createGamepadInputProvider() {
    let active = true;
    let frameHandle = 0;

    function pollGamepad() {
      if (!active) return;
      const navigatorRef = window.navigator;
      if (navigatorRef && typeof navigatorRef.getGamepads === "function") {
        const pads = navigatorRef.getGamepads() || [];
        let connected = 0;
        for (let i = 0; i < 2; i++) {
          const pad = pads[i];
          if (pad && pad.connected !== false) {
            connected += 1;
            publishGamepadSignals(pad, i);
          } else {
            queueInputSignal("$input.gamepad" + i + ".connected", false);
          }
        }
        queueInputSignal("$input.gamepad.count", connected);
      }
      frameHandle = engineFrame(pollGamepad);
    }

    frameHandle = engineFrame(pollGamepad);

    return {
      dispose() {
        active = false;
        if (frameHandle) {
          cancelEngineFrame(frameHandle);
          frameHandle = 0;
        }
      },
    };
  }

  function createTextInputProvider(entry) {
    var inputEl = null;
    var mount = null;
    var unsubCursorRect = null;
    var unsubClipboard = null;
    var viewportListener = null;

    var mountID = entry && (entry.mountId || entry.id);
    mount = mountID ? document.getElementById(mountID) : null;
    if (!mount) {
      mount = document.body;
    }

    inputEl = document.createElement("div");
    inputEl.contentEditable = "true";
    inputEl.setAttribute("role", "textbox");
    inputEl.setAttribute("aria-multiline", "true");
    inputEl.style.cssText = "position:absolute;opacity:0;width:1px;height:1em;overflow:hidden;white-space:pre;pointer-events:none;z-index:-1";
    if (!mount.style.position || mount.style.position === "static") {
      mount.style.position = "relative";
    }
    mount.appendChild(inputEl);

    function focusInput(e) {
      if (e.target !== inputEl) inputEl.focus();
    }

    mount.addEventListener("mousedown", focusInput);
    mount.addEventListener("touchstart", focusInput);

    inputEl.addEventListener("beforeinput", function(e) {
      var type = e.inputType;
      if (type === "insertText" || type === "insertReplacementText") {
        e.preventDefault();
        if (e.data) queueInputSignal("$input.text.inserted", e.data);
      } else if (type === "insertFromPaste") {
        e.preventDefault();
        var text = e.dataTransfer ? e.dataTransfer.getData("text/plain") : "";
        if (text) queueInputSignal("$input.clipboard.paste", text);
      } else if (type === "deleteContentBackward") {
        e.preventDefault();
        queueInputSignal("$input.command", "delete_backward");
      } else if (type === "deleteContentForward") {
        e.preventDefault();
        queueInputSignal("$input.command", "delete_forward");
      } else if (type === "insertLineBreak" || type === "insertParagraph") {
        e.preventDefault();
        queueInputSignal("$input.command", "newline");
      }
      requestAnimationFrame(function() { if (inputEl) inputEl.textContent = ""; });
    });

    inputEl.addEventListener("compositionstart", function() {
      queueInputSignal("$input.text.composition_active", true);
    });
    inputEl.addEventListener("compositionupdate", function(e) {
      queueInputSignal("$input.text.composing", e.data || "");
    });
    inputEl.addEventListener("compositionend", function(e) {
      queueInputSignal("$input.text.composition_active", false);
      queueInputSignal("$input.text.composing", "");
      if (e.data) queueInputSignal("$input.text.inserted", e.data);
    });

    inputEl.addEventListener("keydown", function(e) {
      if (e.isComposing) return;
      var mod = e.metaKey || e.ctrlKey;
      var shift = e.shiftKey;
      var command = null;

      switch (e.key) {
        case "ArrowUp":    command = shift ? "select_up" : "move_up"; break;
        case "ArrowDown":  command = shift ? "select_down" : "move_down"; break;
        case "ArrowLeft":  command = shift ? "select_left" : "move_left"; break;
        case "ArrowRight": command = shift ? "select_right" : "move_right"; break;
        case "Home":       command = shift ? "select_line_start" : "move_line_start"; break;
        case "End":        command = shift ? "select_line_end" : "move_line_end"; break;
        case "Tab":        command = shift ? "dedent" : "indent"; break;
        case "Escape":     command = "escape"; break;
      }

      if (!command && mod) {
        switch (e.key.toLowerCase()) {
          case "z": command = shift ? "redo" : "undo"; break;
          case "a": command = "select_all"; break;
          case "s": command = "save"; break;
          case "b": command = "bold"; break;
          case "i": command = "italic"; break;
        }
      }

      if (command) {
        e.preventDefault();
        queueInputSignal("$input.command", command);
      }
    });

    mount.addEventListener("dragover", function(e) { e.preventDefault(); });
    mount.addEventListener("drop", function(e) {
      e.preventDefault();
      var files = e.dataTransfer ? e.dataTransfer.files : null;
      if (files && files.length > 0) {
        var file = files[0];
        if (file.type.startsWith("image/")) {
          var reader = new FileReader();
          reader.onload = function() {
            queueInputSignal("$editor.file_drop", JSON.stringify({
              name: file.name, type: file.type, size: file.size, data: reader.result
            }));
          };
          reader.readAsDataURL(file);
        }
      }
    });

    if (window.visualViewport) {
      viewportListener = function() {
        var kh = window.innerHeight - window.visualViewport.height;
        queueInputSignal("$input.keyboard_height", Math.max(0, kh));
      };
      window.visualViewport.addEventListener("resize", viewportListener, { passive: true });
    }

    unsubCursorRect = gosxSubscribeSharedSignal("$editor.cursor_rect", function(rect) {
      if (!inputEl) return;
      var r = typeof rect === "string" ? JSON.parse(rect) : rect;
      if (r) {
        inputEl.style.left = (r.x || 0) + "px";
        inputEl.style.top = (r.y || 0) + "px";
        inputEl.style.height = (r.height || 20) + "px";
      }
    });

    unsubClipboard = gosxSubscribeSharedSignal("$editor.clipboard_content", function(text) {
      if (!inputEl || !text) return;
      inputEl.textContent = text;
      var range = document.createRange();
      range.selectNodeContents(inputEl);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    });

    inputEl.focus();

    return {
      dispose: function() {
        if (unsubCursorRect) { unsubCursorRect(); unsubCursorRect = null; }
        if (unsubClipboard) { unsubClipboard(); unsubClipboard = null; }
        if (viewportListener && window.visualViewport) {
          window.visualViewport.removeEventListener("resize", viewportListener);
          viewportListener = null;
        }
        if (mount) {
          mount.removeEventListener("mousedown", focusInput);
          mount.removeEventListener("touchstart", focusInput);
        }
        if (inputEl && inputEl.parentNode) {
          inputEl.parentNode.removeChild(inputEl);
        }
        inputEl = null;
        mount = null;
      },
    };
  }

  function bindInputProviderListeners(bindings) {
    for (const binding of bindings) {
      binding[0].addEventListener(binding[1], binding[2]);
    }
    return {
      dispose() {
        for (const binding of bindings) {
          binding[0].removeEventListener(binding[1], binding[2]);
        }
      },
    };
  }

  function normalizeKeyName(event) {
    const raw = event && (event.key || event.code);
    if (!raw) return "";
    return String(raw).trim().toLowerCase();
  }

  function resolvePointerSample(event, state) {
    const previousX = state.lastX == null ? 0 : state.lastX;
    const previousY = state.lastY == null ? 0 : state.lastY;
    const x = sceneNumber(event && event.clientX, previousX);
    const y = sceneNumber(event && event.clientY, previousY);
    const sample = {
      x,
      y,
      deltaX: sceneNumber(event && event.movementX, state.lastX == null ? 0 : x - previousX),
      deltaY: sceneNumber(event && event.movementY, state.lastY == null ? 0 : y - previousY),
      buttons: event && typeof event.buttons !== "undefined" ? sceneNumber(event.buttons, 0) : null,
      button: event && typeof event.button === "number" ? event.button : null,
      active: event ? event.type !== "pointerup" : false,
    };
    state.lastX = x;
    state.lastY = y;
    return sample;
  }

  function publishPointerSignals(sample, event) {
    queueInputSignal("$input.pointer.x", sample.x);
    queueInputSignal("$input.pointer.y", sample.y);
    queueInputSignal("$input.pointer.deltaX", sample.deltaX);
    queueInputSignal("$input.pointer.deltaY", sample.deltaY);
    if (sample.buttons != null) {
      queueInputSignal("$input.pointer.buttons", sample.buttons);
    }
    if (sample.button != null) {
      queueInputSignal("$input.pointer.button" + sample.button, sample.active);
    }
  }

  function resetPointerSignals() {
    queueInputSignal("$input.pointer.deltaX", 0);
    queueInputSignal("$input.pointer.deltaY", 0);
    queueInputSignal("$input.pointer.buttons", 0);
  }

  function publishGamepadSignals(pad, slot) {
    const prefix = "$input.gamepad" + Math.max(0, Math.floor(sceneNumber(slot, 0)));
    const axes = Array.isArray(pad.axes) ? pad.axes : [];
    queueInputSignal(prefix + ".connected", true);
    queueInputSignal(prefix + ".leftX", sceneNumber(axes[0], 0));
    queueInputSignal(prefix + ".leftY", sceneNumber(axes[1], 0));
    queueInputSignal(prefix + ".rightX", sceneNumber(axes[2], 0));
    queueInputSignal(prefix + ".rightY", sceneNumber(axes[3], 0));
    queueInputSignal(prefix + ".dpadUp", gamepadButtonPressed(pad, 12));
    queueInputSignal(prefix + ".dpadDown", gamepadButtonPressed(pad, 13));
    queueInputSignal(prefix + ".dpadLeft", gamepadButtonPressed(pad, 14));
    queueInputSignal(prefix + ".dpadRight", gamepadButtonPressed(pad, 15));
    queueInputSignal(prefix + ".buttonA", gamepadButtonPressed(pad, 0));
    queueInputSignal(prefix + ".buttonB", gamepadButtonPressed(pad, 1));
    queueInputSignal(prefix + ".buttonX", gamepadButtonPressed(pad, 2));
    queueInputSignal(prefix + ".buttonY", gamepadButtonPressed(pad, 3));
    queueInputSignal(prefix + ".buttonLB", gamepadButtonPressed(pad, 4));
    queueInputSignal(prefix + ".buttonRB", gamepadButtonPressed(pad, 5));
  }

  function gamepadButtonPressed(pad, index) {
    return Boolean(pad && pad.buttons && pad.buttons[index] && pad.buttons[index].pressed);
  }

  function sceneNumber(value, fallback) {
    const num = Number(value);
    return Number.isFinite(num) ? num : fallback;
  }

  function sceneCSSVarReference(value) {
    return typeof value === "string" && /^var\(\s*--[-_a-zA-Z0-9]+\s*(?:,|\))/.test(value.trim());
  }

  function sceneNumberOrCSSVar(value, fallback) {
    return sceneCSSVarReference(value) ? value.trim() : sceneNumber(value, fallback);
  }

  function sceneClampNumberOrCSSVar(value, fallback, min, max) {
    if (sceneCSSVarReference(value)) {
      return value.trim();
    }
    return Math.max(min, Math.min(max, sceneNumber(value, fallback)));
  }

  function defaultSceneObjects() {
    return [
      {
        kind: "cube",
        size: 1.8,
        x: -1.1,
        y: 0.3,
        z: 0,
        color: "#8de1ff",
        spinX: 0.42,
        spinY: 0.74,
        spinZ: 0.16,
      },
      {
        kind: "cube",
        size: 1.1,
        x: 1.6,
        y: -0.7,
        z: 1.4,
        color: "#ffd48f",
        spinX: -0.24,
        spinY: 0.48,
        spinZ: 0.12,
      },
    ];
  }

  function rawSceneObjects(props) {
    const scene = sceneProps(props);
    return sceneObjectList(scene && scene.objects) || sceneObjectList(props && props.objects) || defaultSceneObjects();
  }

  function rawSceneLabels(props) {
    const scene = sceneProps(props);
    if (scene && Array.isArray(scene.labels)) {
      return scene.labels;
    }
    return props && Array.isArray(props.labels) ? props.labels : [];
  }

  function rawSceneSprites(props) {
    const scene = sceneProps(props);
    if (scene && Array.isArray(scene.sprites)) {
      return scene.sprites;
    }
    return props && Array.isArray(props.sprites) ? props.sprites : [];
  }

  function rawSceneHTML(props) {
    const scene = sceneProps(props);
    if (scene && Array.isArray(scene.html)) {
      return scene.html;
    }
    if (scene && Array.isArray(scene.htmlOverlays)) {
      return scene.htmlOverlays;
    }
    if (scene && Array.isArray(scene.htmls)) {
      return scene.htmls;
    }
    if (props && Array.isArray(props.html)) {
      return props.html;
    }
    return props && Array.isArray(props.htmlOverlays) ? props.htmlOverlays : [];
  }

  function rawSceneLights(props) {
    const scene = sceneProps(props);
    if (scene && Array.isArray(scene.lights)) {
      return scene.lights;
    }
    return props && Array.isArray(props.lights) ? props.lights : [];
  }

  function rawSceneEnvironment(props) {
    const scene = sceneProps(props);
    if (scene && scene.environment && typeof scene.environment === "object") {
      return scene.environment;
    }
    return props && props.environment && typeof props.environment === "object" ? props.environment : null;
  }

  function rawSceneModels(props) {
    const scene = sceneProps(props);
    if (scene && Array.isArray(scene.models)) {
      return scene.models;
    }
    return props && Array.isArray(props.models) ? props.models : [];
  }

  function rawScenePoints(props) {
    const scene = sceneProps(props);
    if (scene && Array.isArray(scene.points)) {
      return scene.points;
    }
    return props && Array.isArray(props.points) ? props.points : [];
  }

  function rawSceneInstancedMeshes(props) {
    const scene = sceneProps(props);
    if (scene && Array.isArray(scene.instancedMeshes)) {
      return scene.instancedMeshes;
    }
    return props && Array.isArray(props.instancedMeshes) ? props.instancedMeshes : [];
  }

  function rawSceneComputeParticles(props) {
    const scene = sceneProps(props);
    if (scene && Array.isArray(scene.computeParticles)) {
      return scene.computeParticles;
    }
    return props && Array.isArray(props.computeParticles) ? props.computeParticles : [];
  }

  function rawSceneMaterials(props) {
    const scene = sceneProps(props);
    if (scene && Array.isArray(scene.materials)) {
      return scene.materials;
    }
    return props && Array.isArray(props.materials) ? props.materials : [];
  }

  function rawScenePostEffects(props) {
    const scene = sceneProps(props);
    if (scene && Array.isArray(scene.postEffects)) {
      return scene.postEffects;
    }
    if (scene && Array.isArray(scene.postFX)) {
      return scene.postFX;
    }
    if (props && Array.isArray(props.postEffects)) {
      return props.postEffects;
    }
    return props && Array.isArray(props.postFX) ? props.postFX : [];
  }

  function sceneProps(props) {
    return props && props.scene && typeof props.scene === "object" ? props.scene : null;
  }

  function sceneObjectList(value) {
    return Array.isArray(value) && value.length > 0 ? value : null;
  }

  function sceneCloneData(value) {
    if (Array.isArray(value)) {
      return value.map(sceneCloneData);
    }
    if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView && ArrayBuffer.isView(value)) {
      return typeof value.slice === "function" ? value.slice() : value;
    }
    if (!value || typeof value !== "object") {
      return value;
    }
    const clone = {};
    const keys = Object.keys(value);
    for (let i = 0; i < keys.length; i += 1) {
      const key = keys[i];
      clone[key] = sceneCloneData(value[key]);
    }
    return clone;
  }

  function sceneIsPlainObject(value) {
    return Boolean(value) && typeof value === "object" && !Array.isArray(value) && !(typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView && ArrayBuffer.isView(value));
  }

  function sceneTransitionMetadataKey(key) {
    return key === "transition" || key === "inState" || key === "outState" || key === "live" || (typeof key === "string" && key.charAt(0) === "_");
  }

  function normalizeSceneEasing(value) {
    switch (String(value || "").trim().toLowerCase()) {
      case "linear":
        return "linear";
      case "ease-in":
        return "ease-in";
      case "ease-out":
        return "ease-out";
      case "ease-in-out":
        return "ease-in-out";
      default:
        return "";
    }
  }

  function normalizeSceneTransitionTiming(raw, fallback) {
    const base = sceneIsPlainObject(fallback) ? fallback : {};
    const source = sceneIsPlainObject(raw) ? raw : {};
    return {
      duration: Math.max(0, Math.round(sceneNumber(source.duration, sceneNumber(base.duration, 0)))),
      easing: normalizeSceneEasing(source.easing || base.easing),
    };
  }

  function normalizeSceneTransition(raw, fallback) {
    const base = sceneIsPlainObject(fallback) ? fallback : {};
    const source = sceneIsPlainObject(raw) ? raw : {};
    return {
      in: normalizeSceneTransitionTiming(source.in, base.in),
      out: normalizeSceneTransitionTiming(source.out, base.out),
      update: normalizeSceneTransitionTiming(source.update, base.update),
    };
  }

  function sceneNormalizeLive(value, fallback) {
    const source = Array.isArray(value) ? value : (Array.isArray(fallback) ? fallback : []);
    if (!source.length) {
      return [];
    }
    const seen = new Set();
    const out = [];
    for (let i = 0; i < source.length; i += 1) {
      const next = typeof source[i] === "string" ? source[i].trim() : "";
      if (!next || seen.has(next)) {
        continue;
      }
      seen.add(next);
      out.push(next);
    }
    return out;
  }

  function sceneNormalizeLifecycle(item, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const source = sceneIsPlainObject(item) ? item : {};
    const hasInState = Object.prototype.hasOwnProperty.call(source, "inState");
    const hasOutState = Object.prototype.hasOwnProperty.call(source, "outState");
    const hasLive = Object.prototype.hasOwnProperty.call(source, "live");
    return {
      transition: normalizeSceneTransition(source.transition, current._transition),
      inState: sceneCloneData(hasInState ? source.inState : current._inState),
      outState: sceneCloneData(hasOutState ? source.outState : current._outState),
      live: sceneNormalizeLive(hasLive ? source.live : undefined, current._live),
    };
  }

  function sceneLinePoint(value) {
    if (Array.isArray(value)) {
      return {
        x: sceneNumber(value[0], 0),
        y: sceneNumber(value[1], 0),
        z: sceneNumber(value[2], 0),
      };
    }
    const item = value && typeof value === "object" ? value : {};
    return {
      x: sceneNumber(item.x, 0),
      y: sceneNumber(item.y, 0),
      z: sceneNumber(item.z, 0),
    };
  }

  function sceneLinePoints(value) {
    const list = Array.isArray(value) ? value : [];
    return list.map(sceneLinePoint);
  }

  function sceneLineSegmentValue(value) {
    function sceneLineIndex(entry) {
      const index = Math.floor(sceneNumber(entry, -1));
      return Number.isFinite(index) ? index : -1;
    }
    if (Array.isArray(value)) {
      return [sceneLineIndex(value[0]), sceneLineIndex(value[1])];
    }
    const item = value && typeof value === "object" ? value : {};
    return [
      sceneLineIndex(item.from !== undefined ? item.from : item.a),
      sceneLineIndex(item.to !== undefined ? item.to : item.b),
    ];
  }

  function sceneLineSegments(value, pointCount) {
    const list = Array.isArray(value) ? value : [];
    const out = [];
    for (const item of list) {
      const pair = sceneLineSegmentValue(item);
      if (!Number.isFinite(pair[0]) || !Number.isFinite(pair[1])) {
        continue;
      }
      if (pair[0] < 0 || pair[1] < 0 || pair[0] === pair[1]) {
        continue;
      }
      if (pair[0] >= pointCount || pair[1] >= pointCount) {
        continue;
      }
      out.push(pair);
    }
    if (out.length === 0 && pointCount > 1) {
      for (let index = 0; index + 1 < pointCount; index += 1) {
        out.push([index, index + 1]);
      }
    }
    return out;
  }

  function sceneNormalizeMeshFloatArray(value, tupleSize) {
    const typed = sceneTypedFloatArray(value);
    const safeTupleSize = Math.max(1, Math.floor(sceneNumber(tupleSize, 1)));
    const count = Math.floor(typed.length / safeTupleSize);
    if (!count) {
      return new Float32Array(0);
    }
    if (typed.length === count * safeTupleSize) {
      return typed;
    }
    return typed.slice(0, count * safeTupleSize);
  }

  function sceneNormalizeMeshVertexData(value) {
    const item = value && typeof value === "object" ? value : {};
    const positions = sceneNormalizeMeshFloatArray(item.positions, 3);
    if (!positions.length) {
      return null;
    }
    const inferredCount = Math.floor(positions.length / 3);
    const count = Math.max(0, Math.min(
      inferredCount,
      Math.floor(sceneNumber(item.count, inferredCount)),
    ));
    if (!count) {
      return null;
    }
    const normals = sceneNormalizeMeshFloatArray(item.normals, 3);
    const uvs = sceneNormalizeMeshFloatArray(item.uvs, 2);
    const tangents = sceneNormalizeMeshFloatArray(item.tangents, 4);
    const joints = sceneNormalizeMeshFloatArray(item.joints, 4);
    const weights = sceneNormalizeMeshFloatArray(item.weights, 4);
    return {
      positions: count * 3 === positions.length ? positions : positions.slice(0, count * 3),
      normals: normals.length >= count * 3 ? normals.slice(0, count * 3) : new Float32Array(0),
      uvs: uvs.length >= count * 2 ? uvs.slice(0, count * 2) : new Float32Array(0),
      tangents: tangents.length >= count * 4 ? tangents.slice(0, count * 4) : new Float32Array(0),
      joints: joints.length >= count * 4 ? joints.slice(0, count * 4) : new Float32Array(0),
      weights: weights.length >= count * 4 ? weights.slice(0, count * 4) : new Float32Array(0),
      count,
    };
  }

  function sceneLineGeometryMetrics(points) {
    if (!Array.isArray(points) || points.length === 0) {
      return null;
    }
    let minX = points[0].x;
    let minY = points[0].y;
    let minZ = points[0].z;
    let maxX = points[0].x;
    let maxY = points[0].y;
    let maxZ = points[0].z;
    for (let i = 1; i < points.length; i += 1) {
      const point = points[i];
      minX = Math.min(minX, point.x);
      minY = Math.min(minY, point.y);
      minZ = Math.min(minZ, point.z);
      maxX = Math.max(maxX, point.x);
      maxY = Math.max(maxY, point.y);
      maxZ = Math.max(maxZ, point.z);
    }
    return {
      width: Math.max(0.0001, maxX - minX),
      height: Math.max(0.0001, maxY - minY),
      depth: Math.max(0.0001, maxZ - minZ),
      radius: Math.max(0.0001, Math.max(maxX - minX, maxY - minY, maxZ - minZ) / 2),
    };
  }

  function normalizeSceneObject(object, index, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const item = sceneIsPlainObject(object) ? object : {};
    const scaleSource = sceneIsPlainObject(item.scale) ? item.scale : (sceneIsPlainObject(current.scale) ? current.scale : null);
    const vertices = sceneNormalizeMeshVertexData(item.vertices);
    const kind = normalizeSceneKind(item.kind || current.kind);
    const size = sceneNumber(item.size, sceneNumber(current.size, 1.2));
    const points = kind === "lines"
      ? sceneLinePoints(Object.prototype.hasOwnProperty.call(item, "points") ? item.points : current.points)
      : [];
    const lineMetrics = kind === "lines" ? sceneLineGeometryMetrics(points) : null;
    const materialKind = normalizeSceneMaterialKind(sceneObjectMaterialKindValue(item) || current.materialKind);
    const materialColor = sceneObjectMaterialHasValue(item, "color") ? sceneObjectMaterialValue(item, "color") : current.color;
    const textureValue = sceneObjectMaterialHasValue(item, "texture") ? sceneObjectMaterialValue(item, "texture") : current.texture;
    const texture = typeof textureValue === "string" ? textureValue.trim() : "";
    const opacity = sceneClampNumberOrCSSVar(sceneObjectMaterialValue(item, "opacity"), sceneNumber(current.opacity, sceneDefaultMaterialOpacity(materialKind)), 0, 1);
    const numericOpacity = sceneNumber(opacity, sceneNumber(current.opacity, sceneDefaultMaterialOpacity(materialKind)));
    const blendMode = normalizeSceneMaterialBlendMode(
      sceneObjectBlendModeHasValue(item) ? sceneObjectBlendModeValue(item) : current.blendMode,
      materialKind,
      numericOpacity,
    );
    const lifecycle = sceneNormalizeLifecycle(item, current);
    const normalized = {
      id: item.id || current.id || ("scene-object-" + index),
      kind,
      material: typeof item.material === "string" && item.material.trim() ? item.material.trim() : (typeof current.material === "string" ? current.material : ""),
      size,
      width: sceneNumber(item.width, sceneNumber(current.width, lineMetrics ? lineMetrics.width : size)),
      height: sceneNumber(item.height, sceneNumber(current.height, lineMetrics ? lineMetrics.height : size)),
      depth: sceneNumber(item.depth, sceneNumber(current.depth, kind === "plane" ? sceneNumber(item.height, size) : (lineMetrics ? lineMetrics.depth : size))),
      radius: sceneNumber(item.radius, sceneNumber(current.radius, lineMetrics ? lineMetrics.radius : (size / 2))),
      segments: sceneSegmentResolution(Object.prototype.hasOwnProperty.call(item, "segments") ? item.segments : current.segments),
      points,
      lineSegments: kind === "lines" ? sceneLineSegments(Array.isArray(item.lineSegments) ? item.lineSegments : (Array.isArray(current.lineSegments) ? current.lineSegments : item.segments), points.length) : [],
      vertices: vertices || current.vertices || null,
      x: sceneNumber(item.x, sceneNumber(current.x, 0)),
      y: sceneNumber(item.y, sceneNumber(current.y, 0)),
      z: sceneNumber(item.z, sceneNumber(current.z, 0)),
      materialKind,
      color: typeof materialColor === "string" && materialColor ? materialColor : (typeof current.color === "string" && current.color ? current.color : "#8de1ff"),
      texture,
      opacity,
      emissive: sceneClampNumberOrCSSVar(sceneObjectMaterialValue(item, "emissive"), sceneNumber(current.emissive, sceneDefaultMaterialEmissive(materialKind)), 0, 1),
      roughness: sceneNumberOrCSSVar(sceneObjectMaterialValue(item, "roughness"), sceneNumber(current.roughness, 0.5)),
      metalness: sceneNumberOrCSSVar(sceneObjectMaterialValue(item, "metalness"), sceneNumber(current.metalness, 0)),
      clearcoat: sceneClampNumberOrCSSVar(sceneObjectMaterialValue(item, "clearcoat"), sceneNumber(current.clearcoat, 0), 0, 1),
      sheen: sceneClampNumberOrCSSVar(sceneObjectMaterialValue(item, "sheen"), sceneNumber(current.sheen, 0), 0, 1),
      transmission: sceneClampNumberOrCSSVar(sceneObjectMaterialValue(item, "transmission"), sceneNumber(current.transmission, 0), 0, 1),
      iridescence: sceneClampNumberOrCSSVar(sceneObjectMaterialValue(item, "iridescence"), sceneNumber(current.iridescence, 0), 0, 1),
      anisotropy: sceneClampNumberOrCSSVar(sceneObjectMaterialValue(item, "anisotropy"), sceneNumber(current.anisotropy, 0), -1, 1),
      lineDash: sceneBool(sceneObjectMaterialHasValue(item, "lineDash") ? sceneObjectMaterialValue(item, "lineDash") : current.lineDash, false),
      dashSize: sceneNumber(sceneObjectMaterialValue(item, "dashSize"), sceneNumber(current.dashSize, 0)),
      gapSize: sceneNumber(sceneObjectMaterialValue(item, "gapSize"), sceneNumber(current.gapSize, 0)),
      customVertex: typeof sceneObjectMaterialValue(item, "customVertex") === "string" ? sceneObjectMaterialValue(item, "customVertex") : (typeof current.customVertex === "string" ? current.customVertex : ""),
      customFragment: typeof sceneObjectMaterialValue(item, "customFragment") === "string" ? sceneObjectMaterialValue(item, "customFragment") : (typeof current.customFragment === "string" ? current.customFragment : ""),
      customVertexWGSL: typeof sceneObjectMaterialValue(item, "customVertexWGSL") === "string" ? sceneObjectMaterialValue(item, "customVertexWGSL") : (typeof current.customVertexWGSL === "string" ? current.customVertexWGSL : ""),
      customFragmentWGSL: typeof sceneObjectMaterialValue(item, "customFragmentWGSL") === "string" ? sceneObjectMaterialValue(item, "customFragmentWGSL") : (typeof current.customFragmentWGSL === "string" ? current.customFragmentWGSL : ""),
      customUniforms: sceneIsPlainObject(sceneObjectMaterialValue(item, "customUniforms")) ? Object.assign({}, sceneObjectMaterialValue(item, "customUniforms")) : (sceneIsPlainObject(current.customUniforms) ? Object.assign({}, current.customUniforms) : null),
      blendMode,
      renderPass: normalizeSceneMaterialRenderPass(
        sceneObjectMaterialHasValue(item, "renderPass") ? sceneObjectMaterialValue(item, "renderPass") : current.renderPass,
        blendMode,
        numericOpacity,
        materialKind,
      ),
      wireframe: sceneBool(
        sceneObjectMaterialHasValue(item, "wireframe") ? sceneObjectMaterialValue(item, "wireframe") : current.wireframe,
        texture === "",
      ),
      pickable: Object.prototype.hasOwnProperty.call(item, "pickable") ? sceneBool(item.pickable, false) : current.pickable,
      rotationX: sceneNumber(item.rotationX, sceneNumber(current.rotationX, 0)),
      rotationY: sceneNumber(item.rotationY, sceneNumber(current.rotationY, 0)),
      rotationZ: sceneNumber(item.rotationZ, sceneNumber(current.rotationZ, 0)),
      scaleX: sceneNumber(item.scaleX, sceneNumber(scaleSource ? scaleSource.x : undefined, sceneNumber(current.scaleX, 1))),
      scaleY: sceneNumber(item.scaleY, sceneNumber(scaleSource ? scaleSource.y : undefined, sceneNumber(current.scaleY, 1))),
      scaleZ: sceneNumber(item.scaleZ, sceneNumber(scaleSource ? scaleSource.z : undefined, sceneNumber(current.scaleZ, 1))),
      spinX: sceneNumber(item.spinX, sceneNumber(current.spinX, 0)),
      spinY: sceneNumber(item.spinY, sceneNumber(current.spinY, 0)),
      spinZ: sceneNumber(item.spinZ, sceneNumber(current.spinZ, 0)),
      shiftX: sceneNumber(item.shiftX, sceneNumber(current.shiftX, 0)),
      shiftY: sceneNumber(item.shiftY, sceneNumber(current.shiftY, 0)),
      shiftZ: sceneNumber(item.shiftZ, sceneNumber(current.shiftZ, 0)),
      driftSpeed: sceneNumber(item.driftSpeed, sceneNumber(current.driftSpeed, 0)),
      driftPhase: sceneNumber(item.driftPhase, sceneNumber(current.driftPhase, 0)),
      lineWidth: sceneNumber(item.lineWidth, sceneNumber(current.lineWidth, 0)),
      selected: sceneBool(Object.prototype.hasOwnProperty.call(item, "selected") ? item.selected : current.selected, false),
      outlineColor: typeof item.outlineColor === "string" && item.outlineColor ? item.outlineColor : (typeof current.outlineColor === "string" ? current.outlineColor : ""),
      outlineWidth: sceneNumber(item.outlineWidth, sceneNumber(current.outlineWidth, 0)),
      viewCulled: sceneBool(Object.prototype.hasOwnProperty.call(item, "viewCulled") ? item.viewCulled : current.viewCulled, false),
      castShadow: sceneBool(Object.prototype.hasOwnProperty.call(item, "castShadow") ? item.castShadow : current.castShadow, false),
      receiveShadow: sceneBool(Object.prototype.hasOwnProperty.call(item, "receiveShadow") ? item.receiveShadow : current.receiveShadow, false),
      doubleSided: sceneBool(Object.prototype.hasOwnProperty.call(item, "doubleSided") ? item.doubleSided : current.doubleSided, false),
      depthWrite: Object.prototype.hasOwnProperty.call(item, "depthWrite") ? sceneBool(item.depthWrite, true) : current.depthWrite,
      lodGroup: typeof item.lodGroup === "string" && item.lodGroup ? item.lodGroup : (typeof current.lodGroup === "string" ? current.lodGroup : ""),
      lodLevel: Math.max(0, Math.floor(sceneNumber(item.lodLevel, sceneNumber(current.lodLevel, 0)))),
      lodMinDistance: Math.max(0, sceneNumber(item.lodMinDistance, sceneNumber(current.lodMinDistance, 0))),
      lodMaxDistance: Math.max(0, sceneNumber(item.lodMaxDistance, sceneNumber(current.lodMaxDistance, 0))),
      skin: item.skin && typeof item.skin === "object" ? item.skin : (current.skin && typeof current.skin === "object" ? current.skin : null),
      _transition: lifecycle.transition,
      _inState: lifecycle.inState,
      _outState: lifecycle.outState,
      _live: lifecycle.live,
    };
    normalized.static = sceneBool(
      Object.prototype.hasOwnProperty.call(item, "static") ? item.static : current.static,
      !sceneObjectAnimated(normalized),
    );
    return normalized;
  }

  function normalizeSceneLightKind(value) {
    const kind = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (kind) {
      case "ambient":
        return "ambient";
      case "directional":
      case "sun":
        return "directional";
      case "point":
        return "point";
      case "spot":
      case "spotlight":
        return "spot";
      case "hemisphere":
      case "hemi":
      case "hemispherelight":
        return "hemisphere";
      case "rect":
      case "area":
      case "rectarea":
      case "rect-area":
      case "rectarealight":
      case "rect-area-light":
        return "rect-area";
      case "probe":
      case "lightprobe":
      case "light-probe":
        return "light-probe";
      default:
        return "";
    }
  }

  function sceneDefaultLightIntensity(kind) {
    switch (normalizeSceneLightKind(kind)) {
      case "ambient":
        return 0.28;
      case "directional":
        return 1;
      case "point":
        return 1.1;
      case "rect-area":
        return 1.4;
      case "light-probe":
        return 0.25;
      default:
        return 1;
    }
  }

  function normalizeSceneLight(light, index, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const item = sceneIsPlainObject(light) ? light : {};
    const kind = normalizeSceneLightKind(item.kind || item.lightKind || current.kind);
    if (!kind) {
      return null;
    }
    const lifecycle = sceneNormalizeLifecycle(item, current);
    const normalized = {
      id: (typeof item.id === "string" && item.id) || current.id || ("scene-light-" + index),
      kind,
      color: typeof item.color === "string" && item.color ? item.color : (typeof current.color === "string" && current.color ? current.color : "#f3fbff"),
      groundColor: typeof item.groundColor === "string" && item.groundColor ? item.groundColor : (typeof current.groundColor === "string" ? current.groundColor : ""),
      intensity: sceneClampNumberOrCSSVar(item.intensity, sceneNumber(current.intensity, sceneDefaultLightIntensity(kind)), 0, 6),
      x: sceneNumber(item.x, sceneNumber(current.x, 0)),
      y: sceneNumber(item.y, sceneNumber(current.y, 0)),
      z: sceneNumber(item.z, sceneNumber(current.z, 0)),
      directionX: sceneNumber(item.directionX, sceneNumber(current.directionX, 0)),
      directionY: sceneNumber(item.directionY, sceneNumber(current.directionY, 0)),
      directionZ: sceneNumber(item.directionZ, sceneNumber(current.directionZ, 0)),
      angle: Math.max(0, Math.min(Math.PI, sceneNumber(item.angle, sceneNumber(current.angle, 0)))),
      penumbra: sceneClamp(sceneNumber(item.penumbra, sceneNumber(current.penumbra, 0)), 0, 1),
      range: Math.max(0, Math.min(256, sceneNumber(item.range, sceneNumber(current.range, (kind === "point" || kind === "spot" || kind === "rect-area") ? 6.5 : 0)))),
      decay: Math.max(0.1, Math.min(8, sceneNumber(item.decay, sceneNumber(current.decay, (kind === "point" || kind === "spot" || kind === "rect-area") ? 1.35 : 1)))),
      width: Math.max(0, sceneNumber(item.width, sceneNumber(current.width, kind === "rect-area" ? 1 : 0))),
      height: Math.max(0, sceneNumber(item.height, sceneNumber(current.height, kind === "rect-area" ? 1 : 0))),
      coefficients: Array.isArray(item.coefficients) ? item.coefficients.slice() : (Array.isArray(current.coefficients) ? current.coefficients.slice() : []),
      castShadow: sceneBool(Object.prototype.hasOwnProperty.call(item, "castShadow") ? item.castShadow : current.castShadow, false),
      shadowBias: sceneNumber(item.shadowBias, sceneNumber(current.shadowBias, 0)),
      shadowSize: Math.max(0, Math.floor(sceneNumber(item.shadowSize, sceneNumber(current.shadowSize, 0)))),
      shadowCascades: kind === "directional"
        ? Math.max(0, Math.min(4, Math.floor(sceneNumber(item.shadowCascades, sceneNumber(current.shadowCascades, 0)))))
        : 0,
      shadowSoftness: Math.max(0, sceneNumber(item.shadowSoftness, sceneNumber(current.shadowSoftness, 0))),
      _transition: lifecycle.transition,
      _inState: lifecycle.inState,
      _outState: lifecycle.outState,
      _live: lifecycle.live,
    };
    if (normalized.kind === "directional" && normalized.directionX === 0 && normalized.directionY === 0 && normalized.directionZ === 0) {
      normalized.directionX = 0.35;
      normalized.directionY = -1;
      normalized.directionZ = -0.4;
    }
    if ((normalized.kind === "spot" || normalized.kind === "rect-area") && normalized.directionX === 0 && normalized.directionY === 0 && normalized.directionZ === 0) {
      normalized.directionY = -1;
    }
    if (typeof hashLightContent === "function") {
      normalized._lightHash = hashLightContent(normalized);
    }
    return normalized;
  }

  function normalizeSceneLabel(label, index, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const item = sceneIsPlainObject(label) ? label : {};
    const lifecycle = sceneNormalizeLifecycle(item, current);
    return {
      id: item.id || current.id || ("scene-label-" + index),
      text: typeof item.text === "string" ? item.text : (typeof current.text === "string" ? current.text : ""),
      className: sceneLabelClassName(item) || sceneLabelClassName(current),
      x: sceneNumber(item.x, sceneNumber(current.x, 0)),
      y: sceneNumber(item.y, sceneNumber(current.y, 0)),
      z: sceneNumber(item.z, sceneNumber(current.z, 0)),
      priority: sceneNumber(item.priority, sceneNumber(current.priority, 0)),
      shiftX: sceneNumber(item.shiftX, sceneNumber(current.shiftX, 0)),
      shiftY: sceneNumber(item.shiftY, sceneNumber(current.shiftY, 0)),
      shiftZ: sceneNumber(item.shiftZ, sceneNumber(current.shiftZ, 0)),
      driftSpeed: sceneNumber(item.driftSpeed, sceneNumber(current.driftSpeed, 0)),
      driftPhase: sceneNumber(item.driftPhase, sceneNumber(current.driftPhase, 0)),
      maxWidth: Math.max(48, sceneNumber(item.maxWidth, sceneNumber(current.maxWidth, 180))),
      maxLines: Math.max(0, Math.floor(sceneNumber(item.maxLines, sceneNumber(current.maxLines, 0)))),
      overflow: normalizeTextLayoutOverflow(item.overflow || current.overflow),
      font: typeof item.font === "string" && item.font ? item.font : (typeof current.font === "string" && current.font ? current.font : '600 13px "IBM Plex Sans", "Segoe UI", sans-serif'),
      lineHeight: Math.max(12, sceneNumber(item.lineHeight, sceneNumber(current.lineHeight, 18))),
      color: typeof item.color === "string" && item.color ? item.color : (typeof current.color === "string" && current.color ? current.color : "#ecf7ff"),
      background: typeof item.background === "string" && item.background ? item.background : (typeof current.background === "string" && current.background ? current.background : "rgba(8, 21, 31, 0.82)"),
      borderColor: typeof item.borderColor === "string" && item.borderColor ? item.borderColor : (typeof current.borderColor === "string" && current.borderColor ? current.borderColor : "rgba(141, 225, 255, 0.24)"),
      offsetX: sceneNumber(item.offsetX, sceneNumber(current.offsetX, 0)),
      offsetY: sceneNumber(item.offsetY, sceneNumber(current.offsetY, -14)),
      anchorX: Math.max(0, Math.min(1, sceneNumber(item.anchorX, sceneNumber(current.anchorX, 0.5)))),
      anchorY: Math.max(0, Math.min(1, sceneNumber(item.anchorY, sceneNumber(current.anchorY, 1)))),
      collision: normalizeSceneLabelCollision(item.collision || current.collision),
      occlude: sceneBool(Object.prototype.hasOwnProperty.call(item, "occlude") ? item.occlude : current.occlude, false),
      whiteSpace: normalizeSceneLabelWhiteSpace(item.whiteSpace || current.whiteSpace),
      textAlign: normalizeSceneLabelAlign(item.textAlign || current.textAlign),
      _transition: lifecycle.transition,
      _inState: lifecycle.inState,
      _outState: lifecycle.outState,
      _live: lifecycle.live,
    };
  }

  function normalizeSceneSpriteFit(value) {
    const mode = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (mode) {
      case "cover":
        return "cover";
      case "stretch":
      case "fill":
        return "fill";
      default:
        return "contain";
    }
  }

  function normalizeSceneSprite(sprite, index, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const item = sceneIsPlainObject(sprite) ? sprite : {};
    const width = Math.max(0.05, sceneNumber(item.width, sceneNumber(current.width, 1.25)));
    const height = Math.max(0.05, sceneNumber(item.height, sceneNumber(current.height, width)));
    const scale = Math.max(0.05, sceneNumber(item.scale, sceneNumber(current.scale, 1)));
    const lifecycle = sceneNormalizeLifecycle(item, current);
    return {
      id: item.id || current.id || ("scene-sprite-" + index),
      src: typeof item.src === "string" ? item.src.trim() : (typeof current.src === "string" ? current.src : ""),
      className: sceneLabelClassName(item) || sceneLabelClassName(current),
      x: sceneNumber(item.x, sceneNumber(current.x, 0)),
      y: sceneNumber(item.y, sceneNumber(current.y, 0)),
      z: sceneNumber(item.z, sceneNumber(current.z, 0)),
      priority: sceneNumber(item.priority, sceneNumber(current.priority, 0)),
      shiftX: sceneNumber(item.shiftX, sceneNumber(current.shiftX, 0)),
      shiftY: sceneNumber(item.shiftY, sceneNumber(current.shiftY, 0)),
      shiftZ: sceneNumber(item.shiftZ, sceneNumber(current.shiftZ, 0)),
      driftSpeed: sceneNumber(item.driftSpeed, sceneNumber(current.driftSpeed, 0)),
      driftPhase: sceneNumber(item.driftPhase, sceneNumber(current.driftPhase, 0)),
      width: width,
      height: height,
      scale: scale,
      opacity: clamp01(sceneNumber(item.opacity, sceneNumber(current.opacity, 1))),
      offsetX: sceneNumber(item.offsetX, sceneNumber(current.offsetX, 0)),
      offsetY: sceneNumber(item.offsetY, sceneNumber(current.offsetY, 0)),
      anchorX: sceneClamp(sceneNumber(item.anchorX, sceneNumber(current.anchorX, 0.5)), 0, 1),
      anchorY: sceneClamp(sceneNumber(item.anchorY, sceneNumber(current.anchorY, 0.5)), 0, 1),
      occlude: sceneBool(Object.prototype.hasOwnProperty.call(item, "occlude") ? item.occlude : current.occlude, false),
      fit: normalizeSceneSpriteFit(item.fit || current.fit),
      _transition: lifecycle.transition,
      _inState: lifecycle.inState,
      _outState: lifecycle.outState,
      _live: lifecycle.live,
    };
  }

  function sceneHTMLMarkup(item, current) {
    for (const key of ["html", "markup", "content"]) {
      if (typeof item[key] === "string") {
        return item[key];
      }
    }
    for (const key of ["html", "markup", "content"]) {
      if (typeof current[key] === "string") {
        return current[key];
      }
    }
    return "";
  }

  function normalizeSceneHTMLPointerEvents(value, fallback) {
    const raw = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (raw) {
      case "auto":
      case "true":
      case "interactive":
        return "auto";
      case "none":
      case "false":
        return "none";
      default:
        return fallback || "none";
    }
  }

  function normalizeSceneHTML(entry, index, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const item = sceneIsPlainObject(entry) ? entry : {};
    const width = Math.max(0.05, sceneNumber(item.width, sceneNumber(current.width, 1.8)));
    const height = Math.max(0.05, sceneNumber(item.height, sceneNumber(current.height, 0.72)));
    const scale = Math.max(0.05, sceneNumber(item.scale, sceneNumber(current.scale, 1)));
    const lifecycle = sceneNormalizeLifecycle(item, current);
    return {
      id: item.id || current.id || ("scene-html-" + index),
      html: sceneHTMLMarkup(item, current),
      className: sceneLabelClassName(item) || sceneLabelClassName(current),
      x: sceneNumber(item.x, sceneNumber(current.x, 0)),
      y: sceneNumber(item.y, sceneNumber(current.y, 0)),
      z: sceneNumber(item.z, sceneNumber(current.z, 0)),
      priority: sceneNumber(item.priority, sceneNumber(current.priority, 0)),
      shiftX: sceneNumber(item.shiftX, sceneNumber(current.shiftX, 0)),
      shiftY: sceneNumber(item.shiftY, sceneNumber(current.shiftY, 0)),
      shiftZ: sceneNumber(item.shiftZ, sceneNumber(current.shiftZ, 0)),
      driftSpeed: sceneNumber(item.driftSpeed, sceneNumber(current.driftSpeed, 0)),
      driftPhase: sceneNumber(item.driftPhase, sceneNumber(current.driftPhase, 0)),
      width,
      height,
      scale,
      opacity: clamp01(sceneNumber(item.opacity, sceneNumber(current.opacity, 1))),
      offsetX: sceneNumber(item.offsetX, sceneNumber(current.offsetX, 0)),
      offsetY: sceneNumber(item.offsetY, sceneNumber(current.offsetY, 0)),
      anchorX: sceneClamp(sceneNumber(item.anchorX, sceneNumber(current.anchorX, 0.5)), 0, 1),
      anchorY: sceneClamp(sceneNumber(item.anchorY, sceneNumber(current.anchorY, 0.5)), 0, 1),
      occlude: sceneBool(Object.prototype.hasOwnProperty.call(item, "occlude") ? item.occlude : current.occlude, false),
      pointerEvents: normalizeSceneHTMLPointerEvents(item.pointerEvents, normalizeSceneHTMLPointerEvents(current.pointerEvents, "none")),
      _transition: lifecycle.transition,
      _inState: lifecycle.inState,
      _outState: lifecycle.outState,
      _live: lifecycle.live,
    };
  }

  function sceneLabelClassName(item) {
    if (!item || typeof item !== "object") {
      return "";
    }
    if (typeof item.className === "string" && item.className.trim()) {
      return item.className.trim();
    }
    if (typeof item.class === "string" && item.class.trim()) {
      return item.class.trim();
    }
    return "";
  }

  function normalizeSceneKind(value) {
    const kind = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (kind) {
      case "box":
      case "lines":
      case "plane":
      case "pyramid":
      case "sphere":
      case "gltf-mesh":
        return kind;
      default:
        return "cube";
    }
  }

  function sceneObjects(props) {
    return rawSceneObjects(props).map(function(object, index) {
      return normalizeSceneObject(object, index, null);
    });
  }

  function normalizeSceneModel(item, index) {
    const current = item && typeof item === "object" ? item : {};
    const scaleSource = current.scale && typeof current.scale === "object" ? current.scale : null;
    const hasStatic = Object.prototype.hasOwnProperty.call(current, "static");
    const hasPickable = Object.prototype.hasOwnProperty.call(current, "pickable");
    const override = {};
    const lifecycle = sceneNormalizeLifecycle(current, null);
    const materialKind = sceneObjectMaterialKindValue(current);
    if (materialKind) {
      override.materialKind = normalizeSceneMaterialKind(materialKind);
    }
    if (sceneObjectMaterialHasValue(current, "color")) {
      override.color = sceneObjectMaterialValue(current, "color");
    }
    if (sceneObjectMaterialHasValue(current, "texture")) {
      override.texture = sceneObjectMaterialValue(current, "texture");
    }
    if (sceneObjectMaterialHasValue(current, "opacity")) {
      override.opacity = sceneObjectMaterialValue(current, "opacity");
    }
    if (sceneObjectMaterialHasValue(current, "emissive")) {
      override.emissive = sceneObjectMaterialValue(current, "emissive");
    }
    if (sceneObjectMaterialHasValue(current, "roughness")) {
      override.roughness = sceneObjectMaterialValue(current, "roughness");
    }
    if (sceneObjectMaterialHasValue(current, "metalness")) {
      override.metalness = sceneObjectMaterialValue(current, "metalness");
    }
    for (const key of ["clearcoat", "sheen", "transmission", "iridescence", "anisotropy"]) {
      if (sceneObjectMaterialHasValue(current, key)) {
        override[key] = sceneObjectMaterialValue(current, key);
      }
    }
    if (sceneObjectBlendModeHasValue(current)) {
      override.blendMode = sceneObjectBlendModeValue(current);
    }
    if (sceneObjectMaterialHasValue(current, "renderPass")) {
      override.renderPass = sceneObjectMaterialValue(current, "renderPass");
    }
    if (sceneObjectMaterialHasValue(current, "wireframe")) {
      override.wireframe = sceneObjectMaterialValue(current, "wireframe");
    }
    return {
      id: typeof current.id === "string" && current.id.trim() ? current.id.trim() : ("scene-model-" + index),
      src: typeof current.src === "string" && current.src.trim() ? current.src.trim() : "",
      x: sceneNumber(current.x, 0),
      y: sceneNumber(current.y, 0),
      z: sceneNumber(current.z, 0),
      rotationX: sceneNumber(current.rotationX, 0),
      rotationY: sceneNumber(current.rotationY, 0),
      rotationZ: sceneNumber(current.rotationZ, 0),
      scaleX: sceneNumber(current.scaleX, sceneNumber(scaleSource && scaleSource.x, sceneNumber(current.scale, 1))),
      scaleY: sceneNumber(current.scaleY, sceneNumber(scaleSource && scaleSource.y, sceneNumber(current.scale, 1))),
      scaleZ: sceneNumber(current.scaleZ, sceneNumber(scaleSource && scaleSource.z, sceneNumber(current.scale, 1))),
      animation: typeof current.animation === "string" && current.animation.trim() ? current.animation.trim() : "",
      loop: Object.prototype.hasOwnProperty.call(current, "loop") ? sceneBool(current.loop, true) : true,
      pickable: hasPickable ? sceneBool(current.pickable, false) : undefined,
      static: hasStatic ? sceneBool(current.static, false) : null,
      lodGroup: typeof current.lodGroup === "string" && current.lodGroup ? current.lodGroup : "",
      lodLevel: Math.max(0, Math.floor(sceneNumber(current.lodLevel, 0))),
      lodMinDistance: Math.max(0, sceneNumber(current.lodMinDistance, 0)),
      lodMaxDistance: Math.max(0, sceneNumber(current.lodMaxDistance, 0)),
      materialOverride: Object.keys(override).length > 0 ? override : null,
      _transition: lifecycle.transition,
      _inState: lifecycle.inState,
      _outState: lifecycle.outState,
      _live: lifecycle.live,
    };
  }

  function sceneModels(props) {
    return rawSceneModels(props)
      .map(function(model, index) {
        return normalizeSceneModel(model, index);
      })
      .filter(function(model) {
        return Boolean(model && model.src);
      });
  }

  function sceneLights(props) {
    return rawSceneLights(props)
      .map(function(light, index) {
        return normalizeSceneLight(light, index, null);
      })
      .filter(Boolean);
  }

  function normalizeSceneLabelWhiteSpace(value) {
    const mode = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (mode) {
      case "pre-wrap":
        return "pre-wrap";
      case "pre":
        return "pre";
      default:
        return "normal";
    }
  }

  function normalizeSceneLabelAlign(value) {
    const align = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (align) {
      case "left":
      case "start":
        return "left";
      case "right":
      case "end":
        return "right";
      default:
        return "center";
    }
  }

  function normalizeSceneLabelCollision(value) {
    const mode = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (mode) {
      case "allow":
      case "none":
      case "overlap":
        return "allow";
      default:
        return "avoid";
    }
  }

  function sceneLabels(props) {
    const raw = rawSceneLabels(props);
    return raw
      .map(function(label, index) {
        return normalizeSceneLabel(label, index, null);
      })
      .filter(function(label) {
        return label.text.trim() !== "";
      });
  }

  function sceneSprites(props) {
    return rawSceneSprites(props)
      .map(function(sprite, index) {
        return normalizeSceneSprite(sprite, index, null);
      })
      .filter(function(sprite) {
        return sprite.src !== "";
      });
  }

  function sceneHTML(props) {
    return rawSceneHTML(props)
      .map(function(entry, index) {
        return normalizeSceneHTML(entry, index, null);
      })
      .filter(function(entry) {
        return entry.html.trim() !== "";
      });
  }

  function normalizeScenePointStyle(value, fallback) {
    const current = typeof fallback === "string" && fallback ? fallback : "square";
    const raw = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (raw) {
      case "focus":
      case "focused":
      case "focus-star":
        return "focus";
      case "glow":
      case "gas":
      case "cloud":
      case "nebula":
        return "glow";
      case "square":
      case "pixel":
      case "hard":
      case "block":
      case "blocky":
        return "square";
      default:
        return current;
    }
  }

  function scenePointStyleCode(value) {
    const style = normalizeScenePointStyle(value, "square");
    if (style === "focus") return 1;
    if (style === "glow") return 2;
    return 0;
  }

  function sceneIsNumericTypedArray(value) {
    return value &&
      typeof value === "object" &&
      typeof value.length === "number" &&
      typeof ArrayBuffer !== "undefined" &&
      typeof ArrayBuffer.isView === "function" &&
      ArrayBuffer.isView(value) &&
      Object.prototype.toString.call(value) !== "[object DataView]";
  }

  function scenePointDataBuffer(value, cloneArrays) {
    if (Array.isArray(value)) {
      return cloneArrays ? value.slice() : value;
    }
    if (sceneIsNumericTypedArray(value)) {
      return value;
    }
    return null;
  }

  function scenePointDataLength(value) {
    return value && typeof value.length === "number" ? value.length : 0;
  }

  function sceneFloat32PointData(value) {
    if (!sceneIsNumericTypedArray(value)) {
      return null;
    }
    return value instanceof Float32Array ? value : new Float32Array(value);
  }

  function sceneRGBAFloat32PointColors(value, count) {
    if (!sceneIsNumericTypedArray(value)) {
      return null;
    }
    if (value.length >= count * 4) {
      return value instanceof Float32Array ? value : new Float32Array(value);
    }
    if (value.length < count * 3) {
      return null;
    }
    const colors = new Float32Array(count * 4);
    for (let i = 0; i < count; i += 1) {
      colors[i * 4] = value[i * 3];
      colors[i * 4 + 1] = value[i * 3 + 1];
      colors[i * 4 + 2] = value[i * 3 + 2];
      colors[i * 4 + 3] = 1;
    }
    return colors;
  }

  function normalizeScenePointsEntry(entry, index, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const item = sceneIsPlainObject(entry) ? entry : {};
    const lifecycle = sceneNormalizeLifecycle(item, current);
    const itemPositions = scenePointDataBuffer(item.positions, true);
    const currentPositions = scenePointDataBuffer(current.positions, false);
    const itemSizes = scenePointDataBuffer(item.sizes, true);
    const currentSizes = scenePointDataBuffer(current.sizes, false);
    const itemColors = scenePointDataBuffer(item.colors, true);
    const currentColors = scenePointDataBuffer(current.colors, false);
    const positions = itemPositions !== null ? itemPositions : (currentPositions !== null ? currentPositions : []);
    const sizes = itemSizes !== null ? itemSizes : (currentSizes !== null ? currentSizes : []);
    const colors = itemColors !== null ? itemColors : (currentColors !== null ? currentColors : []);
    const normalized = {
      id: item.id || current.id || ("scene-points-" + index),
      count: Math.max(0, Math.floor(sceneNumber(item.count, sceneNumber(current.count, scenePointDataLength(positions) >= 3 ? Math.floor(scenePointDataLength(positions) / 3) : 0)))),
      positions,
      sizes,
      colors,
      material: typeof item.material === "string" && item.material ? item.material : (typeof current.material === "string" ? current.material : ""),
      color: typeof item.color === "string" && item.color ? item.color : (typeof current.color === "string" ? current.color : "#ffffff"),
      style: normalizeScenePointStyle(item.style, current.style),
      size: sceneClampNumberOrCSSVar(item.size, sceneNumber(current.size, 1), 0, Number.POSITIVE_INFINITY),
      opacity: sceneClampNumberOrCSSVar(item.opacity, sceneNumber(current.opacity, 1), 0, 1),
      blendMode: normalizeSceneMaterialBlendMode(item.blendMode || current.blendMode, "flat", sceneNumber(item.opacity, sceneNumber(current.opacity, 1))),
      depthWrite: Object.prototype.hasOwnProperty.call(item, "depthWrite") ? sceneBool(item.depthWrite, true) : current.depthWrite,
      attenuation: sceneBool(Object.prototype.hasOwnProperty.call(item, "attenuation") ? item.attenuation : current.attenuation, false),
      x: sceneNumber(item.x, sceneNumber(current.x, 0)),
      y: sceneNumber(item.y, sceneNumber(current.y, 0)),
      z: sceneNumber(item.z, sceneNumber(current.z, 0)),
      rotationX: sceneNumber(item.rotationX, sceneNumber(current.rotationX, 0)),
      rotationY: sceneNumber(item.rotationY, sceneNumber(current.rotationY, 0)),
      rotationZ: sceneNumber(item.rotationZ, sceneNumber(current.rotationZ, 0)),
      spinX: sceneNumber(item.spinX, sceneNumber(current.spinX, 0)),
      spinY: sceneNumber(item.spinY, sceneNumber(current.spinY, 0)),
      spinZ: sceneNumber(item.spinZ, sceneNumber(current.spinZ, 0)),
      _transition: lifecycle.transition,
      _inState: lifecycle.inState,
      _outState: lifecycle.outState,
      _live: lifecycle.live,
    };
    if (positions === current.positions && current._cachedPos) {
      normalized._cachedPos = current._cachedPos;
    }
    if (sizes === current.sizes && current._cachedSizes) {
      normalized._cachedSizes = current._cachedSizes;
    }
    if (colors === current.colors && current._cachedColors) {
      normalized._cachedColors = current._cachedColors;
    }
    if (!normalized._cachedPos && sceneIsNumericTypedArray(positions) && scenePointDataLength(positions) >= normalized.count * 3) {
      normalized._cachedPos = sceneFloat32PointData(positions);
    }
    if (!normalized._cachedSizes && sceneIsNumericTypedArray(sizes) && scenePointDataLength(sizes) >= normalized.count) {
      normalized._cachedSizes = sceneFloat32PointData(sizes);
    }
    if (!normalized._cachedColors && sceneIsNumericTypedArray(colors)) {
      normalized._cachedColors = sceneRGBAFloat32PointColors(colors, normalized.count);
    }
    if (Array.isArray(item.previewPositions)) {
      normalized.previewPositions = item.previewPositions.slice();
    } else if (Array.isArray(current.previewPositions)) {
      normalized.previewPositions = current.previewPositions;
    }
    if (Array.isArray(item.previewSizes)) {
      normalized.previewSizes = item.previewSizes.slice();
    } else if (Array.isArray(current.previewSizes)) {
      normalized.previewSizes = current.previewSizes;
    }
    return normalized;
  }

  function scenePoints(props) {
    return rawScenePoints(props).map(function(entry, index) {
      return normalizeScenePointsEntry(entry, index, null);
    });
  }

  function normalizeSceneInstancedMeshEntry(entry, index, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const item = sceneIsPlainObject(entry) ? entry : {};
    const lifecycle = sceneNormalizeLifecycle(item, current);
    const transforms = Array.isArray(item.transforms) ? item.transforms.slice() : (Array.isArray(current.transforms) ? current.transforms : []);
    const colors = Object.prototype.hasOwnProperty.call(item, "colors")
      ? sceneCloneData(item.colors)
      : (Object.prototype.hasOwnProperty.call(current, "colors") ? current.colors : []);
    const attributes = Object.prototype.hasOwnProperty.call(item, "attributes")
      ? sceneCloneData(item.attributes)
      : (Object.prototype.hasOwnProperty.call(current, "attributes") ? current.attributes : undefined);
    const normalized = {
      id: item.id || current.id || ("scene-instanced-" + index),
      count: Math.max(0, Math.floor(sceneNumber(item.count, sceneNumber(current.count, 0)))),
      kind: normalizeSceneKind(item.kind || current.kind),
      width: Math.max(0.0001, sceneNumber(item.width, sceneNumber(current.width, sceneNumber(current.size, 1.2)))),
      height: Math.max(0.0001, sceneNumber(item.height, sceneNumber(current.height, sceneNumber(current.size, 1.2)))),
      depth: Math.max(0.0001, sceneNumber(item.depth, sceneNumber(current.depth, sceneNumber(current.size, 1.2)))),
      radius: Math.max(0.0001, sceneNumber(item.radius, sceneNumber(current.radius, sceneNumber(current.size, 0.6)))),
      segments: sceneSegmentResolution(Object.prototype.hasOwnProperty.call(item, "segments") ? item.segments : current.segments),
      materialKind: normalizeSceneMaterialKind(item.materialKind || current.materialKind),
      color: typeof item.color === "string" && item.color ? item.color : (typeof current.color === "string" ? current.color : "#8de1ff"),
      roughness: sceneNumberOrCSSVar(item.roughness, sceneNumber(current.roughness, 0)),
      metalness: sceneNumberOrCSSVar(item.metalness, sceneNumber(current.metalness, 0)),
      transforms,
      colors,
      attributes,
      castShadow: sceneBool(Object.prototype.hasOwnProperty.call(item, "castShadow") ? item.castShadow : current.castShadow, false),
      receiveShadow: sceneBool(Object.prototype.hasOwnProperty.call(item, "receiveShadow") ? item.receiveShadow : current.receiveShadow, false),
      _transition: lifecycle.transition,
      _inState: lifecycle.inState,
      _outState: lifecycle.outState,
      _live: lifecycle.live,
    };
    if (transforms === current.transforms && current._cachedTransforms) {
      normalized._cachedTransforms = current._cachedTransforms;
    }
    if (colors === current.colors && current._cachedInstanceColors) {
      normalized._cachedInstanceColors = current._cachedInstanceColors;
    }
    return normalized;
  }

  function sceneInstancedMeshes(props) {
    return rawSceneInstancedMeshes(props).map(function(entry, index) {
      return normalizeSceneInstancedMeshEntry(entry, index, null);
    });
  }

  function normalizeSceneComputeEmitter(raw, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const item = sceneIsPlainObject(raw) ? raw : {};
    return {
      kind: typeof item.kind === "string" && item.kind ? item.kind : (typeof current.kind === "string" ? current.kind : "point"),
      x: sceneNumber(item.x, sceneNumber(current.x, 0)),
      y: sceneNumber(item.y, sceneNumber(current.y, 0)),
      z: sceneNumber(item.z, sceneNumber(current.z, 0)),
      rotationX: sceneNumber(item.rotationX, sceneNumber(current.rotationX, 0)),
      rotationY: sceneNumber(item.rotationY, sceneNumber(current.rotationY, 0)),
      rotationZ: sceneNumber(item.rotationZ, sceneNumber(current.rotationZ, 0)),
      spinX: sceneNumber(item.spinX, sceneNumber(current.spinX, 0)),
      spinY: sceneNumber(item.spinY, sceneNumber(current.spinY, 0)),
      spinZ: sceneNumber(item.spinZ, sceneNumber(current.spinZ, 0)),
      radius: Math.max(0, sceneNumber(item.radius, sceneNumber(current.radius, 0))),
      rate: Math.max(0, sceneNumber(item.rate, sceneNumber(current.rate, 0))),
      lifetime: Math.max(0.01, sceneNumber(item.lifetime, sceneNumber(current.lifetime, 1))),
      arms: Math.max(0, Math.floor(sceneNumber(item.arms, sceneNumber(current.arms, 0)))),
      wind: sceneNumberOrCSSVar(item.wind, sceneNumber(current.wind, 0)),
      scatter: Math.max(0, sceneNumber(item.scatter, sceneNumber(current.scatter, 0))),
    };
  }

  function normalizeSceneComputeForce(raw, index, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const item = sceneIsPlainObject(raw) ? raw : {};
    return {
      kind: typeof item.kind === "string" && item.kind ? item.kind : (typeof current.kind === "string" ? current.kind : ""),
      strength: sceneNumber(item.strength, sceneNumber(current.strength, 0)),
      x: sceneNumber(item.x, sceneNumber(current.x, 0)),
      y: sceneNumber(item.y, sceneNumber(current.y, 0)),
      z: sceneNumber(item.z, sceneNumber(current.z, 0)),
      frequency: sceneNumber(item.frequency, sceneNumber(current.frequency, 0)),
      id: current.id || ("scene-force-" + index),
    };
  }

  function normalizeSceneComputeMaterial(raw, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const item = sceneIsPlainObject(raw) ? raw : {};
    return {
      color: typeof item.color === "string" && item.color ? item.color : (typeof current.color === "string" ? current.color : "#ffffff"),
      colorEnd: typeof item.colorEnd === "string" && item.colorEnd ? item.colorEnd : (typeof current.colorEnd === "string" ? current.colorEnd : ""),
      style: normalizeScenePointStyle(item.style, current.style),
      size: sceneClampNumberOrCSSVar(item.size, sceneNumber(current.size, 1), 0, Number.POSITIVE_INFINITY),
      sizeEnd: sceneClampNumberOrCSSVar(item.sizeEnd, sceneNumber(current.sizeEnd, sceneNumber(current.size, 1)), 0, Number.POSITIVE_INFINITY),
      opacity: sceneClampNumberOrCSSVar(item.opacity, sceneNumber(current.opacity, 1), 0, 1),
      opacityEnd: sceneClampNumberOrCSSVar(item.opacityEnd, sceneNumber(current.opacityEnd, sceneNumber(current.opacity, 1)), 0, 1),
      blendMode: normalizeSceneMaterialBlendMode(item.blendMode || current.blendMode, "flat", sceneNumber(item.opacity, sceneNumber(current.opacity, 1))),
      attenuation: sceneBool(Object.prototype.hasOwnProperty.call(item, "attenuation") ? item.attenuation : current.attenuation, false),
    };
  }

  function normalizeSceneComputeParticlesEntry(entry, index, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const item = sceneIsPlainObject(entry) ? entry : {};
    const lifecycle = sceneNormalizeLifecycle(item, current);
    const emitterSource = Object.prototype.hasOwnProperty.call(item, "emitter") ? item.emitter : current.emitter;
    const materialSource = Object.prototype.hasOwnProperty.call(item, "material") ? item.material : current.material;
    const forcesSource = Array.isArray(item.forces) ? item.forces : (Array.isArray(current.forces) ? current.forces : []);
    return {
      id: item.id || current.id || ("scene-particles-" + index),
      count: Math.max(0, Math.floor(sceneNumber(item.count, sceneNumber(current.count, 0)))),
      emitter: normalizeSceneComputeEmitter(emitterSource, current.emitter),
      forces: forcesSource.map(function(force, forceIndex) {
        return normalizeSceneComputeForce(force, forceIndex, Array.isArray(current.forces) ? current.forces[forceIndex] : null);
      }),
      material: normalizeSceneComputeMaterial(materialSource, current.material),
      bounds: Math.max(0, sceneNumber(item.bounds, sceneNumber(current.bounds, 0))),
      _transition: lifecycle.transition,
      _inState: lifecycle.inState,
      _outState: lifecycle.outState,
      _live: lifecycle.live,
    };
  }

  function sceneComputeParticles(props) {
    return rawSceneComputeParticles(props).map(function(entry, index) {
      return normalizeSceneComputeParticlesEntry(entry, index, null);
    });
  }

  function normalizeSceneMaterialRecord(raw, index, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const item = sceneIsPlainObject(raw) ? raw : {};
    const kind = normalizeSceneMaterialKind(item.kind || item.materialKind || current.kind);
    const colorSpecified = typeof item.color === "string" && item.color !== "";
    const opacitySpecified = Object.prototype.hasOwnProperty.call(item, "opacity");
    const blendModeSpecified = Object.prototype.hasOwnProperty.call(item, "blendMode") && String(item.blendMode || "").trim() !== "";
    const depthWriteSpecified = Object.prototype.hasOwnProperty.call(item, "depthWrite");
    const opacity = sceneClampNumberOrCSSVar(item.opacity, sceneNumber(current.opacity, sceneDefaultMaterialOpacity(kind)), 0, 1);
    const numericOpacity = sceneNumber(opacity, sceneNumber(current.opacity, sceneDefaultMaterialOpacity(kind)));
    const blendMode = normalizeSceneMaterialBlendMode(item.blendMode || current.blendMode, kind, numericOpacity);
    const out = {
      id: typeof item.id === "string" && item.id ? item.id : (typeof current.id === "string" ? current.id : ""),
      name: typeof item.name === "string" && item.name ? item.name : (typeof current.name === "string" ? current.name : ("scene-material-" + index)),
      kind,
      color: typeof item.color === "string" && item.color ? item.color : (typeof current.color === "string" ? current.color : "#8de1ff"),
      texture: typeof item.texture === "string" ? item.texture.trim() : (typeof current.texture === "string" ? current.texture : ""),
      opacity,
      emissive: sceneClampNumberOrCSSVar(item.emissive, sceneNumber(current.emissive, sceneDefaultMaterialEmissive(kind)), 0, 1),
      roughness: sceneNumberOrCSSVar(item.roughness, sceneNumber(current.roughness, 0.5)),
      metalness: sceneNumberOrCSSVar(item.metalness, sceneNumber(current.metalness, 0)),
      clearcoat: sceneClampNumberOrCSSVar(item.clearcoat, sceneNumber(current.clearcoat, 0), 0, 1),
      sheen: sceneClampNumberOrCSSVar(item.sheen, sceneNumber(current.sheen, 0), 0, 1),
      transmission: sceneClampNumberOrCSSVar(item.transmission, sceneNumber(current.transmission, 0), 0, 1),
      iridescence: sceneClampNumberOrCSSVar(item.iridescence, sceneNumber(current.iridescence, 0), 0, 1),
      anisotropy: sceneClampNumberOrCSSVar(item.anisotropy, sceneNumber(current.anisotropy, 0), -1, 1),
      normalMap: typeof item.normalMap === "string" ? item.normalMap.trim() : (typeof current.normalMap === "string" ? current.normalMap : ""),
      roughnessMap: typeof item.roughnessMap === "string" ? item.roughnessMap.trim() : (typeof current.roughnessMap === "string" ? current.roughnessMap : ""),
      metalnessMap: typeof item.metalnessMap === "string" ? item.metalnessMap.trim() : (typeof current.metalnessMap === "string" ? current.metalnessMap : ""),
      emissiveMap: typeof item.emissiveMap === "string" ? item.emissiveMap.trim() : (typeof current.emissiveMap === "string" ? current.emissiveMap : ""),
      blendMode,
      renderPass: normalizeSceneMaterialRenderPass(item.renderPass || current.renderPass, blendMode, numericOpacity, kind),
      wireframe: sceneBool(Object.prototype.hasOwnProperty.call(item, "wireframe") ? item.wireframe : current.wireframe, false),
      lineDash: sceneBool(Object.prototype.hasOwnProperty.call(item, "lineDash") ? item.lineDash : current.lineDash, false),
      dashSize: sceneNumber(item.dashSize, sceneNumber(current.dashSize, 0)),
      gapSize: sceneNumber(item.gapSize, sceneNumber(current.gapSize, 0)),
      customVertex: typeof item.customVertex === "string" ? item.customVertex : (typeof current.customVertex === "string" ? current.customVertex : ""),
      customFragment: typeof item.customFragment === "string" ? item.customFragment : (typeof current.customFragment === "string" ? current.customFragment : ""),
      customVertexWGSL: typeof item.customVertexWGSL === "string" ? item.customVertexWGSL : (typeof current.customVertexWGSL === "string" ? current.customVertexWGSL : ""),
      customFragmentWGSL: typeof item.customFragmentWGSL === "string" ? item.customFragmentWGSL : (typeof current.customFragmentWGSL === "string" ? current.customFragmentWGSL : ""),
      customUniforms: sceneIsPlainObject(item.customUniforms) ? Object.assign({}, item.customUniforms) : (sceneIsPlainObject(current.customUniforms) ? Object.assign({}, current.customUniforms) : null),
      depthWrite: Object.prototype.hasOwnProperty.call(item, "depthWrite") ? sceneBool(item.depthWrite, true) : current.depthWrite,
      _colorSpecified: colorSpecified || current._colorSpecified === true,
      _opacitySpecified: opacitySpecified || current._opacitySpecified === true,
      _blendModeSpecified: blendModeSpecified || current._blendModeSpecified === true,
      _depthWriteSpecified: depthWriteSpecified || current._depthWriteSpecified === true,
    };
    out.key = sceneMaterialProfileKey(out);
    out.shaderData = sceneMaterialShaderData(out);
    return out;
  }

  function sceneMaterials(props) {
    return rawSceneMaterials(props).map(function(entry, index) {
      return normalizeSceneMaterialRecord(entry, index, null);
    });
  }

  function normalizeScenePostEffect(raw, index, fallback) {
    const current = sceneIsPlainObject(fallback) ? fallback : {};
    const item = sceneIsPlainObject(raw) ? raw : {};
    const kind = typeof item.kind === "string" && item.kind ? item.kind.trim().toLowerCase() : (typeof current.kind === "string" ? current.kind : "");
    if (!kind) {
      return null;
    }
    return {
      kind,
      threshold: sceneNumberOrCSSVar(item.threshold, sceneNumber(current.threshold, 0)),
      intensity: sceneNumberOrCSSVar(item.intensity, sceneNumber(current.intensity, 0)),
      radius: sceneNumberOrCSSVar(item.radius, sceneNumber(current.radius, 0)),
      scale: sceneNumberOrCSSVar(item.scale, sceneNumber(current.scale, 0)),
      bias: sceneNumberOrCSSVar(item.bias, sceneNumber(current.bias, 0)),
      saturation: sceneNumberOrCSSVar(item.saturation, sceneNumber(current.saturation, 0)),
      contrast: sceneNumberOrCSSVar(item.contrast, sceneNumber(current.contrast, 0)),
      exposure: sceneNumberOrCSSVar(item.exposure, sceneNumber(current.exposure, 0)),
      focusDistance: sceneNumberOrCSSVar(item.focusDistance, sceneNumber(current.focusDistance, 0)),
      aperture: sceneNumberOrCSSVar(item.aperture, sceneNumber(current.aperture, 0)),
      maxBlur: sceneNumberOrCSSVar(item.maxBlur, sceneNumber(current.maxBlur, 0)),
      mode: typeof item.mode === "string" ? item.mode : (typeof current.mode === "string" ? current.mode : ""),
      id: typeof item.id === "string" && item.id ? item.id : (typeof current.id === "string" ? current.id : ("scene-postfx-" + index)),
    };
  }

  function scenePostEffects(props) {
    const out = [];
    const raw = rawScenePostEffects(props);
    for (let index = 0; index < raw.length; index += 1) {
      const effect = normalizeScenePostEffect(raw[index], index, null);
      if (effect) {
        out.push(effect);
      }
    }
    return out;
  }

  function sceneCamera(props) {
    const raw = props && props.camera && typeof props.camera === "object" ? props.camera : {};
    return normalizeSceneCamera(raw, {
      kind: "perspective",
      x: 0,
      y: 0,
      z: 6,
      fov: 75,
      near: 0.05,
      far: 128,
    });
  }

  function normalizeSceneCameraKind(value, fallback) {
    const kind = typeof value === "string" ? value.trim().toLowerCase() : "";
    if (kind === "orthographic" || kind === "ortho") {
      return "orthographic";
    }
    if (kind === "perspective" || kind === "persp") {
      return "perspective";
    }
    return fallback === "orthographic" ? "orthographic" : "perspective";
  }

  function sceneCanvasAlpha(props) {
    if (props && typeof props.canvasAlpha === "boolean") {
      return props.canvasAlpha;
    }
    const background = props && typeof props.background === "string"
      ? props.background.trim().toLowerCase()
      : "";
    return background === "transparent" || background === "rgba(0,0,0,0)" || background === "rgba(0, 0, 0, 0)";
  }

  function normalizeSceneCamera(raw, fallback) {
    const base = fallback || {};
    const kind = normalizeSceneCameraKind(raw.kind, base.kind);
    return {
      kind,
      x: sceneNumber(raw.x, sceneNumber(base.x, 0)),
      y: sceneNumber(raw.y, sceneNumber(base.y, 0)),
      z: sceneNumber(raw.z, sceneNumber(base.z, 6)),
      rotationX: sceneNumber(raw.rotationX, sceneNumber(base.rotationX, 0)),
      rotationY: sceneNumber(raw.rotationY, sceneNumber(base.rotationY, 0)),
      rotationZ: sceneNumber(raw.rotationZ, sceneNumber(base.rotationZ, 0)),
      fov: sceneNumber(raw.fov, sceneNumber(base.fov, 75)),
      left: sceneNumber(raw.left, sceneNumber(base.left, 0)),
      right: sceneNumber(raw.right, sceneNumber(base.right, 0)),
      top: sceneNumber(raw.top, sceneNumber(base.top, 0)),
      bottom: sceneNumber(raw.bottom, sceneNumber(base.bottom, 0)),
      zoom: sceneNumber(raw.zoom, sceneNumber(base.zoom, 1)),
      near: sceneNumber(raw.near, sceneNumber(base.near, 0.05)),
      far: sceneNumber(raw.far, sceneNumber(base.far, 128)),
    };
  }

  function normalizeSceneEnvironment(raw, fallback) {
    const base = sceneIsPlainObject(fallback) ? fallback : {};
    const source = sceneIsPlainObject(raw) ? raw : {};
    const lifecycle = sceneNormalizeLifecycle(source, base);
    const environment = {
      ambientColor: typeof source.ambientColor === "string" && source.ambientColor ? source.ambientColor : (typeof base.ambientColor === "string" ? base.ambientColor : ""),
      ambientIntensity: sceneClampNumberOrCSSVar(source.ambientIntensity, sceneNumber(base.ambientIntensity, 0), 0, 4),
      skyColor: typeof source.skyColor === "string" && source.skyColor ? source.skyColor : (typeof base.skyColor === "string" ? base.skyColor : ""),
      skyIntensity: sceneClampNumberOrCSSVar(source.skyIntensity, sceneNumber(base.skyIntensity, 0), 0, 4),
      groundColor: typeof source.groundColor === "string" && source.groundColor ? source.groundColor : (typeof base.groundColor === "string" ? base.groundColor : ""),
      groundIntensity: sceneClampNumberOrCSSVar(source.groundIntensity, sceneNumber(base.groundIntensity, 0), 0, 4),
      envMap: typeof source.envMap === "string" && source.envMap ? source.envMap : (typeof base.envMap === "string" ? base.envMap : ""),
      envIntensity: sceneClampNumberOrCSSVar(Object.prototype.hasOwnProperty.call(source, "envIntensity") ? source.envIntensity : undefined, sceneNumber(base.envIntensity, 1) || 1, 0, 8),
      envRotation: sceneClampNumberOrCSSVar(source.envRotation, sceneNumber(base.envRotation, 0), Number.NEGATIVE_INFINITY, Number.POSITIVE_INFINITY),
      exposure: sceneClampNumberOrCSSVar(Object.prototype.hasOwnProperty.call(source, "exposure") ? source.exposure : undefined, sceneNumber(base.exposure, 1) || 1, 0.05, 4),
      toneMapping: typeof source.toneMapping === "string" && source.toneMapping ? source.toneMapping : (typeof base.toneMapping === "string" ? base.toneMapping : ""),
      fogColor: typeof source.fogColor === "string" && source.fogColor ? source.fogColor : (typeof base.fogColor === "string" ? base.fogColor : ""),
      fogDensity: sceneClampNumberOrCSSVar(source.fogDensity, sceneNumber(base.fogDensity, 0), 0, Number.POSITIVE_INFINITY),
      _transition: lifecycle.transition,
      _inState: lifecycle.inState,
      _outState: lifecycle.outState,
      _live: lifecycle.live,
      specified: false,
    };
    environment.specified = Boolean(raw || base.specified) && (
      environment.ambientColor ||
      environment.ambientIntensity !== 0 ||
      environment.skyColor ||
      environment.skyIntensity !== 0 ||
      environment.groundColor ||
      environment.groundIntensity !== 0 ||
      environment.envMap ||
      environment.envIntensity !== 1 ||
      environment.envRotation !== 0 ||
      environment.fogColor ||
      environment.fogDensity !== 0 ||
      environment.toneMapping ||
      Object.prototype.hasOwnProperty.call(source, "exposure")
    );
    if (typeof hashEnvironmentContent === "function") {
      environment._envHash = hashEnvironmentContent(environment);
    }
    return environment;
  }

  function sceneResolveLightingEnvironment(environment, hasLights) {
    const base = environment && typeof environment === "object" && Object.prototype.hasOwnProperty.call(environment, "specified")
      ? {
        ambientColor: typeof environment.ambientColor === "string" ? environment.ambientColor : "",
        ambientIntensity: sceneClampNumberOrCSSVar(environment.ambientIntensity, 0, 0, 4),
        skyColor: typeof environment.skyColor === "string" ? environment.skyColor : "",
        skyIntensity: sceneClampNumberOrCSSVar(environment.skyIntensity, 0, 0, 4),
        groundColor: typeof environment.groundColor === "string" ? environment.groundColor : "",
        groundIntensity: sceneClampNumberOrCSSVar(environment.groundIntensity, 0, 0, 4),
        envMap: typeof environment.envMap === "string" ? environment.envMap : "",
        envIntensity: sceneClampNumberOrCSSVar(environment.envIntensity, 1, 0, 8),
        envRotation: sceneClampNumberOrCSSVar(environment.envRotation, 0, Number.NEGATIVE_INFINITY, Number.POSITIVE_INFINITY),
        exposure: sceneClampNumberOrCSSVar(environment.exposure, 1, 0.05, 4),
        toneMapping: typeof environment.toneMapping === "string" ? environment.toneMapping : "",
        fogColor: typeof environment.fogColor === "string" ? environment.fogColor : "",
        fogDensity: sceneClampNumberOrCSSVar(environment.fogDensity, 0, 0, Number.POSITIVE_INFINITY),
        specified: Boolean(environment.specified),
      }
      : normalizeSceneEnvironment(environment, null);
    if (typeof base._envHash !== "number" && typeof hashEnvironmentContent === "function") {
      base._envHash = hashEnvironmentContent(base);
    }
    if (base.specified || !hasLights) {
      return base;
    }
    return normalizeSceneEnvironment({
      ambientColor: "#f5fbff",
      ambientIntensity: 0.18,
      skyColor: "#d5ebff",
      skyIntensity: 0.12,
      groundColor: "#102030",
      groundIntensity: 0.04,
      exposure: base.exposure,
    }, base);
  }

  function createSceneState(props) {
    if (typeof sceneDecompressProps === "function") {
      sceneDecompressProps(props);
    }
    const scene = sceneProps(props);
    const postEffects = scenePostEffects(props);
    const postFXMaxPixels = Math.max(0, Math.floor(sceneNumber(
      scene && scene.postFXMaxPixels,
      sceneNumber(props && props.postFXMaxPixels, 0),
    )));
    const deferPostFX = sceneBool(props && props.deferPostFX, sceneBool(props && props.progressivePostFX, false)) && postEffects.length > 0;
    const state = {
      background: typeof props.background === "string" && props.background ? props.background : "#08151f",
      camera: sceneCamera(props),
      objects: new Map(),
      labels: new Map(),
      sprites: new Map(),
      html: new Map(),
      lights: new Map(),
      points: scenePoints(props),
      instancedMeshes: sceneInstancedMeshes(props),
      computeParticles: sceneComputeParticles(props),
      materials: sceneMaterials(props),
      postEffects: deferPostFX ? [] : postEffects,
      postFXMaxPixels: postFXMaxPixels,
      _deferredPostEffects: deferPostFX ? postEffects : null,
      _transitions: [],
      _scrollCamera: (sceneNumber(props.scrollCameraStart, 0) !== 0 || sceneNumber(props.scrollCameraEnd, 0) !== 0)
        ? { start: sceneNumber(props.scrollCameraStart, 0), end: sceneNumber(props.scrollCameraEnd, 0) }
        : null,
      environment: normalizeSceneEnvironment(rawSceneEnvironment(props), null),
    };
    for (const object of sceneObjects(props)) {
      state.objects.set(object.id, object);
    }
    for (const label of sceneLabels(props)) {
      state.labels.set(label.id, label);
    }
    for (const sprite of sceneSprites(props)) {
      state.sprites.set(sprite.id, sprite);
    }
    for (const entry of sceneHTML(props)) {
      state.html.set(entry.id, entry);
    }
    for (const light of sceneLights(props)) {
      state.lights.set(light.id, light);
    }
    return state;
  }

  function sceneStateObjects(state) {
    return Array.from(state.objects.values());
  }

  function sceneStateObjectsWithMaterials(state) {
    const objects = sceneStateObjects(state);
    const lookup = sceneMaterialLookup(state);
    if (!lookup.size) {
      return objects;
    }
    return objects.map(function(object) {
      const material = sceneNamedMaterialForRecord(lookup, object);
      if (!material) {
        return object;
      }
      return sceneApplyNamedMaterialToObject(object, material);
    });
  }

  function sceneStatePointsWithMaterials(state) {
    const points = Array.isArray(state && state.points) ? state.points : [];
    const lookup = sceneMaterialLookup(state);
    if (!lookup.size) {
      return points;
    }
    return points.map(function(point) {
      const material = sceneNamedMaterialForRecord(lookup, point);
      if (!material) {
        return point;
      }
      return sceneApplyNamedMaterialToPoints(point, material);
    });
  }

  function sceneMaterialLookup(state) {
    const materials = Array.isArray(state && state.materials) ? state.materials : [];
    if (!materials.length) {
      return new Map();
    }
    const lookup = new Map();
    for (let index = 0; index < materials.length; index += 1) {
      const material = materials[index];
      if (!material) {
        continue;
      }
      if (material.name) {
        lookup.set(String(material.name), material);
      }
      if (material.id) {
        lookup.set(String(material.id), material);
      }
    }
    return lookup;
  }

  function sceneNamedMaterialForRecord(lookup, record) {
    const materialName = record && record.material ? String(record.material) : "";
    return materialName ? lookup.get(materialName) || null : null;
  }

  function sceneApplyNamedMaterialToObject(object, material) {
    return Object.assign({}, object, {
      materialKind: material.kind || object.materialKind,
      color: material.color || object.color,
      texture: material.texture || object.texture,
      opacity: material.opacity != null ? material.opacity : object.opacity,
      emissive: material.emissive != null ? material.emissive : object.emissive,
      roughness: material.roughness != null ? material.roughness : object.roughness,
      metalness: material.metalness != null ? material.metalness : object.metalness,
      clearcoat: material.clearcoat != null ? material.clearcoat : object.clearcoat,
      sheen: material.sheen != null ? material.sheen : object.sheen,
      transmission: material.transmission != null ? material.transmission : object.transmission,
      iridescence: material.iridescence != null ? material.iridescence : object.iridescence,
      anisotropy: material.anisotropy != null ? material.anisotropy : object.anisotropy,
      normalMap: material.normalMap || object.normalMap,
      roughnessMap: material.roughnessMap || object.roughnessMap,
      metalnessMap: material.metalnessMap || object.metalnessMap,
      emissiveMap: material.emissiveMap || object.emissiveMap,
      blendMode: material.blendMode || object.blendMode,
      renderPass: material.renderPass || object.renderPass,
      wireframe: material.wireframe != null ? material.wireframe : object.wireframe,
      depthWrite: material.depthWrite != null ? material.depthWrite : object.depthWrite,
    });
  }

  function sceneApplyNamedMaterialToPoints(point, material) {
    const nextValues = {
      color: material._colorSpecified ? material.color : point.color,
      style: material.style || point.style,
      size: material.size != null ? material.size : point.size,
      opacity: material._opacitySpecified ? material.opacity : point.opacity,
      blendMode: material._blendModeSpecified ? material.blendMode : point.blendMode,
      depthWrite: material._depthWriteSpecified ? material.depthWrite : point.depthWrite,
      attenuation: material.attenuation != null ? material.attenuation : point.attenuation,
    };
    const cache = point._namedMaterialCache;
    if (
      cache &&
      cache.material === material &&
      cache.positions === point.positions &&
      cache.sizes === point.sizes &&
      cache.colors === point.colors &&
      cache.color === nextValues.color &&
      cache.style === nextValues.style &&
      cache.size === nextValues.size &&
      cache.opacity === nextValues.opacity &&
      cache.blendMode === nextValues.blendMode &&
      cache.depthWrite === nextValues.depthWrite &&
      cache.attenuation === nextValues.attenuation
    ) {
      return cache.value;
    }
    const previousValue = cache &&
      cache.positions === point.positions &&
      cache.sizes === point.sizes &&
      cache.colors === point.colors &&
      cache.value
        ? cache.value
        : null;
    const value = Object.assign({}, point, nextValues);
    if (previousValue) {
      if (previousValue._cachedPos) {
        value._cachedPos = previousValue._cachedPos;
      }
      if (previousValue._cachedSizes) {
        value._cachedSizes = previousValue._cachedSizes;
      }
      if (previousValue._cachedColors) {
        value._cachedColors = previousValue._cachedColors;
      }
    }
    point._namedMaterialCache = Object.assign({
      material,
      positions: point.positions,
      sizes: point.sizes,
      colors: point.colors,
      value,
    }, nextValues);
    return value;
  }

  function sceneStateLabels(state) {
    return Array.from(state.labels.values());
  }

  function sceneStateSprites(state) {
    return Array.from(state.sprites.values());
  }

  function sceneStateHTML(state) {
    return Array.from(state.html.values());
  }

  function sceneStateLights(state) {
    return Array.from(state.lights.values());
  }

  function sceneStateTransitions(state) {
    if (!state || !Array.isArray(state._transitions)) {
      return [];
    }
    return state._transitions;
  }

  function sceneHasActiveTransitions(state) {
    return sceneStateTransitions(state).length > 0;
  }

  function sceneNowMilliseconds() {
    if (typeof window !== "undefined" && window.performance && typeof window.performance.now === "function") {
      return window.performance.now();
    }
    return Date.now();
  }

  function sceneTransitionTimingForPhase(entry, phase) {
    const transition = sceneIsPlainObject(entry && entry._transition) ? entry._transition : null;
    const fallback = transition && phase === "update" ? transition.in : null;
    const timing = transition && sceneIsPlainObject(transition[phase]) ? transition[phase] : null;
    const duration = Math.max(0, Math.round(sceneNumber(timing && timing.duration, sceneNumber(fallback && fallback.duration, 0))));
    const easing = normalizeSceneEasing((timing && timing.easing) || (fallback && fallback.easing));
    return { duration, easing };
  }

  function sceneTransitionEase(easing, t) {
    const clamped = sceneClamp(sceneNumber(t, 0), 0, 1);
    switch (normalizeSceneEasing(easing)) {
      case "ease-in":
        return clamped * clamped;
      case "ease-out":
        return clamped * (2 - clamped);
      case "ease-in-out":
        return clamped < 0.5 ? 2 * clamped * clamped : -1 + (4 - 2 * clamped) * clamped;
      default:
        return clamped;
    }
  }

  function sceneTransitionColorLike(key, from, to) {
    if (typeof from !== "string" || typeof to !== "string") {
      return false;
    }
    if (typeof key === "string" && key.toLowerCase().indexOf("color") >= 0) {
      return true;
    }
    return /^#|^rgba?\(/i.test(from.trim()) && /^#|^rgba?\(/i.test(to.trim());
  }

  function sceneRGBAToHSL(rgba) {
    const r = clamp01(sceneNumber(rgba && rgba[0], 0));
    const g = clamp01(sceneNumber(rgba && rgba[1], 0));
    const b = clamp01(sceneNumber(rgba && rgba[2], 0));
    const a = clamp01(sceneNumber(rgba && rgba[3], 1));
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const delta = max - min;
    let h = 0;
    let s = 0;
    const l = (max + min) / 2;
    if (delta > 0.000001) {
      s = l > 0.5 ? delta / (2 - max - min) : delta / (max + min);
      switch (max) {
        case r:
          h = ((g - b) / delta) + (g < b ? 6 : 0);
          break;
        case g:
          h = ((b - r) / delta) + 2;
          break;
        default:
          h = ((r - g) / delta) + 4;
          break;
      }
      h /= 6;
    }
    return [h, s, l, a];
  }

  function sceneHueToRGB(p, q, t) {
    let value = t;
    if (value < 0) value += 1;
    if (value > 1) value -= 1;
    if (value < 1 / 6) return p + (q - p) * 6 * value;
    if (value < 1 / 2) return q;
    if (value < 2 / 3) return p + (q - p) * (2 / 3 - value) * 6;
    return p;
  }

  function sceneHSLToRGBA(hsla) {
    const h = sceneNumber(hsla && hsla[0], 0);
    const s = clamp01(sceneNumber(hsla && hsla[1], 0));
    const l = clamp01(sceneNumber(hsla && hsla[2], 0));
    const a = clamp01(sceneNumber(hsla && hsla[3], 1));
    if (s <= 0.000001) {
      return [l, l, l, a];
    }
    const q = l < 0.5 ? l * (1 + s) : l + s - (l * s);
    const p = 2 * l - q;
    return [
      sceneHueToRGB(p, q, h + (1 / 3)),
      sceneHueToRGB(p, q, h),
      sceneHueToRGB(p, q, h - (1 / 3)),
      a,
    ];
  }

  function sceneLerpColorString(from, to, t) {
    const left = sceneColorRGBA(from, [0, 0, 0, 1]);
    const right = sceneColorRGBA(to, left);
    const leftHSL = sceneRGBAToHSL(left);
    const rightHSL = sceneRGBAToHSL(right);
    const achromatic = leftHSL[1] <= 0.0001 && rightHSL[1] <= 0.0001;
    let rgba;
    if (achromatic) {
      rgba = [
        left[0] + (right[0] - left[0]) * t,
        left[1] + (right[1] - left[1]) * t,
        left[2] + (right[2] - left[2]) * t,
        left[3] + (right[3] - left[3]) * t,
      ];
    } else {
      let hueDelta = rightHSL[0] - leftHSL[0];
      if (hueDelta > 0.5) hueDelta -= 1;
      if (hueDelta < -0.5) hueDelta += 1;
      rgba = sceneHSLToRGBA([
        (leftHSL[0] + hueDelta * t + 1) % 1,
        leftHSL[1] + (rightHSL[1] - leftHSL[1]) * t,
        leftHSL[2] + (rightHSL[2] - leftHSL[2]) * t,
        leftHSL[3] + (rightHSL[3] - leftHSL[3]) * t,
      ]);
    }
    return sceneRGBAString(rgba);
  }

  function sceneTransitionValuesEqual(left, right) {
    if (left === right) {
      return true;
    }
    if (Array.isArray(left) || Array.isArray(right)) {
      if (!Array.isArray(left) || !Array.isArray(right) || left.length !== right.length) {
        return false;
      }
      for (let i = 0; i < left.length; i += 1) {
        if (!sceneTransitionValuesEqual(left[i], right[i])) {
          return false;
        }
      }
      return true;
    }
    if (sceneIsPlainObject(left) && sceneIsPlainObject(right)) {
      const keys = new Set(Object.keys(left).concat(Object.keys(right)));
      for (const key of keys) {
        if (sceneTransitionMetadataKey(key)) {
          continue;
        }
        if (!sceneTransitionValuesEqual(left[key], right[key])) {
          return false;
        }
      }
      return true;
    }
    return false;
  }

  function sceneTransitionBuildDelta(from, to, keyName) {
    if (sceneTransitionValuesEqual(from, to)) {
      return null;
    }
    if (sceneIsPlainObject(from) && sceneIsPlainObject(to)) {
      const delta = {};
      const keys = new Set(Object.keys(from).concat(Object.keys(to)));
      for (const key of keys) {
        if (sceneTransitionMetadataKey(key)) {
          continue;
        }
        const child = sceneTransitionBuildDelta(from[key], to[key], key);
        if (child !== null) {
          delta[key] = child;
        }
      }
      return Object.keys(delta).length > 0 ? delta : null;
    }
    return {
      __from: sceneCloneData(from),
      __to: sceneCloneData(to),
      __key: typeof keyName === "string" ? keyName : "",
    };
  }

  function sceneTransitionLeafValue(from, to, t, keyName) {
    if (typeof from === "number" && typeof to === "number" && Number.isFinite(from) && Number.isFinite(to)) {
      const value = from + (to - from) * t;
      return Number.isInteger(from) && Number.isInteger(to) ? Math.round(value) : value;
    }
    if (sceneTransitionColorLike(keyName, from, to)) {
      return sceneLerpColorString(from, to, t);
    }
    return sceneCloneData(to);
  }

  function sceneTransitionPatchAt(delta, t) {
    if (!delta || typeof delta !== "object") {
      return null;
    }
    if (Object.prototype.hasOwnProperty.call(delta, "__from")) {
      return sceneTransitionLeafValue(delta.__from, delta.__to, t, delta.__key);
    }
    const patch = {};
    const keys = Object.keys(delta);
    for (let i = 0; i < keys.length; i += 1) {
      const key = keys[i];
      patch[key] = sceneTransitionPatchAt(delta[key], t);
    }
    return patch;
  }

  function sceneApplyTransitionPatch(target, patch) {
    if (!sceneIsPlainObject(target) || patch == null) {
      return;
    }
    const keys = Object.keys(patch);
    for (let i = 0; i < keys.length; i += 1) {
      const key = keys[i];
      const value = patch[key];
      if (sceneIsPlainObject(value) && sceneIsPlainObject(target[key])) {
        sceneApplyTransitionPatch(target[key], value);
      } else {
        target[key] = sceneCloneData(value);
        if (key === "colors") {
          if (Object.prototype.hasOwnProperty.call(target, "_cachedColors")) {
            target._cachedColors = null;
          }
          if (Object.prototype.hasOwnProperty.call(target, "_cachedInstanceColors")) {
            target._cachedInstanceColors = null;
          }
        } else if (key === "positions" && Object.prototype.hasOwnProperty.call(target, "_cachedPos")) {
          target._cachedPos = null;
        } else if (key === "sizes" && Object.prototype.hasOwnProperty.call(target, "_cachedSizes")) {
          target._cachedSizes = null;
        } else if (key === "transforms" && Object.prototype.hasOwnProperty.call(target, "_cachedTransforms")) {
          target._cachedTransforms = null;
        }
      }
    }
    if (typeof target._lightHash === "number" && typeof hashLightContent === "function") {
      target._lightHash = hashLightContent(target);
    }
    if (typeof target._envHash === "number" && typeof hashEnvironmentContent === "function") {
      target._envHash = hashEnvironmentContent(target);
    }
  }

  function sceneInstantLiveBufferKeys(kind) {
    switch (kind) {
      case "points":
        return ["count", "positions", "sizes", "colors"];
      case "instanced":
        return ["count", "transforms"];
      default:
        return [];
    }
  }

  function sceneCloneTransitionData(kind, value) {
    if (!sceneIsPlainObject(value)) {
      return sceneCloneData(value);
    }
    const bufferKeys = sceneInstantLiveBufferKeys(kind);
    const clone = {};
    const keys = Object.keys(value);
    for (let i = 0; i < keys.length; i += 1) {
      const key = keys[i];
      if (sceneTransitionMetadataKey(key) || bufferKeys.indexOf(key) >= 0) {
        continue;
      }
      clone[key] = sceneCloneData(value[key]);
    }
    return clone;
  }

  function sceneApplyInstantLiveBufferPatch(kind, entry, target, payload) {
    if (!sceneIsPlainObject(entry) || !sceneIsPlainObject(target) || !sceneIsPlainObject(payload)) {
      return false;
    }
    const keys = sceneInstantLiveBufferKeys(kind);
    if (!keys.length) {
      return false;
    }
    let changed = false;
    for (let i = 0; i < keys.length; i += 1) {
      const key = keys[i];
      if (!Object.prototype.hasOwnProperty.call(payload, key)) {
        continue;
      }
      if (!sceneTransitionValuesEqual(entry[key], target[key])) {
        const patch = {};
        patch[key] = target[key];
        sceneApplyTransitionPatch(entry, patch);
        changed = true;
      }
      target[key] = entry[key];
    }
    return changed;
  }

  function sceneTransitionKey(kind, entry) {
    return String(kind || "scene") + ":" + String(entry && entry.id ? entry.id : "__singleton");
  }

  function sceneCancelEntryTransition(state, kind, entry) {
    if (!state || !Array.isArray(state._transitions)) {
      return;
    }
    const key = sceneTransitionKey(kind, entry);
    state._transitions = state._transitions.filter(function(item) {
      return item.key !== key;
    });
  }

  function sceneNormalizeEntryByKind(kind, raw, fallback) {
    switch (kind) {
      case "object":
        return normalizeSceneObject(raw, fallback && fallback.id ? fallback.id : 0, fallback);
      case "label":
        return normalizeSceneLabel(raw, fallback && fallback.id ? fallback.id : 0, fallback);
      case "sprite":
        return normalizeSceneSprite(raw, fallback && fallback.id ? fallback.id : 0, fallback);
      case "html":
        return normalizeSceneHTML(raw, fallback && fallback.id ? fallback.id : 0, fallback);
      case "light":
        return normalizeSceneLight(raw, fallback && fallback.id ? fallback.id : 0, fallback);
      case "points":
        return normalizeScenePointsEntry(raw, fallback && fallback.id ? fallback.id : 0, fallback);
      case "instanced":
        return normalizeSceneInstancedMeshEntry(raw, fallback && fallback.id ? fallback.id : 0, fallback);
      case "compute":
        return normalizeSceneComputeParticlesEntry(raw, fallback && fallback.id ? fallback.id : 0, fallback);
      case "environment":
        return normalizeSceneEnvironment(raw, fallback);
      default:
        return sceneCloneData(fallback || raw);
    }
  }

  function sceneDefaultTransitionPatch(kind) {
    switch (kind) {
      case "object":
      case "points":
      case "sprite":
      case "html":
        return { opacity: 0 };
      case "light":
        return { intensity: 0 };
      case "compute":
        return { count: 0, material: { opacity: 0 } };
      case "environment":
        return { ambientIntensity: 0, skyIntensity: 0, groundIntensity: 0, fogDensity: 0 };
      default:
        return null;
    }
  }

  function sceneTransitionStatePatch(kind, entry, phase) {
    const statePatch = phase === "out" ? entry && entry._outState : entry && entry._inState;
    if (sceneIsPlainObject(statePatch) && Object.keys(statePatch).length > 0) {
      return sceneCloneData(statePatch);
    }
    return null;
  }

  function sceneStartEntryTransition(state, kind, entry, reducedMotion, nowMs) {
    if (!entry || !sceneIsPlainObject(entry)) {
      return false;
    }
    const timing = sceneTransitionTimingForPhase(entry, "in");
    let startPatch = sceneTransitionStatePatch(kind, entry, "in");
    if (!startPatch && timing.duration > 0) {
      startPatch = sceneCloneData(sceneDefaultTransitionPatch(kind));
    }
    if ((!startPatch || !Object.keys(startPatch).length) && timing.duration <= 0) {
      return false;
    }
    const target = sceneCloneData(entry);
    const startState = sceneNormalizeEntryByKind(kind, startPatch || {}, target);
    sceneApplyTransitionPatch(entry, startState);
    if (reducedMotion || timing.duration <= 0) {
      sceneApplyTransitionPatch(entry, target);
      return false;
    }
    const delta = sceneTransitionBuildDelta(startState, target, "");
    if (!delta) {
      sceneApplyTransitionPatch(entry, target);
      return false;
    }
    sceneCancelEntryTransition(state, kind, entry);
    sceneStateTransitions(state).push({
      key: sceneTransitionKey(kind, entry),
      entry,
      target,
      delta,
      startTime: nowMs,
      duration: Math.max(1, timing.duration),
      easing: timing.easing,
    });
    return true;
  }

  function scenePrimeInitialTransitions(state, reducedMotion, nowMs) {
    let started = false;
    if (state && sceneIsPlainObject(state.environment)) {
      started = sceneStartEntryTransition(state, "environment", state.environment, reducedMotion, nowMs) || started;
    }
    const collections = [
      ["object", sceneStateObjects(state)],
      ["label", sceneStateLabels(state)],
      ["sprite", sceneStateSprites(state)],
      ["html", sceneStateHTML(state)],
      ["light", sceneStateLights(state)],
      ["points", Array.isArray(state && state.points) ? state.points : []],
      ["instanced", Array.isArray(state && state.instancedMeshes) ? state.instancedMeshes : []],
      ["compute", Array.isArray(state && state.computeParticles) ? state.computeParticles : []],
    ];
    for (let ci = 0; ci < collections.length; ci += 1) {
      const kind = collections[ci][0];
      const entries = collections[ci][1];
      for (let i = 0; i < entries.length; i += 1) {
        started = sceneStartEntryTransition(state, kind, entries[i], reducedMotion, nowMs) || started;
      }
    }
    return started;
  }

  function sceneAdvanceTransitions(state, nowMs) {
    const active = sceneStateTransitions(state);
    if (!active.length) {
      return false;
    }
    const next = [];
    for (let i = 0; i < active.length; i += 1) {
      const transition = active[i];
      const elapsed = Math.max(0, nowMs - sceneNumber(transition.startTime, 0));
      const rawT = sceneClamp(elapsed / Math.max(1, sceneNumber(transition.duration, 1)), 0, 1);
      const eased = sceneTransitionEase(transition.easing, rawT);
      const patch = sceneTransitionPatchAt(transition.delta, eased);
      if (patch) {
        sceneApplyTransitionPatch(transition.entry, patch);
      }
      if (rawT >= 1) {
        sceneApplyTransitionPatch(transition.entry, transition.target);
      } else {
        next.push(transition);
      }
    }
    state._transitions = next;
    return true;
  }

  function sceneEntryListensToEvent(entry, eventName) {
    if (!entry || !Array.isArray(entry._live) || !eventName) {
      return false;
    }
    return entry._live.indexOf(eventName) >= 0;
  }

  function sceneApplyLiveTransition(state, kind, entry, eventName, payload, reducedMotion, nowMs) {
    if (!entry || !sceneEntryListensToEvent(entry, eventName)) {
      return false;
    }
    const target = sceneNormalizeEntryByKind(kind, payload, entry);
    const instantChanged = sceneApplyInstantLiveBufferPatch(kind, entry, target, payload);
    if (sceneTransitionValuesEqual(entry, target)) {
      return instantChanged;
    }
    const timing = sceneTransitionTimingForPhase(entry, "update");
    sceneCancelEntryTransition(state, kind, entry);
    const current = sceneCloneTransitionData(kind, entry);
    const transitionTarget = sceneCloneTransitionData(kind, target);
    if (reducedMotion || timing.duration <= 0) {
      sceneApplyTransitionPatch(entry, transitionTarget);
      return true;
    }
    const delta = sceneTransitionBuildDelta(current, transitionTarget, "");
    if (!delta) {
      return instantChanged;
    }
    sceneStateTransitions(state).push({
      key: sceneTransitionKey(kind, entry),
      entry,
      target: transitionTarget,
      delta,
      startTime: nowMs,
      duration: Math.max(1, timing.duration),
      easing: timing.easing,
    });
    return true;
  }

  function sceneApplyLiveEvent(state, eventName, payload, reducedMotion, nowMs) {
    const event = typeof eventName === "string" ? eventName.trim() : "";
    if (!event) {
      return false;
    }
    const rawPayload = sceneIsPlainObject(payload) ? payload : {};
    let changed = sceneApplyLiveTransition(state, "environment", state && state.environment, event, rawPayload, reducedMotion, nowMs);
    const collections = [
      ["object", sceneStateObjects(state)],
      ["label", sceneStateLabels(state)],
      ["sprite", sceneStateSprites(state)],
      ["html", sceneStateHTML(state)],
      ["light", sceneStateLights(state)],
      ["points", Array.isArray(state && state.points) ? state.points : []],
      ["instanced", Array.isArray(state && state.instancedMeshes) ? state.instancedMeshes : []],
      ["compute", Array.isArray(state && state.computeParticles) ? state.computeParticles : []],
    ];
    for (let ci = 0; ci < collections.length; ci += 1) {
      const kind = collections[ci][0];
      const entries = collections[ci][1];
      for (let i = 0; i < entries.length; i += 1) {
        changed = sceneApplyLiveTransition(state, kind, entries[i], event, rawPayload, reducedMotion, nowMs) || changed;
      }
    }
    return changed;
  }

  function sceneObjectAnimated(object) {
    if (!object || typeof object !== "object") {
      return false;
    }
    if (sceneNumber(object.spinX, 0) !== 0 || sceneNumber(object.spinY, 0) !== 0 || sceneNumber(object.spinZ, 0) !== 0) {
      return true;
    }
    if (sceneNumber(object.driftSpeed, 0) === 0) {
      return false;
    }
    return sceneNumber(object.shiftX, 0) !== 0 || sceneNumber(object.shiftY, 0) !== 0 || sceneNumber(object.shiftZ, 0) !== 0;
  }

  function sceneLabelAnimated(label) {
    if (!label || typeof label !== "object") {
      return false;
    }
    if (sceneNumber(label.driftSpeed, 0) === 0) {
      return false;
    }
    return sceneNumber(label.shiftX, 0) !== 0 || sceneNumber(label.shiftY, 0) !== 0 || sceneNumber(label.shiftZ, 0) !== 0;
  }

  function sceneSpriteAnimated(sprite) {
    if (!sprite || typeof sprite !== "object") {
      return false;
    }
    if (sceneNumber(sprite.driftSpeed, 0) === 0) {
      return false;
    }
    return sceneNumber(sprite.shiftX, 0) !== 0 || sceneNumber(sprite.shiftY, 0) !== 0 || sceneNumber(sprite.shiftZ, 0) !== 0;
  }

  function sceneHTMLAnimated(entry) {
    if (!entry || typeof entry !== "object") {
      return false;
    }
    if (sceneNumber(entry.driftSpeed, 0) === 0) {
      return false;
    }
    return sceneNumber(entry.shiftX, 0) !== 0 || sceneNumber(entry.shiftY, 0) !== 0 || sceneNumber(entry.shiftZ, 0) !== 0;
  }

  const SCENE_CMD_CREATE_OBJECT = 0;
  const SCENE_CMD_REMOVE_OBJECT = 1;
  const SCENE_CMD_SET_TRANSFORM = 2;
  const SCENE_CMD_SET_MATERIAL = 3;
  const SCENE_CMD_SET_LIGHT = 4;
  const SCENE_CMD_SET_CAMERA = 5;
  const SCENE_CMD_SET_PARTICLES = 6;

  function applySceneCommands(state, commands) {
    if (!state || !Array.isArray(commands) || commands.length === 0) return;
    for (const command of commands) {
      applySceneCommand(state, command);
    }
  }

  function applySceneCommand(state, command) {
    if (!command || typeof command !== "object") return;
    switch (command.kind) {
      case SCENE_CMD_CREATE_OBJECT:
        applySceneCreateCommand(state, command.objectId, command.data);
        return;
      case SCENE_CMD_REMOVE_OBJECT:
        state.objects.delete(sceneObjectKey(command.objectId));
        state.labels.delete(sceneObjectKey(command.objectId));
        state.sprites.delete(sceneObjectKey(command.objectId));
        state.html.delete(sceneObjectKey(command.objectId));
        state.lights.delete(sceneObjectKey(command.objectId));
        return;
      case SCENE_CMD_SET_TRANSFORM:
      case SCENE_CMD_SET_MATERIAL:
        applySceneObjectPatch(state, command.objectId, command.data);
        return;
      case SCENE_CMD_SET_CAMERA:
        state.camera = normalizeSceneCamera(command.data || {}, state.camera);
        return;
      case SCENE_CMD_SET_LIGHT:
        applySceneLightPatch(state, command.objectId, command.data);
        return;
      case SCENE_CMD_SET_PARTICLES:
      default:
        return;
    }
  }

  function applySceneCreateCommand(state, objectID, payload) {
    if (!payload || typeof payload !== "object") return;
    if (payload.kind === "camera") {
      state.camera = normalizeSceneCamera(payload.props || {}, state.camera);
      return;
    }
    if (payload.kind === "light") {
      const light = sceneLightFromPayload(objectID, payload, state.lights.get(sceneObjectKey(objectID)));
      if (light) {
        state.lights.set(sceneObjectKey(objectID), light);
      }
      return;
    }
    if (payload.kind === "particles") {
      return;
    }
    if (payload.kind === "label") {
      const label = sceneLabelFromPayload(objectID, payload, state.labels.get(sceneObjectKey(objectID)));
      if (label) {
        state.labels.set(sceneObjectKey(objectID), label);
      }
      return;
    }
    if (payload.kind === "sprite") {
      const sprite = sceneSpriteFromPayload(objectID, payload, state.sprites.get(sceneObjectKey(objectID)));
      if (sprite) {
        state.sprites.set(sceneObjectKey(objectID), sprite);
      }
      return;
    }
    if (payload.kind === "html") {
      const entry = sceneHTMLFromPayload(objectID, payload, state.html.get(sceneObjectKey(objectID)));
      if (entry) {
        state.html.set(sceneObjectKey(objectID), entry);
      }
      return;
    }
    const key = sceneObjectKey(objectID);
    const next = sceneObjectFromPayload(objectID, payload, state.objects.get(key));
    if (next) {
      state.objects.set(key, next);
    }
  }

  function applySceneObjectPatch(state, objectID, patch) {
    const key = sceneObjectKey(objectID);
    const current = state.objects.get(key);
    if (current) {
      const next = sceneObjectFromPayload(objectID, {
        geometry: current.kind,
        props: Object.assign({}, current, patch || {}),
      }, current);
      if (next) {
        state.objects.set(key, next);
      }
      return;
    }
    const currentLabel = state.labels.get(key);
    if (currentLabel) {
      const nextLabel = sceneLabelFromPayload(objectID, {
        props: Object.assign({}, currentLabel, patch || {}),
      }, currentLabel);
      if (nextLabel) {
        state.labels.set(key, nextLabel);
      }
      return;
    }
    const currentSprite = state.sprites.get(key);
    if (currentSprite) {
      const nextSprite = sceneSpriteFromPayload(objectID, {
        props: Object.assign({}, currentSprite, patch || {}),
      }, currentSprite);
      if (nextSprite) {
        state.sprites.set(key, nextSprite);
      }
      return;
    }
    const currentHTML = state.html.get(key);
    if (currentHTML) {
      const nextHTML = sceneHTMLFromPayload(objectID, {
        props: Object.assign({}, currentHTML, patch || {}),
      }, currentHTML);
      if (nextHTML) {
        state.html.set(key, nextHTML);
      }
    }
  }

  function sceneObjectKey(objectID) {
    return String(objectID);
  }

  function sceneObjectFromPayload(objectID, payload, fallback) {
    const current = fallback && typeof fallback === "object" ? fallback : {};
    const props = payload && payload.props && typeof payload.props === "object" ? payload.props : {};
    const geometry = payload && typeof payload.geometry === "string" && payload.geometry ? payload.geometry : current.kind;
    const merged = Object.assign({}, current, props);
    merged.id = current.id || merged.id || ("scene-object-" + objectID);
    merged.kind = normalizeSceneKind(merged.kind || geometry);
    return normalizeSceneObject(merged, objectID, current);
  }

  function sceneLabelFromPayload(objectID, payload, fallback) {
    const current = fallback && typeof fallback === "object" ? fallback : {};
    const props = payload && payload.props && typeof payload.props === "object" ? payload.props : {};
    const merged = Object.assign({}, current, props);
    merged.id = current.id || merged.id || ("scene-label-" + objectID);
    const label = normalizeSceneLabel(merged, objectID, current);
    if (!label.text.trim()) {
      return null;
    }
    return label;
  }

  function sceneSpriteFromPayload(objectID, payload, fallback) {
    const current = fallback && typeof fallback === "object" ? fallback : {};
    const props = payload && payload.props && typeof payload.props === "object" ? payload.props : {};
    const merged = Object.assign({}, current, props);
    merged.id = current.id || merged.id || ("scene-sprite-" + objectID);
    const sprite = normalizeSceneSprite(merged, objectID, current);
    if (!sprite.src) {
      return null;
    }
    return sprite;
  }

  function sceneHTMLFromPayload(objectID, payload, fallback) {
    const current = fallback && typeof fallback === "object" ? fallback : {};
    const props = payload && payload.props && typeof payload.props === "object" ? payload.props : {};
    const merged = Object.assign({}, current, props);
    merged.id = current.id || merged.id || ("scene-html-" + objectID);
    const entry = normalizeSceneHTML(merged, objectID, current);
    if (!entry.html.trim()) {
      return null;
    }
    return entry;
  }

  function applySceneLightPatch(state, objectID, patch) {
    const key = sceneObjectKey(objectID);
    const current = state.lights.get(key);
    if (!current) {
      return;
    }
    const next = normalizeSceneLight(Object.assign({}, current, patch || {}), objectID, current);
    if (next) {
      state.lights.set(key, next);
    }
  }

  function sceneLightFromPayload(objectID, payload, fallback) {
    const current = fallback && typeof fallback === "object" ? fallback : {};
    const props = payload && payload.props && typeof payload.props === "object" ? payload.props : {};
    const merged = Object.assign({}, current, props);
    merged.id = current.id || merged.id || ("scene-light-" + objectID);
    return normalizeSceneLight(merged, objectID, current);
  }

  function sceneRenderCamera(camera, out) {
    const target = out || {
      kind: "perspective",
      x: 0, y: 0, z: 0,
      rotationX: 0, rotationY: 0, rotationZ: 0,
      fov: 0,
      left: 0, right: 0, top: 0, bottom: 0, zoom: 1,
      near: 0, far: 0,
    };
    target.kind = normalizeSceneCameraKind(camera && camera.kind, "perspective");
    target.x = sceneNumber(camera && camera.x, 0);
    target.y = sceneNumber(camera && camera.y, 0);
    target.z = sceneNumber(camera && camera.z, 6);
    target.rotationX = sceneNumber(camera && camera.rotationX, 0);
    target.rotationY = sceneNumber(camera && camera.rotationY, 0);
    target.rotationZ = sceneNumber(camera && camera.rotationZ, 0);
    target.fov = sceneNumber(camera && camera.fov, 75);
    target.left = sceneNumber(camera && camera.left, 0);
    target.right = sceneNumber(camera && camera.right, 0);
    target.top = sceneNumber(camera && camera.top, 0);
    target.bottom = sceneNumber(camera && camera.bottom, 0);
    target.zoom = Math.max(0.0001, sceneNumber(camera && camera.zoom, 1));
    target.near = sceneNumber(camera && camera.near, 0.05);
    target.far = sceneNumber(camera && camera.far, 128);
    return target;
  }

  function sceneOrthographicBounds(camera, width, height) {
    const cam = sceneRenderCamera(camera);
    const aspect = Math.max(0.0001, sceneNumber(width, 1) / Math.max(1, sceneNumber(height, 1)));
    let left = sceneNumber(cam.left, 0);
    let right = sceneNumber(cam.right, 0);
    let top = sceneNumber(cam.top, 0);
    let bottom = sceneNumber(cam.bottom, 0);
    if (Math.abs(right - left) <= 0.000001 || Math.abs(top - bottom) <= 0.000001) {
      const halfHeight = 3;
      const halfWidth = halfHeight * aspect;
      left = -halfWidth;
      right = halfWidth;
      top = halfHeight;
      bottom = -halfHeight;
    }
    const zoom = Math.max(0.0001, sceneNumber(cam.zoom, 1));
    const centerX = (left + right) * 0.5;
    const centerY = (top + bottom) * 0.5;
    const halfWidth = Math.max(0.000001, Math.abs(right - left) * 0.5 / zoom);
    const halfHeight = Math.max(0.000001, Math.abs(top - bottom) * 0.5 / zoom);
    return {
      left: centerX - halfWidth,
      right: centerX + halfWidth,
      top: centerY + halfHeight,
      bottom: centerY - halfHeight,
    };
  }

  function sceneCameraEquivalent(left, right) {
    const a = sceneRenderCamera(left);
    const b = sceneRenderCamera(right);
    return a.kind === b.kind &&
      Math.abs(a.x - b.x) <= 0.0001 &&
      Math.abs(a.y - b.y) <= 0.0001 &&
      Math.abs(a.z - b.z) <= 0.0001 &&
      Math.abs(a.rotationX - b.rotationX) <= 0.0001 &&
      Math.abs(a.rotationY - b.rotationY) <= 0.0001 &&
      Math.abs(a.rotationZ - b.rotationZ) <= 0.0001 &&
      Math.abs(a.fov - b.fov) <= 0.0001 &&
      Math.abs(a.left - b.left) <= 0.0001 &&
      Math.abs(a.right - b.right) <= 0.0001 &&
      Math.abs(a.top - b.top) <= 0.0001 &&
      Math.abs(a.bottom - b.bottom) <= 0.0001 &&
      Math.abs(a.zoom - b.zoom) <= 0.0001 &&
      Math.abs(a.near - b.near) <= 0.0001 &&
      Math.abs(a.far - b.far) <= 0.0001;
  }

  const _sceneBoundsDepthCameraScratch = {
    kind: "perspective",
    x: 0, y: 0, z: 0,
    rotationX: 0, rotationY: 0, rotationZ: 0,
    left: 0, right: 0, top: 0, bottom: 0, zoom: 1,
    fov: 0, near: 0, far: 0,
  };

  function sceneBoundsDepthMetrics(bounds, camera, cacheOwner) {
    if (!bounds) {
      const depth = sceneWorldPointDepth(0, camera);
      return { near: depth, far: depth, center: depth };
    }
    const cam = sceneRenderCamera(camera, _sceneBoundsDepthCameraScratch);

    let cacheHash = 0;
    if (cacheOwner) {
      cacheHash = sceneNumber(bounds.minX, 0) + sceneNumber(bounds.minY, 0) + sceneNumber(bounds.minZ, 0)
        + sceneNumber(bounds.maxX, 0) + sceneNumber(bounds.maxY, 0) + sceneNumber(bounds.maxZ, 0)
        + cam.x + cam.y + cam.z
        + cam.rotationX + cam.rotationY + cam.rotationZ
        + (cam.kind === "orthographic" ? 17 : 0)
        + cam.left + cam.right + cam.top + cam.bottom + cam.zoom;
      if (cacheOwner._depthCacheHash === cacheHash && cacheOwner._depthCacheResult) {
        return cacheOwner._depthCacheResult;
      }
    }

    const sinX = Math.sin(-cam.rotationX);
    const cosX = Math.cos(-cam.rotationX);
    const sinY = Math.sin(-cam.rotationY);
    const cosY = Math.cos(-cam.rotationY);
    const sinZ = Math.sin(-cam.rotationZ);
    const cosZ = Math.cos(-cam.rotationZ);

    const minX = sceneNumber(bounds.minX, 0);
    const minY = sceneNumber(bounds.minY, 0);
    const minZ = sceneNumber(bounds.minZ, 0);
    const maxX = sceneNumber(bounds.maxX, 0);
    const maxY = sceneNumber(bounds.maxY, 0);
    const maxZ = sceneNumber(bounds.maxZ, 0);

    let near = Infinity;
    let far = -Infinity;

    for (let i = 0; i < 8; i += 1) {
      const worldX = (i & 4) ? maxX : minX;
      const worldY = (i & 2) ? maxY : minY;
      const worldZ = (i & 1) ? maxZ : minZ;

      let lx = worldX - cam.x;
      let ly = worldY - cam.y;
      let lz = worldZ + cam.z;

      let nX = lx * cosZ - ly * sinZ;
      let nY = lx * sinZ + ly * cosZ;
      lx = nX;
      ly = nY;

      nX = lx * cosY + lz * sinY;
      let nZ = -lx * sinY + lz * cosY;
      lx = nX;
      lz = nZ;

      nZ = ly * sinX + lz * cosX;
      lz = nZ;

      if (lz < near) near = lz;
      if (lz > far) far = lz;
    }

    const result = {
      near: near,
      far: far,
      center: (near + far) / 2,
    };
    if (cacheOwner) {
      cacheOwner._depthCacheHash = cacheHash;
      cacheOwner._depthCacheResult = result;
    }
    return result;
  }

  function sceneBoundsViewCulled(bounds, camera, cacheOwner) {
    if (!bounds) {
      return false;
    }
    const depth = sceneBoundsDepthMetrics(bounds, camera, cacheOwner);
    const near = sceneNumber(camera && camera.near, 0.05);
    const far = sceneNumber(camera && camera.far, 128);
    return depth.far <= near || depth.near >= far;
  }

  function sceneLODDistance(object, camera) {
    const dx = sceneNumber(object && object.x, 0) - sceneNumber(camera && camera.x, 0);
    const dy = sceneNumber(object && object.y, 0) - sceneNumber(camera && camera.y, 0);
    const dz = sceneNumber(object && object.z, 0) - sceneNumber(camera && camera.z, 0);
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  function sceneLODLevelActive(entries, distance) {
    let best = null;
    let bestMin = -1;
    for (const entry of entries) {
      const minDistance = Math.max(0, sceneNumber(entry && entry.lodMinDistance, 0));
      const maxDistance = Math.max(0, sceneNumber(entry && entry.lodMaxDistance, 0));
      if (distance + 0.0001 < minDistance) {
        continue;
      }
      if (maxDistance > 0 && distance >= maxDistance) {
        continue;
      }
      if (minDistance >= bestMin) {
        best = entry;
        bestMin = minDistance;
      }
    }
    return best;
  }

  function sceneSelectLODObjects(objects, camera) {
    const source = Array.isArray(objects) ? objects : [];
    if (!source.length) {
      return source;
    }
    const plain = [];
    const groups = new Map();
    for (const object of source) {
      const group = object && typeof object.lodGroup === "string" ? object.lodGroup.trim() : "";
      if (!group) {
        plain.push(object);
        continue;
      }
      let levels = groups.get(group);
      if (!levels) {
        levels = new Map();
        groups.set(group, levels);
      }
      const level = Math.max(0, Math.floor(sceneNumber(object && object.lodLevel, 0)));
      let entries = levels.get(level);
      if (!entries) {
        entries = [];
        levels.set(level, entries);
      }
      entries.push(object);
    }
    if (!groups.size) {
      return source;
    }
    const selected = plain.slice();
    for (const levels of groups.values()) {
      const candidates = [];
      for (const entries of levels.values()) {
        if (entries.length) {
          candidates.push(entries[0]);
        }
      }
      const distance = sceneLODDistance(candidates[0], camera);
      const active = sceneLODLevelActive(candidates, distance) || candidates[0];
      const activeLevel = Math.max(0, Math.floor(sceneNumber(active && active.lodLevel, 0)));
      const activeEntries = levels.get(activeLevel);
      if (activeEntries && activeEntries.length) {
        selected.push.apply(selected, activeEntries);
      }
    }
    return selected;
  }

  function createSceneRenderBundle(width, height, background, camera, objects, labels, sprites, html, lights, environment, timeSeconds, points, instancedMeshes, computeParticles, postEffects, postFXMaxPixels) {
    const resolvedEnvironment = sceneResolveLightingEnvironment(environment, Array.isArray(lights) && lights.length > 0);
    const renderCamera = sceneRenderCamera(camera);
    const bundle = {
      bundleVersion: 1,
      background: background,
      timeSeconds: sceneNumber(timeSeconds, 0),
      camera: renderCamera,
      lights: Array.isArray(lights) ? lights.slice() : [],
      environment: resolvedEnvironment,
      postEffects: Array.isArray(postEffects) ? postEffects.slice() : [],
      materials: [],
      objects: [],
      surfaces: [],
      labels: [],
      sprites: [],
      html: [],
      lines: [],
      points: Array.isArray(points) ? points : [],
      instancedMeshes: Array.isArray(instancedMeshes) ? instancedMeshes : [],
      computeParticles: Array.isArray(computeParticles) ? computeParticles : [],
      positions: [],
      colors: [],
      worldPositions: [],
      worldColors: [],
      worldLineWidths: [],
      worldLineDashes: [],
      worldLineDashSizes: [],
      worldLineGapSizes: [],
      worldLinePasses: [],
      meshObjects: [],
      worldMeshPositions: [],
      worldMeshColors: [],
      worldMeshNormals: [],
      worldMeshUVs: [],
      worldMeshTangents: [],
      vertexCount: 0,
      worldVertexCount: 0,
      worldMeshVertexCount: 0,
      objectCount: 0,
    };
    const normalizedPostFXMaxPixels = Math.max(0, Math.floor(sceneNumber(postFXMaxPixels, 0)));
    if (normalizedPostFXMaxPixels > 0) {
      bundle.postFXMaxPixels = normalizedPostFXMaxPixels;
    }
    const materialLookup = new Map();
    appendSceneGridToBundle(bundle, width, height);
    for (const object of sceneSelectLODObjects(objects, renderCamera)) {
      appendSceneObjectToBundle(bundle, materialLookup, renderCamera, width, height, object, bundle.lights, resolvedEnvironment, timeSeconds);
    }
    for (const label of labels || []) {
      appendSceneLabelToBundle(bundle, camera, width, height, label, timeSeconds);
    }
    for (const sprite of sprites || []) {
      appendSceneSpriteToBundle(bundle, camera, width, height, sprite, timeSeconds);
    }
    for (const entry of html || []) {
      appendSceneHTMLToBundle(bundle, camera, width, height, entry, timeSeconds);
    }
    bundle.positions = new Float32Array(bundle.positions);
    bundle.colors = new Float32Array(bundle.colors);
    bundle.vertexCount = bundle.positions.length / 2;
    bundle.worldPositions = new Float32Array(bundle.worldPositions);
    bundle.worldColors = new Float32Array(bundle.worldColors);
    bundle.worldVertexCount = bundle.worldPositions.length / 3;
    bundle.worldLineWidths = new Float32Array(bundle.worldLineWidths);
    bundle.worldLinePasses = new Uint8Array(bundle.worldLinePasses);
    bundle.worldMeshPositions = new Float32Array(bundle.worldMeshPositions);
    bundle.worldMeshColors = new Float32Array(bundle.worldMeshColors);
    bundle.worldMeshNormals = new Float32Array(bundle.worldMeshNormals);
    bundle.worldMeshUVs = new Float32Array(bundle.worldMeshUVs);
    bundle.worldMeshTangents = new Float32Array(bundle.worldMeshTangents);
    bundle.worldMeshVertexCount = bundle.worldMeshPositions.length / 3;
    bundle.objectCount = bundle.objects.length;
    return bundle;
  }

  function translateScenePointInto(out, px, py, pz, object, timeSeconds) {
    const scaleX = sceneNumber(object && object.scaleX, 1);
    const scaleY = sceneNumber(object && object.scaleY, 1);
    const scaleZ = sceneNumber(object && object.scaleZ, 1);
    let x = sceneNumber(px, 0) * scaleX;
    let y = sceneNumber(py, 0) * scaleY;
    let z = sceneNumber(pz, 0) * scaleZ;

    const rotX = object.rotationX + object.spinX * timeSeconds;
    const rotY = object.rotationY + object.spinY * timeSeconds;
    const rotZ = object.rotationZ + object.spinZ * timeSeconds;

    const sinX = Math.sin(rotX);
    const cosX = Math.cos(rotX);
    let nextY = y * cosX - z * sinX;
    let nextZ = y * sinX + z * cosX;
    y = nextY;
    z = nextZ;

    const sinY = Math.sin(rotY);
    const cosY = Math.cos(rotY);
    let nextX = x * cosY + z * sinY;
    nextZ = -x * sinY + z * cosY;
    x = nextX;
    z = nextZ;

    const sinZ = Math.sin(rotZ);
    const cosZ = Math.cos(rotZ);
    nextX = x * cosZ - y * sinZ;
    nextY = x * sinZ + y * cosZ;
    x = nextX;
    y = nextY;

    if (object && (object.shiftX || object.shiftY || object.shiftZ)) {
      const driftPhase = sceneNumber(object.driftPhase, 0);
      const angle = driftPhase + timeSeconds * sceneNumber(object.driftSpeed, 0);
      x += Math.cos(angle) * sceneNumber(object.shiftX, 0);
      y += Math.sin(angle * 0.82 + driftPhase * 0.35) * sceneNumber(object.shiftY, 0);
      z += Math.sin(angle) * sceneNumber(object.shiftZ, 0);
    }

    out.x = x + object.x;
    out.y = y + object.y;
    out.z = z + object.z;
  }

  const _lineSegmentFromScratch = { x: 0, y: 0, z: 0 };
  const _lineSegmentToScratch = { x: 0, y: 0, z: 0 };
	  const _meshTriangleP0Scratch = { x: 0, y: 0, z: 0 };
	  const _meshTriangleP1Scratch = { x: 0, y: 0, z: 0 };
	  const _meshTriangleP2Scratch = { x: 0, y: 0, z: 0 };
	  const _meshTrianglePoints = [_meshTriangleP0Scratch, _meshTriangleP1Scratch, _meshTriangleP2Scratch];
	  const _objectMatrixOriginScratch = { x: 0, y: 0, z: 0 };
	  const _objectMatrixXScratch = { x: 0, y: 0, z: 0 };
	  const _objectMatrixYScratch = { x: 0, y: 0, z: 0 };
	  const _objectMatrixZScratch = { x: 0, y: 0, z: 0 };

	  function sceneObjectModelMatrix(object, timeSeconds) {
	    const origin = _objectMatrixOriginScratch;
	    const axisX = _objectMatrixXScratch;
	    const axisY = _objectMatrixYScratch;
	    const axisZ = _objectMatrixZScratch;
	    translateScenePointInto(origin, 0, 0, 0, object, timeSeconds);
	    translateScenePointInto(axisX, 1, 0, 0, object, timeSeconds);
	    translateScenePointInto(axisY, 0, 1, 0, object, timeSeconds);
	    translateScenePointInto(axisZ, 0, 0, 1, object, timeSeconds);

	    const out = new Float32Array(16);
	    out[0] = axisX.x - origin.x;
	    out[1] = axisX.y - origin.y;
	    out[2] = axisX.z - origin.z;
	    out[3] = 0;
	    out[4] = axisY.x - origin.x;
	    out[5] = axisY.y - origin.y;
	    out[6] = axisY.z - origin.z;
	    out[7] = 0;
	    out[8] = axisZ.x - origin.x;
	    out[9] = axisZ.y - origin.y;
	    out[10] = axisZ.z - origin.z;
	    out[11] = 0;
	    out[12] = origin.x;
	    out[13] = origin.y;
	    out[14] = origin.z;
	    out[15] = 1;
	    return out;
	  }

  function appendSceneGridToBundle(bundle, width, height) {
    for (let x = 0; x <= width; x += 48) {
      appendSceneLine(bundle, width, height, { x: x, y: 0 }, { x: x, y: height }, "rgba(141, 225, 255, 0.14)", 1);
    }
    for (let y = 0; y <= height; y += 48) {
      appendSceneLine(bundle, width, height, { x: 0, y: y }, { x: width, y: y }, "rgba(141, 225, 255, 0.14)", 1);
    }
  }

  function appendSceneObjectToBundle(bundle, materialLookup, camera, width, height, object, lights, environment, timeSeconds) {
    if (sceneObjectHasTriangleMesh(object)) {
      appendSceneMeshObjectToBundle(bundle, materialLookup, camera, width, height, object, lights, environment, timeSeconds);
      return;
    }
    const sourceSegments = sceneObjectSegments(object);
    const vertexOffset = bundle.worldPositions.length / 3;
    const material = sceneObjectMaterialProfile(object);
    const materialIndex = sceneBundleMaterialIndex(bundle, materialLookup, material);
    const includeLineGeometry = sceneWorldObjectUsesLinePass(object, material);
    let bounds = null;
    let vertexCount = 0;
    if (includeLineGeometry) {
      const rawLineWidth = sceneNumber(object && object.lineWidth, 0);
      const objectLineWidth = rawLineWidth > 0 ? rawLineWidth : 1.8;
      const objectPassString = sceneWorldObjectRenderPass(object, material);
      const objectPassIndex = objectPassString === "alpha" ? 1 : (objectPassString === "additive" ? 2 : 0);
      const fromWorld = _lineSegmentFromScratch;
      const toWorld = _lineSegmentToScratch;
      for (let index = 0; index < sourceSegments.length; index += 1) {
        const sourceSegment = sourceSegments[index];
        translateScenePointInto(fromWorld, sourceSegment[0] && sourceSegment[0].x, sourceSegment[0] && sourceSegment[0].y, sourceSegment[0] && sourceSegment[0].z, object, timeSeconds);
        translateScenePointInto(toWorld, sourceSegment[1] && sourceSegment[1].x, sourceSegment[1] && sourceSegment[1].y, sourceSegment[1] && sourceSegment[1].z, object, timeSeconds);
        const fromLighting = sceneLitColorRGBA(material, fromWorld, sceneObjectWorldNormal(object, sourceSegment[0], timeSeconds), lights, environment);
        const toLighting = sceneLitColorRGBA(material, toWorld, sceneObjectWorldNormal(object, sourceSegment[1], timeSeconds), lights, environment);
        bundle.worldPositions.push(fromWorld.x, fromWorld.y, fromWorld.z, toWorld.x, toWorld.y, toWorld.z);
        bundle.worldColors.push(
          fromLighting[0], fromLighting[1], fromLighting[2], fromLighting[3],
          toLighting[0], toLighting[1], toLighting[2], toLighting[3],
        );
        bundle.worldLineWidths.push(rawLineWidth);
        bundle.worldLineDashes.push(Boolean(material && material.lineDash));
        bundle.worldLineDashSizes.push(sceneNumber(material && material.dashSize, 0));
        bundle.worldLineGapSizes.push(sceneNumber(material && material.gapSize, 0));
        bundle.worldLinePasses.push(objectPassIndex);
        bounds = sceneExpandWorldBounds(bounds, fromWorld);
        bounds = sceneExpandWorldBounds(bounds, toWorld);
        vertexCount += 2;
        const from = sceneProjectPoint(fromWorld, camera, width, height);
        const to = sceneProjectPoint(toWorld, camera, width, height);
        if (!from || !to) continue;
        const stroke = sceneMixRGBA(fromLighting, toLighting);
        stroke[3] = clamp01(stroke[3] * sceneMaterialOpacity(material));
        appendSceneLine(bundle, width, height, from, to, sceneRGBAString(stroke), objectLineWidth, {
          dashed: Boolean(material && material.lineDash),
          dashSize: sceneNumber(material && material.dashSize, 0),
          gapSize: sceneNumber(material && material.gapSize, 0),
        });
      }
    } else if (sceneObjectHasTexturedSurface(object, material)) {
      const corners = scenePlaneSurfaceCorners(object, timeSeconds);
      for (const corner of corners) {
        bounds = sceneExpandWorldBounds(bounds, corner);
      }
    }
    if (vertexCount > 0 || bounds) {
      const depth = sceneBoundsDepthMetrics(bounds, camera, object);
      bundle.objects.push({
        id: object.id,
        kind: object.kind,
        pickable: typeof object.pickable === "boolean" ? object.pickable : undefined,
        materialIndex: materialIndex,
        renderPass: sceneWorldObjectRenderPass(object, material),
        vertexOffset: vertexOffset,
        vertexCount: vertexCount,
        static: Boolean(object.static),
        castShadow: Boolean(object.castShadow),
        receiveShadow: Boolean(object.receiveShadow),
        depthWrite: object.depthWrite,
        bounds: bounds || {
          minX: 0,
          minY: 0,
          minZ: 0,
          maxX: 0,
          maxY: 0,
          maxZ: 0,
        },
        depthNear: depth.near,
        depthFar: depth.far,
        depthCenter: depth.center,
        viewCulled: Boolean(object.viewCulled) || sceneBoundsViewCulled(bounds, camera, object),
      });
      appendSceneSurfaceToBundle(bundle, camera, object, materialIndex, material, bounds, depth, timeSeconds);
    }
  }

  function sceneObjectHasTriangleMesh(object) {
    return Boolean(
      object &&
      object.vertices &&
      object.vertices.positions &&
      typeof object.vertices.count === "number" &&
      object.vertices.count >= 3
    );
  }

  function sceneMeshVertexPoint(vertices, index) {
    const offset = index * 3;
    return {
      x: sceneNumber(vertices && vertices.positions && vertices.positions[offset], 0),
      y: sceneNumber(vertices && vertices.positions && vertices.positions[offset + 1], 0),
      z: sceneNumber(vertices && vertices.positions && vertices.positions[offset + 2], 0),
    };
  }

  function sceneMeshVertexNormal(vertices, index) {
    const offset = index * 3;
    if (!vertices || !vertices.normals || vertices.normals.length < offset + 3) {
      return { x: 0, y: 1, z: 0 };
    }
    return {
      x: sceneNumber(vertices.normals[offset], 0),
      y: sceneNumber(vertices.normals[offset + 1], 1),
      z: sceneNumber(vertices.normals[offset + 2], 0),
    };
  }

  function sceneMeshVertexUV(vertices, index) {
    const offset = index * 2;
    if (!vertices || !vertices.uvs || vertices.uvs.length < offset + 2) {
      return { x: 0, y: 0 };
    }
    return {
      x: sceneNumber(vertices.uvs[offset], 0),
      y: sceneNumber(vertices.uvs[offset + 1], 0),
    };
  }

  function sceneMeshVertexTangent(vertices, index) {
    const offset = index * 4;
    if (!vertices || !vertices.tangents || vertices.tangents.length < offset + 4) {
      return { x: 1, y: 0, z: 0, w: 1 };
    }
    return {
      x: sceneNumber(vertices.tangents[offset], 1),
      y: sceneNumber(vertices.tangents[offset + 1], 0),
      z: sceneNumber(vertices.tangents[offset + 2], 0),
      w: sceneNumber(vertices.tangents[offset + 3], 1),
    };
  }

  function sceneMeshWorldNormal(object, vertices, index, timeSeconds) {
    const normal = sceneMeshVertexNormal(vertices, index);
    return sceneNormalizeDirection(sceneRotatePoint(
      normal,
      object.rotationX + object.spinX * timeSeconds,
      object.rotationY + object.spinY * timeSeconds,
      object.rotationZ + object.spinZ * timeSeconds,
    ));
  }

  function sceneMeshWorldTangent(object, vertices, index, timeSeconds) {
    const tangent = sceneMeshVertexTangent(vertices, index);
    const rotated = sceneNormalizeDirection(sceneRotatePoint({
      x: tangent.x,
      y: tangent.y,
      z: tangent.z,
    }, object.rotationX + object.spinX * timeSeconds, object.rotationY + object.spinY * timeSeconds, object.rotationZ + object.spinZ * timeSeconds));
    return {
      x: rotated.x,
      y: rotated.y,
      z: rotated.z,
      w: tangent.w,
    };
  }

  function sceneNormalizeDirection(point) {
    const length = Math.sqrt(
      sceneNumber(point && point.x, 0) * sceneNumber(point && point.x, 0) +
      sceneNumber(point && point.y, 0) * sceneNumber(point && point.y, 0) +
      sceneNumber(point && point.z, 0) * sceneNumber(point && point.z, 0)
    );
    if (length <= 0.000001) {
      return { x: 0, y: 1, z: 0 };
    }
    return {
      x: sceneNumber(point && point.x, 0) / length,
      y: sceneNumber(point && point.y, 0) / length,
      z: sceneNumber(point && point.z, 0) / length,
    };
  }

  function appendSceneMeshWireSegment(bundle, camera, width, height, fromWorld, toWorld, fromLighting, toLighting, lineWidth, passIndex) {
    bundle.worldPositions.push(fromWorld.x, fromWorld.y, fromWorld.z, toWorld.x, toWorld.y, toWorld.z);
    bundle.worldColors.push(
      fromLighting[0], fromLighting[1], fromLighting[2], fromLighting[3],
      toLighting[0], toLighting[1], toLighting[2], toLighting[3],
    );
    bundle.worldLineWidths.push(lineWidth > 0 ? lineWidth : 0);
    bundle.worldLineDashes.push(false);
    bundle.worldLineDashSizes.push(0);
    bundle.worldLineGapSizes.push(0);
    bundle.worldLinePasses.push(passIndex || 0);
    const from = sceneProjectPoint(fromWorld, camera, width, height);
    const to = sceneProjectPoint(toWorld, camera, width, height);
    if (!from || !to) {
      return 2;
    }
    const stroke = sceneMixRGBA(fromLighting, toLighting);
    appendSceneLine(bundle, width, height, from, to, sceneRGBAString(stroke), lineWidth > 0 ? lineWidth : 1.6);
    return 2;
  }

  function appendSceneMeshObjectToBundle(bundle, materialLookup, camera, width, height, object, lights, environment, timeSeconds) {
    const vertices = object && object.vertices;
    if (!vertices || !vertices.positions || !vertices.count) {
      return;
    }
    const material = sceneObjectMaterialProfile(object);
    const materialIndex = sceneBundleMaterialIndex(bundle, materialLookup, material);
    const outlineColor = object && object.selected ? (object.outlineColor || "#facc15") : "";
    const outlineWidth = object && object.selected ? Math.max(2, sceneNumber(object.outlineWidth, 3)) : 0;
    const outlineLighting = outlineColor ? sceneColorRGBA(outlineColor, [1, 0.8, 0.15, 1]) : null;
    const objectPassString = sceneWorldObjectRenderPass(object, material);
    const objectPassIndex = objectPassString === "alpha" ? 1 : (objectPassString === "additive" ? 2 : 0);
    if (object.skin && vertices.joints && vertices.weights) {
      const bounds = vertices._skinnedLocalBounds || object.bounds || { minX: -1, minY: -1, minZ: -1, maxX: 1, maxY: 2, maxZ: 1 };
      bundle.meshObjects.push({
        id: object.id,
        kind: object.kind,
        pickable: typeof object.pickable === "boolean" ? object.pickable : undefined,
        materialIndex: materialIndex,
        renderPass: sceneWorldObjectRenderPass(object, material),
        static: false,
        castShadow: false,
        receiveShadow: Boolean(object.receiveShadow),
        depthWrite: object.depthWrite,
        bounds: bounds,
        depthNear: 0,
        depthFar: 0,
        depthCenter: 0,
        viewCulled: false,
        doubleSided: Boolean(object.doubleSided),
        skin: object.skin,
        vertices: vertices,
        directVertices: true,
        modelMatrix: sceneObjectModelMatrix(object, timeSeconds),
        vertexOffset: 0,
        vertexCount: Math.max(0, Math.floor(sceneNumber(vertices.count, 0))),
      });
      return;
    }
    const wireVertexOffset = bundle.worldPositions.length / 3;
    const meshVertexOffset = bundle.worldMeshPositions.length / 3;
    let wireVertexCount = 0;
    let meshVertexCount = 0;
    let bounds = null;

    const points = _meshTrianglePoints;
    const positions = vertices.positions;
    for (let tri = 0; tri + 2 < vertices.count; tri += 3) {
      const triOffset = tri * 3;
      const tri0 = triOffset;
      const tri1 = triOffset + 3;
      const tri2 = triOffset + 6;
      translateScenePointInto(points[0], positions[tri0], positions[tri0 + 1], positions[tri0 + 2], object, timeSeconds);
      translateScenePointInto(points[1], positions[tri1], positions[tri1 + 1], positions[tri1 + 2], object, timeSeconds);
      translateScenePointInto(points[2], positions[tri2], positions[tri2 + 1], positions[tri2 + 2], object, timeSeconds);
      const normals = [
        sceneMeshWorldNormal(object, vertices, tri, timeSeconds),
        sceneMeshWorldNormal(object, vertices, tri + 1, timeSeconds),
        sceneMeshWorldNormal(object, vertices, tri + 2, timeSeconds),
      ];
      const lighting = [
        sceneLitColorRGBA(material, points[0], normals[0], lights, environment),
        sceneLitColorRGBA(material, points[1], normals[1], lights, environment),
        sceneLitColorRGBA(material, points[2], normals[2], lights, environment),
      ];
      const uvs = [
        sceneMeshVertexUV(vertices, tri),
        sceneMeshVertexUV(vertices, tri + 1),
        sceneMeshVertexUV(vertices, tri + 2),
      ];
      const tangents = [
        sceneMeshWorldTangent(object, vertices, tri, timeSeconds),
        sceneMeshWorldTangent(object, vertices, tri + 1, timeSeconds),
        sceneMeshWorldTangent(object, vertices, tri + 2, timeSeconds),
      ];

      for (let index = 0; index < 3; index += 1) {
        const point = points[index];
        const normal = normals[index];
        const uv = uvs[index];
        const tangent = tangents[index];
        const color = lighting[index];
        bundle.worldMeshPositions.push(point.x, point.y, point.z);
        bundle.worldMeshColors.push(color[0], color[1], color[2], color[3]);
        bundle.worldMeshNormals.push(normal.x, normal.y, normal.z);
        bundle.worldMeshUVs.push(uv.x, uv.y);
        bundle.worldMeshTangents.push(tangent.x, tangent.y, tangent.z, tangent.w);
        bounds = sceneExpandWorldBounds(bounds, point);
        meshVertexCount += 1;
      }

      const line0 = outlineLighting || lighting[0];
      const line1 = outlineLighting || lighting[1];
      const line2 = outlineLighting || lighting[2];
      wireVertexCount += appendSceneMeshWireSegment(bundle, camera, width, height, points[0], points[1], line0, line1, outlineWidth, objectPassIndex);
      wireVertexCount += appendSceneMeshWireSegment(bundle, camera, width, height, points[1], points[2], line1, line2, outlineWidth, objectPassIndex);
      wireVertexCount += appendSceneMeshWireSegment(bundle, camera, width, height, points[2], points[0], line2, line0, outlineWidth, objectPassIndex);
    }

    if (!bounds || meshVertexCount <= 0) {
      return;
    }
    const depth = sceneBoundsDepthMetrics(bounds, camera, object);
    const shared = {
      id: object.id,
      kind: object.kind,
      pickable: typeof object.pickable === "boolean" ? object.pickable : undefined,
      materialIndex: materialIndex,
      renderPass: sceneWorldObjectRenderPass(object, material),
      static: Boolean(object.static),
      castShadow: Boolean(object.castShadow),
      receiveShadow: Boolean(object.receiveShadow),
      depthWrite: object.depthWrite,
      bounds: bounds,
      depthNear: depth.near,
      depthFar: depth.far,
      depthCenter: depth.center,
      viewCulled: Boolean(object.viewCulled) || sceneBoundsViewCulled(bounds, camera, object),
      doubleSided: Boolean(object.doubleSided),
      skin: object.skin,
      vertices: vertices,
    };
    bundle.objects.push(Object.assign({}, shared, {
      vertexOffset: wireVertexOffset,
      vertexCount: wireVertexCount,
    }));
    bundle.meshObjects.push(Object.assign({}, shared, {
      vertexOffset: meshVertexOffset,
      vertexCount: meshVertexCount,
    }));
  }

  function sceneObjectHasTexturedSurface(object, material) {
    return Boolean(
      object &&
      object.kind === "plane" &&
      material &&
      typeof material.texture === "string" &&
      material.texture.trim() !== "",
    );
  }

  function appendSceneSurfaceToBundle(bundle, camera, object, materialIndex, material, bounds, depthMetrics, timeSeconds) {
    if (!sceneObjectHasTexturedSurface(object, material)) {
      return;
    }
    bundle.surfaces.push({
      id: object.id,
      kind: object.kind,
      materialIndex: materialIndex,
      renderPass: sceneWorldObjectRenderPass(object, material),
      static: Boolean(object.static),
      positions: scenePlaneSurfacePositions(scenePlaneSurfaceCorners(object, timeSeconds)),
      uv: scenePlaneSurfaceUVs(),
      vertexCount: 6,
      bounds: bounds,
      depthNear: depthMetrics.near,
      depthFar: depthMetrics.far,
      depthCenter: depthMetrics.center,
      viewCulled: Boolean(object.viewCulled) || sceneBoundsViewCulled(bounds, camera, object),
    });
  }

  function sceneLabelPoint(label, timeSeconds) {
    const offset = sceneLabelOffset(label, timeSeconds);
    return {
      x: label.x + offset.x,
      y: label.y + offset.y,
      z: label.z + offset.z,
    };
  }

  function sceneLabelOffset(label, timeSeconds) {
    if (!label || (!label.shiftX && !label.shiftY && !label.shiftZ)) {
      return { x: 0, y: 0, z: 0 };
    }
    const angle = sceneNumber(label.driftPhase, 0) + timeSeconds * sceneNumber(label.driftSpeed, 0);
    return {
      x: Math.cos(angle) * sceneNumber(label.shiftX, 0),
      y: Math.sin(angle * 0.82 + sceneNumber(label.driftPhase, 0) * 0.35) * sceneNumber(label.shiftY, 0),
      z: Math.sin(angle) * sceneNumber(label.shiftZ, 0),
    };
  }

  function sceneSpritePoint(sprite, timeSeconds) {
    const offset = sceneSpriteOffset(sprite, timeSeconds);
    return {
      x: sceneNumber(sprite && sprite.x, 0) + offset.x,
      y: sceneNumber(sprite && sprite.y, 0) + offset.y,
      z: sceneNumber(sprite && sprite.z, 0) + offset.z,
    };
  }

  function sceneSpriteOffset(sprite, timeSeconds) {
    if (!sprite || (!sprite.shiftX && !sprite.shiftY && !sprite.shiftZ)) {
      return { x: 0, y: 0, z: 0 };
    }
    const angle = sceneNumber(sprite.driftPhase, 0) + timeSeconds * sceneNumber(sprite.driftSpeed, 0);
    return {
      x: Math.cos(angle) * sceneNumber(sprite.shiftX, 0),
      y: Math.sin(angle * 0.82 + sceneNumber(sprite.driftPhase, 0) * 0.35) * sceneNumber(sprite.shiftY, 0),
      z: Math.sin(angle) * sceneNumber(sprite.shiftZ, 0),
    };
  }

  function sceneProjectedSpriteSize(camera, width, height, sprite, depth) {
    if (depth <= 0) {
      return { width: 0, height: 0 };
    }
    const normalizedCamera = sceneRenderCamera(camera);
    if (normalizedCamera.kind === "orthographic") {
      const bounds = sceneOrthographicBounds(normalizedCamera, width, height);
      const spanX = Math.max(0.000001, bounds.right - bounds.left);
      const spanY = Math.max(0.000001, bounds.top - bounds.bottom);
      const scale = Math.max(0.05, sceneNumber(sprite && sprite.scale, 1));
      const worldWidth = Math.max(0.05, sceneNumber(sprite && sprite.width, 1.25));
      const worldHeight = Math.max(0.05, sceneNumber(sprite && sprite.height, worldWidth));
      return {
        width: Math.max(1, worldWidth * scale * (width / spanX)),
        height: Math.max(1, worldHeight * scale * (height / spanY)),
      };
    }
    const focal = (Math.min(width, height) / 2) / Math.tan((normalizedCamera.fov * Math.PI) / 360);
    const scale = Math.max(0.05, sceneNumber(sprite && sprite.scale, 1));
    const worldWidth = Math.max(0.05, sceneNumber(sprite && sprite.width, 1.25));
    const worldHeight = Math.max(0.05, sceneNumber(sprite && sprite.height, worldWidth));
    return {
      width: Math.max(1, (worldWidth * scale * focal) / depth),
      height: Math.max(1, (worldHeight * scale * focal) / depth),
    };
  }

  function appendSceneLabelToBundle(bundle, camera, width, height, label, timeSeconds) {
    const point = sceneLabelPoint(label, timeSeconds);
    const projected = sceneProjectPoint(point, camera, width, height);
    if (!projected) {
      return;
    }

    const marginX = Math.max(24, sceneNumber(label.maxWidth, 180));
    const marginY = Math.max(24, sceneNumber(label.lineHeight, 18) * 2);
    if (projected.x < -marginX || projected.x > width + marginX || projected.y < -marginY || projected.y > height + marginY) {
      return;
    }

    bundle.labels.push({
      id: label.id,
      text: label.text,
      className: label.className,
      position: { x: projected.x, y: projected.y },
      depth: projected.depth,
      priority: sceneNumber(label.priority, 0),
      maxWidth: sceneNumber(label.maxWidth, 180),
      maxLines: Math.max(0, Math.floor(sceneNumber(label.maxLines, 0))),
      overflow: normalizeTextLayoutOverflow(label.overflow),
      font: label.font,
      lineHeight: sceneNumber(label.lineHeight, 18),
      color: label.color,
      background: label.background,
      borderColor: label.borderColor,
      offsetX: sceneNumber(label.offsetX, 0),
      offsetY: sceneNumber(label.offsetY, -14),
      anchorX: sceneNumber(label.anchorX, 0.5),
      anchorY: sceneNumber(label.anchorY, 1),
      collision: normalizeSceneLabelCollision(label.collision),
      occlude: Boolean(label.occlude),
      whiteSpace: normalizeSceneLabelWhiteSpace(label.whiteSpace),
      textAlign: normalizeSceneLabelAlign(label.textAlign),
    });
  }

  function appendSceneSpriteToBundle(bundle, camera, width, height, sprite, timeSeconds) {
    const point = sceneSpritePoint(sprite, timeSeconds);
    const projected = sceneProjectPoint(point, camera, width, height);
    if (!projected) {
      return;
    }
    const size = sceneProjectedSpriteSize(camera, width, height, sprite, projected.depth);
    if (size.width <= 0 || size.height <= 0) {
      return;
    }
    const marginX = Math.max(24, size.width);
    const marginY = Math.max(24, size.height);
    if (projected.x < -marginX || projected.x > width + marginX || projected.y < -marginY || projected.y > height + marginY) {
      return;
    }
    bundle.sprites.push({
      id: sprite.id,
      src: sprite.src,
      className: sprite.className,
      position: { x: projected.x, y: projected.y },
      depth: projected.depth,
      priority: sceneNumber(sprite.priority, 0),
      width: size.width,
      height: size.height,
      opacity: clamp01(sceneNumber(sprite.opacity, 1)),
      offsetX: sceneNumber(sprite.offsetX, 0),
      offsetY: sceneNumber(sprite.offsetY, 0),
      anchorX: sceneNumber(sprite.anchorX, 0.5),
      anchorY: sceneNumber(sprite.anchorY, 0.5),
      occlude: Boolean(sprite.occlude),
      fit: normalizeSceneSpriteFit(sprite.fit),
    });
  }

  function appendSceneHTMLToBundle(bundle, camera, width, height, entry, timeSeconds) {
    const point = sceneSpritePoint(entry, timeSeconds);
    const projected = sceneProjectPoint(point, camera, width, height);
    if (!projected) {
      return;
    }
    const size = sceneProjectedSpriteSize(camera, width, height, entry, projected.depth);
    if (size.width <= 0 || size.height <= 0) {
      return;
    }
    const marginX = Math.max(24, size.width);
    const marginY = Math.max(24, size.height);
    if (projected.x < -marginX || projected.x > width + marginX || projected.y < -marginY || projected.y > height + marginY) {
      return;
    }
    bundle.html.push({
      id: entry.id,
      html: entry.html,
      className: entry.className,
      position: { x: projected.x, y: projected.y },
      depth: projected.depth,
      priority: sceneNumber(entry.priority, 0),
      width: size.width,
      height: size.height,
      opacity: clamp01(sceneNumber(entry.opacity, 1)),
      offsetX: sceneNumber(entry.offsetX, 0),
      offsetY: sceneNumber(entry.offsetY, 0),
      anchorX: sceneNumber(entry.anchorX, 0.5),
      anchorY: sceneNumber(entry.anchorY, 0.5),
      occlude: Boolean(entry.occlude),
      pointerEvents: normalizeSceneHTMLPointerEvents(entry.pointerEvents, "none"),
    });
  }

  function sceneExpandWorldBounds(bounds, point) {
    const next = bounds || {
      minX: point.x,
      minY: point.y,
      minZ: point.z,
      maxX: point.x,
      maxY: point.y,
      maxZ: point.z,
    };
    next.minX = Math.min(next.minX, point.x);
    next.minY = Math.min(next.minY, point.y);
    next.minZ = Math.min(next.minZ, point.z);
    next.maxX = Math.max(next.maxX, point.x);
    next.maxY = Math.max(next.maxY, point.y);
    next.maxZ = Math.max(next.maxZ, point.z);
    return next;
  }

  function appendSceneLine(bundle, width, height, from, to, color, lineWidth, options) {
    if (!from || !to) return;
    const rgba = sceneColorRGBA(color, [0.55, 0.88, 1, 1]);
    const fromClip = sceneClipPoint(from, width, height);
    const toClip = sceneClipPoint(to, width, height);
    const dashOptions = options && typeof options === "object" ? options : null;
    bundle.lines.push({
      from: from,
      to: to,
      color: color,
      lineWidth: lineWidth,
      lineDash: Boolean(dashOptions && dashOptions.dashed),
      dashSize: sceneNumber(dashOptions && dashOptions.dashSize, 0),
      gapSize: sceneNumber(dashOptions && dashOptions.gapSize, 0),
    });
    bundle.positions.push(fromClip.x, fromClip.y, toClip.x, toClip.y);
    bundle.colors.push(rgba[0], rgba[1], rgba[2], rgba[3], rgba[0], rgba[1], rgba[2], rgba[3]);
  }

  function createSceneWebGLRenderer(canvas, options) {
    if (!canvas || typeof canvas.getContext !== "function") {
      return null;
    }
    const contextOptions = {
      alpha: false,
      antialias: !(options && options.antialias === false),
      powerPreference: options && options.powerPreference ? options.powerPreference : "high-performance",
      preserveDrawingBuffer: false,
    };
    const gl =
      canvas.getContext("webgl", contextOptions) ||
      canvas.getContext("experimental-webgl", contextOptions) ||
      canvas.getContext("webgl2", contextOptions);
    if (!gl) {
      return null;
    }

    const program = createSceneWebGLProgram(gl);
    const surfaceProgram = createSceneWebGLSurfaceProgram(gl);
    if (!program) {
      return null;
    }

    const resources = createSceneWebGLResources(gl, program, surfaceProgram);
    return {
      kind: "webgl",
      render(bundle) {
        const geometry = sceneWebGLBundleGeometry(bundle);
        prepareSceneWebGLFrame(gl, canvas, bundle, geometry.usePerspective, resources);
        if (!bundle) {
          return;
        }
        const worldRendered = geometry.usePerspective && renderSceneWebGLWorldBundle(gl, bundle, canvas, resources);
        if (worldRendered) {
          applySceneWebGLBlend(gl, "opaque", resources.stateCache);
          applySceneWebGLDepth(gl, "opaque", resources.stateCache);
          return;
        }
        if (geometry.vertexCount === 0 || !geometry.positions || !geometry.colors) {
          return;
        }
        gl.useProgram(program);
        applySceneWebGLUniforms(gl, bundle, canvas, geometry.usePerspective, resources);
        renderSceneWebGLFallbackBundle(gl, geometry, resources);
      },
      dispose() {
        disposeSceneWebGLRenderer(gl, program, resources);
      },
    };
  }

  function createSceneWebGLResources(gl, program, surfaceProgram) {
    const thickLineProgram = createSceneThickLineProgram(gl);
    return {
      program,
      surfaceProgram,
      fallbackBuffers: createSceneWebGLBufferSet(gl),
      passBuffers: {
        staticOpaque: createSceneWebGLBufferSet(gl),
        alpha: createSceneWebGLBufferSet(gl),
        additive: createSceneWebGLBufferSet(gl),
        dynamicOpaque: createSceneWebGLBufferSet(gl),
      },
      drawScratch: createSceneWorldDrawScratch(),
      thickLineProgram,
      thickLineBuffers: createSceneThickLineBufferSet(gl),
      thickLineScratch: createSceneThickLineScratch(),
      positionLocation: gl.getAttribLocation(program, "a_position"),
      colorLocation: gl.getAttribLocation(program, "a_color"),
      materialLocation: gl.getAttribLocation(program, "a_material"),
      cameraLocation: gl.getUniformLocation(program, "u_camera"),
      cameraRotationLocation: gl.getUniformLocation(program, "u_camera_rotation"),
      aspectLocation: gl.getUniformLocation(program, "u_aspect"),
      perspectiveLocation: gl.getUniformLocation(program, "u_use_perspective"),
      cameraModeLocation: gl.getUniformLocation(program, "u_camera_mode"),
      orthoLocation: gl.getUniformLocation(program, "u_ortho"),
      surfaceBuffers: createSceneWebGLSurfaceBufferSet(gl),
      surfacePositionLocation: surfaceProgram ? gl.getAttribLocation(surfaceProgram, "a_position") : -1,
      surfaceUVLocation: surfaceProgram ? gl.getAttribLocation(surfaceProgram, "a_uv") : -1,
      surfaceCameraLocation: surfaceProgram ? gl.getUniformLocation(surfaceProgram, "u_camera") : null,
      surfaceCameraRotationLocation: surfaceProgram ? gl.getUniformLocation(surfaceProgram, "u_camera_rotation") : null,
      surfaceAspectLocation: surfaceProgram ? gl.getUniformLocation(surfaceProgram, "u_aspect") : null,
      surfaceCameraModeLocation: surfaceProgram ? gl.getUniformLocation(surfaceProgram, "u_camera_mode") : null,
      surfaceOrthoLocation: surfaceProgram ? gl.getUniformLocation(surfaceProgram, "u_ortho") : null,
      surfaceTintLocation: surfaceProgram ? gl.getUniformLocation(surfaceProgram, "u_tint") : null,
      surfaceEmissiveLocation: surfaceProgram ? gl.getUniformLocation(surfaceProgram, "u_emissive") : null,
      surfaceTextureLocation: surfaceProgram ? gl.getUniformLocation(surfaceProgram, "u_texture") : null,
      floatType: typeof gl.FLOAT === "number" ? gl.FLOAT : 0x1406,
      arrayBuffer: typeof gl.ARRAY_BUFFER === "number" ? gl.ARRAY_BUFFER : 0x8892,
      staticDraw: typeof gl.STATIC_DRAW === "number" ? gl.STATIC_DRAW : 0x88E4,
      dynamicDraw: typeof gl.DYNAMIC_DRAW === "number" ? gl.DYNAMIC_DRAW : 0x88E8,
      trianglesMode: typeof gl.TRIANGLES === "number" ? gl.TRIANGLES : 0x0004,
      colorBufferBit: typeof gl.COLOR_BUFFER_BIT === "number" ? gl.COLOR_BUFFER_BIT : 0x4000,
      depthBufferBit: typeof gl.DEPTH_BUFFER_BIT === "number" ? gl.DEPTH_BUFFER_BIT : 0x0100,
      linesMode: typeof gl.LINES === "number" ? gl.LINES : 0x0001,
      texture2D: typeof gl.TEXTURE_2D === "number" ? gl.TEXTURE_2D : 0x0DE1,
      texture0: typeof gl.TEXTURE0 === "number" ? gl.TEXTURE0 : 0x84C0,
      rgbaFormat: typeof gl.RGBA === "number" ? gl.RGBA : 0x1908,
      unsignedByte: typeof gl.UNSIGNED_BYTE === "number" ? gl.UNSIGNED_BYTE : 0x1401,
      linearFilter: typeof gl.LINEAR === "number" ? gl.LINEAR : 0x2601,
      clampToEdge: typeof gl.CLAMP_TO_EDGE === "number" ? gl.CLAMP_TO_EDGE : 0x812F,
      textureMinFilter: typeof gl.TEXTURE_MIN_FILTER === "number" ? gl.TEXTURE_MIN_FILTER : 0x2801,
      textureMagFilter: typeof gl.TEXTURE_MAG_FILTER === "number" ? gl.TEXTURE_MAG_FILTER : 0x2800,
      textureWrapS: typeof gl.TEXTURE_WRAP_S === "number" ? gl.TEXTURE_WRAP_S : 0x2802,
      textureWrapT: typeof gl.TEXTURE_WRAP_T === "number" ? gl.TEXTURE_WRAP_T : 0x2803,
      passCache: {
        staticOpaque: {
          key: "",
          vertexCount: 0,
        },
      },
      textureCache: new Map(),
      stateCache: {
        blendMode: "",
        depthMode: "",
      },
    };
  }

  function sceneWebGLBundleGeometry(bundle) {
    const hasWorldLines = Boolean(bundle && bundle.worldVertexCount > 0 && bundle.worldPositions && bundle.worldColors);
    const hasSurfaces = Boolean(bundle && Array.isArray(bundle.surfaces) && bundle.surfaces.length > 0);
    const camera = sceneRenderCamera(bundle && bundle.camera);
    const usePerspective = (hasWorldLines || hasSurfaces) && !(camera.kind === "orthographic" && !hasSurfaces);
    return {
      usePerspective,
      positions: usePerspective ? bundle.worldPositions : bundle && bundle.positions,
      colors: usePerspective ? bundle.worldColors : bundle && bundle.colors,
      vertexCount: usePerspective ? bundle && bundle.worldVertexCount : bundle && bundle.vertexCount,
    };
  }

  function prepareSceneWebGLFrame(gl, canvas, bundle, usePerspective, resources) {
    const background = sceneColorRGBA(bundle && bundle.background, [0.03, 0.08, 0.12, 1]);
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(background[0], background[1], background[2], background[3]);
    if (usePerspective && typeof gl.clearDepth === "function") {
      gl.clearDepth(1);
    }
    gl.clear(usePerspective ? resources.colorBufferBit | resources.depthBufferBit : resources.colorBufferBit);
  }

  function applySceneWebGLUniforms(gl, bundle, canvas, usePerspective, resources) {
    const aspect = Math.max(0.0001, canvas.width / Math.max(1, canvas.height));
    const camera = sceneRenderCamera(bundle && bundle.camera);
    if (typeof gl.uniform4f === "function" && resources.cameraLocation) {
      gl.uniform4f(
        resources.cameraLocation,
        camera.x,
        camera.y,
        camera.z,
        camera.fov,
      );
    }
    if (typeof gl.uniform3f === "function" && resources.cameraRotationLocation) {
      gl.uniform3f(
        resources.cameraRotationLocation,
        camera.rotationX,
        camera.rotationY,
        camera.rotationZ,
      );
    }
    if (typeof gl.uniform1f === "function" && resources.aspectLocation) {
      gl.uniform1f(resources.aspectLocation, aspect);
    }
    if (typeof gl.uniform1f === "function" && resources.perspectiveLocation) {
      gl.uniform1f(resources.perspectiveLocation, usePerspective ? 1 : 0);
    }
    if (typeof gl.uniform1f === "function" && resources.cameraModeLocation) {
      gl.uniform1f(resources.cameraModeLocation, camera.kind === "orthographic" ? 1 : 0);
    }
    if (typeof gl.uniform4f === "function" && resources.orthoLocation) {
      const bounds = sceneOrthographicBounds(camera, canvas.width, canvas.height);
      gl.uniform4f(resources.orthoLocation, bounds.left, bounds.right, bounds.top, bounds.bottom);
    }
  }

  function renderSceneWebGLWorldBundle(gl, bundle, canvas, resources) {
    let drew = renderSceneWebGLSurfaces(gl, bundle, canvas, resources, "opaque");
    drew = renderSceneWebGLMeshWorldBundle(gl, bundle, canvas, resources) || drew;

    if (sceneBundleNeedsThickLines(bundle) && resources.thickLineProgram) {
      const thickDrew = drawSceneThickLines(gl, bundle, canvas, resources);
      if (thickDrew) {
        gl.useProgram(resources.program);
        applySceneWebGLUniforms(gl, bundle, canvas, true, resources);
        drew = renderSceneWebGLSurfaces(gl, bundle, canvas, resources, "alpha") || drew || true;
        drew = renderSceneWebGLSurfaces(gl, bundle, canvas, resources, "additive") || drew;
        return true;
      }
    }

    gl.useProgram(resources.program);
    applySceneWebGLUniforms(gl, bundle, canvas, true, resources);
    if (sceneBundleCanUseBundledPasses(bundle)) {
      const bundledPasses = createSceneWorldWebGLPassesFromBundle(bundle, resources.passBuffers, {
        staticDraw: resources.staticDraw,
        dynamicDraw: resources.dynamicDraw,
      });
      if (bundledPasses.length > 0) {
        drawSceneWebGLPasses(gl, resources.arrayBuffer, resources.floatType, resources.linesMode, resources.positionLocation, resources.colorLocation, resources.materialLocation, bundledPasses, resources.passCache, resources.stateCache);
        drew = true;
        drew = renderSceneWebGLSurfaces(gl, bundle, canvas, resources, "alpha") || drew;
        drew = renderSceneWebGLSurfaces(gl, bundle, canvas, resources, "additive") || drew;
        return true;
      }
    }
    const drawPlan = buildSceneWorldDrawPlan(bundle, resources.drawScratch);
    if (!drawPlan) {
      drew = renderSceneWebGLSurfaces(gl, bundle, canvas, resources, "alpha") || drew;
      drew = renderSceneWebGLSurfaces(gl, bundle, canvas, resources, "additive") || drew;
      return drew;
    }
    const worldPasses = createSceneWorldWebGLPasses(drawPlan, resources.passBuffers, {
      staticDraw: resources.staticDraw,
      dynamicDraw: resources.dynamicDraw,
    });
    drawSceneWebGLPasses(gl, resources.arrayBuffer, resources.floatType, resources.linesMode, resources.positionLocation, resources.colorLocation, resources.materialLocation, worldPasses, resources.passCache, resources.stateCache);
    drew = true;
    drew = renderSceneWebGLSurfaces(gl, bundle, canvas, resources, "alpha") || drew;
    drew = renderSceneWebGLSurfaces(gl, bundle, canvas, resources, "additive") || drew;
    return true;
  }

  function renderSceneWebGLMeshWorldBundle(gl, bundle, canvas, resources) {
    const meshObjects = Array.isArray(bundle && bundle.meshObjects) ? bundle.meshObjects : [];
    if (!meshObjects.length || !bundle || !bundle.worldMeshPositions || !bundle.worldMeshColors) {
      return false;
    }
    const opaque = [];
    const alpha = [];
    const additive = [];
    for (let index = 0; index < meshObjects.length; index += 1) {
      const object = meshObjects[index];
      if (!sceneWorldObjectRenderable(object, bundle.camera)) {
        continue;
      }
      const material = Array.isArray(bundle.materials) ? bundle.materials[object.materialIndex] || null : null;
      const renderPass = sceneWorldObjectRenderPass(object, material);
      const entry = {
        object,
        material,
        order: index,
        depth: sceneNumber(object && object.depthCenter, 0),
      };
      if (renderPass === "alpha") {
        alpha.push(entry);
        continue;
      }
      if (renderPass === "additive") {
        additive.push(entry);
        continue;
      }
      opaque.push(entry);
    }
    if (!opaque.length && !alpha.length && !additive.length) {
      return false;
    }
    gl.useProgram(resources.program);
    applySceneWebGLUniforms(gl, bundle, canvas, true, resources);
    let drew = false;
    drew = renderSceneWebGLMeshWorldPass(gl, bundle, resources, opaque, "opaque", "opaque") || drew;
    drew = renderSceneWebGLMeshWorldPass(gl, bundle, resources, alpha, "alpha", "translucent") || drew;
    drew = renderSceneWebGLMeshWorldPass(gl, bundle, resources, additive, "additive", "translucent") || drew;
    return drew;
  }

  function renderSceneWebGLMeshWorldPass(gl, bundle, resources, entries, blendMode, depthMode) {
    if (!Array.isArray(entries) || !entries.length) {
      return false;
    }
    if (blendMode !== "opaque") {
      entries.sort(compareSceneWorldPassEntries);
    }
    applySceneWebGLDepth(gl, depthMode, resources.stateCache);
    applySceneWebGLBlend(gl, blendMode, resources.stateCache);
    let drew = false;
    for (const entry of entries) {
      drew = renderSceneWebGLMeshObject(gl, bundle, resources, entry.object, entry.material) || drew;
    }
    return drew;
  }

  function renderSceneWebGLMeshObject(gl, bundle, resources, object, material) {
    const vertexOffset = Math.max(0, Math.floor(sceneNumber(object && object.vertexOffset, 0)));
    const vertexCount = Math.max(0, Math.floor(sceneNumber(object && object.vertexCount, 0)));
    if (!vertexCount) {
      return false;
    }
    const positions = sceneSliceFloatArray(bundle.worldMeshPositions, vertexOffset * 3, vertexCount * 3);
    const colors = sceneSliceFloatArray(bundle.worldMeshColors, vertexOffset * 4, vertexCount * 4);
    const materials = sceneMeshMaterialArray(vertexCount, material);
    uploadSceneWebGLBuffers(
      gl,
      resources.arrayBuffer,
      object && object.static ? resources.staticDraw : resources.dynamicDraw,
      resources.fallbackBuffers.position,
      resources.fallbackBuffers.color,
      resources.fallbackBuffers.material,
      positions,
      colors,
      materials,
    );
    drawSceneWebGLPrimitives(
      gl,
      resources.arrayBuffer,
      resources.floatType,
      resources.trianglesMode,
      resources.positionLocation,
      resources.colorLocation,
      resources.materialLocation,
      resources.fallbackBuffers.position,
      resources.fallbackBuffers.color,
      resources.fallbackBuffers.material,
      vertexCount,
      3,
    );
    return true;
  }

  function sceneSliceFloatArray(values, start, count) {
    const safeStart = Math.max(0, Math.floor(sceneNumber(start, 0)));
    const safeCount = Math.max(0, Math.floor(sceneNumber(count, 0)));
    const typed = new Float32Array(safeCount);
    for (let index = 0; index < safeCount; index += 1) {
      typed[index] = sceneNumber(values && values[safeStart + index], 0);
    }
    return typed;
  }

  function sceneMeshMaterialArray(vertexCount, material) {
    const data = sceneMaterialShaderData(material);
    const typed = new Float32Array(Math.max(0, vertexCount) * 3);
    for (let index = 0; index < vertexCount; index += 1) {
      const offset = index * 3;
      typed[offset] = data[0];
      typed[offset + 1] = data[1];
      typed[offset + 2] = data[2];
    }
    return typed;
  }

  function sceneBundleCanUseBundledPasses(bundle) {
    if (!bundle || !Array.isArray(bundle.passes) || bundle.passes.length === 0) {
      return false;
    }
    if (!bundle.sourceCamera) {
      return true;
    }
    return sceneCameraEquivalent(bundle.sourceCamera, bundle.camera);
  }

  function renderSceneWebGLSurfaces(gl, bundle, canvas, resources, renderPass) {
    const surfaces = sceneBundleSurfaceEntries(bundle, renderPass);
    if (!surfaces.length || !resources.surfaceProgram) {
      return false;
    }
    gl.useProgram(resources.surfaceProgram);
    applySceneWebGLSurfaceUniforms(gl, bundle, canvas, resources);
    applySceneWebGLBlend(gl, renderPass === "additive" ? "additive" : (renderPass === "alpha" ? "alpha" : "opaque"), resources.stateCache);
    applySceneWebGLDepth(gl, renderPass === "opaque" ? "opaque" : "translucent", resources.stateCache);
    for (const entry of surfaces) {
      const material = bundle.materials[entry.materialIndex] || null;
      const textureRecord = sceneWebGLTextureRecord(gl, resources, material && material.texture);
      if (!textureRecord || !textureRecord.texture) {
        continue;
      }
      uploadSceneWebGLSurfaceBuffers(gl, resources, entry);
      bindSceneWebGLSurfaceTexture(gl, resources, textureRecord);
      applySceneWebGLSurfaceMaterial(gl, resources, material);
      drawSceneWebGLSurface(gl, resources, entry.vertexCount);
    }
    return true;
  }

  function sceneBundleSurfaceEntries(bundle, renderPass) {
    const surfaces = Array.isArray(bundle && bundle.surfaces) ? bundle.surfaces.slice() : [];
    const filtered = surfaces.filter(function(surface) {
      return surface &&
        !surface.viewCulled &&
        Math.max(0, Math.floor(sceneNumber(surface.vertexCount, 0))) > 0 &&
        String(surface.renderPass || "opaque") === renderPass;
    });
    if (renderPass !== "opaque") {
      filtered.sort(function(left, right) {
        if (sceneNumber(left.depthCenter, 0) !== sceneNumber(right.depthCenter, 0)) {
          return sceneNumber(right.depthCenter, 0) - sceneNumber(left.depthCenter, 0);
        }
        return String(left.id || "").localeCompare(String(right.id || ""));
      });
    }
    return filtered;
  }

  function applySceneWebGLSurfaceUniforms(gl, bundle, canvas, resources) {
    const aspect = Math.max(0.0001, canvas.width / Math.max(1, canvas.height));
    const camera = sceneRenderCamera(bundle && bundle.camera);
    if (typeof gl.uniform4f === "function" && resources.surfaceCameraLocation) {
      gl.uniform4f(resources.surfaceCameraLocation, camera.x, camera.y, camera.z, camera.fov);
    }
    if (typeof gl.uniform3f === "function" && resources.surfaceCameraRotationLocation) {
      gl.uniform3f(resources.surfaceCameraRotationLocation, camera.rotationX, camera.rotationY, camera.rotationZ);
    }
    if (typeof gl.uniform1f === "function" && resources.surfaceAspectLocation) {
      gl.uniform1f(resources.surfaceAspectLocation, aspect);
    }
    if (typeof gl.uniform1f === "function" && resources.surfaceCameraModeLocation) {
      gl.uniform1f(resources.surfaceCameraModeLocation, camera.kind === "orthographic" ? 1 : 0);
    }
    if (typeof gl.uniform4f === "function" && resources.surfaceOrthoLocation) {
      const bounds = sceneOrthographicBounds(camera, canvas.width, canvas.height);
      gl.uniform4f(resources.surfaceOrthoLocation, bounds.left, bounds.right, bounds.top, bounds.bottom);
    }
  }

  function uploadSceneWebGLSurfaceBuffers(gl, resources, surface) {
    gl.bindBuffer(resources.arrayBuffer, resources.surfaceBuffers.position);
    gl.bufferData(resources.arrayBuffer, sceneTypedFloatArray(surface && surface.positions), resources.dynamicDraw);
    gl.bindBuffer(resources.arrayBuffer, resources.surfaceBuffers.uv);
    gl.bufferData(resources.arrayBuffer, sceneTypedFloatArray(surface && surface.uv), resources.dynamicDraw);
  }

  function bindSceneWebGLSurfaceTexture(gl, resources, record) {
    if (typeof gl.activeTexture === "function") {
      gl.activeTexture(resources.texture0);
    }
    if (typeof gl.bindTexture === "function") {
      gl.bindTexture(resources.texture2D, record.texture);
    }
    if (typeof gl.uniform1i === "function" && resources.surfaceTextureLocation) {
      gl.uniform1i(resources.surfaceTextureLocation, 0);
    }
  }

  function applySceneWebGLSurfaceMaterial(gl, resources, material) {
    const tint = sceneColorRGBA(material && material.color, [1, 1, 1, 1]);
    tint[3] = clamp01(tint[3] * sceneMaterialOpacity(material));
    if (typeof gl.uniform4f === "function" && resources.surfaceTintLocation) {
      gl.uniform4f(resources.surfaceTintLocation, tint[0], tint[1], tint[2], tint[3]);
    }
    if (typeof gl.uniform1f === "function" && resources.surfaceEmissiveLocation) {
      gl.uniform1f(resources.surfaceEmissiveLocation, sceneMaterialEmissive(material));
    }
  }

  function drawSceneWebGLSurface(gl, resources, vertexCount) {
    if (!vertexCount) {
      return;
    }
    gl.bindBuffer(resources.arrayBuffer, resources.surfaceBuffers.position);
    gl.enableVertexAttribArray(resources.surfacePositionLocation);
    gl.vertexAttribPointer(resources.surfacePositionLocation, 3, resources.floatType, false, 0, 0);
    gl.bindBuffer(resources.arrayBuffer, resources.surfaceBuffers.uv);
    gl.enableVertexAttribArray(resources.surfaceUVLocation);
    gl.vertexAttribPointer(resources.surfaceUVLocation, 2, resources.floatType, false, 0, 0);
    gl.drawArrays(resources.trianglesMode, 0, vertexCount);
  }

  function sceneWebGLTextureRecord(gl, resources, src) {
    const key = typeof src === "string" ? src.trim() : "";
    if (!key || !resources || !resources.textureCache) {
      return null;
    }
    if (resources.textureCache.has(key)) {
      return resources.textureCache.get(key);
    }
    const texture = typeof gl.createTexture === "function" ? gl.createTexture() : null;
    const record = { texture, src: key, loaded: false };
    resources.textureCache.set(key, record);
    if (!texture) {
      return record;
    }
    initializeSceneWebGLTexture(gl, resources, texture);
    const image = createSceneWebGLImage();
    if (!image) {
      return record;
    }
    image.onload = function() {
      uploadSceneWebGLTextureImage(gl, resources, texture, image);
      record.loaded = true;
    };
    image.onerror = function() {
      record.failed = true;
    };
    image.src = key;
    return record;
  }

  function createSceneWebGLImage() {
    if (typeof Image === "function") {
      return new Image();
    }
    return null;
  }

  function initializeSceneWebGLTexture(gl, resources, texture) {
    if (typeof gl.bindTexture !== "function" || typeof gl.texImage2D !== "function") {
      return;
    }
    gl.bindTexture(resources.texture2D, texture);
    if (typeof gl.texParameteri === "function") {
      gl.texParameteri(resources.texture2D, resources.textureMinFilter, resources.linearFilter);
      gl.texParameteri(resources.texture2D, resources.textureMagFilter, resources.linearFilter);
      gl.texParameteri(resources.texture2D, resources.textureWrapS, resources.clampToEdge);
      gl.texParameteri(resources.texture2D, resources.textureWrapT, resources.clampToEdge);
    }
    gl.texImage2D(resources.texture2D, 0, resources.rgbaFormat, 1, 1, 0, resources.rgbaFormat, resources.unsignedByte, new Uint8Array([255, 255, 255, 255]));
  }

  function uploadSceneWebGLTextureImage(gl, resources, texture, image) {
    if (typeof gl.bindTexture !== "function" || typeof gl.texImage2D !== "function") {
      return;
    }
    gl.bindTexture(resources.texture2D, texture);
    if (typeof gl.texParameteri === "function") {
      gl.texParameteri(resources.texture2D, resources.textureMinFilter, resources.linearFilter);
      gl.texParameteri(resources.texture2D, resources.textureMagFilter, resources.linearFilter);
      gl.texParameteri(resources.texture2D, resources.textureWrapS, resources.clampToEdge);
      gl.texParameteri(resources.texture2D, resources.textureWrapT, resources.clampToEdge);
    }
    gl.texImage2D(resources.texture2D, 0, resources.rgbaFormat, resources.rgbaFormat, resources.unsignedByte, image);
  }

  function renderSceneWebGLFallbackBundle(gl, geometry, resources) {
    applySceneWebGLDepth(gl, "disabled", resources.stateCache);
    applySceneWebGLBlend(gl, "opaque", resources.stateCache);
    uploadSceneWebGLBuffers(
      gl,
      resources.arrayBuffer,
      resources.dynamicDraw,
      resources.fallbackBuffers.position,
      resources.fallbackBuffers.color,
      resources.fallbackBuffers.material,
      geometry.positions,
      geometry.colors,
      sceneFallbackMaterialData(geometry.vertexCount),
    );
    drawSceneWebGLLines(
      gl,
      resources.arrayBuffer,
      resources.floatType,
      resources.linesMode,
      resources.positionLocation,
      resources.colorLocation,
      resources.materialLocation,
      resources.fallbackBuffers.position,
      resources.fallbackBuffers.color,
      resources.fallbackBuffers.material,
      geometry.vertexCount,
      geometry.usePerspective ? 3 : 2,
    );
  }

  function disposeSceneWebGLRenderer(gl, program, resources) {
    if (typeof gl.deleteBuffer === "function") {
      deleteSceneWebGLBufferSet(gl, resources.fallbackBuffers);
      deleteSceneWebGLBufferSet(gl, resources.passBuffers.staticOpaque);
      deleteSceneWebGLBufferSet(gl, resources.passBuffers.alpha);
      deleteSceneWebGLBufferSet(gl, resources.passBuffers.additive);
      deleteSceneWebGLBufferSet(gl, resources.passBuffers.dynamicOpaque);
      deleteSceneWebGLSurfaceBufferSet(gl, resources.surfaceBuffers);
    }
    if (resources && resources.textureCache && typeof gl.deleteTexture === "function") {
      for (const record of resources.textureCache.values()) {
        if (record && record.texture) {
          gl.deleteTexture(record.texture);
        }
      }
    }
    if (typeof gl.deleteProgram === "function") {
      gl.deleteProgram(program);
      if (resources && resources.surfaceProgram) {
        gl.deleteProgram(resources.surfaceProgram);
      }
    }
  }

  function createSceneWebGLBufferSet(gl) {
    return {
      position: gl.createBuffer(),
      color: gl.createBuffer(),
      material: gl.createBuffer(),
    };
  }

  function createSceneWebGLSurfaceBufferSet(gl) {
    return {
      position: gl.createBuffer(),
      uv: gl.createBuffer(),
    };
  }

  function deleteSceneWebGLBufferSet(gl, buffers) {
    if (!buffers) {
      return;
    }
    gl.deleteBuffer(buffers.position);
    gl.deleteBuffer(buffers.color);
    gl.deleteBuffer(buffers.material);
  }

  function deleteSceneWebGLSurfaceBufferSet(gl, buffers) {
    if (!buffers) {
      return;
    }
    gl.deleteBuffer(buffers.position);
    gl.deleteBuffer(buffers.uv);
  }

  function createSceneWorldWebGLPasses(drawPlan, buffers, usages) {
    const passes = [];
    passes.push({
      name: "staticOpaque",
      blend: "opaque",
      depth: "opaque",
      usage: usages.staticDraw,
      cacheSlot: "staticOpaque",
      cacheKey: drawPlan.staticOpaqueKey,
      buffers: buffers.staticOpaque,
      positions: drawPlan.staticOpaquePositions,
      colors: drawPlan.staticOpaqueColors,
      materials: drawPlan.staticOpaqueMaterials,
      vertexCount: drawPlan.staticOpaqueVertexCount,
    });
    passes.push({
      name: "dynamicOpaque",
      blend: "opaque",
      depth: "opaque",
      usage: usages.dynamicDraw,
      buffers: buffers.dynamicOpaque,
      positions: drawPlan.dynamicOpaquePositions,
      colors: drawPlan.dynamicOpaqueColors,
      materials: drawPlan.dynamicOpaqueMaterials,
      vertexCount: drawPlan.dynamicOpaqueVertexCount,
    });
    if (drawPlan.hasAlphaPass) {
      passes.push({
        name: "alpha",
        blend: "alpha",
        depth: "translucent",
        usage: usages.dynamicDraw,
        buffers: buffers.alpha,
        positions: drawPlan.alphaPositions,
        colors: drawPlan.alphaColors,
        materials: drawPlan.alphaMaterials,
        vertexCount: drawPlan.alphaVertexCount,
      });
    }
    if (drawPlan.hasAdditivePass) {
      passes.push({
        name: "additive",
        blend: "additive",
        depth: "translucent",
        usage: usages.dynamicDraw,
        buffers: buffers.additive,
        positions: drawPlan.additivePositions,
        colors: drawPlan.additiveColors,
        materials: drawPlan.additiveMaterials,
        vertexCount: drawPlan.additiveVertexCount,
      });
    }
    return passes;
  }

  function createSceneWorldWebGLPassesFromBundle(bundle, buffers, usages) {
    const sourcePasses = Array.isArray(bundle && bundle.passes) ? bundle.passes : [];
    const passes = [];
    for (const source of sourcePasses) {
      const pass = sceneWorldWebGLPassFromSource(source, buffers, usages);
      if (pass) {
        passes.push(pass);
      }
    }
    return passes;
  }

  function sceneWorldWebGLPassFromSource(source, buffers, usages) {
    const name = sceneWorldWebGLPassName(source);
    if (!name) {
      return null;
    }
    const targetBuffers = buffers[name];
    if (!targetBuffers) {
      return null;
    }
    const isStatic = Boolean(source && source.static);
    const positions = sceneTypedFloatArray(source && source.positions);
    const colors = sceneTypedFloatArray(source && source.colors);
    const materials = sceneTypedFloatArray(source && source.materials);
    return {
      name,
      blend: sceneWorldWebGLPassMode(source && source.blend, "opaque"),
      depth: sceneWorldWebGLPassMode(source && source.depth, "opaque"),
      usage: isStatic ? usages.staticDraw : usages.dynamicDraw,
      cacheSlot: sceneWorldWebGLPassCacheSlot(name, isStatic),
      cacheKey: String(source && source.cacheKey || ""),
      buffers: targetBuffers,
      positions,
      colors,
      materials,
      vertexCount: sceneWorldWebGLPassVertexCount(source, positions, colors, materials),
    };
  }

  function sceneWorldWebGLPassName(source) {
    return String(source && source.name || "");
  }

  function sceneWorldWebGLPassMode(value, fallback) {
    const mode = String(value || fallback);
    return mode || fallback;
  }

  function sceneWorldWebGLPassCacheSlot(name, isStatic) {
    if (!isStatic) {
      return "";
    }
    return name;
  }

  function sceneWorldWebGLPassVertexCount(source, positions, colors, materials) {
    const requested = Math.max(0, Math.floor(sceneNumber(source && source.vertexCount, NaN)));
    const positionCount = Math.floor((positions && positions.length || 0) / 3);
    const colorCount = Math.floor((colors && colors.length || 0) / 4);
    const materialCount = Math.floor((materials && materials.length || 0) / 3);
    const maxCount = Math.max(0, Math.min(positionCount, colorCount, materialCount));
    if (Number.isFinite(requested)) {
      return Math.min(requested, maxCount);
    }
    return maxCount;
  }

  function drawSceneWebGLPasses(gl, arrayBuffer, floatType, linesMode, positionLocation, colorLocation, materialLocation, passes, cache, stateCache) {
    for (const pass of passes) {
      const vertexCount = uploadSceneWebGLPass(gl, arrayBuffer, pass, cache);
      if (!vertexCount) {
        continue;
      }
      applySceneWebGLDepth(gl, pass.depth, stateCache);
      applySceneWebGLBlend(gl, pass.blend, stateCache);
      drawSceneWebGLLines(gl, arrayBuffer, floatType, linesMode, positionLocation, colorLocation, materialLocation, pass.buffers.position, pass.buffers.color, pass.buffers.material, vertexCount, 3);
    }
  }

  function uploadSceneWebGLPass(gl, arrayBuffer, pass, cache) {
    if (!pass || !pass.buffers) {
      return 0;
    }
    if (pass.cacheSlot) {
      const record = cache[pass.cacheSlot] || (cache[pass.cacheSlot] = { key: "", vertexCount: 0 });
      if (record.key !== pass.cacheKey) {
        uploadSceneWebGLBuffers(gl, arrayBuffer, pass.usage, pass.buffers.position, pass.buffers.color, pass.buffers.material, pass.positions, pass.colors, pass.materials);
        record.key = pass.cacheKey;
        record.vertexCount = pass.vertexCount;
      }
      return record.vertexCount;
    }
    if (!pass.vertexCount) {
      return 0;
    }
    uploadSceneWebGLBuffers(gl, arrayBuffer, pass.usage, pass.buffers.position, pass.buffers.color, pass.buffers.material, pass.positions, pass.colors, pass.materials);
    return pass.vertexCount;
  }

  function uploadSceneWebGLBuffers(gl, arrayBuffer, usage, positionBuffer, colorBuffer, materialBuffer, positions, colors, materials) {
    gl.bindBuffer(arrayBuffer, positionBuffer);
    gl.bufferData(arrayBuffer, positions, usage);
    gl.bindBuffer(arrayBuffer, colorBuffer);
    gl.bufferData(arrayBuffer, colors, usage);
    gl.bindBuffer(arrayBuffer, materialBuffer);
    gl.bufferData(arrayBuffer, materials, usage);
  }

  function drawSceneWebGLLines(gl, arrayBuffer, floatType, linesMode, positionLocation, colorLocation, materialLocation, positionBuffer, colorBuffer, materialBuffer, vertexCount, positionSize) {
    drawSceneWebGLPrimitives(gl, arrayBuffer, floatType, linesMode, positionLocation, colorLocation, materialLocation, positionBuffer, colorBuffer, materialBuffer, vertexCount, positionSize);
  }

  function drawSceneWebGLPrimitives(gl, arrayBuffer, floatType, drawMode, positionLocation, colorLocation, materialLocation, positionBuffer, colorBuffer, materialBuffer, vertexCount, positionSize) {
    if (!vertexCount) {
      return;
    }
    gl.bindBuffer(arrayBuffer, positionBuffer);
    gl.enableVertexAttribArray(positionLocation);
    gl.vertexAttribPointer(positionLocation, positionSize, floatType, false, 0, 0);

    gl.bindBuffer(arrayBuffer, colorBuffer);
    gl.enableVertexAttribArray(colorLocation);
    gl.vertexAttribPointer(colorLocation, 4, floatType, false, 0, 0);

    gl.bindBuffer(arrayBuffer, materialBuffer);
    gl.enableVertexAttribArray(materialLocation);
    gl.vertexAttribPointer(materialLocation, 3, floatType, false, 0, 0);

    gl.drawArrays(drawMode, 0, vertexCount);
  }

  function sceneTypedFloatArray(values) {
    if (values instanceof Float32Array) {
      return values;
    }
    const list = Array.isArray(values) ? values : [];
    const typed = new Float32Array(list.length);
    for (let i = 0; i < list.length; i += 1) {
      typed[i] = sceneNumber(list[i], 0);
    }
    return typed;
  }

  function applySceneWebGLBlend(gl, mode, stateCache) {
    if (sceneWebGLStateUnchanged(stateCache, "blendMode", mode)) {
      return;
    }
    const blendConst = typeof gl.BLEND === "number" ? gl.BLEND : 0x0BE2;
    const one = typeof gl.ONE === "number" ? gl.ONE : 1;
    const srcAlpha = typeof gl.SRC_ALPHA === "number" ? gl.SRC_ALPHA : 0x0302;
    const oneMinusSrcAlpha = typeof gl.ONE_MINUS_SRC_ALPHA === "number" ? gl.ONE_MINUS_SRC_ALPHA : 0x0303;
    const config = sceneWebGLBlendConfig(mode, srcAlpha, oneMinusSrcAlpha, one);
    rememberSceneWebGLState(stateCache, "blendMode", mode);
    setSceneWebGLCapability(gl, blendConst, config.enabled);
    if (config.enabled && typeof gl.blendFunc === "function") {
      gl.blendFunc(config.src, config.dst);
    }
  }

  function applySceneWebGLDepth(gl, mode, stateCache) {
    if (sceneWebGLStateUnchanged(stateCache, "depthMode", mode)) {
      return;
    }
    const depthTest = typeof gl.DEPTH_TEST === "number" ? gl.DEPTH_TEST : 0x0B71;
    const lequal = typeof gl.LEQUAL === "number" ? gl.LEQUAL : 0x0203;
    const config = sceneWebGLDepthConfig(mode);
    rememberSceneWebGLState(stateCache, "depthMode", mode);
    setSceneWebGLCapability(gl, depthTest, config.enabled);
    if (!config.enabled) {
      return;
    }
    if (typeof gl.depthFunc === "function") {
      gl.depthFunc(lequal);
    }
    if (typeof gl.depthMask === "function") {
      gl.depthMask(config.mask);
    }
  }

  function sceneWebGLStateUnchanged(stateCache, key, mode) {
    return Boolean(stateCache && stateCache[key] === mode);
  }

  function rememberSceneWebGLState(stateCache, key, mode) {
    if (!stateCache) {
      return;
    }
    stateCache[key] = mode;
  }

  function setSceneWebGLCapability(gl, capability, enabled) {
    if (enabled) {
      if (typeof gl.enable === "function") {
        gl.enable(capability);
      }
      return;
    }
    if (typeof gl.disable === "function") {
      gl.disable(capability);
    }
  }

  function sceneWebGLBlendConfig(mode, srcAlpha, oneMinusSrcAlpha, one) {
    switch (mode) {
    case "alpha":
      return { enabled: true, src: srcAlpha, dst: oneMinusSrcAlpha };
    case "additive":
      return { enabled: true, src: srcAlpha, dst: one };
    default:
      return { enabled: false };
    }
  }

  function sceneWebGLDepthConfig(mode) {
    switch (mode) {
    case "opaque":
      return { enabled: true, mask: true };
    case "translucent":
      return { enabled: true, mask: false };
    default:
      return { enabled: false, mask: false };
    }
  }

  function createSceneWebGLProgram(gl) {
    const vertexSource = [
      "attribute vec3 a_position;",
      "attribute vec4 a_color;",
      "attribute vec3 a_material;",
      "uniform vec4 u_camera;",
      "uniform vec3 u_camera_rotation;",
      "uniform float u_aspect;",
      "uniform float u_use_perspective;",
      "uniform float u_camera_mode;",
      "uniform vec4 u_ortho;",
      "varying vec4 v_color;",
      "varying vec3 v_material;",
      "vec3 inverseRotatePoint(vec3 point, vec3 rotation) {",
      "  float sinZ = sin(-rotation.z);",
      "  float cosZ = cos(-rotation.z);",
      "  float nextX = point.x * cosZ - point.y * sinZ;",
      "  float nextY = point.x * sinZ + point.y * cosZ;",
      "  point = vec3(nextX, nextY, point.z);",
      "  float sinY = sin(-rotation.y);",
      "  float cosY = cos(-rotation.y);",
      "  nextX = point.x * cosY + point.z * sinY;",
      "  float nextZ = -point.x * sinY + point.z * cosY;",
      "  point = vec3(nextX, point.y, nextZ);",
      "  float sinX = sin(-rotation.x);",
      "  float cosX = cos(-rotation.x);",
      "  nextY = point.y * cosX - point.z * sinX;",
      "  nextZ = point.y * sinX + point.z * cosX;",
      "  return vec3(point.x, nextY, nextZ);",
      "}",
      "void main() {",
      "  vec4 clip = vec4(a_position.xy, 0.0, 1.0);",
      "  if (u_use_perspective > 0.5) {",
      "    vec3 local = inverseRotatePoint(vec3(a_position.x - u_camera.x, a_position.y - u_camera.y, a_position.z + u_camera.z), u_camera_rotation);",
      "    float depth = local.z;",
      "    if (depth <= 0.001) {",
      "      clip = vec4(2.0, 2.0, 0.0, 1.0);",
      "    } else if (u_camera_mode > 0.5) {",
      "      float ox = ((local.x - u_ortho.x) / max(u_ortho.y - u_ortho.x, 0.0001)) * 2.0 - 1.0;",
      "      float oy = ((local.y - u_ortho.w) / max(u_ortho.z - u_ortho.w, 0.0001)) * 2.0 - 1.0;",
      "      float clipDepth = clamp(depth / max(u_camera.z + 128.0, 0.0001), 0.0, 1.0) * 2.0 - 1.0;",
      "      clip = vec4(ox, oy, clipDepth, 1.0);",
      "    } else {",
      "      float focal = 1.0 / tan(radians(u_camera.w) * 0.5);",
      "      vec2 projected = vec2(local.x * focal / depth, local.y * focal / depth);",
      "      projected.x /= max(u_aspect, 0.0001);",
      "      float clipDepth = clamp(depth / 128.0, 0.0, 1.0) * 2.0 - 1.0;",
      "      clip = vec4(projected, clipDepth, 1.0);",
      "    }",
      "  }",
      "  gl_Position = clip;",
      "  v_color = a_color;",
      "  v_material = a_material;",
      "}",
    ].join("\n");
    const fragmentSource = [
      "precision mediump float;",
      "varying vec4 v_color;",
      "varying vec3 v_material;",
      "void main() {",
      "  vec4 color = v_color;",
      "  float kind = floor(v_material.x + 0.5);",
      "  float emissive = max(v_material.y, 0.0);",
      "  float tone = clamp(v_material.z, 0.0, 1.0);",
      "  if (kind > 3.5) {",
      "    color.rgb *= mix(0.78, 1.0, tone);",
      "  } else if (kind > 2.5) {",
      "    color.rgb *= 1.0 + emissive * 0.75;",
      "  } else if (kind > 1.5) {",
      "    color.rgb = mix(color.rgb, vec3(0.92, 0.98, 1.0), 0.28 + tone * 0.16);",
      "    color.a *= 0.84;",
      "  } else if (kind > 0.5) {",
      "    color.rgb = mix(color.rgb, vec3(0.84, 0.94, 1.0), 0.18 + tone * 0.12);",
      "    color.a *= 0.9;",
      "  } else {",
      "    color.rgb *= mix(0.9, 1.0, tone);",
      "  }",
      "  gl_FragColor = vec4(clamp(color.rgb, 0.0, 1.0), clamp(color.a, 0.0, 1.0));",
      "}",
    ].join("\n");

    const vertexShader = createSceneShader(gl, gl.VERTEX_SHADER, vertexSource);
    const fragmentShader = createSceneShader(gl, gl.FRAGMENT_SHADER, fragmentSource);
    if (!vertexShader || !fragmentShader) {
      return null;
    }

    const program = gl.createProgram();
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      console.warn("[gosx] Scene3D WebGL link failed");
      return null;
    }
    return program;
  }

  function createSceneWebGLSurfaceProgram(gl) {
    const vertexSource = [
      "attribute vec3 a_position;",
      "attribute vec2 a_uv;",
      "uniform vec4 u_camera;",
      "uniform vec3 u_camera_rotation;",
      "uniform float u_aspect;",
      "uniform float u_camera_mode;",
      "uniform vec4 u_ortho;",
      "varying vec2 v_uv;",
      "vec3 inverseRotatePoint(vec3 point, vec3 rotation) {",
      "  float sinZ = sin(-rotation.z);",
      "  float cosZ = cos(-rotation.z);",
      "  float nextX = point.x * cosZ - point.y * sinZ;",
      "  float nextY = point.x * sinZ + point.y * cosZ;",
      "  point = vec3(nextX, nextY, point.z);",
      "  float sinY = sin(-rotation.y);",
      "  float cosY = cos(-rotation.y);",
      "  nextX = point.x * cosY + point.z * sinY;",
      "  float nextZ = -point.x * sinY + point.z * cosY;",
      "  point = vec3(nextX, point.y, nextZ);",
      "  float sinX = sin(-rotation.x);",
      "  float cosX = cos(-rotation.x);",
      "  nextY = point.y * cosX - point.z * sinX;",
      "  nextZ = point.y * sinX + point.z * cosX;",
      "  return vec3(point.x, nextY, nextZ);",
      "}",
      "void main() {",
      "  vec3 local = inverseRotatePoint(vec3(a_position.x - u_camera.x, a_position.y - u_camera.y, a_position.z + u_camera.z), u_camera_rotation);",
      "  float depth = local.z;",
      "  if (depth <= 0.001) {",
      "    gl_Position = vec4(2.0, 2.0, 0.0, 1.0);",
      "  } else if (u_camera_mode > 0.5) {",
      "    float ox = ((local.x - u_ortho.x) / max(u_ortho.y - u_ortho.x, 0.0001)) * 2.0 - 1.0;",
      "    float oy = ((local.y - u_ortho.w) / max(u_ortho.z - u_ortho.w, 0.0001)) * 2.0 - 1.0;",
      "    float clipDepth = clamp(depth / max(u_camera.z + 128.0, 0.0001), 0.0, 1.0) * 2.0 - 1.0;",
      "    gl_Position = vec4(ox, oy, clipDepth, 1.0);",
      "  } else {",
      "    float focal = 1.0 / tan(radians(u_camera.w) * 0.5);",
      "    vec2 projected = vec2(local.x * focal / depth, local.y * focal / depth);",
      "    projected.x /= max(u_aspect, 0.0001);",
      "    float clipDepth = clamp(depth / 128.0, 0.0, 1.0) * 2.0 - 1.0;",
      "    gl_Position = vec4(projected, clipDepth, 1.0);",
      "  }",
      "  v_uv = a_uv;",
      "}",
    ].join("\n");
    const fragmentSource = [
      "precision mediump float;",
      "varying vec2 v_uv;",
      "uniform sampler2D u_texture;",
      "uniform vec4 u_tint;",
      "uniform float u_emissive;",
      "void main() {",
      "  vec4 sampleColor = texture2D(u_texture, v_uv);",
      "  vec3 rgb = sampleColor.rgb * u_tint.rgb;",
      "  rgb *= 1.0 + max(u_emissive, 0.0) * 0.5;",
      "  gl_FragColor = vec4(clamp(rgb, 0.0, 1.0), clamp(sampleColor.a * u_tint.a, 0.0, 1.0));",
      "}",
    ].join("\n");

    const vertexShader = createSceneShader(gl, gl.VERTEX_SHADER, vertexSource);
    const fragmentShader = createSceneShader(gl, gl.FRAGMENT_SHADER, fragmentSource);
    if (!vertexShader || !fragmentShader) {
      return null;
    }

    const program = gl.createProgram();
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      console.warn("[gosx] Scene3D WebGL surface link failed");
      return null;
    }
    return program;
  }

  function createSceneShader(gl, type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      console.warn("[gosx] Scene3D WebGL shader compile failed");
      return null;
    }
    return shader;
  }

  function createSceneThickLineProgram(gl) {
    const vertexSource = [
      "attribute vec3 a_positionA;",
      "attribute vec3 a_positionB;",
      "attribute vec4 a_colorA;",
      "attribute vec4 a_colorB;",
      "attribute float a_side;",
      "attribute float a_endpoint;",
      "attribute float a_width;",
      "uniform vec4 u_camera;",
      "uniform vec3 u_camera_rotation;",
      "uniform float u_aspect;",
      "uniform vec2 u_viewport;",
      "uniform float u_camera_mode;",
      "uniform vec4 u_ortho;",
      "varying vec4 v_color;",
      "vec3 inverseRotatePoint(vec3 point, vec3 rotation) {",
      "  float sinZ = sin(-rotation.z);",
      "  float cosZ = cos(-rotation.z);",
      "  float nextX = point.x * cosZ - point.y * sinZ;",
      "  float nextY = point.x * sinZ + point.y * cosZ;",
      "  point = vec3(nextX, nextY, point.z);",
      "  float sinY = sin(-rotation.y);",
      "  float cosY = cos(-rotation.y);",
      "  nextX = point.x * cosY + point.z * sinY;",
      "  float nextZ = -point.x * sinY + point.z * cosY;",
      "  point = vec3(nextX, point.y, nextZ);",
      "  float sinX = sin(-rotation.x);",
      "  float cosX = cos(-rotation.x);",
      "  nextY = point.y * cosX - point.z * sinX;",
      "  nextZ = point.y * sinX + point.z * cosX;",
      "  return vec3(point.x, nextY, nextZ);",
      "}",
      "vec4 projectEndpoint(vec3 world) {",
      "  vec3 local = inverseRotatePoint(vec3(world.x - u_camera.x, world.y - u_camera.y, world.z + u_camera.z), u_camera_rotation);",
      "  float depth = local.z;",
      "  if (depth <= 0.001) {",
      "    return vec4(2.0, 2.0, 0.0, 1.0);",
      "  }",
      "  if (u_camera_mode > 0.5) {",
      "    float ox = ((local.x - u_ortho.x) / max(u_ortho.y - u_ortho.x, 0.0001)) * 2.0 - 1.0;",
      "    float oy = ((local.y - u_ortho.w) / max(u_ortho.z - u_ortho.w, 0.0001)) * 2.0 - 1.0;",
      "    float clipDepth = clamp(depth / max(u_camera.z + 128.0, 0.0001), 0.0, 1.0) * 2.0 - 1.0;",
      "    return vec4(ox, oy, clipDepth, 1.0);",
      "  }",
      "  float focal = 1.0 / tan(radians(u_camera.w) * 0.5);",
      "  vec2 projected = vec2(local.x * focal / depth, local.y * focal / depth);",
      "  projected.x /= max(u_aspect, 0.0001);",
      "  float clipDepth = clamp(depth / 128.0, 0.0, 1.0) * 2.0 - 1.0;",
      "  return vec4(projected, clipDepth, 1.0);",
      "}",
      "void main() {",
      "  vec4 clipA = projectEndpoint(a_positionA);",
      "  vec4 clipB = projectEndpoint(a_positionB);",
      "  vec4 base = mix(clipA, clipB, a_endpoint);",
      "  vec2 ndcA = clipA.xy / max(clipA.w, 0.0001);",
      "  vec2 ndcB = clipB.xy / max(clipB.w, 0.0001);",
      "  vec2 screenA = ndcA * (u_viewport * 0.5);",
      "  vec2 screenB = ndcB * (u_viewport * 0.5);",
      "  vec2 dir = screenB - screenA;",
      "  float len = length(dir);",
      "  if (len < 0.0001) {",
      "    dir = vec2(1.0, 0.0);",
      "  } else {",
      "    dir = dir / len;",
      "  }",
      "  vec2 normal = vec2(-dir.y, dir.x);",
      "  vec2 pixelOffset = normal * (a_side * a_width * 0.5);",
      "  vec2 ndcOffset = pixelOffset / max(u_viewport * 0.5, vec2(0.0001));",
      "  vec2 clipOffset = ndcOffset * base.w;",
      "  gl_Position = base + vec4(clipOffset, 0.0, 0.0);",
      "  v_color = mix(a_colorA, a_colorB, a_endpoint);",
      "}",
    ].join("\n");

    const fragmentSource = [
      "precision mediump float;",
      "varying vec4 v_color;",
      "void main() {",
      "  gl_FragColor = vec4(clamp(v_color.rgb, 0.0, 1.0), clamp(v_color.a, 0.0, 1.0));",
      "}",
    ].join("\n");

    const vertexShader = createSceneShader(gl, gl.VERTEX_SHADER, vertexSource);
    const fragmentShader = createSceneShader(gl, gl.FRAGMENT_SHADER, fragmentSource);
    if (!vertexShader || !fragmentShader) {
      return null;
    }
    const program = gl.createProgram();
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      console.warn("[gosx] Scene3D thick-line link failed");
      return null;
    }
    return {
      program,
      positionALocation: gl.getAttribLocation(program, "a_positionA"),
      positionBLocation: gl.getAttribLocation(program, "a_positionB"),
      colorALocation: gl.getAttribLocation(program, "a_colorA"),
      colorBLocation: gl.getAttribLocation(program, "a_colorB"),
      sideLocation: gl.getAttribLocation(program, "a_side"),
      endpointLocation: gl.getAttribLocation(program, "a_endpoint"),
      widthLocation: gl.getAttribLocation(program, "a_width"),
      cameraLocation: gl.getUniformLocation(program, "u_camera"),
      cameraRotationLocation: gl.getUniformLocation(program, "u_camera_rotation"),
      aspectLocation: gl.getUniformLocation(program, "u_aspect"),
      viewportLocation: gl.getUniformLocation(program, "u_viewport"),
      cameraModeLocation: gl.getUniformLocation(program, "u_camera_mode"),
      orthoLocation: gl.getUniformLocation(program, "u_ortho"),
    };
  }

  function createSceneThickLineScratch() {
    return {
      segmentCapacity: 0,
      positionsA: new Float32Array(0),
      positionsB: new Float32Array(0),
      colorsA: new Float32Array(0),
      colorsB: new Float32Array(0),
      sides: new Float32Array(0),
      endpoints: new Float32Array(0),
      widths: new Float32Array(0),
      opaqueIndices: new Uint16Array(0),
      alphaIndices: new Uint16Array(0),
      additiveIndices: new Uint16Array(0),
      opaqueIndexCount: 0,
      alphaIndexCount: 0,
      additiveIndexCount: 0,
    };
  }

  function ensureSceneThickLineScratchCapacity(scratch, segmentCount) {
    if (scratch.segmentCapacity >= segmentCount) {
      return;
    }
    const nextCapacity = Math.max(64, Math.max(scratch.segmentCapacity * 2, segmentCount));
    const totalVerts = nextCapacity * 4;
    scratch.positionsA = new Float32Array(totalVerts * 3);
    scratch.positionsB = new Float32Array(totalVerts * 3);
    scratch.colorsA = new Float32Array(totalVerts * 4);
    scratch.colorsB = new Float32Array(totalVerts * 4);
    scratch.sides = new Float32Array(totalVerts);
    scratch.endpoints = new Float32Array(totalVerts);
    scratch.widths = new Float32Array(totalVerts);
    scratch.opaqueIndices = new Uint16Array(nextCapacity * 6);
    scratch.alphaIndices = new Uint16Array(nextCapacity * 6);
    scratch.additiveIndices = new Uint16Array(nextCapacity * 6);
    scratch.segmentCapacity = nextCapacity;
  }

  const _thickLineQuadEndpoints = [0, 0, 1, 1];
  const _thickLineQuadSides = [-1, 1, 1, -1];

  function expandSceneThickLineIntoScratch(scratch, worldPositions, worldColors, worldLineWidths, worldLinePasses, segmentCount) {
    const safeCount = Math.min(segmentCount, 16384);
    ensureSceneThickLineScratchCapacity(scratch, safeCount);

    const positionsA = scratch.positionsA;
    const positionsB = scratch.positionsB;
    const colorsA = scratch.colorsA;
    const colorsB = scratch.colorsB;
    const sides = scratch.sides;
    const endpoints = scratch.endpoints;
    const widths = scratch.widths;
    const opaqueIndices = scratch.opaqueIndices;
    const alphaIndices = scratch.alphaIndices;
    const additiveIndices = scratch.additiveIndices;

    let opaqueIdx = 0;
    let alphaIdx = 0;
    let additiveIdx = 0;

    for (let seg = 0; seg < safeCount; seg += 1) {
      const posOffset = seg * 6;
      const colorOffset = seg * 8;
      const ax = worldPositions[posOffset];
      const ay = worldPositions[posOffset + 1];
      const az = worldPositions[posOffset + 2];
      const bx = worldPositions[posOffset + 3];
      const by = worldPositions[posOffset + 4];
      const bz = worldPositions[posOffset + 5];
      const caR = worldColors[colorOffset];
      const caG = worldColors[colorOffset + 1];
      const caB = worldColors[colorOffset + 2];
      const caA = worldColors[colorOffset + 3];
      const cbR = worldColors[colorOffset + 4];
      const cbG = worldColors[colorOffset + 5];
      const cbB = worldColors[colorOffset + 6];
      const cbA = worldColors[colorOffset + 7];
      const width = (worldLineWidths && worldLineWidths[seg] > 0) ? worldLineWidths[seg] : 1;

      for (let corner = 0; corner < 4; corner += 1) {
        const vi = seg * 4 + corner;
        const p3 = vi * 3;
        const p4 = vi * 4;
        positionsA[p3] = ax;
        positionsA[p3 + 1] = ay;
        positionsA[p3 + 2] = az;
        positionsB[p3] = bx;
        positionsB[p3 + 1] = by;
        positionsB[p3 + 2] = bz;
        colorsA[p4] = caR;
        colorsA[p4 + 1] = caG;
        colorsA[p4 + 2] = caB;
        colorsA[p4 + 3] = caA;
        colorsB[p4] = cbR;
        colorsB[p4 + 1] = cbG;
        colorsB[p4 + 2] = cbB;
        colorsB[p4 + 3] = cbA;
        sides[vi] = _thickLineQuadSides[corner];
        endpoints[vi] = _thickLineQuadEndpoints[corner];
        widths[vi] = width;
      }

      const base = seg * 4;
      const pass = (worldLinePasses && seg < worldLinePasses.length) ? worldLinePasses[seg] : 0;
      if (pass === 2) {
        additiveIndices[additiveIdx] = base;
        additiveIndices[additiveIdx + 1] = base + 1;
        additiveIndices[additiveIdx + 2] = base + 2;
        additiveIndices[additiveIdx + 3] = base;
        additiveIndices[additiveIdx + 4] = base + 2;
        additiveIndices[additiveIdx + 5] = base + 3;
        additiveIdx += 6;
      } else if (pass === 1) {
        alphaIndices[alphaIdx] = base;
        alphaIndices[alphaIdx + 1] = base + 1;
        alphaIndices[alphaIdx + 2] = base + 2;
        alphaIndices[alphaIdx + 3] = base;
        alphaIndices[alphaIdx + 4] = base + 2;
        alphaIndices[alphaIdx + 5] = base + 3;
        alphaIdx += 6;
      } else {
        opaqueIndices[opaqueIdx] = base;
        opaqueIndices[opaqueIdx + 1] = base + 1;
        opaqueIndices[opaqueIdx + 2] = base + 2;
        opaqueIndices[opaqueIdx + 3] = base;
        opaqueIndices[opaqueIdx + 4] = base + 2;
        opaqueIndices[opaqueIdx + 5] = base + 3;
        opaqueIdx += 6;
      }
    }

    scratch.opaqueIndexCount = opaqueIdx;
    scratch.alphaIndexCount = alphaIdx;
    scratch.additiveIndexCount = additiveIdx;
    return safeCount;
  }

  function createSceneThickLineBufferSet(gl) {
    return {
      positionA: gl.createBuffer(),
      positionB: gl.createBuffer(),
      colorA: gl.createBuffer(),
      colorB: gl.createBuffer(),
      side: gl.createBuffer(),
      endpoint: gl.createBuffer(),
      width: gl.createBuffer(),
      opaqueIndex: gl.createBuffer(),
      alphaIndex: gl.createBuffer(),
      additiveIndex: gl.createBuffer(),
    };
  }

  function uploadSceneThickLineBuffers(gl, resources, scratch, segmentCount) {
    const buffers = resources.thickLineBuffers;
    const arrayBuffer = resources.arrayBuffer;
    const elementArrayBuffer = typeof gl.ELEMENT_ARRAY_BUFFER === "number" ? gl.ELEMENT_ARRAY_BUFFER : 0x8893;
    const usedVerts = segmentCount * 4;

    gl.bindBuffer(arrayBuffer, buffers.positionA);
    gl.bufferData(arrayBuffer, scratch.positionsA.subarray(0, usedVerts * 3), resources.dynamicDraw);
    gl.bindBuffer(arrayBuffer, buffers.positionB);
    gl.bufferData(arrayBuffer, scratch.positionsB.subarray(0, usedVerts * 3), resources.dynamicDraw);
    gl.bindBuffer(arrayBuffer, buffers.colorA);
    gl.bufferData(arrayBuffer, scratch.colorsA.subarray(0, usedVerts * 4), resources.dynamicDraw);
    gl.bindBuffer(arrayBuffer, buffers.colorB);
    gl.bufferData(arrayBuffer, scratch.colorsB.subarray(0, usedVerts * 4), resources.dynamicDraw);
    gl.bindBuffer(arrayBuffer, buffers.side);
    gl.bufferData(arrayBuffer, scratch.sides.subarray(0, usedVerts), resources.dynamicDraw);
    gl.bindBuffer(arrayBuffer, buffers.endpoint);
    gl.bufferData(arrayBuffer, scratch.endpoints.subarray(0, usedVerts), resources.dynamicDraw);
    gl.bindBuffer(arrayBuffer, buffers.width);
    gl.bufferData(arrayBuffer, scratch.widths.subarray(0, usedVerts), resources.dynamicDraw);

    if (scratch.opaqueIndexCount > 0) {
      gl.bindBuffer(elementArrayBuffer, buffers.opaqueIndex);
      gl.bufferData(elementArrayBuffer, scratch.opaqueIndices.subarray(0, scratch.opaqueIndexCount), resources.dynamicDraw);
    }
    if (scratch.alphaIndexCount > 0) {
      gl.bindBuffer(elementArrayBuffer, buffers.alphaIndex);
      gl.bufferData(elementArrayBuffer, scratch.alphaIndices.subarray(0, scratch.alphaIndexCount), resources.dynamicDraw);
    }
    if (scratch.additiveIndexCount > 0) {
      gl.bindBuffer(elementArrayBuffer, buffers.additiveIndex);
      gl.bufferData(elementArrayBuffer, scratch.additiveIndices.subarray(0, scratch.additiveIndexCount), resources.dynamicDraw);
    }
  }

  function drawSceneThickLines(gl, bundle, canvas, resources) {
    const thickProgram = resources.thickLineProgram;
    if (!thickProgram || !thickProgram.program) {
      return false;
    }
    const widths = bundle && bundle.worldLineWidths;
    const passes = bundle && bundle.worldLinePasses;
    const vertexCount = Math.floor(sceneNumber(bundle && bundle.worldVertexCount, 0));
    const segmentCount = Math.floor(vertexCount / 2);
    if (segmentCount <= 0 || !bundle.worldPositions || !bundle.worldColors) {
      return false;
    }
    if (segmentCount > 16384) {
      return false;
    }

    const scratch = resources.thickLineScratch;
    const usedSegments = expandSceneThickLineIntoScratch(scratch, bundle.worldPositions, bundle.worldColors, widths, passes, segmentCount);
    uploadSceneThickLineBuffers(gl, resources, scratch, usedSegments);

    gl.useProgram(thickProgram.program);

    const camera = sceneRenderCamera(bundle && bundle.camera);
    if (thickProgram.cameraLocation && typeof gl.uniform4f === "function") {
      gl.uniform4f(thickProgram.cameraLocation, camera.x, camera.y, camera.z, camera.fov);
    }
    if (thickProgram.cameraRotationLocation && typeof gl.uniform3f === "function") {
      gl.uniform3f(thickProgram.cameraRotationLocation, camera.rotationX, camera.rotationY, camera.rotationZ);
    }
    if (thickProgram.aspectLocation && typeof gl.uniform1f === "function") {
      const aspect = Math.max(0.0001, canvas.width / Math.max(1, canvas.height));
      gl.uniform1f(thickProgram.aspectLocation, aspect);
    }
    if (thickProgram.viewportLocation && typeof gl.uniform2f === "function") {
      gl.uniform2f(thickProgram.viewportLocation, canvas.width, canvas.height);
    }
    if (thickProgram.cameraModeLocation && typeof gl.uniform1f === "function") {
      gl.uniform1f(thickProgram.cameraModeLocation, camera.kind === "orthographic" ? 1 : 0);
    }
    if (thickProgram.orthoLocation && typeof gl.uniform4f === "function") {
      const bounds = sceneOrthographicBounds(camera, canvas.width, canvas.height);
      gl.uniform4f(thickProgram.orthoLocation, bounds.left, bounds.right, bounds.top, bounds.bottom);
    }

    const arrayBuffer = resources.arrayBuffer;
    const floatType = resources.floatType;
    const buffers = resources.thickLineBuffers;

    gl.bindBuffer(arrayBuffer, buffers.positionA);
    gl.enableVertexAttribArray(thickProgram.positionALocation);
    gl.vertexAttribPointer(thickProgram.positionALocation, 3, floatType, false, 0, 0);

    gl.bindBuffer(arrayBuffer, buffers.positionB);
    gl.enableVertexAttribArray(thickProgram.positionBLocation);
    gl.vertexAttribPointer(thickProgram.positionBLocation, 3, floatType, false, 0, 0);

    gl.bindBuffer(arrayBuffer, buffers.colorA);
    gl.enableVertexAttribArray(thickProgram.colorALocation);
    gl.vertexAttribPointer(thickProgram.colorALocation, 4, floatType, false, 0, 0);

    gl.bindBuffer(arrayBuffer, buffers.colorB);
    gl.enableVertexAttribArray(thickProgram.colorBLocation);
    gl.vertexAttribPointer(thickProgram.colorBLocation, 4, floatType, false, 0, 0);

    gl.bindBuffer(arrayBuffer, buffers.side);
    gl.enableVertexAttribArray(thickProgram.sideLocation);
    gl.vertexAttribPointer(thickProgram.sideLocation, 1, floatType, false, 0, 0);

    gl.bindBuffer(arrayBuffer, buffers.endpoint);
    gl.enableVertexAttribArray(thickProgram.endpointLocation);
    gl.vertexAttribPointer(thickProgram.endpointLocation, 1, floatType, false, 0, 0);

    gl.bindBuffer(arrayBuffer, buffers.width);
    gl.enableVertexAttribArray(thickProgram.widthLocation);
    gl.vertexAttribPointer(thickProgram.widthLocation, 1, floatType, false, 0, 0);

    const elementArrayBuffer = typeof gl.ELEMENT_ARRAY_BUFFER === "number" ? gl.ELEMENT_ARRAY_BUFFER : 0x8893;
    const unsignedShort = typeof gl.UNSIGNED_SHORT === "number" ? gl.UNSIGNED_SHORT : 0x1403;

    if (scratch.opaqueIndexCount > 0) {
      applySceneWebGLDepth(gl, "opaque", resources.stateCache);
      applySceneWebGLBlend(gl, "opaque", resources.stateCache);
      gl.bindBuffer(elementArrayBuffer, buffers.opaqueIndex);
      gl.drawElements(resources.trianglesMode, scratch.opaqueIndexCount, unsignedShort, 0);
    }
    if (scratch.alphaIndexCount > 0) {
      applySceneWebGLDepth(gl, "translucent", resources.stateCache);
      applySceneWebGLBlend(gl, "alpha", resources.stateCache);
      gl.bindBuffer(elementArrayBuffer, buffers.alphaIndex);
      gl.drawElements(resources.trianglesMode, scratch.alphaIndexCount, unsignedShort, 0);
    }
    if (scratch.additiveIndexCount > 0) {
      applySceneWebGLDepth(gl, "translucent", resources.stateCache);
      applySceneWebGLBlend(gl, "additive", resources.stateCache);
      gl.bindBuffer(elementArrayBuffer, buffers.additiveIndex);
      gl.drawElements(resources.trianglesMode, scratch.additiveIndexCount, unsignedShort, 0);
    }
    return true;
  }

  function sceneBundleNeedsThickLines(bundle) {
    const widths = bundle && bundle.worldLineWidths;
    if (!widths || !widths.length) {
      return false;
    }
    for (let i = 0; i < widths.length; i += 1) {
      if (widths[i] > 1) {
        return true;
      }
    }
    return false;
  }

  if (typeof window !== "undefined" && window.__gosx_runtime_api) {
    window.__gosx_runtime_api.browserCapabilitySupported = browserCapabilitySupported;
    window.__gosx_runtime_api.runtimeCapabilityStatus = runtimeCapabilityStatus;
    window.__gosx_runtime_api.engineCapabilityStatus = engineCapabilityStatus;
  }

  window.__gosx_scene3d_api = {
    appendSceneObjectToBundle,
    appendSceneSurfaceToBundle,
    applySceneCommands,
    cancelEngineFrame,
    clearChildren,
    createSceneRenderBundle,
    sceneSelectLODObjects,
    SCENE_IR_VERSION: 1,
    SCENE_RENDER_BUNDLE_VERSION: 1,
    SCENE_POST_TONE_MAPPING: "toneMapping",
    SCENE_POST_BLOOM: "bloom",
    SCENE_POST_VIGNETTE: "vignette",
    SCENE_POST_COLOR_GRADE: "colorGrade",
    SCENE_POST_SSAO: "ssao",
    SCENE_POST_DOF: "dof",
    validateSceneIR: typeof validateSceneIR === "function" ? validateSceneIR : undefined,
    prepareScene: typeof prepareScene === "function" ? prepareScene : undefined,
    scenePreparedCommandSequence: typeof scenePreparedCommandSequence === "function" ? scenePreparedCommandSequence : undefined,
    sceneCachedBuffer: typeof sceneCachedBuffer === "function" ? sceneCachedBuffer : undefined,
    sceneWebGLCommandSequence: typeof sceneWebGLCommandSequence === "function" ? sceneWebGLCommandSequence : undefined,
    sceneWebGPUCommandSequence: typeof sceneWebGPUCommandSequence === "function" ? sceneWebGPUCommandSequence : undefined,
    sceneBackendRegistry: undefined,
    createSceneState,
    createSceneParticleSystem: typeof createSceneParticleSystem === "function" ? createSceneParticleSystem : undefined,
    sceneStatePointsWithMaterials,
    createSceneWebGLRenderer,
    engineFrame,
    normalizeSceneEnvironment,
    normalizeSceneHTML,
    normalizeSceneLabel,
    normalizeSceneLabelAlign,
    normalizeSceneLabelCollision,
    normalizeSceneLabelWhiteSpace,
    normalizeSceneLight,
    normalizeSceneObject,
    normalizeSceneSprite,
    normalizeSceneSpriteFit,
    listSceneMaterialProfiles: typeof listSceneMaterialProfiles === "function" ? listSceneMaterialProfiles : undefined,
    listSceneParticleForces: typeof listSceneParticleForces === "function" ? listSceneParticleForces : undefined,
    registerSceneMaterialProfile: typeof registerSceneMaterialProfile === "function" ? registerSceneMaterialProfile : undefined,
    registerSceneParticleForce: typeof registerSceneParticleForce === "function" ? registerSceneParticleForce : undefined,
    registerSceneParticleForceKind: typeof registerSceneParticleForceKind === "function" ? registerSceneParticleForceKind : undefined,
    sceneComputeSystemSignature: typeof sceneComputeSystemSignature === "function" ? sceneComputeSystemSignature : undefined,
    sceneMaterialShaderData: typeof sceneMaterialShaderData === "function" ? sceneMaterialShaderData : undefined,
    unregisterSceneMaterialProfile: typeof unregisterSceneMaterialProfile === "function" ? unregisterSceneMaterialProfile : undefined,
    unregisterSceneParticleForce: typeof unregisterSceneParticleForce === "function" ? unregisterSceneParticleForce : undefined,
    publishPointerSignals,
    queueInputSignal,
    sceneAdvanceTransitions,
    sceneApplyLiveEvent,
    sceneBool,
    sceneBoundsDepthMetrics,
    sceneBoundsViewCulled,
    buildSceneWorldDrawPlan: typeof buildSceneWorldDrawPlan === "function" ? buildSceneWorldDrawPlan : undefined,
    createSceneWorldDrawScratch: typeof createSceneWorldDrawScratch === "function" ? createSceneWorldDrawScratch : undefined,
    createSceneThickLineScratch: typeof createSceneThickLineScratch === "function" ? createSceneThickLineScratch : undefined,
    expandSceneThickLineIntoScratch: typeof expandSceneThickLineIntoScratch === "function" ? expandSceneThickLineIntoScratch : undefined,
    sceneBundleNeedsThickLines,
    sceneCameraEquivalent,
    sceneOrthographicBounds,
    clamp01,
    sceneHasActiveTransitions,
    sceneHTMLAnimated,
    sceneLabelAnimated,
    sceneMeshMaterialArray,
    sceneModels,
    sceneNormalizeDirection,
    sceneNowMilliseconds,
    sceneNumber,
    sceneObjectAnimated,
    scenePointStyleCode,
    scenePrimeInitialTransitions,
    sceneProps,
    sceneRenderCamera,
    sceneResolveLightingEnvironment,
    sceneSpriteAnimated,
    sceneStateLabels,
    sceneStateHTML,
    sceneStateLights,
    sceneStateObjects,
    sceneStateSprites,
    sceneTypedFloatArray,
    translateScenePointInto,

    scenePBRDepthSort: typeof scenePBRDepthSort === "function" ? scenePBRDepthSort : undefined,
    scenePBRObjectRenderPass: typeof scenePBRObjectRenderPass === "function" ? scenePBRObjectRenderPass : undefined,
    scenePBRProjectionMatrix: typeof scenePBRProjectionMatrix === "function" ? scenePBRProjectionMatrix : undefined,
    scenePBRProjectionMatrixForCamera: typeof scenePBRProjectionMatrixForCamera === "function" ? scenePBRProjectionMatrixForCamera : undefined,
    scenePBRViewMatrix: typeof scenePBRViewMatrix === "function" ? scenePBRViewMatrix : undefined,
    sceneShadowLightSpaceMatrix: typeof sceneShadowLightSpaceMatrix === "function" ? sceneShadowLightSpaceMatrix : undefined,
    sceneShadowComputeBounds: typeof sceneShadowComputeBounds === "function" ? sceneShadowComputeBounds : undefined,
    generateInstancedGeometry: typeof generateInstancedGeometry === "function" ? generateInstancedGeometry : undefined,

    resolvePostFXFactor: typeof resolvePostFXFactor === "function" ? resolvePostFXFactor : undefined,
    resolveShadowSize: typeof resolveShadowSize === "function" ? resolveShadowSize : undefined,

    sceneColorRGBA: typeof sceneColorRGBA === "function" ? sceneColorRGBA : undefined,
  };

  function sceneClamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function sceneAddPoint(left, right) {
    return {
      x: sceneNumber(left && left.x, 0) + sceneNumber(right && right.x, 0),
      y: sceneNumber(left && left.y, 0) + sceneNumber(right && right.y, 0),
      z: sceneNumber(left && left.z, 0) + sceneNumber(right && right.z, 0),
    };
  }

  function sceneScalePoint(point, scale) {
    return {
      x: sceneNumber(point && point.x, 0) * scale,
      y: sceneNumber(point && point.y, 0) * scale,
      z: sceneNumber(point && point.z, 0) * scale,
    };
  }

  function sceneMultiplyPoint(left, right) {
    return {
      x: sceneNumber(left && left.x, 0) * sceneNumber(right && right.x, 0),
      y: sceneNumber(left && left.y, 0) * sceneNumber(right && right.y, 0),
      z: sceneNumber(left && left.z, 0) * sceneNumber(right && right.z, 0),
    };
  }

  function scenePointLength(point) {
    var px = sceneNumber(point && point.x, 0);
    var py = sceneNumber(point && point.y, 0);
    var pz = sceneNumber(point && point.z, 0);
    return Math.sqrt(px * px + py * py + pz * pz);
  }

  function sceneNormalizePoint(point) {
    const length = scenePointLength(point);
    if (length <= 0.000001) {
      return { x: 0, y: 0, z: 0 };
    }
    return sceneScalePoint(point, 1 / length);
  }

  function sceneDotPoint(left, right) {
    return (
      sceneNumber(left && left.x, 0) * sceneNumber(right && right.x, 0) +
      sceneNumber(left && left.y, 0) * sceneNumber(right && right.y, 0) +
      sceneNumber(left && left.z, 0) * sceneNumber(right && right.z, 0)
    );
  }

  function sceneRotatePoint(point, rotationX, rotationY, rotationZ) {
    let x = point.x;
    let y = point.y;
    let z = point.z;

    const sinX = Math.sin(rotationX);
    const cosX = Math.cos(rotationX);
    let nextY = y * cosX - z * sinX;
    let nextZ = y * sinX + z * cosX;
    y = nextY;
    z = nextZ;

    const sinY = Math.sin(rotationY);
    const cosY = Math.cos(rotationY);
    let nextX = x * cosY + z * sinY;
    nextZ = -x * sinY + z * cosY;
    x = nextX;
    z = nextZ;

    const sinZ = Math.sin(rotationZ);
    const cosZ = Math.cos(rotationZ);
    nextX = x * cosZ - y * sinZ;
    nextY = x * sinZ + y * cosZ;

    return { x: nextX, y: nextY, z: z };
  }

  function sceneInverseRotatePoint(point, rotationX, rotationY, rotationZ) {
    let x = sceneNumber(point && point.x, 0);
    let y = sceneNumber(point && point.y, 0);
    let z = sceneNumber(point && point.z, 0);

    const sinZ = Math.sin(-rotationZ);
    const cosZ = Math.cos(-rotationZ);
    let nextX = x * cosZ - y * sinZ;
    let nextY = x * sinZ + y * cosZ;
    x = nextX;
    y = nextY;

    const sinY = Math.sin(-rotationY);
    const cosY = Math.cos(-rotationY);
    nextX = x * cosY + z * sinY;
    let nextZ = -x * sinY + z * cosY;
    x = nextX;
    z = nextZ;

    const sinX = Math.sin(-rotationX);
    const cosX = Math.cos(-rotationX);
    nextY = y * cosX - z * sinX;
    nextZ = y * sinX + z * cosX;
    return { x, y: nextY, z: nextZ };
  }

  const _sceneProjectCameraScratch = {
    kind: "perspective",
    x: 0, y: 0, z: 0,
    rotationX: 0, rotationY: 0, rotationZ: 0,
    left: 0, right: 0, top: 0, bottom: 0, zoom: 1,
    fov: 0, near: 0, far: 0,
  };

  function sceneProjectPoint(point, camera, width, height) {
    const cam = sceneRenderCamera(camera, _sceneProjectCameraScratch);

    let lx = sceneNumber(point && point.x, 0) - cam.x;
    let ly = sceneNumber(point && point.y, 0) - cam.y;
    let lz = sceneNumber(point && point.z, 0) + cam.z;

    const sinZ = Math.sin(-cam.rotationZ);
    const cosZ = Math.cos(-cam.rotationZ);
    let nextX = lx * cosZ - ly * sinZ;
    let nextY = lx * sinZ + ly * cosZ;
    lx = nextX;
    ly = nextY;

    const sinY = Math.sin(-cam.rotationY);
    const cosY = Math.cos(-cam.rotationY);
    nextX = lx * cosY + lz * sinY;
    let nextZ = -lx * sinY + lz * cosY;
    lx = nextX;
    lz = nextZ;

    const sinX = Math.sin(-cam.rotationX);
    const cosX = Math.cos(-cam.rotationX);
    nextY = ly * cosX - lz * sinX;
    nextZ = ly * sinX + lz * cosX;
    ly = nextY;
    lz = nextZ;

    if (lz <= cam.near || lz >= cam.far) return null;

    if (cam.kind === "orthographic") {
      const bounds = sceneOrthographicBounds(cam, width, height);
      const spanX = Math.max(0.000001, bounds.right - bounds.left);
      const spanY = Math.max(0.000001, bounds.top - bounds.bottom);
      return {
        x: ((lx - bounds.left) / spanX) * width,
        y: ((bounds.top - ly) / spanY) * height,
        depth: lz,
      };
    }

    const focal = (Math.min(width, height) / 2) / Math.tan((cam.fov * Math.PI) / 360);
    return {
      x: width / 2 + (lx * focal) / lz,
      y: height / 2 - (ly * focal) / lz,
      depth: lz,
    };
  }

  function sceneCameraLocalPoint(point, camera) {
    const normalizedCamera = sceneRenderCamera(camera);
    return sceneInverseRotatePoint({
      x: sceneNumber(point && point.x, 0) - normalizedCamera.x,
      y: sceneNumber(point && point.y, 0) - normalizedCamera.y,
      z: sceneNumber(point && point.z, 0) + normalizedCamera.z,
    }, normalizedCamera.rotationX, normalizedCamera.rotationY, normalizedCamera.rotationZ);
  }

  function sceneClipPoint(point, width, height) {
    return {
      x: (point.x / width) * 2 - 1,
      y: 1 - (point.y / height) * 2,
    };
  }

  function sceneSafeNormal(normal) {
    const normalized = sceneNormalizePoint(normal);
    return scenePointLength(normalized) > 0.0001 ? normalized : { x: 0, y: 1, z: 0 };
  }

  function sceneColorPoint(value, fallback) {
    const rgba = sceneColorRGBA(value, [sceneNumber(fallback && fallback.x, 1), sceneNumber(fallback && fallback.y, 1), sceneNumber(fallback && fallback.z, 1), 1]);
    return { x: rgba[0], y: rgba[1], z: rgba[2] };
  }

  function sceneRGBAString(rgba) {
    const color = Array.isArray(rgba) ? rgba : [0.55, 0.88, 1, 1];
    return "rgba(" +
      Math.round(clamp01(sceneNumber(color[0], 0.55)) * 255) + ", " +
      Math.round(clamp01(sceneNumber(color[1], 0.88)) * 255) + ", " +
      Math.round(clamp01(sceneNumber(color[2], 1)) * 255) + ", " +
      clamp01(sceneNumber(color[3], 1)).toFixed(3) + ")";
  }

  function sceneColorRGBA(value, fallback) {
    const base = Array.isArray(fallback) && fallback.length === 4 ? fallback.slice() : [0.55, 0.88, 1, 1];
    if (typeof value !== "string") {
      return base;
    }

    const trimmed = value.trim();
    const shortHex = trimmed.match(/^#([0-9a-f]{3})$/i);
    if (shortHex) {
      return [
        parseInt(shortHex[1][0] + shortHex[1][0], 16) / 255,
        parseInt(shortHex[1][1] + shortHex[1][1], 16) / 255,
        parseInt(shortHex[1][2] + shortHex[1][2], 16) / 255,
        1,
      ];
    }

    const fullHex = trimmed.match(/^#([0-9a-f]{6})$/i);
    if (fullHex) {
      return [
        parseInt(fullHex[1].slice(0, 2), 16) / 255,
        parseInt(fullHex[1].slice(2, 4), 16) / 255,
        parseInt(fullHex[1].slice(4, 6), 16) / 255,
        1,
      ];
    }

    const rgba = trimmed.match(/^rgba?\(([^)]+)\)$/i);
    if (rgba) {
      const parts = rgba[1].split(",").map(function(part) {
        return Number(part.trim());
      });
      if (parts.length >= 3 && parts.every(function(part, index) {
        return Number.isFinite(part) && (index < 3 || index === 3);
      })) {
        return [
          Math.max(0, Math.min(255, parts[0])) / 255,
          Math.max(0, Math.min(255, parts[1])) / 255,
          Math.max(0, Math.min(255, parts[2])) / 255,
          parts.length > 3 ? Math.max(0, Math.min(1, parts[3])) : 1,
        ];
      }
    }

    return base;
  }

  function sceneMixRGBA(left, right) {
    return [
      (sceneNumber(left && left[0], 0.55) + sceneNumber(right && right[0], 0.55)) / 2,
      (sceneNumber(left && left[1], 0.88) + sceneNumber(right && right[1], 0.88)) / 2,
      (sceneNumber(left && left[2], 1) + sceneNumber(right && right[2], 1)) / 2,
      (sceneNumber(left && left[3], 1) + sceneNumber(right && right[3], 1)) / 2,
    ];
  }

  function sceneDot3(ax, ay, az, bx, by, bz) {
    return ax * bx + ay * by + az * bz;
  }

  function sceneCross3Into(out, offset, ax, ay, az, bx, by, bz) {
    out[offset] = ay * bz - az * by;
    out[offset + 1] = az * bx - ax * bz;
    out[offset + 2] = ax * by - ay * bx;
  }

  function sceneNormalize3Into(out, offset, x, y, z) {
    var len = Math.sqrt(x * x + y * y + z * z);
    if (len < 1e-10) { out[offset] = 0; out[offset + 1] = 0; out[offset + 2] = 0; return 0; }
    var inv = 1 / len;
    out[offset] = x * inv; out[offset + 1] = y * inv; out[offset + 2] = z * inv;
    return len;
  }

  function sceneRayIntersectsAABB(rayOrigin, rayDir, boundsMin, boundsMax) {
    var tMin = -Infinity;
    var tMax = Infinity;

    for (var ai = 0; ai < 3; ai++) {
      var axis = ai === 0 ? "x" : ai === 1 ? "y" : "z";
      var origin = rayOrigin[axis];
      var dir = rayDir[axis];
      var min = boundsMin[axis];
      var max = boundsMax[axis];

      if (Math.abs(dir) < 1e-10) {
        if (origin < min || origin > max) return -1;
      } else {
        var t1 = (min - origin) / dir;
        var t2 = (max - origin) / dir;
        if (t1 > t2) { var tmp = t1; t1 = t2; t2 = tmp; }
        tMin = Math.max(tMin, t1);
        tMax = Math.min(tMax, t2);
        if (tMin > tMax) return -1;
      }
    }

    if (tMax < 0) return -1;
    return tMin >= 0 ? tMin : tMax;
  }

  function sceneRayIntersectsTriangle(rayOrigin, rayDir, v0, v1, v2) {
    var EPSILON = 1e-7;

    var rox = rayOrigin.x, roy = rayOrigin.y, roz = rayOrigin.z;
    var rdx = rayDir.x, rdy = rayDir.y, rdz = rayDir.z;
    var v0x = v0.x, v0y = v0.y, v0z = v0.z;

    var edge1x = v1.x - v0x, edge1y = v1.y - v0y, edge1z = v1.z - v0z;
    var edge2x = v2.x - v0x, edge2y = v2.y - v0y, edge2z = v2.z - v0z;

    var hx = rdy * edge2z - rdz * edge2y;
    var hy = rdz * edge2x - rdx * edge2z;
    var hz = rdx * edge2y - rdy * edge2x;

    var a = sceneDot3(edge1x, edge1y, edge1z, hx, hy, hz);
    if (a > -EPSILON && a < EPSILON) return null; // parallel

    var f = 1.0 / a;
    var sx = rox - v0x;
    var sy = roy - v0y;
    var sz = roz - v0z;

    var u = f * sceneDot3(sx, sy, sz, hx, hy, hz);
    if (u < 0.0 || u > 1.0) return null;

    var qx = sy * edge1z - sz * edge1y;
    var qy = sz * edge1x - sx * edge1z;
    var qz = sx * edge1y - sy * edge1x;

    var v = f * sceneDot3(rdx, rdy, rdz, qx, qy, qz);
    if (v < 0.0 || u + v > 1.0) return null;

    var t = f * sceneDot3(edge2x, edge2y, edge2z, qx, qy, qz);
    if (t < EPSILON) return null; // behind ray

    return { distance: t, u: u, v: v };
  }

  function clamp01(value) {
    return Math.max(0, Math.min(1, value));
  }

  var SCENE_IDENTITY_MAT4 = new Float32Array([
    1, 0, 0, 0,
    0, 1, 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1,
  ]);

  var _sceneMat4ScratchA = new Float32Array(16);
  var _sceneMat4ScratchB = new Float32Array(16);

  function sceneMat4Multiply(a, b) {
    var out = new Float32Array(16);
    for (var col = 0; col < 4; col++) {
      for (var row = 0; row < 4; row++) {
        out[col * 4 + row] =
          a[row]      * b[col * 4] +
          a[4 + row]  * b[col * 4 + 1] +
          a[8 + row]  * b[col * 4 + 2] +
          a[12 + row] * b[col * 4 + 3];
      }
    }
    return out;
  }

  function sceneMat4MultiplyInto(out, a, b) {
    for (var col = 0; col < 4; col++) {
      for (var row = 0; row < 4; row++) {
        out[col * 4 + row] =
          a[row]      * b[col * 4] +
          a[4 + row]  * b[col * 4 + 1] +
          a[8 + row]  * b[col * 4 + 2] +
          a[12 + row] * b[col * 4 + 3];
      }
    }
    return out;
  }

  function sceneTRSToMat4(t, r, s) {
    var out = new Float32Array(16);
    var x = r[0], y = r[1], z = r[2], w = r[3];
    var x2 = x + x, y2 = y + y, z2 = z + z;
    var xx = x * x2, xy = x * y2, xz = x * z2;
    var yy = y * y2, yz = y * z2, zz = z * z2;
    var wx = w * x2, wy = w * y2, wz = w * z2;

    out[0]  = (1 - (yy + zz)) * s[0]; out[1]  = (xy + wz) * s[0];       out[2]  = (xz - wy) * s[0];       out[3]  = 0;
    out[4]  = (xy - wz) * s[1];       out[5]  = (1 - (xx + zz)) * s[1]; out[6]  = (yz + wx) * s[1];       out[7]  = 0;
    out[8]  = (xz + wy) * s[2];       out[9]  = (yz - wx) * s[2];       out[10] = (1 - (xx + yy)) * s[2]; out[11] = 0;
    out[12] = t[0];                    out[13] = t[1];                    out[14] = t[2];                    out[15] = 1;

    return out;
  }

  function sceneTRSToMat4Into(out, t, r, s) {
    var x = r[0], y = r[1], z = r[2], w = r[3];
    var x2 = x + x, y2 = y + y, z2 = z + z;
    var xx = x * x2, xy = x * y2, xz = x * z2;
    var yy = y * y2, yz = y * z2, zz = z * z2;
    var wx = w * x2, wy = w * y2, wz = w * z2;

    out[0]  = (1 - (yy + zz)) * s[0]; out[1]  = (xy + wz) * s[0];       out[2]  = (xz - wy) * s[0];       out[3]  = 0;
    out[4]  = (xy - wz) * s[1];       out[5]  = (1 - (xx + zz)) * s[1]; out[6]  = (yz + wx) * s[1];       out[7]  = 0;
    out[8]  = (xz + wy) * s[2];       out[9]  = (yz - wx) * s[2];       out[10] = (1 - (xx + yy)) * s[2]; out[11] = 0;
    out[12] = t[0];                    out[13] = t[1];                    out[14] = t[2];                    out[15] = 1;

    return out;
  }

  var _animScratch3 = [0, 0, 0];
  var _animScratch4 = [0, 0, 0, 0];

  if (typeof window !== "undefined" && window.__gosx_scene3d_api) {
    Object.assign(window.__gosx_scene3d_api, {
      SCENE_IDENTITY_MAT4,
      sceneMat4Multiply,
      sceneMat4MultiplyInto,
      sceneTRSToMat4,
      sceneTRSToMat4Into,
      _sceneMat4ScratchA,
      _sceneMat4ScratchB,
      _animScratch3,
      _animScratch4,
    });
  }

  function sceneScreenToRay(pointerX, pointerY, width, height, camera) {
    var cam = sceneRenderCamera(camera);

    var origin = { x: cam.x, y: cam.y, z: -cam.z };
    if (cam.kind === "orthographic") {
      var bounds = sceneOrthographicBounds(cam, width, height);
      var spanX = Math.max(0.000001, bounds.right - bounds.left);
      var spanY = Math.max(0.000001, bounds.top - bounds.bottom);
      var localOrigin = {
        x: bounds.left + (pointerX / Math.max(1, width)) * spanX,
        y: bounds.top - (pointerY / Math.max(1, height)) * spanY,
        z: 0,
      };
      var localDir = { x: 0, y: 0, z: 1 };
      var worldOffset = sceneRotatePoint(localOrigin, cam.rotationX, cam.rotationY, cam.rotationZ);
      var worldDir = sceneRotatePoint(localDir, cam.rotationX, cam.rotationY, cam.rotationZ);
      var lenOrtho = Math.sqrt(worldDir.x * worldDir.x + worldDir.y * worldDir.y + worldDir.z * worldDir.z);
      return {
        origin: { x: origin.x + worldOffset.x, y: origin.y + worldOffset.y, z: origin.z + worldOffset.z },
        dir: lenOrtho < 1e-12
          ? { x: 0, y: 0, z: 1 }
          : { x: worldDir.x / lenOrtho, y: worldDir.y / lenOrtho, z: worldDir.z / lenOrtho },
      };
    }

    var halfFov = (cam.fov * Math.PI) / 360;
    var tanHalf = Math.tan(halfFov);
    var minDim = Math.min(width, height) / 2;
    var focal = minDim / tanHalf;

    var dirCam = {
      x: (pointerX - width / 2) / focal,
      y: (height / 2 - pointerY) / focal,
      z: 1.0,
    };

    var dirWorld = sceneRotatePoint(dirCam, cam.rotationX, cam.rotationY, cam.rotationZ);

    var len = Math.sqrt(dirWorld.x * dirWorld.x + dirWorld.y * dirWorld.y + dirWorld.z * dirWorld.z);
    if (len < 1e-12) {
      return { origin: origin, dir: { x: 0, y: 0, z: 1 } };
    }

    return {
      origin: origin,
      dir: { x: dirWorld.x / len, y: dirWorld.y / len, z: dirWorld.z / len },
    };
  }

  function sceneDecompressArray(chunks) {
    if (!Array.isArray(chunks) || chunks.length === 0) return null;
    var result = [];
    for (var ci = 0; ci < chunks.length; ci++) {
      var chunk = chunks[ci];
      var packed = chunk.packed;
      var minVal = chunk.norm;      // "norm" field stores the min value
      var maxVal = chunk.maxVal;
      var count = chunk.count;
      var bitWidth = chunk.bitWidth;

      if (!packed || count < 2) continue;

      var bytes;
      if (typeof packed === "string") {
        bytes = sceneBase64Decode(packed);
      } else if (packed instanceof Uint8Array) {
        bytes = packed;
      } else if (Array.isArray(packed)) {
        bytes = new Uint8Array(packed);
      } else {
        continue;
      }

      var levels = (1 << bitWidth) - 1;
      var step = levels > 0 ? (maxVal - minVal) / levels : 0;

      var indices = sceneUnpackIndices(bytes, count, bitWidth);
      for (var i = 0; i < count; i++) {
        result.push(minVal + indices[i] * step);
      }
    }
    return result.length > 0 ? result : null;
  }

  function sceneUnpackIndices(src, count, bitWidth) {
    var indices = new Int32Array(count);
    switch (bitWidth) {
      case 1:
        for (var i = 0; i < count; i++) {
          indices[i] = (src[i >> 3] >> (i & 7)) & 1;
        }
        break;
      case 2:
        for (var i = 0; i < count; i++) {
          indices[i] = (src[i >> 2] >> ((i & 3) * 2)) & 3;
        }
        break;
      case 4:
        for (var i = 0; i < count; i++) {
          indices[i] = (src[i >> 1] >> ((i & 1) * 4)) & 15;
        }
        break;
      case 8:
        for (var i = 0; i < count; i++) {
          indices[i] = src[i];
        }
        break;
      default:
        var bitPos = 0;
        var mask = (1 << bitWidth) - 1;
        for (var i = 0; i < count; i++) {
          var val = 0;
          for (var b = 0; b < bitWidth; b++) {
            if (src[bitPos >> 3] & (1 << (bitPos & 7))) {
              val |= 1 << b;
            }
            bitPos++;
          }
          indices[i] = val & mask;
        }
    }
    return indices;
  }

  function sceneBase64Decode(str) {
    if (typeof atob === "function") {
      var raw = atob(str);
      var bytes = new Uint8Array(raw.length);
      for (var i = 0; i < raw.length; i++) {
        bytes[i] = raw.charCodeAt(i);
      }
      return bytes;
    }
    if (typeof Buffer !== "undefined") {
      return new Uint8Array(Buffer.from(str, "base64"));
    }
    return new Uint8Array(0);
  }

  function sceneReinterleave(data, stride) {
    var n = data.length / stride;
    var out = new Array(data.length);
    for (var c = 0; c < stride; c++) {
      for (var i = 0; i < n; i++) {
        out[i * stride + c] = data[c * n + i];
      }
    }
    return out;
  }

  function sceneDecompressPointsEntry(entry) {
    if (entry.compressedPositions && !entry.positions) {
      entry.positions = sceneDecompressArray(entry.compressedPositions);
      if (entry.positions && entry.positionStride > 1) {
        entry.positions = sceneReinterleave(entry.positions, entry.positionStride);
      }
      if (entry.positions) {
        delete entry.compressedPositions;
      }
    }
    if (entry.compressedSizes && !entry.sizes) {
      entry.sizes = sceneDecompressArray(entry.compressedSizes);
      if (entry.sizes) {
        delete entry.compressedSizes;
      }
    }
  }

  function sceneDecompressInstancedMeshEntry(entry) {
    if (entry.compressedTransforms && !entry.transforms) {
      entry.transforms = sceneDecompressArray(entry.compressedTransforms);
      if (entry.transforms) {
        delete entry.compressedTransforms;
      }
    }
  }

  function sceneDecompressAnimationChannel(channel) {
    if (channel.compressedTimes && !channel.times) {
      channel.times = sceneDecompressArray(channel.compressedTimes);
      if (channel.times) {
        delete channel.compressedTimes;
      }
    }
    if (channel.compressedValues && !channel.values) {
      channel.values = sceneDecompressArray(channel.compressedValues);
      if (channel.values) {
        delete channel.compressedValues;
      }
    }
  }

  function sceneDecompressProps(props) {
    var scene = sceneProps(props);
    var comp = props && props.compression;
    var progressive = comp && comp.progressive;
    var lod = comp && comp.lod;
    var lodThreshold = comp && comp.lodThreshold || 20;

    var points = scene && Array.isArray(scene.points) ? scene.points :
                 (props && Array.isArray(props.points) ? props.points : []);
    for (var i = 0; i < points.length; i++) {
      var entry = points[i];
      if (progressive || lod) {
        if (entry.previewPositions && !entry.positions) {
          entry.positions = sceneDecompressArray(entry.previewPositions);
          if (entry.positions && entry.positionStride > 1) {
            entry.positions = sceneReinterleave(entry.positions, entry.positionStride);
          }
          entry._pendingPositions = entry.compressedPositions;
          entry._positionStride = entry.positionStride || 0;
          entry._previewActive = true;
          delete entry.previewPositions;
        }
        if (entry.previewSizes && !entry.sizes) {
          entry.sizes = sceneDecompressArray(entry.previewSizes);
          entry._pendingSizes = entry.compressedSizes;
          delete entry.previewSizes;
        }
        if (lod) {
          if (entry._pendingPositions) {
            entry._fullPositions = sceneDecompressArray(entry._pendingPositions);
            if (entry._fullPositions && entry._positionStride > 1) {
              entry._fullPositions = sceneReinterleave(entry._fullPositions, entry._positionStride);
            }
            entry._previewPositions = entry.positions;
            entry._lodThreshold = lodThreshold;
          }
        }
      } else {
        sceneDecompressPointsEntry(entry);
      }
    }

    var meshes = scene && Array.isArray(scene.instancedMeshes) ? scene.instancedMeshes :
                 (props && Array.isArray(props.instancedMeshes) ? props.instancedMeshes : []);
    for (var i = 0; i < meshes.length; i++) {
      var entry = meshes[i];
      if (progressive || lod) {
        if (entry.previewTransforms && !entry.transforms) {
          entry.transforms = sceneDecompressArray(entry.previewTransforms);
          entry._pendingTransforms = entry.compressedTransforms;
          entry._previewActive = true;
          delete entry.previewTransforms;
        }
        if (lod && entry._pendingTransforms) {
          entry._fullTransforms = sceneDecompressArray(entry._pendingTransforms);
          entry._previewTransforms = entry.transforms;
          entry._lodThreshold = lodThreshold;
        }
      } else {
        sceneDecompressInstancedMeshEntry(entry);
      }
    }

    var animations = scene && Array.isArray(scene.animations) ? scene.animations :
                     (props && Array.isArray(props.animations) ? props.animations : []);
    for (var i = 0; i < animations.length; i++) {
      var clip = animations[i];
      var channels = clip && Array.isArray(clip.channels) ? clip.channels : [];
      for (var j = 0; j < channels.length; j++) {
        var channel = channels[j];
        if (progressive || lod) {
          if (channel.previewTimes && !channel.times) {
            channel.times = sceneDecompressArray(channel.previewTimes);
            channel._pendingTimes = channel.compressedTimes;
            channel._previewActive = true;
            delete channel.previewTimes;
          }
          if (channel.previewValues && !channel.values) {
            channel.values = sceneDecompressArray(channel.previewValues);
            channel._pendingValues = channel.compressedValues;
            delete channel.previewValues;
          }
          if (!progressive) {
            sceneDecompressAnimationChannel(channel);
          }
        } else {
          sceneDecompressAnimationChannel(channel);
        }
      }
    }
  }

  function sceneUpgradeProgressive(props) {
    var scene = sceneProps(props);
    var points = scene && Array.isArray(scene.points) ? scene.points :
                 (props && Array.isArray(props.points) ? props.points : []);
    for (var i = 0; i < points.length; i++) {
      var entry = points[i];
      if (entry._pendingPositions) {
        entry.positions = sceneDecompressArray(entry._pendingPositions);
        if (entry.positions && entry._positionStride > 1) {
          entry.positions = sceneReinterleave(entry.positions, entry._positionStride);
        }
        delete entry._pendingPositions;
        delete entry._positionStride;
        delete entry._previewActive;
        delete entry._cachedPos;
      }
      if (entry._pendingSizes) {
        entry.sizes = sceneDecompressArray(entry._pendingSizes);
        delete entry._pendingSizes;
        delete entry._cachedSizes;
      }
    }
    var meshes = scene && Array.isArray(scene.instancedMeshes) ? scene.instancedMeshes :
                 (props && Array.isArray(props.instancedMeshes) ? props.instancedMeshes : []);
    for (var i = 0; i < meshes.length; i++) {
      var entry = meshes[i];
      if (entry._pendingTransforms) {
        entry.transforms = sceneDecompressArray(entry._pendingTransforms);
        delete entry._pendingTransforms;
        delete entry._previewActive;
      }
    }
    var animations = scene && Array.isArray(scene.animations) ? scene.animations :
                     (props && Array.isArray(props.animations) ? props.animations : []);
    for (var i = 0; i < animations.length; i++) {
      var clip = animations[i];
      var channels = clip && Array.isArray(clip.channels) ? clip.channels : [];
      for (var j = 0; j < channels.length; j++) {
        var channel = channels[j];
        if (channel._pendingTimes) {
          channel.times = sceneDecompressArray(channel._pendingTimes);
          delete channel._pendingTimes;
          delete channel._previewActive;
        }
        if (channel._pendingValues) {
          channel.values = sceneDecompressArray(channel._pendingValues);
          delete channel._pendingValues;
        }
      }
    }
  }

  function sceneApplyLOD(entry, cameraX, cameraY, cameraZ) {
    if (!entry._fullPositions || !entry._previewPositions) return;
    var dx = (entry.x || 0) - cameraX;
    var dy = (entry.y || 0) - cameraY;
    var dz = (entry.z || 0) - cameraZ;
    var dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
    var threshold = entry._lodThreshold || 20;
    var wantFull = dist < threshold;
    var hasFull = entry.positions === entry._fullPositions;
    if (wantFull && !hasFull) {
      entry.positions = entry._fullPositions;
      delete entry._cachedPos; // force buffer rebuild
    } else if (!wantFull && hasFull) {
      entry.positions = entry._previewPositions;
      delete entry._cachedPos;
    }
  }

  function sceneSegmentResolution(value) {
    const segments = Math.round(sceneNumber(value, 12));
    return Math.max(6, Math.min(24, segments));
  }

  function boxVertices(width, height, depth) {
    const halfWidth = width / 2;
    const halfHeight = height / 2;
    const halfDepth = depth / 2;
    return [
      { x: -halfWidth, y: -halfHeight, z: -halfDepth },
      { x: halfWidth, y: -halfHeight, z: -halfDepth },
      { x: halfWidth, y: halfHeight, z: -halfDepth },
      { x: -halfWidth, y: halfHeight, z: -halfDepth },
      { x: -halfWidth, y: -halfHeight, z: halfDepth },
      { x: halfWidth, y: -halfHeight, z: halfDepth },
      { x: halfWidth, y: halfHeight, z: halfDepth },
      { x: -halfWidth, y: halfHeight, z: halfDepth },
    ];
  }

  const boxEdgePairs = [
    [0, 1], [1, 2], [2, 3], [3, 0],
    [4, 5], [5, 6], [6, 7], [7, 4],
    [0, 4], [1, 5], [2, 6], [3, 7],
  ];

  function indexSegments(points, edgePairs) {
    return edgePairs.map(function(edge) {
      return [points[edge[0]], points[edge[1]]];
    });
  }

  function boxSegments(object) {
    return indexSegments(boxVertices(object.width, object.height, object.depth), boxEdgePairs);
  }

  function planeSegments(object) {
    const vertices = boxVertices(object.width, 0, object.depth);
    return indexSegments(vertices.slice(0, 4), [
      [0, 1], [1, 2], [2, 3], [3, 0],
    ]);
  }

  function pyramidSegments(object) {
    const halfWidth = object.width / 2;
    const halfDepth = object.depth / 2;
    const halfHeight = object.height / 2;
    const vertices = [
      { x: -halfWidth, y: -halfHeight, z: -halfDepth },
      { x: halfWidth, y: -halfHeight, z: -halfDepth },
      { x: halfWidth, y: -halfHeight, z: halfDepth },
      { x: -halfWidth, y: -halfHeight, z: halfDepth },
      { x: 0, y: halfHeight, z: 0 },
    ];
    return indexSegments(vertices, [
      [0, 1], [1, 2], [2, 3], [3, 0],
      [0, 4], [1, 4], [2, 4], [3, 4],
    ]);
  }

  function circleSegments(radius, axis, segments) {
    const points = [];
    for (let i = 0; i < segments; i += 1) {
      const angle = (Math.PI * 2 * i) / segments;
      points.push(circlePoint(radius, axis, angle));
    }
    const out = [];
    for (let i = 0; i < points.length; i += 1) {
      out.push([points[i], points[(i + 1) % points.length]]);
    }
    return out;
  }

  function circlePoint(radius, axis, angle) {
    const sin = Math.sin(angle) * radius;
    const cos = Math.cos(angle) * radius;
    switch (axis) {
      case "xy":
        return { x: cos, y: sin, z: 0 };
      case "yz":
        return { x: 0, y: cos, z: sin };
      default:
        return { x: cos, y: 0, z: sin };
    }
  }

  function sphereSegments(object) {
    return []
      .concat(circleSegments(object.radius, "xy", object.segments))
      .concat(circleSegments(object.radius, "xz", object.segments))
      .concat(circleSegments(object.radius, "yz", object.segments));
  }

  function lineSegments(object) {
    const points = Array.isArray(object && object.points) ? object.points : [];
    const segments = Array.isArray(object && object.lineSegments) ? object.lineSegments : [];
    const out = [];
    for (const pair of segments) {
      if (!Array.isArray(pair) || pair.length < 2) {
        continue;
      }
      const from = points[pair[0]];
      const to = points[pair[1]];
      if (!from || !to) {
        continue;
      }
      out.push([from, to]);
    }
    return out;
  }

  function sceneObjectSegments(object) {
    switch (object.kind) {
      case "box":
      case "cube":
        return boxSegments(object);
      case "lines":
        return lineSegments(object);
      case "plane":
        return planeSegments(object);
      case "pyramid":
        return pyramidSegments(object);
      case "sphere":
        return sphereSegments(object);
      default:
        return boxSegments(object);
    }
  }

  function scenePlaneLocalCorners(object) {
    return boxVertices(
      sceneNumber(object && object.width, 1),
      0,
      sceneNumber(object && object.depth, sceneNumber(object && object.height, 1)),
    ).slice(0, 4);
  }

  const _scenePlaneSurfaceCornersScratch = [
    { x: 0, y: 0, z: 0 },
    { x: 0, y: 0, z: 0 },
    { x: 0, y: 0, z: 0 },
    { x: 0, y: 0, z: 0 },
  ];

  function scenePlaneSurfaceCorners(object, timeSeconds) {
    const local = scenePlaneLocalCorners(object);
    const out = _scenePlaneSurfaceCornersScratch;
    for (let i = 0; i < 4; i += 1) {
      const p = local[i];
      translateScenePointInto(out[i], p && p.x, p && p.y, p && p.z, object, timeSeconds);
    }
    return out;
  }

  function scenePlaneSurfacePositions(corners) {
    if (!Array.isArray(corners) || corners.length < 4) {
      return [];
    }
    return [
      corners[0].x, corners[0].y, corners[0].z,
      corners[1].x, corners[1].y, corners[1].z,
      corners[2].x, corners[2].y, corners[2].z,
      corners[0].x, corners[0].y, corners[0].z,
      corners[2].x, corners[2].y, corners[2].z,
      corners[3].x, corners[3].y, corners[3].z,
    ];
  }

  function scenePlaneSurfaceUVs() {
    return [
      0, 1,
      1, 1,
      1, 0,
      0, 1,
      1, 0,
      0, 0,
    ];
  }

  var sceneMaterialProfileRegistry = Object.create(null);
  var sceneMaterialProfileRegistryVersion = 0;

  function sceneMaterialProfileKindKey(value) {
    const key = typeof value === "string" ? value.trim().toLowerCase() : "";
    return key && /^[a-z][a-z0-9_-]*$/.test(key) ? key : "";
  }

  function sceneMaterialProfileBlendMode(value) {
    const mode = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (mode) {
      case "opaque":
      case "solid":
        return "opaque";
      case "alpha":
      case "transparent":
      case "translucent":
        return "alpha";
      case "add":
      case "additive":
      case "glow":
      case "emissive":
        return "additive";
      default:
        return "";
    }
  }

  function sceneMaterialProfileRenderPass(value) {
    const pass = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (pass) {
      case "opaque":
      case "alpha":
      case "additive":
        return pass;
      case "add":
        return "additive";
      case "transparent":
      case "translucent":
        return "alpha";
      default:
        return "";
    }
  }

  function sceneNormalizeMaterialShaderData(values, fallback) {
    if (values && typeof values.length === "number" && values.length >= 3) {
      return [
        sceneNumber(values[0], fallback ? fallback[0] : 0),
        sceneNumber(values[1], fallback ? fallback[1] : 0),
        sceneNumber(values[2], fallback ? fallback[2] : 1),
      ];
    }
    return fallback ? fallback.slice(0, 3) : null;
  }

  function sceneRegisteredMaterialProfile(kind) {
    const key = sceneMaterialProfileKindKey(kind);
    return key && sceneMaterialProfileRegistry[key] || null;
  }

  function sceneMaterialProfileSnapshot(profile) {
    if (!profile) {
      return null;
    }
    return {
      kind: profile.kind,
      version: profile.version,
      opacity: profile.opacity,
      emissive: profile.emissive,
      blendMode: profile.blendMode,
      renderPass: profile.renderPass,
      shaderData: profile.shaderData ? profile.shaderData.slice(0, 3) : undefined,
      key: profile.key,
      dynamicShaderData: typeof profile.shaderDataFactory === "function",
    };
  }

  function registerSceneMaterialProfile(kind, profile) {
    const key = sceneMaterialProfileKindKey(kind);
    if (!key) {
      return null;
    }
    const src = profile && typeof profile === "object" ? profile : {};
    const record = {
      kind: key,
      version: sceneMaterialProfileRegistryVersion + 1,
      opacity: Object.prototype.hasOwnProperty.call(src, "opacity") ? clamp01(sceneNumber(src.opacity, 1)) : undefined,
      emissive: Object.prototype.hasOwnProperty.call(src, "emissive") ? clamp01(sceneNumber(src.emissive, 0)) : undefined,
      blendMode: sceneMaterialProfileBlendMode(src.blendMode),
      renderPass: sceneMaterialProfileRenderPass(src.renderPass),
      shaderData: typeof src.shaderData === "function" ? null : sceneNormalizeMaterialShaderData(src.shaderData, null),
      shaderDataFactory: typeof src.shaderData === "function" ? src.shaderData : null,
      key: typeof src.key === "string" ? src.key : "",
    };
    sceneMaterialProfileRegistryVersion = record.version;
    sceneMaterialProfileRegistry[key] = record;
    return sceneMaterialProfileSnapshot(record);
  }

  function unregisterSceneMaterialProfile(kind) {
    const key = sceneMaterialProfileKindKey(kind);
    if (!key || !sceneMaterialProfileRegistry[key]) {
      return false;
    }
    delete sceneMaterialProfileRegistry[key];
    sceneMaterialProfileRegistryVersion += 1;
    return true;
  }

  function listSceneMaterialProfiles() {
    return Object.keys(sceneMaterialProfileRegistry).sort().map(function(kind) {
      return sceneMaterialProfileSnapshot(sceneMaterialProfileRegistry[kind]);
    });
  }

  function normalizeSceneMaterialKind(value) {
    const kind = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (kind) {
      case "flat":
      case "ghost":
      case "glass":
      case "glow":
      case "matte":
      case "standard":
      case "custom":
      case "line-basic":
      case "line-dashed":
        return kind;
      default:
        if (sceneRegisteredMaterialProfile(kind)) {
          return kind;
        }
        return "flat";
    }
  }

  function sceneDefaultMaterialOpacity(kind) {
    const profile = sceneRegisteredMaterialProfile(kind);
    if (profile && profile.opacity !== undefined) {
      return profile.opacity;
    }
    switch (normalizeSceneMaterialKind(kind)) {
      case "ghost":
        return 0.42;
      case "glass":
        return 0.28;
      case "glow":
        return 0.92;
      default:
        return 1;
    }
  }

  function sceneDefaultMaterialEmissive(kind) {
    const profile = sceneRegisteredMaterialProfile(kind);
    if (profile && profile.emissive !== undefined) {
      return profile.emissive;
    }
    switch (normalizeSceneMaterialKind(kind)) {
      case "ghost":
        return 0.12;
      case "glass":
        return 0.08;
      case "glow":
        return 0.42;
      default:
        return 0;
    }
  }

  function sceneDefaultMaterialBlendMode(kind) {
    const profile = sceneRegisteredMaterialProfile(kind);
    if (profile && profile.blendMode) {
      return profile.blendMode;
    }
    switch (normalizeSceneMaterialKind(kind)) {
      case "ghost":
      case "glass":
        return "alpha";
      case "glow":
        return "additive";
      default:
        return "opaque";
    }
  }

  function normalizeSceneMaterialBlendMode(value, kind, opacity) {
    const mode = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (mode) {
      case "opaque":
      case "solid":
        return "opaque";
      case "alpha":
      case "transparent":
      case "translucent":
        return "alpha";
      case "add":
      case "additive":
      case "glow":
      case "emissive":
        return "additive";
      default: {
        const fallback = sceneDefaultMaterialBlendMode(kind);
        if (fallback !== "opaque") {
          return fallback;
        }
        return opacity < 0.999 ? "alpha" : "opaque";
      }
    }
  }

  function normalizeSceneMaterialRenderPass(value, blendMode, opacity, kind) {
    const pass = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (pass) {
      case "opaque":
      case "alpha":
      case "additive":
        return pass;
      case "add":
        return "additive";
      case "transparent":
      case "translucent":
        return "alpha";
      default:
        if (blendMode === "additive") {
          return "additive";
        }
        const profile = sceneRegisteredMaterialProfile(kind);
        if (profile && profile.renderPass) {
          return profile.renderPass;
        }
        return blendMode === "alpha" || opacity < 0.999 ? "alpha" : "opaque";
    }
  }

  function sceneObjectMaterialSource(item) {
    return item && item.material && typeof item.material === "object" ? item.material : null;
  }

  function sceneObjectMaterialKindValue(item) {
    if (!item || typeof item !== "object") {
      return "";
    }
    if (typeof item.material === "string" && item.material.trim()) {
      return item.material.trim();
    }
    if (typeof item.materialKind === "string" && item.materialKind.trim()) {
      return item.materialKind.trim();
    }
    const material = sceneObjectMaterialSource(item);
    if (material && typeof material.kind === "string" && material.kind.trim()) {
      return material.kind.trim();
    }
    return "";
  }

  function sceneObjectMaterialValue(item, name) {
    if (!item || typeof item !== "object") {
      return undefined;
    }
    const material = sceneObjectMaterialSource(item);
    if (material && Object.prototype.hasOwnProperty.call(material, name)) {
      return material[name];
    }
    return Object.prototype.hasOwnProperty.call(item, name) ? item[name] : undefined;
  }

  function sceneObjectMaterialHasValue(item, name) {
    if (!item || typeof item !== "object") {
      return false;
    }
    const material = sceneObjectMaterialSource(item);
    if (material && Object.prototype.hasOwnProperty.call(material, name)) {
      return true;
    }
    return Object.prototype.hasOwnProperty.call(item, name);
  }

  function sceneObjectBlendModeValue(item) {
    const direct = sceneObjectMaterialValue(item, "blendMode");
    if (direct !== undefined) {
      return direct;
    }
    const material = sceneObjectMaterialSource(item);
    if (material && Object.prototype.hasOwnProperty.call(material, "blend")) {
      return material.blend;
    }
    return item && Object.prototype.hasOwnProperty.call(item, "blend") ? item.blend : undefined;
  }

  function sceneObjectBlendModeHasValue(item) {
    if (!item || typeof item !== "object") {
      return false;
    }
    if (sceneObjectMaterialHasValue(item, "blendMode")) {
      return true;
    }
    const material = sceneObjectMaterialSource(item);
    if (material && Object.prototype.hasOwnProperty.call(material, "blend")) {
      return true;
    }
    return Object.prototype.hasOwnProperty.call(item, "blend");
  }

  function sceneObjectMaterialProfile(object) {
    const kind = normalizeSceneMaterialKind(object && object.materialKind);
    const opacity = clamp01(sceneNumber(object && object.opacity, sceneDefaultMaterialOpacity(kind)));
    const profile = {
      kind,
      color: object && typeof object.color === "string" && object.color ? object.color : "#8de1ff",
      texture: object && typeof object.texture === "string" ? object.texture.trim() : "",
      opacity,
      wireframe: sceneBool(object && object.wireframe, true),
      blendMode: normalizeSceneMaterialBlendMode(object && object.blendMode, kind, opacity),
      emissive: sceneCSSVarReference(object && object.emissive) ? String(object.emissive).trim() : clamp01(sceneNumber(object && object.emissive, sceneDefaultMaterialEmissive(kind))),
      roughness: sceneNumberOrCSSVar(object && object.roughness, 0.5),
      metalness: sceneNumberOrCSSVar(object && object.metalness, 0),
      clearcoat: sceneNumberOrCSSVar(object && object.clearcoat, 0),
      sheen: sceneNumberOrCSSVar(object && object.sheen, 0),
      transmission: sceneNumberOrCSSVar(object && object.transmission, 0),
      iridescence: sceneNumberOrCSSVar(object && object.iridescence, 0),
      anisotropy: sceneNumberOrCSSVar(object && object.anisotropy, 0),
      lineDash: sceneBool(object && object.lineDash, false),
      dashSize: sceneNumber(object && object.dashSize, 0),
      gapSize: sceneNumber(object && object.gapSize, 0),
      customVertex: typeof (object && object.customVertex) === "string" ? object.customVertex : "",
      customFragment: typeof (object && object.customFragment) === "string" ? object.customFragment : "",
      customVertexWGSL: typeof (object && object.customVertexWGSL) === "string" ? object.customVertexWGSL : "",
      customFragmentWGSL: typeof (object && object.customFragmentWGSL) === "string" ? object.customFragmentWGSL : "",
      customUniforms: object && object.customUniforms && typeof object.customUniforms === "object" ? Object.assign({}, object.customUniforms) : null,
      normalMap: object && typeof object.normalMap === "string" ? object.normalMap.trim() : "",
      roughnessMap: object && typeof object.roughnessMap === "string" ? object.roughnessMap.trim() : "",
      metalnessMap: object && typeof object.metalnessMap === "string" ? object.metalnessMap.trim() : "",
      emissiveMap: object && typeof object.emissiveMap === "string" ? object.emissiveMap.trim() : "",
    };
    profile.renderPass = normalizeSceneMaterialRenderPass(object && object.renderPass, profile.blendMode, profile.opacity, kind);
    profile.key = sceneMaterialProfileKey(profile);
    profile.shaderData = sceneMaterialShaderData(profile);
    return profile;
  }

  function sceneMaterialProfileKey(profile) {
    const registryProfile = sceneRegisteredMaterialProfile(profile && profile.kind);
    const parts = [
      normalizeSceneMaterialKind(profile && profile.kind),
      String(profile && profile.color || ""),
      String(profile && profile.texture || ""),
      clamp01(sceneNumber(profile && profile.opacity, 1)).toFixed(3),
      String(sceneBool(profile && profile.wireframe, true)),
      String(profile && profile.blendMode || "opaque"),
      String(profile && profile.renderPass || "opaque"),
      sceneCSSVarReference(profile && profile.emissive) ? String(profile.emissive).trim() : clamp01(sceneNumber(profile && profile.emissive, 0)).toFixed(3),
      sceneCSSVarReference(profile && profile.roughness) ? String(profile.roughness).trim() : sceneNumber(profile && profile.roughness, 0.5).toFixed(3),
      sceneCSSVarReference(profile && profile.metalness) ? String(profile.metalness).trim() : sceneNumber(profile && profile.metalness, 0).toFixed(3),
      sceneCSSVarReference(profile && profile.clearcoat) ? String(profile.clearcoat).trim() : sceneNumber(profile && profile.clearcoat, 0).toFixed(3),
      sceneCSSVarReference(profile && profile.sheen) ? String(profile.sheen).trim() : sceneNumber(profile && profile.sheen, 0).toFixed(3),
      sceneCSSVarReference(profile && profile.transmission) ? String(profile.transmission).trim() : sceneNumber(profile && profile.transmission, 0).toFixed(3),
      sceneCSSVarReference(profile && profile.iridescence) ? String(profile.iridescence).trim() : sceneNumber(profile && profile.iridescence, 0).toFixed(3),
      sceneCSSVarReference(profile && profile.anisotropy) ? String(profile.anisotropy).trim() : sceneNumber(profile && profile.anisotropy, 0).toFixed(3),
      String(sceneBool(profile && profile.lineDash, false)),
      sceneNumber(profile && profile.dashSize, 0).toFixed(3),
      sceneNumber(profile && profile.gapSize, 0).toFixed(3),
      String(profile && profile.customVertex || ""),
      String(profile && profile.customFragment || ""),
      String(profile && profile.customVertexWGSL || ""),
      String(profile && profile.customFragmentWGSL || ""),
      JSON.stringify(profile && profile.customUniforms || null),
      String(profile && profile.normalMap || ""),
      String(profile && profile.roughnessMap || ""),
      String(profile && profile.metalnessMap || ""),
      String(profile && profile.emissiveMap || ""),
    ];
    if (registryProfile) {
      parts.push("profile:" + registryProfile.version + ":" + String(registryProfile.key || ""));
    }
    return parts.join("|");
  }

  function sceneBundleMaterialIndex(bundle, materialLookup, profile) {
    if (!bundle || !Array.isArray(bundle.materials)) {
      return 0;
    }
    const key = profile && profile.key ? profile.key : sceneMaterialProfileKey(profile);
    if (materialLookup && materialLookup.has(key)) {
      return materialLookup.get(key);
    }
    const index = bundle.materials.length;
    bundle.materials.push(profile);
    if (materialLookup) {
      materialLookup.set(key, index);
    }
    return index;
  }

  function sceneMaterialStrokeColor(material) {
    const rgba = sceneColorRGBA(material && material.color, [0.55, 0.88, 1, 1]);
    rgba[3] = clamp01(rgba[3] * sceneMaterialOpacity(material));
    return "rgba(" +
      Math.round(rgba[0] * 255) + ", " +
      Math.round(rgba[1] * 255) + ", " +
      Math.round(rgba[2] * 255) + ", " +
      rgba[3].toFixed(3) + ")";
  }

  function sceneMaterialOpacity(material) {
    if (!material || typeof material !== "object") {
      return 1;
    }
    return clamp01(sceneNumber(material.opacity, 1));
  }

  function sceneMaterialEmissive(material) {
    if (!material || typeof material !== "object") {
      return 0;
    }
    return clamp01(sceneNumber(material.emissive, 0));
  }

  function sceneMaterialUsesAlpha(material) {
    return sceneMaterialRenderPass(material) !== "opaque";
  }

  function sceneMaterialRenderPass(material) {
    if (!material || typeof material !== "object") {
      return "opaque";
    }
    const renderPass = String(material.renderPass || "").toLowerCase();
    if (renderPass === "opaque" || renderPass === "alpha" || renderPass === "additive") {
      return renderPass;
    }
    const blendMode = String(material.blendMode || "").toLowerCase();
    if (blendMode === "additive") {
      return "additive";
    }
    if (blendMode === "alpha" || sceneMaterialOpacity(material) < 0.999) {
      return "alpha";
    }
    return "opaque";
  }

  function sceneMaterialShaderData(material) {
    if (material && Array.isArray(material.shaderData) && material.shaderData.length >= 3) {
      return material.shaderData;
    }
    if (!material || typeof material !== "object") {
      return [0, 0, 1];
    }
    const kind = String(material.kind || "").toLowerCase();
    const profile = sceneRegisteredMaterialProfile(kind);
    if (profile) {
      if (profile.shaderDataFactory) {
        return sceneNormalizeMaterialShaderData(profile.shaderDataFactory(material), [0, sceneMaterialEmissive(material), 1]);
      }
      if (profile.shaderData) {
        return sceneNormalizeMaterialShaderData(profile.shaderData, [0, sceneMaterialEmissive(material), 1]);
      }
    }
    switch (kind) {
    case "ghost":
      return [1, sceneMaterialEmissive(material), 0.3];
    case "glass":
      return [2, sceneMaterialEmissive(material), 0.7];
    case "glow":
      return [3, sceneMaterialEmissive(material), 1];
    case "matte":
      return [4, sceneMaterialEmissive(material), 0.2];
    default:
      return [0, sceneMaterialEmissive(material), 1];
    }
  }

  function sceneFallbackMaterialData(vertexCount) {
    const values = new Float32Array(vertexCount * 3);
    for (let i = 0; i < vertexCount; i += 1) {
      values[i * 3 + 2] = 1;
    }
    return values;
  }

  function sceneLightingActive(lights, environment) {
    return Boolean(
      (Array.isArray(lights) && lights.length > 0) ||
      sceneNumber(environment && environment.ambientIntensity, 0) > 0 ||
      sceneNumber(environment && environment.skyIntensity, 0) > 0 ||
      sceneNumber(environment && environment.groundIntensity, 0) > 0
    );
  }

  function sceneEnvironmentLightContribution(baseColor, normal, environment) {
    let lighting = { x: 0, y: 0, z: 0 };
    if (sceneNumber(environment && environment.ambientIntensity, 0) > 0) {
      lighting = sceneAddPoint(lighting, sceneMultiplyPoint(
        baseColor,
        sceneScalePoint(sceneColorPoint(environment && environment.ambientColor, { x: 1, y: 1, z: 1 }), sceneNumber(environment && environment.ambientIntensity, 0)),
      ));
    }
    if (sceneNumber(environment && environment.skyIntensity, 0) > 0 || sceneNumber(environment && environment.groundIntensity, 0) > 0) {
      const hemi = clamp01((normal.y * 0.5) + 0.5);
      const sky = sceneScalePoint(sceneColorPoint(environment && environment.skyColor, { x: 0.88, y: 0.94, z: 1 }), sceneNumber(environment && environment.skyIntensity, 0) * hemi);
      const ground = sceneScalePoint(sceneColorPoint(environment && environment.groundColor, { x: 0.12, y: 0.16, z: 0.22 }), sceneNumber(environment && environment.groundIntensity, 0) * (1 - hemi));
      lighting = sceneAddPoint(lighting, sceneMultiplyPoint(baseColor, sceneAddPoint(sky, ground)));
    }
    return lighting;
  }

  function sceneAmbientLightContribution(baseColor, light) {
    return sceneMultiplyPoint(
      baseColor,
      sceneScalePoint(sceneColorPoint(light && light.color, { x: 1, y: 1, z: 1 }), sceneNumber(light && light.intensity, 0)),
    );
  }

  function sceneDirectionalLightContribution(baseColor, normal, light) {
    const direction = sceneNormalizePoint({
      x: -sceneNumber(light && light.directionX, 0),
      y: -sceneNumber(light && light.directionY, -1),
      z: -sceneNumber(light && light.directionZ, 0),
    });
    const diffuse = clamp01(sceneDotPoint(normal, direction));
    if (diffuse <= 0) {
      return { x: 0, y: 0, z: 0 };
    }
    return sceneMultiplyPoint(
      baseColor,
      sceneScalePoint(sceneColorPoint(light && light.color, { x: 1, y: 1, z: 1 }), sceneNumber(light && light.intensity, 0) * diffuse),
    );
  }

  function scenePointLightContribution(baseColor, worldPoint, normal, light) {
    const offset = {
      x: sceneNumber(light && light.x, 0) - sceneNumber(worldPoint && worldPoint.x, 0),
      y: sceneNumber(light && light.y, 0) - sceneNumber(worldPoint && worldPoint.y, 0),
      z: sceneNumber(light && light.z, 0) - sceneNumber(worldPoint && worldPoint.z, 0),
    };
    const distance = Math.max(0.0001, scenePointLength(offset));
    const diffuse = clamp01(sceneDotPoint(normal, sceneScalePoint(offset, 1 / distance)));
    if (diffuse <= 0) {
      return { x: 0, y: 0, z: 0 };
    }
    const attenuation = scenePointLightAttenuation(light, distance);
    if (attenuation <= 0) {
      return { x: 0, y: 0, z: 0 };
    }
    return sceneMultiplyPoint(
      baseColor,
      sceneScalePoint(sceneColorPoint(light && light.color, { x: 1, y: 1, z: 1 }), sceneNumber(light && light.intensity, 0) * diffuse * attenuation),
    );
  }

  function sceneSpotLightContribution(baseColor, worldPoint, normal, light) {
    const offset = {
      x: sceneNumber(light && light.x, 0) - sceneNumber(worldPoint && worldPoint.x, 0),
      y: sceneNumber(light && light.y, 0) - sceneNumber(worldPoint && worldPoint.y, 0),
      z: sceneNumber(light && light.z, 0) - sceneNumber(worldPoint && worldPoint.z, 0),
    };
    const distance = Math.max(0.0001, scenePointLength(offset));
    const lightDir = sceneScalePoint(offset, 1 / distance);
    const spotDir = sceneNormalizePoint({
      x: sceneNumber(light && light.directionX, 0),
      y: sceneNumber(light && light.directionY, -1),
      z: sceneNumber(light && light.directionZ, 0),
    });
    const angle = sceneNumber(light && light.angle, Math.PI / 4);
    const penumbra = clamp01(sceneNumber(light && light.penumbra, 0));
    const outer = Math.cos(angle);
    const inner = Math.cos(angle * (1 - penumbra));
    const cone = clamp01((sceneDotPoint(sceneScalePoint(lightDir, -1), spotDir) - outer) / Math.max(0.001, inner - outer));
    if (cone <= 0) {
      return { x: 0, y: 0, z: 0 };
    }
    const point = scenePointLightContribution(baseColor, worldPoint, normal, light);
    return sceneScalePoint(point, cone);
  }

  function sceneHemisphereLightContribution(baseColor, normal, light) {
    const hemi = clamp01((normal.y * 0.5) + 0.5);
    const sky = sceneScalePoint(sceneColorPoint(light && light.color, { x: 0.88, y: 0.94, z: 1 }), hemi);
    const ground = sceneScalePoint(sceneColorPoint(light && light.groundColor, { x: 0.12, y: 0.16, z: 0.22 }), 1 - hemi);
    return sceneMultiplyPoint(
      baseColor,
      sceneScalePoint(sceneAddPoint(sky, ground), sceneNumber(light && light.intensity, 0)),
    );
  }

  function sceneLightContribution(baseColor, worldPoint, normal, light) {
    switch (light && light.kind) {
      case "ambient":
      case "light-probe":
        return sceneAmbientLightContribution(baseColor, light);
      case "directional":
        return sceneDirectionalLightContribution(baseColor, normal, light);
      case "point":
      case "rect-area":
        return scenePointLightContribution(baseColor, worldPoint, normal, light);
      case "spot":
        return sceneSpotLightContribution(baseColor, worldPoint, normal, light);
      case "hemisphere":
        return sceneHemisphereLightContribution(baseColor, normal, light);
      default:
        return { x: 0, y: 0, z: 0 };
    }
  }

  function sceneLitColorRGBA(material, worldPoint, normal, lights, environment) {
    const base = sceneColorRGBA(material && material.color, [0.55, 0.88, 1, 1]);
    if (!sceneLightingActive(lights, environment)) {
      return base;
    }
    const safeNormal = sceneSafeNormal(normal);
    const baseColor = { x: base[0], y: base[1], z: base[2] };
    const emissive = clamp01(sceneMaterialEmissive(material));
    let lighting = sceneEnvironmentLightContribution(baseColor, safeNormal, environment);
    for (const light of Array.isArray(lights) ? lights : []) {
      lighting = sceneAddPoint(lighting, sceneLightContribution(baseColor, worldPoint, safeNormal, light));
    }
    const exposure = sceneNumber(environment && environment.exposure, 1);
    let lit = sceneAddPoint(
      sceneScalePoint(baseColor, emissive),
      sceneScalePoint(lighting, exposure),
    );
    lit = sceneAddPoint(lit, sceneScalePoint(baseColor, 0.06));
    return [clamp01(lit.x), clamp01(lit.y), clamp01(lit.z), base[3]];
  }

  function sceneObjectWorldNormal(object, point, timeSeconds) {
    const localPoint = {
      x: sceneNumber(point && point.x, 0) * sceneNumber(object && object.scaleX, 1),
      y: sceneNumber(point && point.y, 0) * sceneNumber(object && object.scaleY, 1),
      z: sceneNumber(point && point.z, 0) * sceneNumber(object && object.scaleZ, 1),
    };
    return sceneNormalizePoint(sceneRotatePoint(
      sceneObjectLocalNormal(object, localPoint),
      sceneNumber(object && object.rotationX, 0) + sceneNumber(object && object.spinX, 0) * timeSeconds,
      sceneNumber(object && object.rotationY, 0) + sceneNumber(object && object.spinY, 0) * timeSeconds,
      sceneNumber(object && object.rotationZ, 0) + sceneNumber(object && object.spinZ, 0) * timeSeconds,
    ));
  }

  function sceneObjectLocalNormal(object, point) {
    const safePoint = point && typeof point === "object" ? point : { x: 0, y: 0, z: 0 };
    switch (object && object.kind) {
      case "lines":
        return sceneBoxNormal(object, safePoint);
      case "plane":
        return { x: 0, y: 1, z: 0 };
      case "sphere":
        return sceneNormalizePoint(safePoint);
      case "pyramid":
        return scenePyramidNormal(object, safePoint);
      default:
        return sceneBoxNormal(object, safePoint);
    }
  }

  function scenePyramidNormal(object, point) {
    const width = Math.max((sceneNumber(object && object.width, object && object.size) * Math.abs(sceneNumber(object && object.scaleX, 1))) / 2, 0.0001);
    const height = Math.max((sceneNumber(object && object.height, object && object.size) * Math.abs(sceneNumber(object && object.scaleY, 1))) / 2, 0.0001);
    const depth = Math.max((sceneNumber(object && object.depth, object && object.size) * Math.abs(sceneNumber(object && object.scaleZ, 1))) / 2, 0.0001);
    return sceneNormalizePoint({
      x: sceneNumber(point && point.x, 0) / width,
      y: (sceneNumber(point && point.y, 0) / height) + 0.35,
      z: sceneNumber(point && point.z, 0) / depth,
    });
  }

  function sceneBoxNormal(object, point) {
    const width = Math.max((sceneNumber(object && object.width, object && object.size) * Math.abs(sceneNumber(object && object.scaleX, 1))) / 2, 0.0001);
    const height = Math.max((sceneNumber(object && object.height, object && object.size) * Math.abs(sceneNumber(object && object.scaleY, 1))) / 2, 0.0001);
    const depth = Math.max((sceneNumber(object && object.depth, object && object.size) * Math.abs(sceneNumber(object && object.scaleZ, 1))) / 2, 0.0001);
    const x = sceneNumber(point && point.x, 0);
    const y = sceneNumber(point && point.y, 0);
    const z = sceneNumber(point && point.z, 0);
    const ax = Math.abs(x / width);
    const ay = Math.abs(y / height);
    const az = Math.abs(z / depth);
    if (ax >= ay && ax >= az) {
      return { x: Math.sign(x) || 1, y: 0, z: 0 };
    }
    if (ay >= az) {
      return { x: 0, y: Math.sign(y) || 1, z: 0 };
    }
    return { x: 0, y: 0, z: Math.sign(z) || 1 };
  }

  function scenePointLightAttenuation(light, distance) {
    const range = Math.max(0, sceneNumber(light && light.range, 0));
    const decay = Math.max(0.1, sceneNumber(light && light.decay, 1.35));
    if (range > 0) {
      return Math.pow(clamp01(1 - (distance / range)), decay);
    }
    return 1 / (1 + Math.pow(distance * 0.35, Math.max(decay, 1)));
  }

  const SCENE_IR_VERSION = 1;
  const SCENE_RENDER_BUNDLE_VERSION = 1;

  /**
   * @typedef {object} SceneIR
   * @property {number} version
   * @property {SceneCamera} camera
   * @property {SceneEnvironment} environment
   * @property {SceneMaterial[]} [materials]
   * @property {SceneLight[]} [lights]
   * @property {SceneNode[]} [nodes]
   * @property {ScenePostEffect[]} [postFX]
   */

  /**
   * @typedef {object} SceneRenderBundle
   * @property {number} bundleVersion
   * @property {SceneCamera} camera
   * @property {SceneEnvironment} environment
   * @property {SceneMaterial[]} [materials]
   * @property {object[]} [objects]
   * @property {object[]} [meshObjects]
   * @property {object[]} [points]
   * @property {object[]} [instancedMeshes]
   * @property {object[]} [computeParticles]
   * @property {object[]} [html]
   */

  /**
   * @typedef {object} SceneCamera
   * @property {string} [kind]
   * @property {number} [x]
   * @property {number} [y]
   * @property {number} [z]
   * @property {number} [rotationX]
   * @property {number} [rotationY]
   * @property {number} [rotationZ]
   * @property {number} [fov]
   * @property {number} [near]
   * @property {number} [far]
   */

  /**
   * @typedef {object} SceneEnvironment
   * @property {string} [background]
   * @property {string} [ambientColor]
   * @property {number} [ambientIntensity]
   * @property {string} [skyColor]
   * @property {number} [skyIntensity]
   * @property {string} [groundColor]
   * @property {number} [groundIntensity]
   * @property {string} [envMap]
   * @property {number} [envIntensity]
   * @property {number} [envRotation]
   * @property {number} [exposure]
   * @property {string} [toneMapping]
   * @property {string} [fogColor]
   * @property {number} [fogDensity]
   */

  /**
   * @typedef {object} SceneMaterial
   * @property {string} [name]
   * @property {string} [kind]
   * @property {string} [color]
   * @property {number} [opacity]
   * @property {number} [roughness]
   * @property {number} [metalness]
   */

  /**
   * @typedef {object} SceneNode
   * @property {"mesh"|"points"|"instanced-mesh"|"compute-particles"|"sprite"|"label"|string} kind
   * @property {string} [id]
   * @property {number} [materialIndex]
   * @property {object} transform
   * @property {object} [mesh]
   * @property {object} [points]
   * @property {object} [instancedMesh]
   * @property {object} [compute]
   * @property {object} [sprite]
   * @property {object} [label]
   */

  /**
   * @typedef {object} SceneLight
   * @property {string} kind
   * @property {string} [color]
   * @property {number} [intensity]
   * @property {boolean} [castShadow]
   * @property {number} [shadowBias]
   * @property {number} [shadowSize]
   * @property {number} [shadowCascades]
   * @property {number} [shadowSoftness]
   */

  /**
   * @typedef {object} ScenePostEffect
   * @property {string} kind
   */

  function validateSceneIR(ir) {
    const errors = [];
    if (!ir || typeof ir !== "object") {
      return { valid: false, errors: ["scene IR must be an object"] };
    }
    const isRenderBundle = ir.bundleVersion != null;
    if (isRenderBundle) {
      if (ir.bundleVersion != null && ir.bundleVersion !== SCENE_RENDER_BUNDLE_VERSION) {
        errors.push("bundleVersion must be " + SCENE_RENDER_BUNDLE_VERSION);
      }
      if (ir.version != null && ir.version !== SCENE_IR_VERSION) {
        errors.push("version must be " + SCENE_IR_VERSION);
      }
    } else if (ir.version !== SCENE_IR_VERSION) {
      errors.push("version must be " + SCENE_IR_VERSION);
    }
    if (!ir.camera || typeof ir.camera !== "object") {
      errors.push("camera must be an object");
    } else {
      validateSceneIRCamera(ir.camera, errors);
    }
    if (ir.environment != null && typeof ir.environment !== "object") {
      errors.push("environment must be an object");
    }
    validateSceneIRArray(ir, "materials", errors);
    validateSceneIRArray(ir, "lights", errors);
    validateSceneIRArray(ir, "nodes", errors);
    validateSceneIRArray(ir, "postFX", errors);
    validateSceneIRArray(ir, "postEffects", errors);

    if (isRenderBundle) {
      validateRenderBundleShape(ir, errors);
    } else {
      validateCanonicalSceneNodes(Array.isArray(ir.nodes) ? ir.nodes : [], Array.isArray(ir.materials) ? ir.materials.length : 0, errors);
    }
    return { valid: errors.length === 0, errors };
  }

  function validateSceneIRCamera(camera, errors) {
    const near = sceneNumber(camera.near, 0);
    const far = sceneNumber(camera.far, 0);
    if (near < 0) {
      errors.push("camera.near must be non-negative");
    }
    if (near > 0 && far > 0 && far <= near) {
      errors.push("camera.far must be greater than camera.near");
    }
  }

  function validateSceneIRArray(ir, key, errors) {
    if (ir[key] != null && !Array.isArray(ir[key])) {
      errors.push(key + " must be an array");
    }
  }

  function validateCanonicalSceneNodes(nodes, materialCount, errors) {
    const kindPayloads = {
      "mesh": "mesh",
      "points": "points",
      "instanced-mesh": "instancedMesh",
      "compute-particles": "compute",
      "sprite": "sprite",
      "label": "label",
    };
    for (let index = 0; index < nodes.length; index += 1) {
      const node = nodes[index];
      if (!node || typeof node !== "object") {
        errors.push("nodes[" + index + "] must be an object");
        continue;
      }
      const kind = typeof node.kind === "string" ? node.kind.trim() : "";
      if (!kind) {
        errors.push("nodes[" + index + "].kind is required");
      } else if (!Object.prototype.hasOwnProperty.call(kindPayloads, kind)) {
        errors.push("nodes[" + index + "].kind " + JSON.stringify(kind) + " is unknown");
      }
      if (node.materialIndex != null) {
        const materialIndex = sceneNumber(node.materialIndex, -1);
        if (materialIndex < 0 || Math.floor(materialIndex) !== materialIndex) {
          errors.push("nodes[" + index + "].materialIndex must be a non-negative integer");
        } else if (materialCount > 0 && materialIndex >= materialCount) {
          errors.push("nodes[" + index + "].materialIndex out of range");
        }
      }
      const payloadCount = [
        node.mesh,
        node.points,
        node.instancedMesh,
        node.compute,
        node.sprite,
        node.label,
      ].filter(Boolean).length;
      if (payloadCount !== 1) {
        errors.push("nodes[" + index + "] must set exactly one payload");
      }
      const expectedPayload = kindPayloads[kind];
      if (expectedPayload && !node[expectedPayload]) {
        errors.push("nodes[" + index + "]." + expectedPayload + " is required");
      }
      if (node.points) {
        validateSceneIRNonNegativeInteger(node.points.count, "nodes[" + index + "].points.count", errors);
      }
      if (node.instancedMesh) {
        validateSceneIRNonNegativeInteger(node.instancedMesh.count, "nodes[" + index + "].instancedMesh.count", errors);
      }
      if (node.compute) {
        validateSceneIRNonNegativeInteger(node.compute.count, "nodes[" + index + "].compute.count", errors);
      }
    }
  }

  function validateSceneIRNonNegativeInteger(value, label, errors) {
    if (value == null) {
      return;
    }
    const number = sceneNumber(value, -1);
    if (number < 0 || Math.floor(number) !== number) {
      errors.push(label + " must be non-negative");
    }
  }

  function validateRenderBundleShape(bundle, errors) {
    validateSceneIRArray(bundle, "objects", errors);
    validateSceneIRArray(bundle, "meshObjects", errors);
    validateSceneIRArray(bundle, "points", errors);
    validateSceneIRArray(bundle, "instancedMeshes", errors);
    validateSceneIRArray(bundle, "computeParticles", errors);
    validateSceneIRArray(bundle, "labels", errors);
    validateSceneIRArray(bundle, "sprites", errors);
    validateSceneIRArray(bundle, "html", errors);
    if (!bundle.objects && !bundle.meshObjects && !bundle.points && !bundle.instancedMeshes && !bundle.computeParticles && !bundle.labels && !bundle.sprites && !bundle.html) {
      errors.push("scene IR must include nodes or render-bundle arrays");
    }
  }

  function buildSceneWorldDrawPlan(bundle, scratch) {
    const objects = Array.isArray(bundle.objects) ? bundle.objects : [];
    const materials = Array.isArray(bundle.materials) ? bundle.materials : [];
    if (!objects.length || !materials.length) {
      return null;
    }
    const drawScratch = resetSceneWorldDrawScratch(scratch || createSceneWorldDrawScratch());
    for (let index = 0; index < objects.length; index += 1) {
      collectSceneWorldDrawObject(drawScratch, bundle, materials, objects[index], index);
    }
    return finalizeSceneWorldDrawPlan(bundle, drawScratch);
  }

  function collectSceneWorldDrawObject(drawScratch, bundle, materials, object, order) {
    if (!sceneWorldObjectRenderable(object, bundle && bundle.camera)) {
      return;
    }
    const material = materials[object.materialIndex] || null;
    if (!sceneWorldObjectUsesLinePass(object, material)) {
      return;
    }
    const renderPass = sceneWorldObjectRenderPass(object, material);
    if (renderPass === "additive" || renderPass === "alpha") {
      collectSceneWorldTranslucentObject(drawScratch, bundle, object, material, renderPass, order);
      return;
    }
    collectSceneWorldOpaqueObject(drawScratch, bundle, object, material);
  }

  function sceneWorldObjectRenderable(object, camera) {
    return Boolean(
      object &&
      Number.isFinite(object.vertexOffset) &&
      Number.isFinite(object.vertexCount) &&
      object.vertexCount > 0 &&
      !sceneWorldObjectCulled(object, camera)
    );
  }

  function sceneWorldObjectUsesLinePass(object, material) {
    return !(object && object.kind === "plane" && material && typeof material.texture === "string" && material.texture.trim() !== "" && !sceneBool(material.wireframe, true));
  }

  function collectSceneWorldOpaqueObject(drawScratch, bundle, object, material) {
    const target = object.static ? {
      positions: drawScratch.staticOpaquePositions,
      colors: drawScratch.staticOpaqueColors,
      materials: drawScratch.staticOpaqueMaterials,
    } : {
      positions: drawScratch.dynamicOpaquePositions,
      colors: drawScratch.dynamicOpaqueColors,
      materials: drawScratch.dynamicOpaqueMaterials,
    };
    if (object.static) {
      drawScratch.staticOpaqueObjects.push(object);
      drawScratch.staticOpaqueMaterialProfiles.push(material);
    }
    appendSceneWorldObjectSlice(target.positions, target.colors, target.materials, bundle.worldPositions, bundle.worldColors, object, material);
  }

  function collectSceneWorldTranslucentObject(drawScratch, bundle, object, material, renderPass, order) {
    const targetEntries = renderPass === "additive" ? drawScratch.additiveEntries : drawScratch.alphaEntries;
    targetEntries.push(createSceneWorldPassEntry(object, material, bundle.worldPositions, bundle.camera, order));
  }

  function finalizeSceneWorldDrawPlan(bundle, drawScratch) {
    const typedStaticOpaque = createSceneWorldOpaqueBuffers(drawScratch, "typedStaticOpaque", drawScratch.staticOpaquePositions, drawScratch.staticOpaqueColors, drawScratch.staticOpaqueMaterials);
    const typedDynamicOpaque = createSceneWorldOpaqueBuffers(drawScratch, "typedDynamicOpaque", drawScratch.dynamicOpaquePositions, drawScratch.dynamicOpaqueColors, drawScratch.dynamicOpaqueMaterials);
    const typedAlphaPlan = createSceneWorldPassPlan(bundle.worldPositions, bundle.worldColors, drawScratch.alphaEntries, drawScratch.alphaPlan);
    const typedAdditivePlan = createSceneWorldPassPlan(bundle.worldPositions, bundle.worldColors, drawScratch.additiveEntries, drawScratch.additivePlan);
    const plan = drawScratch.plan;
    plan.staticOpaqueKey = sceneStaticDrawKey(bundle, drawScratch.staticOpaqueObjects, drawScratch.staticOpaqueMaterialProfiles, bundle.camera);
    plan.staticOpaquePositions = typedStaticOpaque.positions;
    plan.staticOpaqueColors = typedStaticOpaque.colors;
    plan.staticOpaqueMaterials = typedStaticOpaque.materials;
    plan.staticOpaqueVertexCount = typedStaticOpaque.vertexCount;
    plan.dynamicOpaquePositions = typedDynamicOpaque.positions;
    plan.dynamicOpaqueColors = typedDynamicOpaque.colors;
    plan.dynamicOpaqueMaterials = typedDynamicOpaque.materials;
    plan.dynamicOpaqueVertexCount = typedDynamicOpaque.vertexCount;
    plan.alphaPositions = typedAlphaPlan.positions;
    plan.alphaColors = typedAlphaPlan.colors;
    plan.alphaMaterials = typedAlphaPlan.materials;
    plan.alphaVertexCount = typedAlphaPlan.vertexCount;
    plan.additivePositions = typedAdditivePlan.positions;
    plan.additiveColors = typedAdditivePlan.colors;
    plan.additiveMaterials = typedAdditivePlan.materials;
    plan.additiveVertexCount = typedAdditivePlan.vertexCount;
    plan.hasAlphaPass = typedAlphaPlan.vertexCount > 0;
    plan.hasAdditivePass = typedAdditivePlan.vertexCount > 0;
    return plan;
  }

  function createSceneWorldOpaqueBuffers(drawScratch, keyPrefix, positions, colors, materials) {
    const typedPositions = sceneWriteFloatArray(drawScratch, keyPrefix + "Positions", positions);
    const typedColors = sceneWriteFloatArray(drawScratch, keyPrefix + "Colors", colors);
    const typedMaterials = sceneWriteFloatArray(drawScratch, keyPrefix + "Materials", materials);
    return {
      positions: typedPositions,
      colors: typedColors,
      materials: typedMaterials,
      vertexCount: typedPositions.length / 3,
    };
  }

  function createSceneWorldPassEntry(object, material, sourcePositions, camera, order) {
    return {
      object,
      material,
      order,
      depth: sceneWorldObjectDepth(sourcePositions, object, camera),
    };
  }

  function createSceneWorldPassPlan(sourcePositions, sourceColors, entries, scratch) {
    const passScratch = resetSceneWorldPassScratch(scratch || createSceneWorldPassScratch());
    if (!entries.length) {
      passScratch.typedPositions = sceneWriteFloatArray(passScratch, "typedPositions", passScratch.positions);
      passScratch.typedColors = sceneWriteFloatArray(passScratch, "typedColors", passScratch.colors);
      passScratch.typedMaterials = sceneWriteFloatArray(passScratch, "typedMaterials", passScratch.materials);
      passScratch.vertexCount = 0;
      return passScratch;
    }
    const positions = passScratch.positions;
    const colors = passScratch.colors;
    const materials = passScratch.materials;
    entries.sort(compareSceneWorldPassEntries);
    for (const entry of entries) {
      appendSceneWorldObjectSlice(positions, colors, materials, sourcePositions, sourceColors, entry.object, entry.material);
    }
    passScratch.typedPositions = sceneWriteFloatArray(passScratch, "typedPositions", positions);
    passScratch.typedColors = sceneWriteFloatArray(passScratch, "typedColors", colors);
    passScratch.typedMaterials = sceneWriteFloatArray(passScratch, "typedMaterials", materials);
    passScratch.vertexCount = passScratch.typedPositions.length / 3;
    return passScratch;
  }

  function compareSceneWorldPassEntries(a, b) {
    if (a.depth !== b.depth) {
      return b.depth - a.depth;
    }
    return a.order - b.order;
  }

  const _sceneWorldObjectDepthCameraScratch = {
    x: 0, y: 0, z: 0,
    rotationX: 0, rotationY: 0, rotationZ: 0,
    fov: 0, near: 0, far: 0,
  };

  function sceneWorldObjectDepth(sourcePositions, object, camera) {
    if (object && object.bounds) {
      return sceneBoundsDepthMetrics(object.bounds, camera).center;
    }
    if (object && Number.isFinite(object.depthCenter)) {
      return sceneNumber(object.depthCenter, sceneWorldPointDepth(0, camera));
    }
    const vertexOffset = Math.max(0, Math.floor(sceneNumber(object && object.vertexOffset, 0)));
    const vertexCount = Math.max(0, Math.floor(sceneNumber(object && object.vertexCount, 0)));
    if (!vertexCount) {
      return sceneWorldPointDepth(0, camera);
    }

    const cam = sceneRenderCamera(camera, _sceneWorldObjectDepthCameraScratch);
    const sinX = Math.sin(-cam.rotationX);
    const cosX = Math.cos(-cam.rotationX);
    const sinY = Math.sin(-cam.rotationY);
    const cosY = Math.cos(-cam.rotationY);
    const sinZ = Math.sin(-cam.rotationZ);
    const cosZ = Math.cos(-cam.rotationZ);

    const start = vertexOffset * 3;
    const end = start + vertexCount * 3;
    let depthSum = 0;
    let count = 0;
    for (let i = start; i < end; i += 3) {
      let lx = sceneNumber(sourcePositions[i], 0) - cam.x;
      let ly = sceneNumber(sourcePositions[i + 1], 0) - cam.y;
      let lz = sceneNumber(sourcePositions[i + 2], 0) + cam.z;

      let nX = lx * cosZ - ly * sinZ;
      let nY = lx * sinZ + ly * cosZ;
      lx = nX;
      ly = nY;

      nX = lx * cosY + lz * sinY;
      let nZ = -lx * sinY + lz * cosY;
      lx = nX;
      lz = nZ;

      nZ = ly * sinX + lz * cosX;
      depthSum += nZ;
      count += 1;
    }
    return depthSum / Math.max(1, count);
  }

  function sceneWorldObjectCulled(object, camera) {
    if (object && object.bounds) {
      return sceneBoundsViewCulled(object.bounds, camera);
    }
    return Boolean(object && object.viewCulled);
  }

  function appendSceneWorldObjectSlice(targetPositions, targetColors, targetMaterials, sourcePositions, sourceColors, object, material) {
    const vertexOffset = Math.max(0, Math.floor(sceneNumber(object.vertexOffset, 0)));
    const vertexCount = Math.max(0, Math.floor(sceneNumber(object.vertexCount, 0)));
    const opacity = sceneMaterialOpacity(material);
    const materialData = sceneMaterialShaderData(material);
    const startPosition = vertexOffset * 3;
    const endPosition = startPosition + vertexCount * 3;
    const startColor = vertexOffset * 4;
    const endColor = startColor + vertexCount * 4;
    for (let i = startPosition; i < endPosition; i += 1) {
      targetPositions.push(sceneNumber(sourcePositions[i], 0));
    }
    for (let i = startColor; i < endColor; i += 4) {
      targetColors.push(
        sceneNumber(sourceColors[i], 0),
        sceneNumber(sourceColors[i + 1], 0),
        sceneNumber(sourceColors[i + 2], 0),
        sceneNumber(sourceColors[i + 3], 1) * opacity,
      );
      targetMaterials.push(materialData[0], materialData[1], materialData[2]);
    }
  }

  function createSceneWorldDrawScratch() {
    return {
      staticOpaquePositions: [],
      staticOpaqueColors: [],
      staticOpaqueMaterials: [],
      dynamicOpaquePositions: [],
      dynamicOpaqueColors: [],
      dynamicOpaqueMaterials: [],
      staticOpaqueObjects: [],
      staticOpaqueMaterialProfiles: [],
      alphaEntries: [],
      additiveEntries: [],
      typedStaticOpaquePositions: new Float32Array(0),
      typedStaticOpaqueColors: new Float32Array(0),
      typedStaticOpaqueMaterials: new Float32Array(0),
      typedDynamicOpaquePositions: new Float32Array(0),
      typedDynamicOpaqueColors: new Float32Array(0),
      typedDynamicOpaqueMaterials: new Float32Array(0),
      alphaPlan: createSceneWorldPassScratch(),
      additivePlan: createSceneWorldPassScratch(),
      plan: {},
    };
  }

  function resetSceneWorldDrawScratch(scratch) {
    scratch.staticOpaquePositions.length = 0;
    scratch.staticOpaqueColors.length = 0;
    scratch.staticOpaqueMaterials.length = 0;
    scratch.dynamicOpaquePositions.length = 0;
    scratch.dynamicOpaqueColors.length = 0;
    scratch.dynamicOpaqueMaterials.length = 0;
    scratch.staticOpaqueObjects.length = 0;
    scratch.staticOpaqueMaterialProfiles.length = 0;
    scratch.alphaEntries.length = 0;
    scratch.additiveEntries.length = 0;
    resetSceneWorldPassScratch(scratch.alphaPlan);
    resetSceneWorldPassScratch(scratch.additivePlan);
    return scratch;
  }

  function createSceneWorldPassScratch() {
    return {
      positions: [],
      colors: [],
      materials: [],
      typedPositions: new Float32Array(0),
      typedColors: new Float32Array(0),
      typedMaterials: new Float32Array(0),
      vertexCount: 0,
    };
  }

  function resetSceneWorldPassScratch(scratch) {
    scratch.positions.length = 0;
    scratch.colors.length = 0;
    scratch.materials.length = 0;
    scratch.vertexCount = 0;
    return scratch;
  }

  function sceneWriteFloatArray(target, key, values) {
    let buffer = target[key];
    if (!buffer || buffer.length !== values.length) {
      buffer = new Float32Array(values.length);
      target[key] = buffer;
    }
    for (let i = 0; i < values.length; i += 1) {
      buffer[i] = sceneNumber(values[i], 0);
    }
    return buffer;
  }

  function sceneWorldPointDepth(pointOrZ, camera) {
    if (pointOrZ && typeof pointOrZ === "object") {
      return sceneCameraLocalPoint(pointOrZ, camera).z;
    }
    return sceneCameraLocalPoint({ x: 0, y: 0, z: sceneNumber(pointOrZ, 0) }, camera).z;
  }

  function sceneWorldObjectRenderPass(object, material) {
    const renderPass = String(object && object.renderPass || "").toLowerCase();
    if (renderPass === "opaque" || renderPass === "alpha" || renderPass === "additive") {
      return renderPass;
    }
    return sceneMaterialRenderPass(material);
  }

  function sceneStaticDrawKey(bundle, objects, materials, camera) {
    let hash = 2166136261 >>> 0;
    hash = sceneHashCamera(hash, camera);
    for (const object of objects) {
      const material = object && object.materialIndex >= 0 && object.materialIndex < materials.length ? materials[object.materialIndex] : null;
      if (!sceneWorldObjectUsesLinePass(object, material)) {
        continue;
      }
      hash = sceneHashStaticObject(hash, object);
      const start = Math.max(0, Math.floor(sceneNumber(object && object.vertexOffset, 0))) * 4;
      const end = start + Math.max(0, Math.floor(sceneNumber(object && object.vertexCount, 0))) * 4;
      const colors = bundle && bundle.worldColors;
      for (let index = start; index < end; index += 1) {
        hash = sceneHashNumber(hash, sceneNumber(colors && colors[index], 0));
      }
    }
    for (const material of materials) {
      hash = sceneHashMaterialProfile(hash, material);
    }
    return String(hash) + ":" + objects.length + ":" + materials.length;
  }

  function sceneHashCamera(hash, camera) {
    hash = sceneHashString(hash, camera && camera.kind || "perspective");
    hash = sceneHashNumber(hash, sceneNumber(camera && camera.x, 0));
    hash = sceneHashNumber(hash, sceneNumber(camera && camera.y, 0));
    hash = sceneHashNumber(hash, sceneNumber(camera && camera.z, 6));
    hash = sceneHashNumber(hash, sceneNumber(camera && camera.rotationX, 0));
    hash = sceneHashNumber(hash, sceneNumber(camera && camera.rotationY, 0));
    hash = sceneHashNumber(hash, sceneNumber(camera && camera.rotationZ, 0));
    hash = sceneHashNumber(hash, sceneNumber(camera && camera.fov, 75));
    hash = sceneHashNumber(hash, sceneNumber(camera && camera.left, 0));
    hash = sceneHashNumber(hash, sceneNumber(camera && camera.right, 0));
    hash = sceneHashNumber(hash, sceneNumber(camera && camera.top, 0));
    hash = sceneHashNumber(hash, sceneNumber(camera && camera.bottom, 0));
    hash = sceneHashNumber(hash, sceneNumber(camera && camera.zoom, 1));
    hash = sceneHashNumber(hash, sceneNumber(camera && camera.near, 0.05));
    return sceneHashNumber(hash, sceneNumber(camera && camera.far, 128));
  }

  const sceneStaticObjectStringFields = ["id", "kind"];
  const sceneStaticObjectNumberFields = [
    ["materialIndex", 0],
    ["vertexOffset", 0],
    ["vertexCount", 0],
    ["depthNear", 0],
    ["depthFar", 0],
    ["depthCenter", 0],
  ];
  const sceneStaticObjectFlagFields = ["static", "viewCulled"];
  const sceneBoundsNumberFields = [
    ["minX", 0],
    ["minY", 0],
    ["minZ", 0],
    ["maxX", 0],
    ["maxY", 0],
    ["maxZ", 0],
  ];
  const sceneMaterialStringFields = ["kind", "color", "texture", "blendMode", "renderPass"];
  const sceneMaterialNumberFields = [
    ["opacity", 1],
    ["emissive", 0],
  ];
  const sceneMaterialFlagFields = ["wireframe"];

  function sceneHashStaticObject(hash, object) {
    hash = sceneHashFieldStrings(hash, object, sceneStaticObjectStringFields);
    hash = sceneHashFieldNumbers(hash, object, sceneStaticObjectNumberFields);
    hash = sceneHashFieldFlags(hash, object, sceneStaticObjectFlagFields);
    return sceneHashBounds(hash, object && object.bounds);
  }

  function sceneHashBounds(hash, bounds) {
    return sceneHashFieldNumbers(hash, bounds, sceneBoundsNumberFields);
  }

  function sceneHashMaterialProfile(hash, material) {
    const key = material && material.key;
    if (key) {
      return sceneHashString(hash, key);
    }
    hash = sceneHashFieldStrings(hash, material, sceneMaterialStringFields);
    hash = sceneHashFieldNumbers(hash, material, sceneMaterialNumberFields);
    return sceneHashFieldFlags(hash, material, sceneMaterialFlagFields);
  }

  function sceneHashFieldStrings(hash, source, fields) {
    for (const field of fields) {
      hash = sceneHashString(hash, source && source[field] || "");
    }
    return hash;
  }

  function sceneHashFieldNumbers(hash, source, fields) {
    for (const field of fields) {
      hash = sceneHashNumber(hash, sceneNumber(source && source[field[0]], field[1]));
    }
    return hash;
  }

  function sceneHashFieldFlags(hash, source, fields) {
    for (const field of fields) {
      hash = sceneHashNumber(hash, source && source[field] ? 1 : 0);
    }
    return hash;
  }

  function sceneHashNumber(hash, value) {
    const scaled = Math.round(sceneNumber(value, 0) * 1000);
    hash ^= scaled;
    return Math.imul(hash, 16777619) >>> 0;
  }

  function sceneHashString(hash, value) {
    const text = String(value || "");
    for (let i = 0; i < text.length; i += 1) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619) >>> 0;
    }
    return hash;
  }

  function sceneCSSDebugLog() {
    if (typeof window === "undefined" || window.__gosx_scene3d_css_debug !== true) {
      return;
    }
    if (typeof console !== "undefined" && typeof console.debug === "function") {
      console.debug.apply(console, arguments);
    }
  }

  function prepareScene(ir, camera, viewport, lastPrepared, cssContext) {
    const initialSource = ir && typeof ir === "object" ? ir : {};
    const css = sceneCSSResolverContext(cssContext);
    css.nowMs = typeof cssContext === "object" && cssContext && cssContext.nowMs ? cssContext.nowMs : Date.now();
    const cssInputSignature = sceneCSSInputSignature(initialSource);
    const cssCache = lastPrepared && lastPrepared.cssCache;
    css.prevCache = cssCache || null;
    const hasActiveVarTransitions = cssCache && Array.isArray(cssCache.varTransitions) && cssCache.varTransitions.length > 0;
    const cssResolved = cssCache
      && cssCache.inputSignature === cssInputSignature
      && cssCache.revision === css.revision
      && cssCache.transitionFrame === css.transitionFrame
      && !hasActiveVarTransitions
        ? sceneCSSApplyCachedResolution(initialSource, cssCache)
        : sceneResolveCSSBundleWithContext(initialSource, css, cssInputSignature);
    const source = cssResolved.ir;
    const resolvedCamera = camera || source.camera || {};
    const signature = scenePreparedSignature(source, resolvedCamera, viewport);
    if (lastPrepared && lastPrepared.signature === signature) {
      lastPrepared.ir = source;
      lastPrepared.camera = resolvedCamera;
      lastPrepared.viewport = viewport;
      lastPrepared.resolvedEnv = source.environment || {};
      lastPrepared.cssDynamic = Boolean(cssResolved.dynamic);
      lastPrepared.cssCache = cssResolved.cache;
      return lastPrepared;
    }

    const worldDrawScratch = lastPrepared && lastPrepared.worldDrawScratch
      ? lastPrepared.worldDrawScratch
      : createSceneWorldDrawScratch();
    const worldDrawPlan = buildSceneWorldDrawPlan(source, worldDrawScratch);
    const pbrPasses = prepareScenePBRPasses(source);
    const prepared = {
      ir: source,
      camera: resolvedCamera,
      viewport,
      signature,
      passes: scenePreparedPassList(worldDrawPlan, pbrPasses),
      pbrPasses,
      worldDrawPlan,
      worldDrawScratch,
      caches: lastPrepared && lastPrepared.caches ? lastPrepared.caches : new Map(),
      shadowPassHash: scenePlannerShadowHash(source),
      materialsHash: scenePlannerMaterialsHash(source),
      resolvedEnv: source.environment || {},
      cssDynamic: Boolean(cssResolved.dynamic),
      cssCache: cssResolved.cache,
      rebuilds: lastPrepared ? lastPrepared.rebuilds + 1 : 1,
    };
    return prepared;
  }

  function sceneResolveCSSBundle(source, cssContext) {
    const css = sceneCSSResolverContext(cssContext);
    return sceneResolveCSSBundleWithContext(source, css, sceneCSSInputSignature(source));
  }

  function sceneResolveCSSBundleWithContext(source, css, inputSignature) {
    sceneCSSDebugLog("[gosx:css-transition] FRESH RESOLVE revision=" + css.revision + " prevCache=" + Boolean(css.prevCache));
    const prevCache = css.prevCache || null;
    const prevResolved = prevCache && prevCache.resolvedVars ? prevCache.resolvedVars : null;
    const prevTransitions = prevCache && Array.isArray(prevCache.varTransitions) ? prevCache.varTransitions : [];
    const state = {
      source,
      out: source,
      dynamic: false,
      patches: [],
      resolvedVars: {},
      varTransitions: [],
      prevResolved,
      prevTransitions,
      nowMs: css.nowMs || Date.now(),
      _cssMount: css.mount || null,
    };
    sceneCSSResolveExplicitVars(state, css);
    sceneCSSApplyComputedDefaults(state, css);
    sceneCSSAdvanceVarTransitions(state);
    const cache = {
      inputSignature,
      revision: css.revision,
      transitionFrame: css.transitionFrame,
      dynamic: state.dynamic || state.varTransitions.length > 0,
      patches: state.patches,
      resolvedVars: state.resolvedVars,
      varTransitions: state.varTransitions,
    };
    return {
      ir: state.out,
      dynamic: state.dynamic || state.varTransitions.length > 0,
      cache,
    };
  }

  function sceneCSSVarTransitionKey(kind, collectionKey, index, key) {
    if (kind === "topObject") {
      return collectionKey + ":" + key;
    }
    return collectionKey + ":" + index + ":" + key;
  }

  function sceneCSSRecordTransitionTiming(state, kind, collectionKey, index) {
    var record = null;
    if (kind === "topObject") {
      var bundle = state.out || state.source || {};
      record = bundle[collectionKey];
    } else {
      var collection = sceneCSSCurrentCollection(state, collectionKey);
      record = Array.isArray(collection) ? collection[index] : null;
    }
    if (record && sceneIsPlainObject(record.transition)) {
    } else {
      var fallback = sceneCSSDefaultTransitionTiming(state);
      if (fallback) {
        record = { transition: { update: fallback } };
      } else {
        return null;
      }
    }
    var update = record.transition.update || record.transition;
    var duration = sceneCSSParseDuration(update.duration);
    if (duration <= 0) {
      return null;
    }
    return {
      duration: duration,
      easing: typeof update.easing === "string" ? update.easing : "ease-in-out",
    };
  }

  function sceneCSSDefaultTransitionTiming(state) {
    if (state._defaultTransitionTiming !== undefined) {
      return state._defaultTransitionTiming;
    }
    var mount = state._cssMount;
    var timing = mount && mount.__gosxScene3DCSSVarTransition;
    if (timing && typeof timing.duration === "number" && timing.duration > 0) {
      state._defaultTransitionTiming = timing;
      return timing;
    }
    state._defaultTransitionTiming = null;
    return null;
  }

  function sceneCSSFindMaterialForRecord(state, record) {
    var materials = sceneCSSCurrentCollection(state, "materials");
    if (!Array.isArray(materials) || materials.length === 0) {
      return null;
    }
    var idx = typeof record.materialIndex === "number" ? record.materialIndex : -1;
    if (idx >= 0 && idx < materials.length) {
      return materials[idx];
    }
    var name = typeof record.material === "string" ? record.material : "";
    if (name) {
      for (var i = 0; i < materials.length; i++) {
        if (materials[i] && materials[i].name === name) {
          return materials[i];
        }
      }
    }
    return null;
  }

  function sceneCSSParseDuration(value) {
    if (typeof value === "number") {
      return value;
    }
    if (typeof value !== "string") {
      return 0;
    }
    var text = value.trim().toLowerCase();
    if (text.endsWith("ms")) {
      return parseFloat(text) || 0;
    }
    if (text.endsWith("s")) {
      return (parseFloat(text) || 0) * 1000;
    }
    return parseFloat(text) || 0;
  }

  function sceneCSSMaybeTransitionValue(state, kind, collectionKey, index, key, newValue) {
    var cacheKey = sceneCSSVarTransitionKey(kind, collectionKey, index, key);
    state.resolvedVars[cacheKey] = newValue;
    if (!state.prevResolved || !Object.prototype.hasOwnProperty.call(state.prevResolved, cacheKey)) {
      sceneCSSDebugLog("[gosx:css-transition] no prev for", cacheKey, "value=", newValue);
      return false;
    }
    var oldValue = state.prevResolved[cacheKey];
    if (sceneCSSSameValue(oldValue, newValue)) {
      return false;
    }
    var timing = sceneCSSRecordTransitionTiming(state, kind, collectionKey, index);
    if (!timing) {
      sceneCSSDebugLog("[gosx:css-transition] no timing for", cacheKey, "old=", oldValue, "new=", newValue);
      return false;
    }
    sceneCSSDebugLog("[gosx:css-transition] CREATING transition", cacheKey, oldValue, "->", newValue, "duration=", timing.duration);
    for (var i = state.varTransitions.length - 1; i >= 0; i--) {
      if (state.varTransitions[i].cacheKey === cacheKey) {
        state.varTransitions.splice(i, 1);
      }
    }
    for (var j = state.prevTransitions.length - 1; j >= 0; j--) {
      if (state.prevTransitions[j].cacheKey === cacheKey) {
        var active = state.prevTransitions[j];
        var elapsed = Math.max(0, state.nowMs - active.startTime);
        var t = Math.min(1, elapsed / Math.max(1, active.duration));
        oldValue = sceneTransitionLeafValue(active.from, active.to, sceneTransitionEase(active.easing, t), key);
        state.prevTransitions.splice(j, 1);
      }
    }
    state.varTransitions.push({
      cacheKey: cacheKey,
      kind: kind,
      collectionKey: collectionKey,
      index: index,
      key: key,
      from: sceneCloneData(oldValue),
      to: sceneCloneData(newValue),
      startTime: state.nowMs,
      duration: timing.duration,
      easing: timing.easing,
    });
    return true;
  }

  function sceneCSSAdvanceVarTransitions(state) {
    var carried = state.prevTransitions;
    var all = carried.concat(state.varTransitions);
    var active = [];
    for (var i = 0; i < all.length; i++) {
      var transition = all[i];
      var elapsed = Math.max(0, state.nowMs - transition.startTime);
      var rawT = Math.min(1, elapsed / Math.max(1, transition.duration));
      var eased = sceneTransitionEase(transition.easing, rawT);
      var value = sceneTransitionLeafValue(transition.from, transition.to, eased, transition.key);
      if (transition.kind === "topObject") {
        sceneCSSSetTopObjectKey(state, transition.collectionKey, transition.key, value);
      } else if (transition.kind === "nested") {
        sceneCSSSetNestedKey(state, transition.collectionKey, transition.index, transition.childKey || "", transition.key, value);
      } else {
        sceneCSSSetRecordKey(state, transition.collectionKey, transition.index, transition.key, value);
      }
      if (rawT < 1) {
        active.push(transition);
      }
      state.resolvedVars[transition.cacheKey] = transition.to;
    }
    state.varTransitions = active;
    if (active.length > 0) {
      state.dynamic = true;
    }
  }

  function sceneCSSResolverContext(input) {
    const context = input && typeof input === "object" ? input : {};
    const mount = context.mount && typeof context.mount === "object" ? context.mount : null;
    const sentinels = context.sentinels || (mount && mount.__gosxScene3DSentinels) || null;
    const win = typeof window !== "undefined" ? window : null;
    const revision = sceneCSSContextRevision(context, mount);
    const animationUntil = sceneCSSContextAnimationUntil(context, mount);
    const now = typeof Date !== "undefined" && typeof Date.now === "function" ? Date.now() : 0;
    return {
      mount,
      sentinels,
      styles: typeof Map === "function" ? new Map() : null,
      hasComputedStyle: Boolean(win && typeof win.getComputedStyle === "function"),
      revision,
      transitionFrame: animationUntil > now ? Math.floor(now / 16) : 0,
    };
  }

  function sceneCSSContextRevision(context, mount) {
    const raw = context.revision != null
      ? context.revision
      : context.cssRevision != null
        ? context.cssRevision
        : mount && mount.__gosxScene3DCSSRevision;
    const revision = Number(raw);
    return Number.isFinite(revision) ? revision : 0;
  }

  function sceneCSSContextAnimationUntil(context, mount) {
    const raw = context.animationUntil != null
      ? context.animationUntil
      : context.cssAnimationUntil != null
        ? context.cssAnimationUntil
        : mount && mount.__gosxScene3DCSSAnimationUntil;
    const until = Number(raw);
    return Number.isFinite(until) ? until : 0;
  }

  function sceneCSSInputSignature(bundle) {
    let hash = 2166136261 >>> 0;
    hash = scenePlannerHashString(hash, "css");
    hash = scenePlannerHashAny(hash, bundle && bundle.environment, 0);
    hash = sceneCSSHashCollection(hash, bundle && bundle.materials, [
      "id", "name", "kind", "color", "opacity", "emissive", "roughness", "metalness",
      "normalMap", "roughnessMap", "metalnessMap", "emissiveMap", "blendMode",
      "renderPass", "depthWrite", "style", "size", "attenuation",
    ]);
    hash = sceneCSSHashCollection(hash, bundle && bundle.lights, [
      "id", "kind", "color", "groundColor", "intensity", "x", "y", "z",
      "directionX", "directionY", "directionZ", "angle", "penumbra",
      "range", "decay", "shadowBias", "shadowSize",
    ]);
    hash = sceneCSSHashCollection(hash, bundle && bundle.objects, [
      "id", "kind", "material", "materialIndex", "color", "opacity", "emissive",
      "roughness", "metalness", "lineWidth", "x", "y", "z", "rotationX",
      "rotationY", "rotationZ", "spinX", "spinY", "spinZ",
    ]);
    hash = sceneCSSHashCollection(hash, bundle && bundle.meshObjects, [
      "id", "kind", "material", "materialIndex", "depthCenter", "vertexOffset",
      "vertexCount", "color", "opacity", "roughness", "metalness",
    ]);
    hash = sceneCSSHashCollection(hash, bundle && bundle.points, [
      "id", "material", "materialIndex", "count", "color", "size", "opacity",
      "blendMode", "depthWrite", "x", "y", "z", "rotationX", "rotationY",
      "rotationZ", "spinX", "spinY", "spinZ",
    ]);
    hash = sceneCSSHashCollection(hash, bundle && bundle.instancedMeshes, [
      "id", "kind", "material", "materialIndex", "count", "color", "roughness",
      "metalness", "width", "height", "depth", "radius",
    ]);
    hash = sceneCSSHashCollection(hash, bundle && bundle.labels, [
      "id", "color", "background", "borderColor", "offsetX", "offsetY", "opacity",
    ]);
    hash = sceneCSSHashCollection(hash, bundle && bundle.sprites, [
      "id", "width", "height", "scale", "opacity", "offsetX", "offsetY",
    ]);
    hash = sceneCSSHashComputeParticles(hash, bundle && bundle.computeParticles);
    hash = sceneCSSHashCollection(hash, bundle && bundle.postEffects, [
      "kind", "threshold", "intensity", "radius", "scale", "bias", "saturation", "contrast", "exposure",
    ]);
    hash = sceneCSSHashCollection(hash, bundle && bundle.postFX, [
      "kind", "threshold", "intensity", "radius", "scale", "bias", "saturation", "contrast", "exposure",
    ]);
    return String(hash);
  }

  function sceneCSSHashCollection(hash, collection, keys) {
    if (!Array.isArray(collection)) {
      return scenePlannerHashNumber(hash, 0);
    }
    hash = scenePlannerHashNumber(hash, collection.length);
    for (let index = 0; index < collection.length; index += 1) {
      hash = sceneCSSHashRecordKeys(hash, collection[index], keys);
    }
    return hash;
  }

  function sceneCSSHashRecordKeys(hash, record, keys) {
    if (!record || typeof record !== "object") {
      return scenePlannerHashString(hash, "null");
    }
    for (let index = 0; index < keys.length; index += 1) {
      const key = keys[index];
      hash = scenePlannerHashString(hash, key);
      hash = scenePlannerHashAny(hash, record[key], 0);
    }
    return hash;
  }

  function sceneCSSHashComputeParticles(hash, collection) {
    if (!Array.isArray(collection)) {
      return scenePlannerHashNumber(hash, 0);
    }
    hash = scenePlannerHashNumber(hash, collection.length);
    for (let index = 0; index < collection.length; index += 1) {
      const record = collection[index] || {};
      hash = sceneCSSHashRecordKeys(hash, record, ["id", "kind", "count"]);
      hash = sceneCSSHashRecordKeys(hash, record.emitter, [
        "x", "y", "z", "rotationX", "rotationY", "rotationZ", "spinX", "spinY",
        "spinZ", "radius", "rate", "lifetime", "arms", "wind", "scatter",
      ]);
      hash = sceneCSSHashRecordKeys(hash, record.material, [
        "color", "colorEnd", "size", "sizeEnd", "opacity", "opacityEnd",
      ]);
    }
    return hash;
  }

  function sceneCSSApplyCachedResolution(source, cache) {
    const patches = cache && Array.isArray(cache.patches) ? cache.patches : [];
    if (!patches.length) {
      return {
        ir: source,
        dynamic: Boolean(cache && cache.dynamic),
        cache,
      };
    }
    const state = {
      source,
      out: source,
      dynamic: Boolean(cache.dynamic),
    };
    const recordGroups = typeof Map === "function" ? new Map() : null;
    for (let index = 0; index < patches.length; index += 1) {
      const patch = patches[index];
      if (patch && patch.kind === "record" && recordGroups) {
        const key = String(patch.collectionKey) + ":" + String(patch.index);
        if (!recordGroups.has(key)) {
          recordGroups.set(key, []);
        }
        recordGroups.get(key).push(patch);
      } else {
        sceneCSSApplyPatch(state, patch);
      }
    }
    if (recordGroups) {
      recordGroups.forEach(function(group) {
        sceneCSSApplyRecordPatchGroup(state, group, cache);
      });
    }
    return {
      ir: state.out,
      dynamic: Boolean(cache.dynamic),
      cache,
    };
  }

  function sceneCSSApplyRecordPatchGroup(state, patches, cache) {
    if (!Array.isArray(patches) || patches.length === 0) {
      return;
    }
    const first = patches[0];
    const collectionKey = first.collectionKey;
    const index = first.index;
    const sourceList = Array.isArray(state.source[collectionKey]) ? state.source[collectionKey] : [];
    const sourceRecord = sourceList[index];
    if (!sceneIsPlainObject(sourceRecord)) {
      for (let patchIndex = 0; patchIndex < patches.length; patchIndex += 1) {
        sceneCSSApplyPatch(state, patches[patchIndex]);
      }
      return;
    }
    const signature = sceneCSSRecordPatchSignature(patches);
    const existingCache = sourceRecord._sceneCSSPatchCache;
    if (
      existingCache &&
      existingCache.inputSignature === cache.inputSignature &&
      existingCache.revision === cache.revision &&
      existingCache.transitionFrame === cache.transitionFrame &&
      existingCache.signature === signature &&
      existingCache.value
    ) {
      const list = sceneCSSMutableArray(state, collectionKey);
      list[index] = existingCache.value;
      return;
    }
    const list = sceneCSSMutableArray(state, collectionKey);
    const next = Object.assign({}, sourceRecord);
    for (let patchIndex = 0; patchIndex < patches.length; patchIndex += 1) {
      const patch = patches[patchIndex];
      next[patch.key] = sceneCSSClonePatchValue(patch.value);
    }
    list[index] = next;
    sourceRecord._sceneCSSPatchCache = {
      inputSignature: cache.inputSignature,
      revision: cache.revision,
      transitionFrame: cache.transitionFrame,
      signature,
      value: next,
    };
  }

  function sceneCSSRecordPatchSignature(patches) {
    let signature = "";
    for (let index = 0; index < patches.length; index += 1) {
      const patch = patches[index];
      signature += String(patch.key) + "=" + String(patch.value) + ";";
    }
    return signature;
  }

  function sceneCSSApplyPatch(state, patch) {
    if (!patch || typeof patch !== "object") {
      return;
    }
    const value = sceneCSSClonePatchValue(patch.value);
    switch (patch.kind) {
      case "topObject":
        sceneCSSSetTopObjectKey(state, patch.objectKey, patch.key, value);
        break;
      case "topValue":
        sceneCSSSetTopValue(state, patch.key, value);
        break;
      case "record":
        sceneCSSSetRecordKey(state, patch.collectionKey, patch.index, patch.key, value);
        break;
      case "nested":
        sceneCSSSetNestedKey(state, patch.collectionKey, patch.index, patch.childKey, patch.key, value);
        break;
      default:
        break;
    }
  }

  function sceneCSSClonePatchValue(value) {
    if (Array.isArray(value)) {
      return value.map(sceneCSSClonePatchValue);
    }
    if (sceneIsPlainObject(value)) {
      return Object.assign({}, value);
    }
    return value;
  }

  function sceneCSSResolveExplicitVars(state, css) {
    sceneCSSResolveTopObjectKeys(state, css, "environment", [
      "ambientColor", "ambientIntensity", "skyColor", "skyIntensity",
      "groundColor", "groundIntensity", "exposure", "fogColor", "fogDensity",
    ], css.mount);
    sceneCSSResolveCollectionKeys(state, css, "materials", [
      "color", "opacity", "emissive", "roughness", "metalness",
      "clearcoat", "sheen", "transmission", "iridescence", "anisotropy",
      "normalMap", "roughnessMap", "metalnessMap", "emissiveMap",
    ], null);
    sceneCSSResolveCollectionKeys(state, css, "lights", [
      "color", "groundColor", "intensity", "x", "y", "z",
      "directionX", "directionY", "directionZ", "angle", "penumbra",
      "range", "decay", "width", "height", "shadowBias", "shadowSize",
    ], sceneCSSRecordElement);
    sceneCSSResolveCollectionKeys(state, css, "objects", [
      "color", "opacity", "emissive", "roughness", "metalness",
      "clearcoat", "sheen", "transmission", "iridescence", "anisotropy", "lineWidth",
      "x", "y", "z", "rotationX", "rotationY", "rotationZ",
      "spinX", "spinY", "spinZ",
    ], sceneCSSRecordElement);
    sceneCSSResolveCollectionKeys(state, css, "meshObjects", [
      "depthCenter", "vertexOffset", "vertexCount",
    ], sceneCSSRecordElement);
    sceneCSSResolveCollectionKeys(state, css, "points", [
      "color", "size", "opacity", "x", "y", "z",
      "rotationX", "rotationY", "rotationZ", "spinX", "spinY", "spinZ",
    ], sceneCSSRecordElement);
    sceneCSSResolveCollectionKeys(state, css, "instancedMeshes", [
      "color", "roughness", "metalness", "width", "height", "depth", "radius",
    ], sceneCSSRecordElement);
    sceneCSSResolveCollectionKeys(state, css, "labels", [
      "color", "background", "borderColor", "offsetX", "offsetY", "opacity",
    ], sceneCSSRecordElement);
    sceneCSSResolveCollectionKeys(state, css, "sprites", [
      "width", "height", "scale", "opacity", "offsetX", "offsetY",
    ], sceneCSSRecordElement);
    sceneCSSResolveCollectionKeys(state, css, "postEffects", [
      "threshold", "intensity", "radius", "scale", "bias", "saturation", "contrast", "exposure", "focusDistance", "aperture", "maxBlur",
    ], null);
    sceneCSSResolveCollectionKeys(state, css, "postFX", [
      "threshold", "intensity", "radius", "scale", "bias", "saturation", "contrast", "exposure", "focusDistance", "aperture", "maxBlur",
    ], null);
    sceneCSSResolveComputeParticleVars(state, css);
  }

  function sceneCSSResolveTopObjectKeys(state, css, objectKey, keys, element) {
    const bundle = state.out || state.source || {};
    const target = bundle && bundle[objectKey];
    if (!sceneIsPlainObject(target)) {
      return;
    }
    for (let index = 0; index < keys.length; index += 1) {
      const key = keys[index];
      const resolved = sceneCSSResolveVarValue(target[key], element || css.mount, css);
      if (!resolved.matched) {
        continue;
      }
      state.dynamic = true;
      if (resolved.hasValue) {
        if (sceneCSSMaybeTransitionValue(state, "topObject", objectKey, 0, key, resolved.value)) {
          continue;
        }
        sceneCSSSetTopObjectKey(state, objectKey, key, resolved.value);
      }
    }
  }

  function sceneCSSResolveCollectionKeys(state, css, collectionKey, keys, elementFn) {
    const collection = sceneCSSCurrentCollection(state, collectionKey);
    if (!Array.isArray(collection)) {
      return;
    }
    for (let index = 0; index < collection.length; index += 1) {
      const record = collection[index];
      if (!sceneIsPlainObject(record)) {
        continue;
      }
      const element = typeof elementFn === "function" ? elementFn(css, record) : css.mount;
      for (let keyIndex = 0; keyIndex < keys.length; keyIndex += 1) {
        const key = keys[keyIndex];
        const resolved = sceneCSSResolveVarValue(record[key], element, css);
        if (!resolved.matched) {
          continue;
        }
        state.dynamic = true;
        if (resolved.hasValue) {
          if (sceneCSSMaybeTransitionValue(state, "record", collectionKey, index, key, resolved.value)) {
            continue;
          }
          sceneCSSSetRecordKey(state, collectionKey, index, key, resolved.value);
        }
      }
    }
  }

  function sceneCSSResolveComputeParticleVars(state, css) {
    const collection = sceneCSSCurrentCollection(state, "computeParticles");
    if (!Array.isArray(collection)) {
      return;
    }
    const nested = [
      ["emitter", ["x", "y", "z", "rotationX", "rotationY", "rotationZ", "spinX", "spinY", "spinZ", "radius", "rate", "lifetime", "arms", "wind", "scatter"]],
      ["material", ["color", "colorEnd", "size", "sizeEnd", "opacity", "opacityEnd"]],
    ];
    for (let index = 0; index < collection.length; index += 1) {
      const record = collection[index];
      if (!sceneIsPlainObject(record)) {
        continue;
      }
      const element = sceneCSSRecordElement(css, record);
      for (let nestedIndex = 0; nestedIndex < nested.length; nestedIndex += 1) {
        const childKey = nested[nestedIndex][0];
        const keys = nested[nestedIndex][1];
        const child = sceneIsPlainObject(record[childKey]) ? record[childKey] : null;
        if (!child) {
          continue;
        }
        for (let keyIndex = 0; keyIndex < keys.length; keyIndex += 1) {
          const key = keys[keyIndex];
          const resolved = sceneCSSResolveVarValue(child[key], element, css);
          if (!resolved.matched) {
            continue;
          }
          state.dynamic = true;
          if (resolved.hasValue) {
            sceneCSSSetNestedKey(state, "computeParticles", index, childKey, key, resolved.value);
          }
        }
      }
    }
  }

  function sceneCSSApplyComputedDefaults(state, css) {
    if (!css.hasComputedStyle || !css.mount) {
      return;
    }
    sceneCSSApplyEnvironmentDefaults(state, css);
    sceneCSSApplySceneFilter(state, css);
    sceneCSSApplyLightDefaults(state, css);
    sceneCSSApplyNodeDefaults(state, css);
  }

  function sceneCSSApplyEnvironmentDefaults(state, css) {
    const mappings = [
      ["ambientColor", ["--scene-ambient-color"]],
      ["ambientIntensity", ["--scene-ambient-intensity"]],
      ["fogColor", ["--scene-fog-color"]],
      ["fogDensity", ["--scene-fog-density"]],
      ["skyColor", ["--scene-sky-color"]],
      ["skyIntensity", ["--scene-sky-intensity"]],
      ["groundColor", ["--scene-ground-color"]],
      ["groundIntensity", ["--scene-ground-intensity"]],
      ["exposure", ["--scene-exposure"]],
      ["toneMapping", ["--scene-tone-mapping"]],
    ];
    for (let index = 0; index < mappings.length; index += 1) {
      const key = mappings[index][0];
      const value = sceneCSSReadFirstProperty(css, css.mount, mappings[index][1]);
      if (value == null) {
        continue;
      }
      sceneCSSSetTopObjectKey(state, "environment", key, sceneCSSCoerceValue(value));
      state.dynamic = true;
    }
  }

  function sceneCSSApplySceneFilter(state, css) {
    const value = sceneCSSReadFirstProperty(css, css.mount, ["--scene-filter", "scene-filter"]);
    if (value == null) {
      return;
    }
    const effects = sceneParseSceneFilter(value);
    if (!effects || effects.length === 0) {
      return;
    }
    sceneCSSSetTopValue(state, "postEffects", effects);
    state.dynamic = true;
  }

  function sceneCSSApplyLightDefaults(state, css) {
    const lights = sceneCSSCurrentCollection(state, "lights");
    if (!Array.isArray(lights)) {
      return;
    }
    for (let index = 0; index < lights.length; index += 1) {
      const light = lights[index];
      if (!sceneIsPlainObject(light)) {
        continue;
      }
      const element = sceneCSSRecordElement(css, light);
      const directional = String(light.kind || "").toLowerCase() === "directional";
      const colorNames = directional
        ? ["--sun-color", "--scene-sun-color", "--light-color", "--scene-light-color"]
        : ["--light-color", "--scene-light-color"];
      const intensityNames = directional
        ? ["--sun-intensity", "--scene-sun-intensity", "--light-intensity", "--scene-light-intensity"]
        : ["--light-intensity", "--scene-light-intensity"];
      const color = sceneCSSReadFirstProperty(css, element, colorNames);
      if (color != null) {
        sceneCSSSetRecordKey(state, "lights", index, "color", color);
        state.dynamic = true;
      }
      const intensity = sceneCSSReadFirstProperty(css, element, intensityNames);
      if (intensity != null) {
        sceneCSSSetRecordKey(state, "lights", index, "intensity", sceneCSSCoerceValue(intensity));
        state.dynamic = true;
      }
    }
  }

  function sceneCSSApplyNodeDefaults(state, css) {
    sceneCSSApplyMeshCollectionDefaults(state, css, "meshObjects");
    sceneCSSApplyMeshCollectionDefaults(state, css, "objects");
    sceneCSSApplyPointDefaults(state, css);
    sceneCSSApplyInstancedDefaults(state, css);
    sceneCSSApplyComputeDefaults(state, css);
  }

  function sceneCSSApplyMeshCollectionDefaults(state, css, collectionKey) {
    const collection = sceneCSSCurrentCollection(state, collectionKey);
    if (!Array.isArray(collection)) {
      return;
    }
    for (let index = 0; index < collection.length; index += 1) {
      const record = collection[index];
      if (!sceneIsPlainObject(record)) {
        continue;
      }
      const element = sceneCSSRecordElement(css, record);
      const color = sceneCSSReadFirstProperty(css, element, ["--mesh-color"]);
      const roughness = sceneCSSReadFirstProperty(css, element, ["--mesh-roughness"]);
      const metalness = sceneCSSReadFirstProperty(css, element, ["--mesh-metalness"]);
      const opacity = sceneCSSReadFirstProperty(css, element, ["--mesh-opacity", "--material-opacity"]);
      if (color != null || roughness != null || metalness != null || opacity != null) {
        const material = sceneCSSMutableMaterialForRecord(state, record);
        if (material) {
          const materialIndex = sceneCSSMaterialIndexForRecord(record);
          if (color != null) sceneCSSSetRecordKey(state, "materials", materialIndex, "color", color);
          if (roughness != null) sceneCSSSetRecordKey(state, "materials", materialIndex, "roughness", sceneCSSCoerceValue(roughness));
          if (metalness != null) sceneCSSSetRecordKey(state, "materials", materialIndex, "metalness", sceneCSSCoerceValue(metalness));
          if (opacity != null) sceneCSSSetRecordKey(state, "materials", materialIndex, "opacity", sceneCSSCoerceValue(opacity));
        } else {
          if (color != null) sceneCSSSetRecordKey(state, collectionKey, index, "color", color);
          if (roughness != null) sceneCSSSetRecordKey(state, collectionKey, index, "roughness", sceneCSSCoerceValue(roughness));
          if (metalness != null) sceneCSSSetRecordKey(state, collectionKey, index, "metalness", sceneCSSCoerceValue(metalness));
          if (opacity != null) sceneCSSSetRecordKey(state, collectionKey, index, "opacity", sceneCSSCoerceValue(opacity));
        }
        state.dynamic = true;
      }
    }
  }

  function sceneCSSApplyPointDefaults(state, css) {
    const collection = sceneCSSCurrentCollection(state, "points");
    if (!Array.isArray(collection)) {
      return;
    }
    for (let index = 0; index < collection.length; index += 1) {
      const record = collection[index];
      if (!sceneIsPlainObject(record)) {
        continue;
      }
      const element = sceneCSSRecordElement(css, record);
      const color = sceneCSSReadFirstProperty(css, element, ["--point-color", "--mesh-color"]);
      const size = sceneCSSReadFirstProperty(css, element, ["--point-size"]);
      const opacity = sceneCSSReadFirstProperty(css, element, ["--point-opacity"]);
      if (color != null) {
        sceneCSSSetRecordKey(state, "points", index, "color", color);
        state.dynamic = true;
      }
      if (size != null) {
        sceneCSSSetRecordKey(state, "points", index, "size", sceneCSSCoerceValue(size));
        state.dynamic = true;
      }
      if (opacity != null) {
        sceneCSSSetRecordKey(state, "points", index, "opacity", sceneCSSCoerceValue(opacity));
        state.dynamic = true;
      }
    }
  }

  function sceneCSSApplyInstancedDefaults(state, css) {
    const collection = sceneCSSCurrentCollection(state, "instancedMeshes");
    if (!Array.isArray(collection)) {
      return;
    }
    for (let index = 0; index < collection.length; index += 1) {
      const record = collection[index];
      if (!sceneIsPlainObject(record)) {
        continue;
      }
      const element = sceneCSSRecordElement(css, record);
      const color = sceneCSSReadFirstProperty(css, element, ["--mesh-color"]);
      const roughness = sceneCSSReadFirstProperty(css, element, ["--mesh-roughness"]);
      const metalness = sceneCSSReadFirstProperty(css, element, ["--mesh-metalness"]);
      if (color != null) {
        sceneCSSSetRecordKey(state, "instancedMeshes", index, "color", color);
        state.dynamic = true;
      }
      if (roughness != null) {
        sceneCSSSetRecordKey(state, "instancedMeshes", index, "roughness", sceneCSSCoerceValue(roughness));
        state.dynamic = true;
      }
      if (metalness != null) {
        sceneCSSSetRecordKey(state, "instancedMeshes", index, "metalness", sceneCSSCoerceValue(metalness));
        state.dynamic = true;
      }
    }
  }

  function sceneCSSApplyComputeDefaults(state, css) {
    const collection = sceneCSSCurrentCollection(state, "computeParticles");
    if (!Array.isArray(collection)) {
      return;
    }
    for (let index = 0; index < collection.length; index += 1) {
      const record = collection[index];
      if (!sceneIsPlainObject(record)) {
        continue;
      }
      const element = sceneCSSRecordElement(css, record);
      const wind = sceneCSSReadFirstProperty(css, element, ["--scene-particle-wind"]);
      if (wind != null) {
        sceneCSSSetNestedKey(state, "computeParticles", index, "emitter", "wind", sceneCSSCoerceValue(wind));
        state.dynamic = true;
      }
      const color = sceneCSSReadFirstProperty(css, element, ["--point-color", "--mesh-color"]);
      const size = sceneCSSReadFirstProperty(css, element, ["--point-size"]);
      const opacity = sceneCSSReadFirstProperty(css, element, ["--point-opacity"]);
      if (color != null || size != null || opacity != null) {
        if (color != null) sceneCSSSetNestedKey(state, "computeParticles", index, "material", "color", color);
        if (size != null) sceneCSSSetNestedKey(state, "computeParticles", index, "material", "size", sceneCSSCoerceValue(size));
        if (opacity != null) sceneCSSSetNestedKey(state, "computeParticles", index, "material", "opacity", sceneCSSCoerceValue(opacity));
        state.dynamic = true;
      }
    }
  }

  function sceneCSSCurrentCollection(state, key) {
    const bundle = state.out || state.source || {};
    return bundle[key];
  }

  function sceneCSSRecordElement(css, record) {
    if (!record || !record.id) {
      return css.mount;
    }
    const id = String(record.id);
    const sentinels = css.sentinels;
    if (!sentinels) {
      return css.mount;
    }
    if (typeof sentinels.get === "function") {
      return sentinels.get(id) || css.mount;
    }
    return sentinels[id] || css.mount;
  }

  function sceneCSSResolveVarValue(value, element, css) {
    if (typeof value !== "string") {
      return { matched: false, hasValue: false, value };
    }
    const parsed = sceneCSSParseVarExpression(value);
    if (!parsed) {
      return { matched: false, hasValue: false, value };
    }
    const computed = sceneCSSReadProperty(css, element, parsed.name);
    const text = computed != null && computed !== "" ? computed : parsed.fallback;
    if (text == null || String(text).trim() === "") {
      return { matched: true, hasValue: false, value };
    }
    return {
      matched: true,
      hasValue: true,
      value: sceneCSSCoerceValue(text),
    };
  }

  function sceneCSSParseVarExpression(value) {
    const text = String(value || "").trim();
    const match = /^var\(\s*(--[-_a-zA-Z0-9]+)\s*(?:,\s*([\s\S]*?))?\s*\)$/.exec(text);
    if (!match) {
      return null;
    }
    return {
      name: match[1],
      fallback: match[2] == null ? null : match[2].trim(),
    };
  }

  function sceneCSSReadFirstProperty(css, element, names) {
    for (let index = 0; index < names.length; index += 1) {
      const value = sceneCSSReadProperty(css, element, names[index]);
      if (value != null && value !== "") {
        return value;
      }
    }
    return null;
  }

  function sceneCSSReadProperty(css, element, name) {
    if (!css || !css.hasComputedStyle || !name) {
      return null;
    }
    const primary = sceneCSSReadPropertyOnElement(css, element || css.mount, name);
    if (primary != null && primary !== "") {
      return primary;
    }
    if (element && element !== css.mount) {
      return sceneCSSReadPropertyOnElement(css, css.mount, name);
    }
    return primary;
  }

  function sceneCSSReadPropertyOnElement(css, element, name) {
    const style = sceneCSSComputedStyle(css, element);
    if (!style) {
      return null;
    }
    let value = "";
    if (typeof style.getPropertyValue === "function") {
      value = style.getPropertyValue(name);
    } else if (Object.prototype.hasOwnProperty.call(style, name)) {
      value = style[name];
    }
    const text = String(value == null ? "" : value).trim();
    return text === "" ? null : text;
  }

  function sceneCSSComputedStyle(css, element) {
    if (!element || !css.hasComputedStyle) {
      return null;
    }
    if (css.styles && css.styles.has(element)) {
      return css.styles.get(element);
    }
    let style = null;
    try {
      style = window.getComputedStyle(element);
    } catch (_error) {
      style = null;
    }
    if (css.styles) {
      css.styles.set(element, style);
    }
    return style;
  }

  function sceneCSSCoerceValue(value) {
    const text = String(value == null ? "" : value).trim();
    if (text === "") {
      return "";
    }
    if (/^[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?$/i.test(text)) {
      const number = Number(text);
      if (Number.isFinite(number)) {
        return number;
      }
    }
    return text;
  }

  function sceneCSSSameValue(left, right) {
    return left === right || String(left) === String(right);
  }

  function sceneCSSMutableBundle(state) {
    if (state.out === state.source) {
      state.out = Object.assign({}, state.source);
    }
    return state.out;
  }

  function sceneCSSMutableTopObject(state, key) {
    const bundle = sceneCSSMutableBundle(state);
    const current = sceneIsPlainObject(bundle[key]) ? bundle[key] : {};
    if (current === state.source[key]) {
      bundle[key] = Object.assign({}, current);
    } else if (!sceneIsPlainObject(bundle[key])) {
      bundle[key] = {};
    }
    return bundle[key];
  }

  function sceneCSSSetTopObjectKey(state, objectKey, key, value) {
    const current = state.out && state.out[objectKey];
    const oldValue = current && current[key];
    if (sceneCSSSameValue(oldValue, value)) {
      return false;
    }
    const object = sceneCSSMutableTopObject(state, objectKey);
    object[key] = value;
    sceneCSSRecordPatch(state, { kind: "topObject", objectKey, key, value });
    return true;
  }

  function sceneCSSSetTopValue(state, key, value) {
    const bundle = state.out || state.source || {};
    if (bundle[key] === value) {
      return false;
    }
    const mutable = sceneCSSMutableBundle(state);
    mutable[key] = value;
    sceneCSSRecordPatch(state, { kind: "topValue", key, value });
    return true;
  }

  function sceneCSSMutableArray(state, key) {
    const bundle = sceneCSSMutableBundle(state);
    const current = Array.isArray(bundle[key]) ? bundle[key] : [];
    if (current === state.source[key]) {
      bundle[key] = current.slice();
    } else if (!Array.isArray(bundle[key])) {
      bundle[key] = [];
    }
    return bundle[key];
  }

  function sceneCSSMutableRecord(state, key, index) {
    const list = sceneCSSMutableArray(state, key);
    const current = sceneIsPlainObject(list[index]) ? list[index] : {};
    const sourceList = Array.isArray(state.source[key]) ? state.source[key] : [];
    if (current === sourceList[index]) {
      list[index] = Object.assign({}, current);
    } else if (!sceneIsPlainObject(list[index])) {
      list[index] = {};
    }
    return list[index];
  }

  function sceneCSSSetRecordKey(state, collectionKey, index, key, value) {
    const list = sceneCSSCurrentCollection(state, collectionKey);
    const record = Array.isArray(list) ? list[index] : null;
    if (record && sceneCSSSameValue(record[key], value)) {
      return false;
    }
    const mutable = sceneCSSMutableRecord(state, collectionKey, index);
    mutable[key] = value;
    sceneCSSRecordPatch(state, { kind: "record", collectionKey, index, key, value });
    return true;
  }

  function sceneCSSSetNestedKey(state, collectionKey, index, childKey, key, value) {
    const list = sceneCSSCurrentCollection(state, collectionKey);
    const record = Array.isArray(list) ? list[index] : null;
    const child = record && sceneIsPlainObject(record[childKey]) ? record[childKey] : null;
    if (child && sceneCSSSameValue(child[key], value)) {
      return false;
    }
    const mutable = sceneCSSMutableNestedObject(state, collectionKey, index, childKey);
    mutable[key] = value;
    sceneCSSRecordPatch(state, { kind: "nested", collectionKey, index, childKey, key, value });
    return true;
  }

  function sceneCSSMutableNestedObject(state, collectionKey, index, childKey) {
    const record = sceneCSSMutableRecord(state, collectionKey, index);
    const current = sceneIsPlainObject(record[childKey]) ? record[childKey] : {};
    const sourceList = Array.isArray(state.source[collectionKey]) ? state.source[collectionKey] : [];
    const sourceRecord = sourceList[index];
    if (sourceRecord && current === sourceRecord[childKey]) {
      record[childKey] = Object.assign({}, current);
    } else if (!sceneIsPlainObject(record[childKey])) {
      record[childKey] = {};
    }
    return record[childKey];
  }

  function sceneCSSMutableMaterialForRecord(state, record) {
    const materialIndex = sceneCSSMaterialIndexForRecord(record);
    const materials = sceneCSSCurrentCollection(state, "materials");
    if (!Array.isArray(materials) || materialIndex < 0 || materialIndex >= materials.length) {
      return null;
    }
    return sceneCSSMutableRecord(state, "materials", materialIndex);
  }

  function sceneCSSMaterialIndexForRecord(record) {
    return Math.floor(sceneNumber(record && record.materialIndex, -1));
  }

  function sceneCSSRecordPatch(state, patch) {
    if (!state || !Array.isArray(state.patches) || !patch) {
      return;
    }
    state.patches.push(Object.assign({}, patch, {
      value: sceneCSSClonePatchValue(patch.value),
    }));
  }

  function sceneParseSceneFilter(value) {
    const text = String(value || "").trim();
    if (!text || text === "none") {
      return [];
    }
    const effects = [];
    const fnPattern = /([a-zA-Z][-_a-zA-Z0-9]*)\s*\(([^)]*)\)/g;
    let match;
    while ((match = fnPattern.exec(text))) {
      const kind = sceneNormalizeSceneFilterKind(match[1]);
      if (!kind) {
        continue;
      }
      const effect = { kind };
      const body = String(match[2] || "").replace(/[,:=]/g, " ");
      const parts = body.split(/\s+/).filter(Boolean);
      for (let index = 0; index + 1 < parts.length; index += 2) {
        const key = sceneNormalizeSceneFilterKey(parts[index]);
        const valueText = parts[index + 1];
        if (!key) {
          continue;
        }
        const number = Number(valueText);
        if (Number.isFinite(number)) {
          effect[key] = number;
        }
      }
      effects.push(effect);
    }
    return effects;
  }

  function sceneNormalizeSceneFilterKind(kind) {
    const text = String(kind || "").trim().toLowerCase();
    if (text === "bloom" || text === "vignette") {
      return text;
    }
    if (text === "color-grade" || text === "color-grading" || text === "colorgrade") {
      return "color-grade";
    }
    return "";
  }

  function sceneNormalizeSceneFilterKey(key) {
    const text = String(key || "").trim().toLowerCase();
    switch (text) {
      case "threshold":
      case "intensity":
      case "radius":
      case "scale":
      case "saturation":
      case "contrast":
      case "exposure":
        return text;
      default:
        return "";
    }
  }

  function prepareScenePBRPasses(bundle) {
    const objects = Array.isArray(bundle && bundle.meshObjects) ? bundle.meshObjects : [];
    const materials = Array.isArray(bundle && bundle.materials) ? bundle.materials : [];
    const opaque = [];
    const alpha = [];
    const additive = [];

    for (let index = 0; index < objects.length; index += 1) {
      const object = objects[index];
      if (!scenePlannerRenderableObject(object)) {
        continue;
      }
      const material = materials[object.materialIndex] || null;
      const pass = typeof scenePBRObjectRenderPass === "function"
        ? scenePBRObjectRenderPass(object, material)
        : scenePlannerObjectRenderPass(object, material);
      if (pass === "alpha") {
        alpha.push(object);
      } else if (pass === "additive") {
        additive.push(object);
      } else {
        opaque.push(object);
      }
    }

    if (typeof scenePBRDepthSort === "function") {
      alpha.sort(scenePBRDepthSort);
      additive.sort(scenePBRDepthSort);
    } else {
      alpha.sort(scenePlannerDepthSort);
      additive.sort(scenePlannerDepthSort);
    }

    return { opaque, alpha, additive };
  }

  function scenePreparedPassList(worldDrawPlan, pbrPasses) {
    const passes = [];
    if (worldDrawPlan) {
      if (worldDrawPlan.staticOpaqueVertexCount > 0) {
        passes.push({ name: "staticOpaque", kind: "lines", blend: "opaque", depth: "opaque", vertexCount: worldDrawPlan.staticOpaqueVertexCount });
      }
      if (worldDrawPlan.dynamicOpaqueVertexCount > 0) {
        passes.push({ name: "dynamicOpaque", kind: "lines", blend: "opaque", depth: "opaque", vertexCount: worldDrawPlan.dynamicOpaqueVertexCount });
      }
      if (worldDrawPlan.alphaVertexCount > 0) {
        passes.push({ name: "alpha", kind: "lines", blend: "alpha", depth: "translucent", vertexCount: worldDrawPlan.alphaVertexCount });
      }
      if (worldDrawPlan.additiveVertexCount > 0) {
        passes.push({ name: "additive", kind: "lines", blend: "additive", depth: "translucent", vertexCount: worldDrawPlan.additiveVertexCount });
      }
    }
    if (pbrPasses) {
      if (pbrPasses.opaque.length > 0) {
        passes.push({ name: "pbrOpaque", kind: "mesh", blend: "opaque", depth: "opaque", count: pbrPasses.opaque.length });
      }
      if (pbrPasses.alpha.length > 0) {
        passes.push({ name: "pbrAlpha", kind: "mesh", blend: "alpha", depth: "translucent", count: pbrPasses.alpha.length });
      }
      if (pbrPasses.additive.length > 0) {
        passes.push({ name: "pbrAdditive", kind: "mesh", blend: "additive", depth: "translucent", count: pbrPasses.additive.length });
      }
    }
    return passes;
  }

  function sceneCachedBuffer(cacheOwner, typedArray, allocFn, uploadFn, options) {
    if (!typedArray) {
      return null;
    }
    const opts = options || {};
    if (opts.slot) {
      return sceneCachedSlotBuffer(cacheOwner, opts.slot, typedArray, allocFn, uploadFn, opts);
    }
    if (!cacheOwner || typeof cacheOwner.get !== "function" || typeof cacheOwner.set !== "function") {
      return sceneCachedSlotBuffer(cacheOwner || {}, "_sceneCachedBuffer", typedArray, allocFn, uploadFn, opts);
    }
    let handle = cacheOwner.get(typedArray);
    if (handle) {
      return handle;
    }
    handle = allocFn(typedArray);
    uploadFn(handle, typedArray, null);
    cacheOwner.set(typedArray, handle);
    return handle;
  }

  function scenePreparedCommandSequence(prepared) {
    const scene = prepared && prepared.ir ? prepared.ir : {};
    const commands = [];
    const pbrPasses = prepared && prepared.pbrPasses;
    if (pbrPasses) {
      sceneAppendPreparedMeshCommands(commands, "opaque", pbrPasses.opaque);
      sceneAppendPreparedMeshCommands(commands, "alpha", pbrPasses.alpha);
      sceneAppendPreparedMeshCommands(commands, "additive", pbrPasses.additive);
    }
    if (prepared && prepared.worldDrawPlan) {
      sceneAppendPreparedLineCommand(commands, "staticOpaque", prepared.worldDrawPlan.staticOpaqueVertexCount);
      sceneAppendPreparedLineCommand(commands, "dynamicOpaque", prepared.worldDrawPlan.dynamicOpaqueVertexCount);
      sceneAppendPreparedLineCommand(commands, "alpha", prepared.worldDrawPlan.alphaVertexCount);
      sceneAppendPreparedLineCommand(commands, "additive", prepared.worldDrawPlan.additiveVertexCount);
    }
    const points = Array.isArray(scene.points) ? scene.points : [];
    for (let index = 0; index < points.length; index += 1) {
      const entry = points[index];
      commands.push({
        op: "drawPoints",
        id: entry && entry.id || "",
        count: Math.max(0, Math.floor(sceneNumber(entry && entry.count, 0))),
      });
    }
    const instanced = Array.isArray(scene.instancedMeshes) ? scene.instancedMeshes : [];
    for (let index = 0; index < instanced.length; index += 1) {
      const entry = instanced[index];
      commands.push({
        op: "drawInstancedMesh",
        id: entry && entry.id || "",
        kind: entry && entry.kind || "",
        count: Math.max(0, Math.floor(sceneNumber(entry && entry.count, 0))),
      });
    }
    return commands;
  }

  function sceneAppendPreparedMeshCommands(commands, pass, objects) {
    const list = Array.isArray(objects) ? objects : [];
    for (let index = 0; index < list.length; index += 1) {
      const object = list[index];
      commands.push({
        op: "drawMesh",
        pass,
        id: object && object.id || "",
        kind: object && object.kind || "",
        vertexOffset: Math.max(0, Math.floor(sceneNumber(object && object.vertexOffset, 0))),
        vertexCount: Math.max(0, Math.floor(sceneNumber(object && object.vertexCount, 0))),
      });
    }
  }

  function sceneAppendPreparedLineCommand(commands, pass, vertexCount) {
    const count = Math.max(0, Math.floor(sceneNumber(vertexCount, 0)));
    if (count > 0) {
      commands.push({ op: "drawLines", pass, vertexCount: count });
    }
  }

  function sceneCachedSlotBuffer(owner, slot, typedArray, allocFn, uploadFn, options) {
    if (!owner) {
      return null;
    }
    const bytesKey = slot + "Bytes";
    const sourceKey = slot + "Source";
    let handle = owner[slot];
    if (!handle) {
      handle = allocFn(typedArray);
      owner[slot] = handle;
      owner[bytesKey] = 0;
      owner[sourceKey] = null;
    }
    const sourceChanged = owner[sourceKey] !== typedArray;
    const bytesChanged = owner[bytesKey] !== typedArray.byteLength;
    if (options && options.dynamic || sourceChanged || bytesChanged) {
      const replacement = uploadFn(handle, typedArray, {
        sourceChanged,
        bytesChanged,
        previousBytes: owner[bytesKey] || 0,
      });
      if (replacement && replacement !== handle) {
        handle = replacement;
        owner[slot] = handle;
      }
      owner[bytesKey] = typedArray.byteLength;
      owner[sourceKey] = typedArray;
    }
    return handle;
  }

  function scenePreparedSignature(bundle, camera, viewport) {
    let hash = 2166136261 >>> 0;
    hash = scenePlannerHashString(hash, "v");
    hash = scenePlannerHashNumber(hash, sceneNumber(bundle && (bundle.bundleVersion != null ? bundle.bundleVersion : bundle.version), 0));
    hash = scenePlannerHashCamera(hash, camera);
    hash = scenePlannerHashViewport(hash, viewport);
    hash = scenePlannerHashCollection(hash, bundle && bundle.meshObjects, scenePlannerHashMeshObject);
    hash = scenePlannerHashCollection(hash, bundle && bundle.objects, scenePlannerHashLineObject);
    hash = scenePlannerHashCollection(hash, bundle && bundle.materials, scenePlannerHashMaterial);
    hash = scenePlannerHashCollection(hash, bundle && bundle.lights, scenePlannerHashLight);
    hash = scenePlannerHashCollection(hash, bundle && bundle.points, scenePlannerHashPointsEntry);
    hash = scenePlannerHashCollection(hash, bundle && bundle.instancedMeshes, scenePlannerHashInstancedEntry);
    hash = scenePlannerHashCollection(hash, bundle && bundle.computeParticles, scenePlannerHashComputeEntry);
    hash = scenePlannerHashNumber(hash, arrayLength(bundle && bundle.worldPositions));
    hash = scenePlannerHashNumber(hash, arrayLength(bundle && bundle.worldColors));
    hash = scenePlannerHashArrayShape(hash, bundle && bundle.worldLineWidths);
    hash = scenePlannerHashArrayShape(hash, bundle && bundle.worldLinePasses);
    hash = scenePlannerHashNumber(hash, arrayLength(bundle && bundle.worldMeshPositions));
    hash = scenePlannerHashNumber(hash, arrayLength(bundle && bundle.worldMeshNormals));
    return String(hash);
  }

  function scenePlannerMaterialsHash(bundle) {
    let hash = 2166136261 >>> 0;
    return String(scenePlannerHashCollection(hash, bundle && bundle.materials, scenePlannerHashMaterial));
  }

  function scenePlannerShadowHash(bundle) {
    let hash = 2166136261 >>> 0;
    hash = scenePlannerHashCollection(hash, bundle && bundle.lights, scenePlannerHashLight);
    hash = scenePlannerHashCollection(hash, bundle && bundle.meshObjects, function(next, object) {
      if (!object || !object.castShadow) {
        return next;
      }
      return scenePlannerHashMeshObject(next, object);
    });
    return String(hash);
  }

  function scenePlannerRenderableObject(object) {
    return Boolean(
      object &&
      !object.viewCulled &&
      Number.isFinite(object.vertexOffset) &&
      Number.isFinite(object.vertexCount) &&
      object.vertexCount > 0
    );
  }

  function scenePlannerObjectRenderPass(object, material) {
    const objectPass = object && typeof object.renderPass === "string" ? object.renderPass.toLowerCase() : "";
    if (objectPass === "opaque" || objectPass === "alpha" || objectPass === "additive") {
      return objectPass;
    }
    const materialPass = material && typeof material.renderPass === "string" ? material.renderPass.toLowerCase() : "";
    if (materialPass === "opaque" || materialPass === "alpha" || materialPass === "additive") {
      return materialPass;
    }
    if (material && sceneNumber(material.opacity, 1) < 1) {
      return "alpha";
    }
    return "opaque";
  }

  function scenePlannerDepthSort(a, b) {
    const da = sceneNumber(a && a.depthCenter, 0);
    const db = sceneNumber(b && b.depthCenter, 0);
    if (da !== db) {
      return db - da;
    }
    return String(a && a.id || "").localeCompare(String(b && b.id || ""));
  }

  function scenePlannerHashCamera(hash, camera) {
    hash = scenePlannerHashString(hash, camera && camera.kind);
    hash = scenePlannerHashNumber(hash, sceneNumber(camera && camera.x, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(camera && camera.y, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(camera && camera.z, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(camera && camera.rotationX, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(camera && camera.rotationY, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(camera && camera.rotationZ, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(camera && camera.fov, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(camera && camera.left, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(camera && camera.right, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(camera && camera.top, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(camera && camera.bottom, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(camera && camera.zoom, 1));
    hash = scenePlannerHashNumber(hash, sceneNumber(camera && camera.near, 0));
    return scenePlannerHashNumber(hash, sceneNumber(camera && camera.far, 0));
  }

  function scenePlannerHashViewport(hash, viewport) {
    hash = scenePlannerHashNumber(hash, sceneNumber(viewport && viewport.cssWidth, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(viewport && viewport.cssHeight, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(viewport && viewport.pixelWidth, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(viewport && viewport.pixelHeight, 0));
    return scenePlannerHashNumber(hash, sceneNumber(viewport && viewport.pixelRatio, 0));
  }

  function scenePlannerHashCollection(hash, collection, itemFn) {
    if (!Array.isArray(collection)) {
      return scenePlannerHashNumber(hash, 0);
    }
    hash = scenePlannerHashNumber(hash, collection.length);
    for (let index = 0; index < collection.length; index += 1) {
      hash = itemFn(hash, collection[index]);
    }
    return hash;
  }

  function scenePlannerHashMeshObject(hash, object) {
    hash = scenePlannerHashString(hash, object && object.id || "");
    hash = scenePlannerHashString(hash, object && object.kind || "");
    hash = scenePlannerHashNumber(hash, sceneNumber(object && object.materialIndex, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(object && object.vertexOffset, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(object && object.vertexCount, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(object && object.depthCenter, 0));
    hash = scenePlannerHashNumber(hash, object && object.viewCulled ? 1 : 0);
    hash = scenePlannerHashNumber(hash, object && object.castShadow ? 1 : 0);
    return scenePlannerHashNumber(hash, object && object.receiveShadow ? 1 : 0);
  }

  function scenePlannerHashLineObject(hash, object) {
    hash = scenePlannerHashString(hash, object && object.id || "");
    hash = scenePlannerHashString(hash, object && object.kind || "");
    hash = scenePlannerHashNumber(hash, sceneNumber(object && object.materialIndex, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(object && object.vertexOffset, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(object && object.vertexCount, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(object && object.depthCenter, 0));
    hash = scenePlannerHashNumber(hash, object && object.static ? 1 : 0);
    return scenePlannerHashNumber(hash, object && object.viewCulled ? 1 : 0);
  }

  function scenePlannerHashMaterial(hash, material) {
    if (material && material.key) {
      hash = scenePlannerHashString(hash, material.key);
    }
    hash = scenePlannerHashString(hash, material && material.kind || "");
    hash = scenePlannerHashString(hash, material && material.color || "");
    hash = scenePlannerHashString(hash, material && material.texture || "");
    hash = scenePlannerHashString(hash, material && material.blendMode || "");
    hash = scenePlannerHashString(hash, material && material.renderPass || "");
    hash = scenePlannerHashNumber(hash, sceneNumber(material && material.opacity, 1));
    hash = scenePlannerHashNumber(hash, sceneNumber(material && material.emissive, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(material && material.roughness, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(material && material.metalness, 0));
    return scenePlannerHashNumber(hash, material && material.wireframe ? 1 : 0);
  }

  function scenePlannerHashLight(hash, light) {
    hash = scenePlannerHashString(hash, light && light.id || "");
    hash = scenePlannerHashString(hash, light && light.kind || "");
    hash = scenePlannerHashString(hash, light && light.color || "");
    hash = scenePlannerHashNumber(hash, sceneNumber(light && light.intensity, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(light && light.x, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(light && light.y, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(light && light.z, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(light && light.directionX, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(light && light.directionY, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(light && light.directionZ, 0));
    hash = scenePlannerHashNumber(hash, light && light.castShadow ? 1 : 0);
    return scenePlannerHashNumber(hash, sceneNumber(light && light.shadowSize, 0));
  }

  function scenePlannerHashPointsEntry(hash, entry) {
    hash = scenePlannerHashString(hash, entry && entry.id || "");
    hash = scenePlannerHashString(hash, entry && entry.material || "");
    hash = scenePlannerHashNumber(hash, sceneNumber(entry && entry.count, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(entry && entry.materialIndex, 0));
    hash = scenePlannerHashString(hash, entry && entry.blendMode || "");
    hash = scenePlannerHashNumber(hash, entry && entry.depthWrite === false ? 0 : 1);
    return scenePlannerHashNumber(hash, entry && entry.viewCulled ? 1 : 0);
  }

  function scenePlannerHashInstancedEntry(hash, entry) {
    hash = scenePlannerHashString(hash, entry && entry.id || "");
    hash = scenePlannerHashString(hash, entry && entry.kind || "");
    hash = scenePlannerHashString(hash, entry && entry.material || "");
    hash = scenePlannerHashNumber(hash, sceneNumber(entry && entry.count, 0));
    hash = scenePlannerHashNumber(hash, sceneNumber(entry && entry.materialIndex, 0));
    hash = scenePlannerHashString(hash, entry && entry.blendMode || "");
    return scenePlannerHashNumber(hash, entry && entry.depthWrite === false ? 0 : 1);
  }

  function scenePlannerHashComputeEntry(hash, entry) {
    hash = scenePlannerHashString(hash, entry && entry.id || "");
    hash = scenePlannerHashNumber(hash, sceneNumber(entry && entry.count, 0));
    hash = scenePlannerHashString(hash, entry && entry.kind || "");
    return scenePlannerHashString(hash, entry && entry.material && entry.material.blendMode || "");
  }

  function scenePlannerHashArrayShape(hash, value) {
    hash = scenePlannerHashNumber(hash, arrayLength(value));
    if (value && typeof value === "object") {
      hash = scenePlannerHashString(hash, Array.isArray(value) ? "array" : "typed");
    }
    return hash;
  }

  function scenePlannerHashAny(hash, value, depth) {
    if (value == null) {
      return scenePlannerHashString(hash, "null");
    }
    const valueType = typeof value;
    if (valueType === "number") {
      return scenePlannerHashNumber(hash, value);
    }
    if (valueType === "string" || valueType === "boolean") {
      return scenePlannerHashString(hash, String(value));
    }
    if (valueType !== "object" || depth > 5) {
      return scenePlannerHashString(hash, valueType);
    }
    if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView && ArrayBuffer.isView(value)) {
      return scenePlannerHashArraySample(hash, value);
    }
    if (Array.isArray(value)) {
      hash = scenePlannerHashString(hash, "array");
      hash = scenePlannerHashNumber(hash, value.length);
      const length = value.length;
      if (length <= 64) {
        for (let index = 0; index < length; index += 1) {
          hash = scenePlannerHashAny(hash, value[index], depth + 1);
        }
      } else {
        for (let index = 0; index < 16; index += 1) {
          hash = scenePlannerHashAny(hash, value[index], depth + 1);
        }
        hash = scenePlannerHashAny(hash, value[Math.floor(length / 2)], depth + 1);
        for (let index = Math.max(16, length - 16); index < length; index += 1) {
          hash = scenePlannerHashAny(hash, value[index], depth + 1);
        }
      }
      return hash;
    }
    const keys = Object.keys(value).filter(function(key) {
      return key && key.charAt(0) !== "_" && typeof value[key] !== "function";
    }).sort();
    hash = scenePlannerHashString(hash, "object");
    hash = scenePlannerHashNumber(hash, keys.length);
    for (let index = 0; index < keys.length; index += 1) {
      const key = keys[index];
      hash = scenePlannerHashString(hash, key);
      hash = scenePlannerHashAny(hash, value[key], depth + 1);
    }
    return hash;
  }

  function scenePlannerHashArraySample(hash, value) {
    const length = arrayLength(value);
    hash = scenePlannerHashString(hash, "typed");
    hash = scenePlannerHashNumber(hash, length);
    if (length === 0) {
      return hash;
    }
    const step = Math.max(1, Math.floor(length / 32));
    for (let index = 0; index < length; index += step) {
      hash = scenePlannerHashNumber(hash, sceneNumber(value[index], 0));
    }
    if ((length - 1) % step !== 0) {
      hash = scenePlannerHashNumber(hash, sceneNumber(value[length - 1], 0));
    }
    return hash;
  }

  function scenePlannerHashNumber(hash, value) {
    const scaled = Math.round(sceneNumber(value, 0) * 1000);
    hash ^= scaled;
    return Math.imul(hash, 16777619) >>> 0;
  }

  function scenePlannerHashString(hash, value) {
    const text = String(value || "");
    for (let i = 0; i < text.length; i += 1) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619) >>> 0;
    }
    return hash;
  }

  function arrayLength(value) {
    return value && typeof value.length === "number" ? value.length : 0;
  }

  var sceneBackendRegistry = (function() {
    const entries = [];
    const byKind = new Map();

    function register(kind, factory, options) {
      const normalizedKind = String(kind || "").trim();
      if (!normalizedKind) {
        throw new Error("scene backend kind is required");
      }
      const entry = normalizeBackendEntry(normalizedKind, factory, options);
      if (byKind.has(normalizedKind)) {
        const previous = byKind.get(normalizedKind);
        const index = entries.indexOf(previous);
        if (index >= 0) {
          entries.splice(index, 1, entry);
        }
      } else {
        entries.push(entry);
      }
      byKind.set(normalizedKind, entry);
      return entry;
    }

    function select(request) {
      const list = candidates(request);
      return list.length > 0 ? list[0] : null;
    }

    function candidates(request) {
      const req = request || {};
      const order = backendSelectionOrder(req);
      const out = [];
      for (const kind of order) {
        const entry = byKind.get(kind);
        if (!entry) {
          continue;
        }
        if (typeof entry.available === "function" && !entry.available(req)) {
          continue;
        }
        out.push(entry);
      }
      for (const entry of entries) {
        if (order.indexOf(entry.kind) >= 0) {
          continue;
        }
        if (!backendRequestAllowsKind(req, entry.kind)) {
          continue;
        }
        if (typeof entry.available === "function" && !entry.available(req)) {
          continue;
        }
        out.push(entry);
      }
      return out;
    }

    function list() {
      return entries.slice();
    }

    function dispose(kind) {
      if (kind == null) {
        entries.length = 0;
        byKind.clear();
        return;
      }
      const normalizedKind = String(kind || "").trim();
      const entry = byKind.get(normalizedKind);
      if (!entry) {
        return;
      }
      byKind.delete(normalizedKind);
      const index = entries.indexOf(entry);
      if (index >= 0) {
        entries.splice(index, 1);
      }
    }

    return {
      register,
      select,
      candidates,
      list,
      dispose,
    };
  })();

  function normalizeBackendEntry(kind, factory, options) {
    const opts = options || {};
    if (typeof factory === "function") {
      return {
        kind,
        capabilities: Array.isArray(opts.capabilities) ? opts.capabilities.slice() : [],
        create: factory,
        available: typeof opts.available === "function" ? opts.available : null,
        priority: sceneNumber(opts.priority, 0),
      };
    }
    const source = factory && typeof factory === "object" ? factory : {};
    return {
      kind,
      capabilities: Array.isArray(source.capabilities) ? source.capabilities.slice() : [],
      create: typeof source.create === "function" ? source.create : function() { return null; },
      available: typeof source.available === "function" ? source.available : null,
      priority: sceneNumber(source.priority, sceneNumber(opts.priority, 0)),
    };
  }

  function backendSelectionOrder(request) {
    const order = [];
    if (request.forceWebGL) {
      if (backendRequestAllowsKind(request, "webgl")) {
        order.push("webgl");
      }
      if (backendRequestAllowsKind(request, "canvas2d")) {
        order.push("canvas2d");
      }
      return order;
    }
    if (request.preferWebGPU && backendRequestAllowsKind(request, "webgpu")) {
      order.push("webgpu");
    }
    if (backendRequestAllowsKind(request, "webgl")) {
      order.push("webgl");
    }
    if (order.indexOf("webgpu") < 0 && backendRequestAllowsKind(request, "webgpu")) {
      order.push("webgpu");
    }
    if (backendRequestAllowsKind(request, "canvas2d")) {
      order.push("canvas2d");
    }
    return order;
  }

  function backendRequestAllowsKind(request, kind) {
    if (kind === "webgpu") {
      return request.webgpu !== false && (request.webgpu === true || request.preferWebGPU === true);
    }
    if (kind === "webgl") {
      return request.webgl !== false && (request.webgl === true || request.webgl2 === true);
    }
    if (kind === "canvas2d") {
      return request.canvas2d !== false && request.canvas !== false;
    }
    return request[kind] !== false;
  }

  if (window.__gosx_scene3d_api) {
    window.__gosx_scene3d_api.sceneBackendRegistry = sceneBackendRegistry;
  }

function resolvePostFXFactor(maxPixels, canvasPixels) {
  var cap = (typeof maxPixels === "number" && maxPixels > 0)
    ? maxPixels
    : 2073600; // PostFXMaxPixels1080p default
  if (canvasPixels <= cap) return 1;
  return Math.sqrt(cap / canvasPixels);
}

function resolveShadowSize(requestedSize, shadowMaxPixels) {
  var size = Math.max(1, requestedSize | 0);
  var cap = (typeof shadowMaxPixels === "number" && shadowMaxPixels > 0)
    ? shadowMaxPixels
    : 1048576; // ShadowMaxPixels1024 default
  var requestedPixels = size * size;
  if (requestedPixels <= cap) return size;
  var factor = Math.sqrt(cap / requestedPixels);
  return Math.max(1, Math.floor(size * factor));
}

var SCENE_TEXTURE_UNIT_MATERIALS = {
  albedo: 0,
  normal: 1,
  roughness: 2,
  metalness: 3,
  emissive: 4,
};
var SCENE_TEXTURE_UNIT_FIRST_SHARED = 5;
var SCENE_TEXTURE_UNIT_DEFAULT_MAX = 16;
var SCENE_TEXTURE_BUDGET_DEFAULT_BYTES = 26 * 1024 * 1024;

function sceneFiniteNumber(value, fallback) {
  return typeof value === "number" && isFinite(value) ? value : fallback;
}

function sceneClampInteger(value, min, max) {
  var next = Math.floor(sceneFiniteNumber(value, min));
  if (next < min) return min;
  if (next > max) return max;
  return next;
}

function sceneAllocateTextureUnits(options) {
  var opts = options || {};
  var requestedMaxUnits = Object.prototype.hasOwnProperty.call(opts, "maxUnits")
    ? opts.maxUnits
    : SCENE_TEXTURE_UNIT_DEFAULT_MAX;
  var maxUnits = sceneClampInteger(requestedMaxUnits, SCENE_TEXTURE_UNIT_FIRST_SHARED, 64);
  var shadowCount = sceneClampInteger(opts.shadowCount || 0, 0, 32);
  var needsIBL = Boolean(opts.ibl || opts.envMap);
  var iblUnitCount = needsIBL ? 3 : 0;
  var warnings = [];
  var availableShared = Math.max(0, maxUnits - SCENE_TEXTURE_UNIT_FIRST_SHARED);
  var availableForShadows = Math.max(0, availableShared - iblUnitCount);
  if (shadowCount > availableForShadows) {
    warnings.push("shadow texture units reduced from " + shadowCount + " to " + availableForShadows);
    shadowCount = availableForShadows;
  }

  var units = {
    material: {
      albedo: SCENE_TEXTURE_UNIT_MATERIALS.albedo,
      normal: SCENE_TEXTURE_UNIT_MATERIALS.normal,
      roughness: SCENE_TEXTURE_UNIT_MATERIALS.roughness,
      metalness: SCENE_TEXTURE_UNIT_MATERIALS.metalness,
      emissive: SCENE_TEXTURE_UNIT_MATERIALS.emissive,
    },
    shadows: [],
    ibl: null,
    maxUnits: maxUnits,
    warnings: warnings,
  };

  var unit = SCENE_TEXTURE_UNIT_FIRST_SHARED;
  for (var i = 0; i < shadowCount; i++) {
    units.shadows.push(unit++);
  }

  if (needsIBL) {
    if (unit + 2 < maxUnits) {
      units.ibl = {
        irradiance: unit,
        radiance: unit + 1,
        brdfLUT: unit + 2,
      };
    } else {
      warnings.push("IBL disabled because texture units are exhausted");
    }
  }

  return units;
}

function sceneTextureMipBytes(baseSize, mipLevels, faceCount, bytesPerPixel) {
  var total = 0;
  var size = Math.max(1, Math.floor(baseSize || 1));
  var levels = Math.max(1, Math.floor(mipLevels || 1));
  var faces = Math.max(1, Math.floor(faceCount || 1));
  var bpp = Math.max(1, Math.floor(bytesPerPixel || 1));
  for (var level = 0; level < levels; level++) {
    var mipSize = Math.max(1, Math.floor(size / Math.pow(2, level)));
    total += mipSize * mipSize * faces * bpp;
  }
  return total;
}

function sceneNormalizeIBLProfile(profile) {
  var source = profile || {};
  return {
    sourceFaceSize: sceneClampInteger(source.sourceFaceSize || 512, 16, 4096),
    irradianceFaceSize: sceneClampInteger(source.irradianceFaceSize || 32, 8, 512),
    radianceFaceSize: sceneClampInteger(source.radianceFaceSize || 128, 16, 1024),
    radianceMipLevels: sceneClampInteger(source.radianceMipLevels || 5, 1, 12),
    brdfSize: sceneClampInteger(source.brdfSize || 512, 16, 2048),
    bytesPerPixel: sceneClampInteger(source.bytesPerPixel || 8, 1, 16),
    brdfBytesPerPixel: sceneClampInteger(source.brdfBytesPerPixel || 4, 1, 16),
  };
}

function sceneEstimateIBLTextureBytes(profile) {
  var p = sceneNormalizeIBLProfile(profile);
  return sceneTextureMipBytes(p.sourceFaceSize, 1, 6, p.bytesPerPixel)
    + sceneTextureMipBytes(p.irradianceFaceSize, 1, 6, p.bytesPerPixel)
    + sceneTextureMipBytes(p.radianceFaceSize, p.radianceMipLevels, 6, p.bytesPerPixel)
    + sceneTextureMipBytes(p.brdfSize, 1, 1, p.brdfBytesPerPixel);
}

function sceneEstimateShadowTextureBytes(shadowSize, shadowCount) {
  var size = Math.max(1, Math.floor(shadowSize || 1));
  var count = Math.max(0, Math.floor(shadowCount || 0));
  return size * size * 4 * count;
}

function sceneDownscaleIBLProfile(profile) {
  var p = sceneNormalizeIBLProfile(profile);
  var next = {
    sourceFaceSize: Math.max(128, Math.floor(p.sourceFaceSize / 2)),
    irradianceFaceSize: Math.max(16, Math.floor(p.irradianceFaceSize / 2)),
    radianceFaceSize: Math.max(64, Math.floor(p.radianceFaceSize / 2)),
    radianceMipLevels: p.radianceMipLevels,
    brdfSize: Math.max(256, Math.floor(p.brdfSize / 2)),
    bytesPerPixel: p.bytesPerPixel,
    brdfBytesPerPixel: p.brdfBytesPerPixel,
  };
  var changed = next.sourceFaceSize !== p.sourceFaceSize
    || next.irradianceFaceSize !== p.irradianceFaceSize
    || next.radianceFaceSize !== p.radianceFaceSize
    || next.brdfSize !== p.brdfSize;
  return changed ? next : p;
}

function sceneResolveTextureMemoryBudget(options) {
  var opts = options || {};
  var maxBytes = Math.max(1, Math.floor(sceneFiniteNumber(opts.maxBytes, SCENE_TEXTURE_BUDGET_DEFAULT_BYTES)));
  var shadowCount = sceneClampInteger(opts.shadowCount || 0, 0, 32);
  var shadowSize = Math.max(1, Math.floor(sceneFiniteNumber(opts.shadowSize, 1024)));
  var iblEnabled = Boolean(opts.ibl || opts.envMap);
  var iblProfile = sceneNormalizeIBLProfile(opts.iblProfile);
  var warnings = [];
  var iblBytes = iblEnabled ? sceneEstimateIBLTextureBytes(iblProfile) : 0;
  var shadowBytes = sceneEstimateShadowTextureBytes(shadowSize, shadowCount);

  while (iblEnabled && shadowBytes + iblBytes > maxBytes) {
    var nextProfile = sceneDownscaleIBLProfile(iblProfile);
    var nextBytes = sceneEstimateIBLTextureBytes(nextProfile);
    if (nextBytes >= iblBytes) break;
    iblProfile = nextProfile;
    iblBytes = nextBytes;
    warnings.push("IBL profile downscaled for shared texture budget");
  }

  if (shadowBytes + iblBytes > maxBytes && shadowCount > 0) {
    var remaining = Math.max(1, maxBytes - iblBytes);
    var cappedShadowSize = Math.max(1, Math.floor(Math.sqrt(remaining / Math.max(1, shadowCount * 4))));
    if (cappedShadowSize < shadowSize) {
      shadowSize = cappedShadowSize;
      shadowBytes = sceneEstimateShadowTextureBytes(shadowSize, shadowCount);
      warnings.push("shadow map size downscaled for shared texture budget");
    }
  }

  if (iblEnabled && shadowBytes + iblBytes > maxBytes) {
    iblEnabled = false;
    iblBytes = 0;
    warnings.push("IBL disabled for shared texture budget");
  }

  return {
    maxBytes: maxBytes,
    shadowCount: shadowCount,
    shadowSize: shadowSize,
    shadowBytes: shadowBytes,
    ibl: iblEnabled,
    iblProfile: iblEnabled ? iblProfile : null,
    iblBytes: iblBytes,
    totalBytes: shadowBytes + iblBytes,
    warnings: warnings,
  };
}

function sceneResolveIBLRenderTargetMode(gl, options) {
  var opts = options || {};
  var ext = null;
  if (gl && typeof gl.getExtension === "function") {
    ext = gl.getExtension("EXT_color_buffer_half_float") || gl.getExtension("EXT_color_buffer_float");
  }
  if (ext) {
    return {
      mode: "half-float",
      extension: ext,
      profile: sceneNormalizeIBLProfile(opts.lowPower ? {
        sourceFaceSize: 256,
        irradianceFaceSize: 16,
        radianceFaceSize: 64,
        brdfSize: 256,
      } : opts.profile),
      reason: "",
    };
  }
  if (opts.allowLDRFallback !== false) {
    return {
      mode: "ldr-fallback",
      extension: null,
      profile: sceneNormalizeIBLProfile({
        sourceFaceSize: opts.lowPower ? 128 : 256,
        irradianceFaceSize: 16,
        radianceFaceSize: 64,
        brdfSize: 256,
        bytesPerPixel: 4,
        brdfBytesPerPixel: 4,
      }),
      reason: "half-float-render-target-unavailable",
    };
  }
  return {
    mode: "disabled",
    extension: null,
    profile: null,
    reason: "half-float-render-target-unavailable",
  };
}

if (typeof window !== "undefined") {
  window.__gosx_scene3d_resource_api = Object.assign(window.__gosx_scene3d_resource_api || {}, {
    allocateTextureUnits: sceneAllocateTextureUnits,
    estimateIBLTextureBytes: sceneEstimateIBLTextureBytes,
    estimateShadowTextureBytes: sceneEstimateShadowTextureBytes,
    resolveTextureMemoryBudget: sceneResolveTextureMemoryBudget,
    resolveIBLRenderTargetMode: sceneResolveIBLRenderTargetMode,
  });
}

  function sceneHDRReadLine(bytes, cursor) {
    var start = cursor.offset;
    while (cursor.offset < bytes.length && bytes[cursor.offset] !== 10) {
      cursor.offset++;
    }
    var end = cursor.offset;
    if (cursor.offset < bytes.length && bytes[cursor.offset] === 10) {
      cursor.offset++;
    }
    if (end > start && bytes[end - 1] === 13) {
      end--;
    }
    var out = "";
    for (var i = start; i < end; i++) {
      out += String.fromCharCode(bytes[i]);
    }
    return out;
  }

  function sceneHDRRGBEToFloat(out, outOffset, r, g, b, e) {
    if (!e) {
      out[outOffset] = 0;
      out[outOffset + 1] = 0;
      out[outOffset + 2] = 0;
      return;
    }
    var scale = Math.pow(2, e - 136);
    out[outOffset] = r * scale;
    out[outOffset + 1] = g * scale;
    out[outOffset + 2] = b * scale;
  }

  function sceneHDRParseResolution(line) {
    var match = /^\s*([+-])Y\s+(\d+)\s+([+-])X\s+(\d+)\s*$/.exec(String(line || ""));
    if (!match) {
      match = /^\s*([+-])X\s+(\d+)\s+([+-])Y\s+(\d+)\s*$/.exec(String(line || ""));
      if (!match) {
        return null;
      }
      return {
        width: Math.max(0, parseInt(match[2], 10) || 0),
        height: Math.max(0, parseInt(match[4], 10) || 0),
      };
    }
    return {
      width: Math.max(0, parseInt(match[4], 10) || 0),
      height: Math.max(0, parseInt(match[2], 10) || 0),
    };
  }

  function sceneHDRDecodeRawRGBE(bytes, offset, width, height) {
    var count = width * height;
    if (bytes.length - offset < count * 4) {
      throw new Error("Radiance HDR data is truncated");
    }
    var data = new Float32Array(count * 3);
    for (var i = 0; i < count; i++) {
      var src = offset + i * 4;
      sceneHDRRGBEToFloat(data, i * 3, bytes[src], bytes[src + 1], bytes[src + 2], bytes[src + 3]);
    }
    return data;
  }

  function sceneHDRDecodeRLEScanlines(bytes, offset, width, height) {
    var data = new Float32Array(width * height * 3);
    var scanline = new Uint8Array(width * 4);
    var cursor = offset;

    for (var y = 0; y < height; y++) {
      if (cursor + 4 > bytes.length) {
        throw new Error("Radiance HDR scanline is truncated");
      }
      var b0 = bytes[cursor++];
      var b1 = bytes[cursor++];
      var b2 = bytes[cursor++];
      var b3 = bytes[cursor++];
      var scanWidth = (b2 << 8) | b3;
      if (b0 !== 2 || b1 !== 2 || scanWidth !== width) {
        return sceneHDRDecodeRawRGBE(bytes, offset, width, height);
      }

      for (var channel = 0; channel < 4; channel++) {
        var x = 0;
        while (x < width) {
          if (cursor >= bytes.length) {
            throw new Error("Radiance HDR RLE data is truncated");
          }
          var code = bytes[cursor++];
          if (code > 128) {
            var run = code - 128;
            if (cursor >= bytes.length || x + run > width) {
              throw new Error("Radiance HDR RLE run is invalid");
            }
            var value = bytes[cursor++];
            for (var ri = 0; ri < run; ri++) {
              scanline[(x + ri) * 4 + channel] = value;
            }
            x += run;
          } else {
            var literal = code;
            if (literal === 0 || cursor + literal > bytes.length || x + literal > width) {
              throw new Error("Radiance HDR RLE literal is invalid");
            }
            for (var li = 0; li < literal; li++) {
              scanline[(x + li) * 4 + channel] = bytes[cursor++];
            }
            x += literal;
          }
        }
      }

      for (var px = 0; px < width; px++) {
        var src = px * 4;
        var dst = (y * width + px) * 3;
        sceneHDRRGBEToFloat(data, dst, scanline[src], scanline[src + 1], scanline[src + 2], scanline[src + 3]);
      }
    }

    return data;
  }

  function sceneParseRadianceHDR(arrayBuffer) {
    var bytes = arrayBuffer instanceof Uint8Array
      ? arrayBuffer
      : new Uint8Array(arrayBuffer || []);
    var cursor = { offset: 0 };
    var first = sceneHDRReadLine(bytes, cursor);
    if (first.indexOf("#?RADIANCE") !== 0 && first.indexOf("#?RGBE") !== 0) {
      throw new Error("unsupported Radiance HDR header");
    }

    var resolution = null;
    for (var guard = 0; guard < 128 && cursor.offset < bytes.length; guard++) {
      var line = sceneHDRReadLine(bytes, cursor);
      var parsed = sceneHDRParseResolution(line);
      if (parsed) {
        resolution = parsed;
        break;
      }
    }
    if (!resolution || resolution.width <= 0 || resolution.height <= 0) {
      throw new Error("Radiance HDR resolution is missing");
    }
    if (resolution.width > 4096 || resolution.height > 2048) {
      throw new Error("Radiance HDR exceeds Scene3D size limit");
    }

    var data = (resolution.width >= 8 && resolution.width <= 32767)
      ? sceneHDRDecodeRLEScanlines(bytes, cursor.offset, resolution.width, resolution.height)
      : sceneHDRDecodeRawRGBE(bytes, cursor.offset, resolution.width, resolution.height);
    return {
      width: resolution.width,
      height: resolution.height,
      data: data,
    };
  }

  if (typeof window !== "undefined") {
    window.__gosx_scene3d_resource_api = Object.assign(window.__gosx_scene3d_resource_api || {}, {
      parseRadianceHDR: sceneParseRadianceHDR,
    });
  }

  var SCENE_POST_TONE_MAPPING = "toneMapping";
  var SCENE_POST_BLOOM = "bloom";
  var SCENE_POST_VIGNETTE = "vignette";
  var SCENE_POST_COLOR_GRADE = "colorGrade";
  var SCENE_POST_SSAO = "ssao";
  var SCENE_POST_DOF = "dof";

  const SCENE_PBR_VERTEX_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "precision highp int;",
    "",
    "in vec3 a_position;",
    "in vec3 a_normal;",
    "in vec2 a_uv;",
    "in vec4 a_tangent;",
    "",
    "uniform mat4 u_viewMatrix;",
    "uniform mat4 u_projectionMatrix;",
    "",
    "out vec3 v_worldPosition;",
    "out vec3 v_normal;",
    "out vec2 v_uv;",
    "out vec3 v_tangent;",
    "out vec3 v_bitangent;",
    "out vec4 v_instanceColor;",
    "",
    "void gosxApplyCustomVertex(inout vec3 position, inout vec3 normal, inout vec2 uv) {}",
    "",
    "void main() {",
    "    vec3 gosxPosition = a_position;",
    "    vec3 gosxNormal = a_normal;",
    "    vec2 gosxUV = a_uv;",
    "    gosxApplyCustomVertex(gosxPosition, gosxNormal, gosxUV);",
    "    v_worldPosition = gosxPosition;",
    "    v_normal = normalize(gosxNormal);",
    "    v_uv = gosxUV;",
    "",
    "    vec3 T = normalize(a_tangent.xyz);",
    "    vec3 N = v_normal;",
    "    vec3 B = cross(N, T) * a_tangent.w;",
    "    v_tangent = T;",
    "    v_bitangent = B;",
    "    v_instanceColor = vec4(1.0);",
    "",
    "    gl_Position = u_projectionMatrix * u_viewMatrix * vec4(gosxPosition, 1.0);",
    "}",
  ].join("\n");

  const SCENE_PBR_FRAGMENT_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "precision highp int;",
    "",
    "in vec3 v_worldPosition;",
    "in vec3 v_normal;",
    "in vec2 v_uv;",
    "in vec3 v_tangent;",
    "in vec3 v_bitangent;",
    "in vec4 v_instanceColor;",
    "",
    "// Camera",
    "uniform vec3 u_cameraPosition;",
    "uniform mat4 u_viewMatrix;",
    "",
    "// Material",
    "uniform vec3 u_albedo;",
    "uniform float u_roughness;",
    "uniform float u_metalness;",
    "uniform float u_clearcoat;",
    "uniform float u_sheen;",
    "uniform float u_transmission;",
    "uniform float u_iridescence;",
    "uniform float u_anisotropy;",
    "uniform float u_emissive;",
    "uniform float u_opacity;",
    "uniform bool u_unlit;",
    "",
    "// Texture maps",
    "uniform sampler2D u_albedoMap;",
    "uniform sampler2D u_normalMap;",
    "uniform sampler2D u_roughnessMap;",
    "uniform sampler2D u_metalnessMap;",
    "uniform sampler2D u_emissiveMap;",
    "uniform bool u_hasAlbedoMap;",
    "uniform bool u_hasNormalMap;",
    "uniform bool u_hasRoughnessMap;",
    "uniform bool u_hasMetalnessMap;",
    "uniform bool u_hasEmissiveMap;",
    "",
    "// Lights (max 8)",
    "uniform int u_lightCount;",
    "uniform int u_lightTypes[8];",
    "uniform vec3 u_lightPositions[8];",
    "uniform vec3 u_lightDirections[8];",
    "uniform vec3 u_lightColors[8];",
    "uniform float u_lightIntensities[8];",
    "uniform float u_lightRanges[8];",
    "uniform float u_lightDecays[8];",
    "uniform float u_lightAngles[8];",
    "uniform float u_lightPenumbras[8];",
    "uniform vec3 u_lightGroundColors[8];",
    "",
    "// Environment",
    "uniform vec3 u_ambientColor;",
    "uniform float u_ambientIntensity;",
    "uniform vec3 u_skyColor;",
    "uniform float u_skyIntensity;",
    "uniform vec3 u_groundColor;",
    "uniform float u_groundIntensity;",
    "uniform sampler2D u_envMap;",
    "uniform bool u_hasEnvMap;",
    "uniform float u_envIntensity;",
    "uniform float u_envRotation;",
    "",
    "// Shadow maps (max 2 directional lights × up to 4 cascades each).",
    "// CSM: the renderer picks a cascade per fragment via view-space depth",
    "// against u_shadowCascadeSplits*[]. When u_shadowCascades* == 1 the",
    "// extra cascade samplers are bound to the same texture as cascade 0 and",
    "// the first branch always wins, matching the pre-CSM single-map path.",
    "uniform sampler2D u_shadowMap0_0;",
    "uniform sampler2D u_shadowMap0_1;",
    "uniform sampler2D u_shadowMap0_2;",
    "uniform sampler2D u_shadowMap0_3;",
    "uniform mat4 u_lightSpaceMatrices0[4];",
    "uniform float u_shadowCascadeSplits0[4];",
    "uniform int u_shadowCascades0;",
    "uniform bool u_hasShadow0;",
    "uniform float u_shadowBias0;",
    "uniform float u_shadowSoftness0;",
    "",
    "uniform sampler2D u_shadowMap1_0;",
    "uniform sampler2D u_shadowMap1_1;",
    "uniform sampler2D u_shadowMap1_2;",
    "uniform sampler2D u_shadowMap1_3;",
    "uniform mat4 u_lightSpaceMatrices1[4];",
    "uniform float u_shadowCascadeSplits1[4];",
    "uniform int u_shadowCascades1;",
    "uniform bool u_hasShadow1;",
    "uniform float u_shadowBias1;",
    "uniform float u_shadowSoftness1;",
    "",
    "// Per-object shadow receive control",
    "uniform bool u_receiveShadow;",
    "",
    "// Shadow-casting light indices — maps shadow slot to light array index.",
    "uniform int u_shadowLightIndex0;",
    "uniform int u_shadowLightIndex1;",
    "",
    "// Exposure and tone mapping control.",
    "uniform float u_exposure;",
    "uniform int u_toneMapMode;",
    "",
    "// Fog",
    "uniform int u_hasFog;",
    "uniform float u_fogDensity;",
    "uniform vec3 u_fogColor;",
    "",
    "out vec4 fragColor;",
    "",
    "const float PI = 3.14159265359;",
    "",
    "void gosxApplyCustomFragment(inout vec3 color, inout float opacity, vec3 normal, vec3 worldPosition, vec2 uv) {}",
    "",
    "// Poisson disk taps used for both the PCSS blocker search and the final",
    "// PCF filter. 8 taps provide a stable penumbra estimate without pushing",
    "// WebGL2 fragment register pressure too high.",
    "const vec2 kPoissonDisk8[8] = vec2[](",
    "    vec2(-0.94201624, -0.39906216),",
    "    vec2( 0.94558609, -0.76890725),",
    "    vec2(-0.09418410, -0.92938870),",
    "    vec2( 0.34495938,  0.29387760),",
    "    vec2(-0.91588581,  0.45771432),",
    "    vec2(-0.81544232, -0.87912464),",
    "    vec2( 0.38277543,  0.27676845),",
    "    vec2( 0.97484398,  0.75648379)",
    ");",
    "",
    "// PCSS (Percentage-Closer Soft Shadows) with PCF fallback.",
    "// The softness parameter is interpreted as a combined (light-size /",
    "// world-units) hint: when > 0 we do a blocker search, estimate the",
    "// penumbra from the receiver-to-blocker distance, and then PCF with a",
    "// filter radius scaled to the penumbra. When softness is 0 we skip the",
    "// extra samples and just return a hard comparison.",
    "float shadowFactor(sampler2D shadowMap, mat4 lightSpaceMatrix, float bias, float softness) {",
    "    vec4 lightSpacePos = lightSpaceMatrix * vec4(v_worldPosition, 1.0);",
    "    vec3 projCoords = lightSpacePos.xyz / lightSpacePos.w;",
    "    projCoords = projCoords * 0.5 + 0.5;",
    "",
    "    if (projCoords.z > 1.0) return 1.0;",
    "",
    "    float receiverDepth = projCoords.z;",
    "    float texelSize = 1.0 / float(textureSize(shadowMap, 0).x);",
    "",
    "    // Hard-shadow fast path.",
    "    if (softness <= 0.0001) {",
    "        float depth = texture(shadowMap, projCoords.xy).r;",
    "        return (receiverDepth - bias > depth) ? 0.0 : 1.0;",
    "    }",
    "",
    "    // --- Blocker search ---",
    "    // Sample a disk sized by the light's shadow-space \"size\" (softness)",
    "    // and average the depth of taps that are behind the receiver. These",
    "    // are the occluders contributing to the penumbra.",
    "    float blockerRadius = max(1.0, softness * 32.0);",
    "    float blockerDepthSum = 0.0;",
    "    float blockerCount = 0.0;",
    "    for (int i = 0; i < 8; i++) {",
    "        vec2 offset = kPoissonDisk8[i] * texelSize * blockerRadius;",
    "        float d = texture(shadowMap, projCoords.xy + offset).r;",
    "        if (receiverDepth - bias > d) {",
    "            blockerDepthSum += d;",
    "            blockerCount += 1.0;",
    "        }",
    "    }",
    "",
    "    // No blockers: fully lit.",
    "    if (blockerCount < 0.5) {",
    "        return 1.0;",
    "    }",
    "",
    "    float avgBlockerDepth = blockerDepthSum / blockerCount;",
    "",
    "    // --- Penumbra estimate ---",
    "    // penumbra = (receiver - blocker) / blocker * lightSize.",
    "    // Guard blocker against zero to avoid division by near-plane epsilon.",
    "    float penumbra = (receiverDepth - avgBlockerDepth) * softness / max(avgBlockerDepth, 1e-4);",
    "",
    "    // --- PCF with penumbra-scaled radius ---",
    "    float filterRadius = max(1.0, clamp(penumbra * 128.0, 1.0, softness * 96.0));",
    "    float shadow = 0.0;",
    "    for (int i = 0; i < 8; i++) {",
    "        vec2 offset = kPoissonDisk8[i] * texelSize * filterRadius;",
    "        float d = texture(shadowMap, projCoords.xy + offset).r;",
    "        shadow += (receiverDepth - bias > d) ? 0.0 : 1.0;",
    "    }",
    "    return shadow / 8.0;",
    "}",
    "",
    "// Cascaded-shadow dispatchers for up to 4 cascades per slot.",
    "// View-space positive depth is compared against u_shadowCascadeSplits*[c],",
    "// where split[c] is the far plane of cascade c. Sampler selection is",
    "// unrolled because GLSL ES 3.00 disallows dynamic uniform-int indexing of",
    "// sampler arrays; mat4 and float arrays are indexed normally.",
    "float shadowFactorSlot0(float viewDepth) {",
    "    int c = 0;",
    "    if (u_shadowCascades0 >= 2 && viewDepth >= u_shadowCascadeSplits0[0]) c = 1;",
    "    if (u_shadowCascades0 >= 3 && viewDepth >= u_shadowCascadeSplits0[1]) c = 2;",
    "    if (u_shadowCascades0 >= 4 && viewDepth >= u_shadowCascadeSplits0[2]) c = 3;",
    "    mat4 ls = u_lightSpaceMatrices0[c];",
    "    if (c == 1) return shadowFactor(u_shadowMap0_1, ls, u_shadowBias0, u_shadowSoftness0);",
    "    if (c == 2) return shadowFactor(u_shadowMap0_2, ls, u_shadowBias0, u_shadowSoftness0);",
    "    if (c == 3) return shadowFactor(u_shadowMap0_3, ls, u_shadowBias0, u_shadowSoftness0);",
    "    return shadowFactor(u_shadowMap0_0, ls, u_shadowBias0, u_shadowSoftness0);",
    "}",
    "",
    "float shadowFactorSlot1(float viewDepth) {",
    "    int c = 0;",
    "    if (u_shadowCascades1 >= 2 && viewDepth >= u_shadowCascadeSplits1[0]) c = 1;",
    "    if (u_shadowCascades1 >= 3 && viewDepth >= u_shadowCascadeSplits1[1]) c = 2;",
    "    if (u_shadowCascades1 >= 4 && viewDepth >= u_shadowCascadeSplits1[2]) c = 3;",
    "    mat4 ls = u_lightSpaceMatrices1[c];",
    "    if (c == 1) return shadowFactor(u_shadowMap1_1, ls, u_shadowBias1, u_shadowSoftness1);",
    "    if (c == 2) return shadowFactor(u_shadowMap1_2, ls, u_shadowBias1, u_shadowSoftness1);",
    "    if (c == 3) return shadowFactor(u_shadowMap1_3, ls, u_shadowBias1, u_shadowSoftness1);",
    "    return shadowFactor(u_shadowMap1_0, ls, u_shadowBias1, u_shadowSoftness1);",
    "}",
    "",
    "// GGX/Trowbridge-Reitz normal distribution function.",
    "float distributionGGX(vec3 N, vec3 H, float roughness) {",
    "    float a = roughness * roughness;",
    "    float a2 = a * a;",
    "    float NdotH = max(dot(N, H), 0.0);",
    "    float NdotH2 = NdotH * NdotH;",
    "    float denom = NdotH2 * (a2 - 1.0) + 1.0;",
    "    denom = PI * denom * denom;",
    "    return a2 / max(denom, 0.0000001);",
    "}",
    "",
    "// Smith geometry function (GGX variant) — single direction.",
    "float geometrySchlickGGX(float NdotV, float roughness) {",
    "    float r = roughness + 1.0;",
    "    float k = (r * r) / 8.0;",
    "    return NdotV / (NdotV * (1.0 - k) + k);",
    "}",
    "",
    "// Smith geometry function — combined for view and light directions.",
    "float geometrySmith(vec3 N, vec3 V, vec3 L, float roughness) {",
    "    float NdotV = max(dot(N, V), 0.0);",
    "    float NdotL = max(dot(N, L), 0.0);",
    "    return geometrySchlickGGX(NdotV, roughness) * geometrySchlickGGX(NdotL, roughness);",
    "}",
    "",
    "// Schlick fresnel approximation.",
    "vec3 fresnelSchlick(float cosTheta, vec3 F0) {",
    "    return F0 + (1.0 - F0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);",
    "}",
    "",
    "vec3 fresnelSchlickRoughness(float cosTheta, vec3 F0, float roughness) {",
    "    return F0 + (max(vec3(1.0 - roughness), F0) - F0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);",
    "}",
    "",
    "vec3 rotateEnvY(vec3 dir, float radians) {",
    "    float c = cos(radians);",
    "    float s = sin(radians);",
    "    return vec3(dir.x * c + dir.z * s, dir.y, -dir.x * s + dir.z * c);",
    "}",
    "",
    "vec2 envEquirectUV(vec3 dir) {",
    "    vec3 d = normalize(dir);",
    "    return vec2(atan(d.z, d.x) / (2.0 * PI) + 0.5, asin(clamp(d.y, -1.0, 1.0)) / PI + 0.5);",
    "}",
    "",
    "// Point light distance attenuation.",
    "float pointLightAttenuation(float distance, float range, float decay) {",
    "    if (range > 0.0) {",
    "        float ratio = clamp(1.0 - pow(distance / range, 4.0), 0.0, 1.0);",
    "        return ratio * ratio / max(distance * distance, 0.0001);",
    "    }",
    "    return 1.0 / max(pow(distance, decay), 0.0001);",
    "}",
    "",
    "void main() {",
    "    // Resolve material properties, sampling textures when available.",
    "    vec3 albedo = u_albedo;",
    "    albedo *= v_instanceColor.rgb;",
    "    if (u_hasAlbedoMap) {",
    "        vec4 texAlbedo = texture(u_albedoMap, v_uv);",
    "        albedo *= texAlbedo.rgb;",
    "    }",
    "",
    "    float roughness = u_roughness;",
    "    if (u_hasRoughnessMap) {",
    "        roughness *= texture(u_roughnessMap, v_uv).g;",
    "    }",
    "    roughness = clamp(roughness, 0.04, 1.0);",
    "    roughness = clamp(roughness * (1.0 - abs(u_anisotropy) * 0.28), 0.04, 1.0);",
    "",
    "    float metalness = u_metalness;",
    "    if (u_hasMetalnessMap) {",
    "        metalness *= texture(u_metalnessMap, v_uv).b;",
    "    }",
    "    metalness = clamp(metalness, 0.0, 1.0);",
    "",
    "    float emissiveStrength = u_emissive;",
    "    vec3 emissiveColor = albedo;",
    "    if (u_hasEmissiveMap) {",
    "        emissiveColor = texture(u_emissiveMap, v_uv).rgb;",
    "    }",
    "",
    "    // Unlit path: output albedo directly.",
    "    if (u_unlit) {",
    "        vec3 color = albedo + emissiveColor * emissiveStrength;",
    "        float opacity = u_opacity;",
    "        gosxApplyCustomFragment(color, opacity, normalize(v_normal), v_worldPosition, v_uv);",
    "        fragColor = vec4(color, opacity * v_instanceColor.a);",
    "        return;",
    "    }",
    "",
    "    // Resolve per-pixel normal via TBN matrix.",
    "    vec3 N = normalize(v_normal);",
    "    if (u_hasNormalMap) {",
    "        vec3 T = normalize(v_tangent);",
    "        vec3 B = normalize(v_bitangent);",
    "        mat3 TBN = mat3(T, B, N);",
    "        vec3 mapNormal = texture(u_normalMap, v_uv).rgb * 2.0 - 1.0;",
    "        N = normalize(TBN * mapNormal);",
    "    }",
    "",
    "    vec3 V = normalize(u_cameraPosition - v_worldPosition);",
    "    float NoV = max(dot(N, V), 0.0);",
    "",
    "    // Fresnel reflectance at normal incidence — dielectric vs metallic blend.",
    "    vec3 F0 = mix(vec3(0.04), albedo, metalness);",
    "",
    "    // Accumulate direct lighting.",
    "    vec3 Lo = vec3(0.0);",
    "",
    "    // View-space positive depth of this fragment — used to pick a cascade",
    "    // in shadowFactorSlot*(). Light-space transforms already happen per",
    "    // cascade inside shadowFactor(); this extra multiply per fragment is",
    "    // cheap and isolates CSM logic to the fragment shader.",
    "    float viewDepth = -(u_viewMatrix * vec4(v_worldPosition, 1.0)).z;",
    "",
    "    for (int i = 0; i < 8; i++) {",
    "        if (i >= u_lightCount) break;",
    "",
    "        int lightType = u_lightTypes[i];",
    "        vec3 lightColor = u_lightColors[i];",
    "        float intensity = u_lightIntensities[i];",
    "",
    "        // Ambient light (type 0): add flat contribution, no BRDF.",
    "        if (lightType == 0) {",
    "            Lo += albedo * lightColor * intensity;",
    "            continue;",
    "        }",
    "",
    "        // Hemisphere light (type 4): sky/ground blend based on normal Y.",
    "        if (lightType == 4) {",
    "            float hBlend = N.y * 0.5 + 0.5;",
    "            vec3 hemiColor = mix(u_lightGroundColors[i], lightColor, hBlend);",
    "            Lo += albedo * hemiColor * intensity;",
    "            continue;",
    "        }",
    "",
    "        vec3 L;",
    "        float attenuation = 1.0;",
    "",
    "        if (lightType == 1) {",
    "            // Directional light.",
    "            L = normalize(-u_lightDirections[i]);",
    "        } else if (lightType == 3) {",
    "            // Spot light.",
    "            vec3 toLight = u_lightPositions[i] - v_worldPosition;",
    "            float dist = length(toLight);",
    "            L = toLight / max(dist, 0.0001);",
    "",
    "            // Cone attenuation.",
    "            float cosAngle = dot(L, -normalize(u_lightDirections[i]));",
    "            float outerCos = cos(u_lightAngles[i]);",
    "            float innerCos = cos(u_lightAngles[i] * (1.0 - u_lightPenumbras[i]));",
    "            float spotAtten = clamp((cosAngle - outerCos) / max(innerCos - outerCos, 0.001), 0.0, 1.0);",
    "",
    "            // Distance attenuation (same as point light).",
    "            attenuation = pointLightAttenuation(dist, u_lightRanges[i], u_lightDecays[i]) * spotAtten;",
    "        } else {",
    "            // Point light (type 2).",
    "            vec3 toLight = u_lightPositions[i] - v_worldPosition;",
    "            float dist = length(toLight);",
    "            L = toLight / max(dist, 0.0001);",
    "            attenuation = pointLightAttenuation(dist, u_lightRanges[i], u_lightDecays[i]);",
    "        }",
    "",
    "        vec3 H = normalize(V + L);",
    "        float NdotL = max(dot(N, L), 0.0);",
    "",
    "        // Cook-Torrance specular BRDF.",
    "        float D = distributionGGX(N, H, roughness);",
    "        float G = geometrySmith(N, V, L, roughness);",
    "        vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);",
    "",
    "        vec3 numerator = D * G * F;",
    "        float denominator = 4.0 * max(dot(N, V), 0.0) * NdotL + 0.0001;",
    "        vec3 specular = numerator / denominator;",
    "",
    "        // Energy conservation: diffuse complement of specular.",
    "        vec3 kD = (vec3(1.0) - F) * (1.0 - metalness);",
    "",
    "        // Shadow attenuation for directional lights.",
    "        float shadow = 1.0;",
    "        if (u_receiveShadow && lightType == 1) {",
    "            if (u_hasShadow0 && i == u_shadowLightIndex0) {",
    "                shadow = shadowFactorSlot0(viewDepth);",
    "            } else if (u_hasShadow1 && i == u_shadowLightIndex1) {",
    "                shadow = shadowFactorSlot1(viewDepth);",
    "            }",
    "        }",
    "",
    "        vec3 radiance = lightColor * intensity * attenuation;",
    "        Lo += (kD * albedo / PI + specular) * radiance * NdotL * shadow;",
    "    }",
    "",
    "    // Environment lighting: equirectangular envMap when loaded, hemisphere fallback otherwise.",
    "    vec3 ambient;",
    "    if (u_hasEnvMap) {",
    "        vec3 Nr = rotateEnvY(N, u_envRotation);",
    "        vec3 Rr = rotateEnvY(reflect(-V, N), u_envRotation);",
    "        vec3 envDiffuse = texture(u_envMap, envEquirectUV(Nr)).rgb * albedo;",
    "        vec3 envSpecular = texture(u_envMap, envEquirectUV(Rr)).rgb;",
    "        vec3 Fenv = fresnelSchlickRoughness(max(dot(N, V), 0.0), F0, roughness);",
    "        vec3 kDenv = (vec3(1.0) - Fenv) * (1.0 - metalness);",
    "        ambient = (kDenv * envDiffuse + envSpecular * Fenv * (1.0 - roughness * 0.65)) * u_envIntensity;",
    "    } else {",
    "        float hemi = N.y * 0.5 + 0.5;",
    "        vec3 envDiffuse = u_ambientColor * u_ambientIntensity",
    "                        + u_skyColor * u_skyIntensity * hemi",
    "                        + u_groundColor * u_groundIntensity * (1.0 - hemi);",
    "        ambient = envDiffuse * albedo;",
    "    }",
    "",
    "    // Emissive contribution.",
    "    vec3 emission = emissiveColor * emissiveStrength;",
    "",
    "    vec3 color = ambient + Lo + emission;",
    "",
    "    float clearcoat = clamp(u_clearcoat, 0.0, 1.0);",
    "    if (clearcoat > 0.0001) {",
    "        float cc = pow(NoV, mix(12.0, 96.0, 1.0 - roughness)) * clearcoat;",
    "        color += vec3(cc * 0.28);",
    "    }",
    "",
    "    float sheen = clamp(u_sheen, 0.0, 1.0);",
    "    if (sheen > 0.0001) {",
    "        float velvet = pow(1.0 - NoV, 3.0) * sheen;",
    "        color += albedo * velvet * 0.55;",
    "    }",
    "",
    "    float iridescence = clamp(u_iridescence, 0.0, 1.0);",
    "    if (iridescence > 0.0001) {",
    "        vec3 iri = 0.5 + 0.5 * cos(vec3(0.0, 2.1, 4.2) + NoV * 8.0);",
    "        color = mix(color, color * (0.65 + iri * 0.7), iridescence * pow(1.0 - NoV, 2.0));",
    "    }",
    "",
    "    float transmission = clamp(u_transmission, 0.0, 1.0) * (1.0 - metalness);",
    "    if (transmission > 0.0001) {",
    "        color = mix(color, ambient + albedo * 0.1, transmission * 0.55);",
    "    }",
    "",
    "    // Exponential fog.",
    "    if (u_hasFog != 0) {",
    "        float fogDist = length(v_worldPosition - u_cameraPosition);",
    "        float fogFactor = exp(-u_fogDensity * u_fogDensity * fogDist * fogDist);",
    "        fogFactor = clamp(fogFactor, 0.0, 1.0);",
    "        color = mix(u_fogColor, color, fogFactor);",
    "    }",
    "",
    "    // Apply exposure.",
    "    color *= u_exposure;",
    "",
    "    // Tone mapping.",
    "    if (u_toneMapMode == 1) {",
    "        // ACES filmic.",
    "        color = (color * (2.51 * color + 0.03)) / (color * (2.43 * color + 0.59) + 0.14);",
    "    } else if (u_toneMapMode == 2) {",
    "        // Reinhard.",
    "        color = color / (color + vec3(1.0));",
    "    }",
    "    // else: linear (no tone mapping).",
    "",
    "    // Gamma correction.",
    "    color = pow(color, vec3(1.0 / 2.2));",
    "",
    "    float opacity = u_opacity;",
    "    gosxApplyCustomFragment(color, opacity, N, v_worldPosition, v_uv);",
    "    fragColor = vec4(color, opacity * v_instanceColor.a);",
    "}",
  ].join("\n");

  const SCENE_SHADOW_VERTEX_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "in vec3 a_position;",
    "uniform mat4 u_lightViewProjection;",
    "void main() {",
    "    gl_Position = u_lightViewProjection * vec4(a_position, 1.0);",
    "}",
  ].join("\n");

  const SCENE_SHADOW_FRAGMENT_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "void main() {}",
  ].join("\n");

  const SCENE_POINTS_VERTEX_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "precision highp int;",
    "",
    "in vec3 a_position;",
    "in float a_size;",
    "in vec4 a_color;",
    "",
    "uniform mat4 u_viewMatrix;",
    "uniform mat4 u_projectionMatrix;",
    "uniform mat4 u_modelMatrix;",
    "uniform float u_defaultSize;",
    "uniform vec4 u_defaultColor;",
    "uniform bool u_hasPerVertexColor;",
    "uniform bool u_hasPerVertexSize;",
    "uniform bool u_sizeAttenuation;",
    "uniform int u_pointStyle;",
    "uniform float u_viewportHeight;",
    "",
    "// Fog",
    "uniform int u_hasFog;",
    "uniform float u_fogDensity;",
    "",
    "out vec4 v_color;",
    "out float v_fogFactor;",
    "out float v_pointSize;",
    "",
    "void main() {",
    "    vec4 worldPos = u_modelMatrix * vec4(a_position, 1.0);",
    "    vec4 viewPos = u_viewMatrix * worldPos;",
    "    gl_Position = u_projectionMatrix * viewPos;",
    "",
    "    float size = u_hasPerVertexSize ? a_size : u_defaultSize;",
    "    if (u_sizeAttenuation) {",
    "        gl_PointSize = max(size * (u_viewportHeight * 0.5) / max(-viewPos.z, 0.001), 1.0);",
    "    } else {",
    "        gl_PointSize = max(size, 1.0);",
    "    }",
    "    v_pointSize = gl_PointSize;",
    "",
    "    v_color = u_hasPerVertexColor ? a_color : u_defaultColor;",
    "",
    "    // Exponential fog",
    "    if (u_hasFog != 0) {",
    "        float dist = length(viewPos.xyz);",
    "        v_fogFactor = exp(-u_fogDensity * u_fogDensity * dist * dist);",
    "        v_fogFactor = clamp(v_fogFactor, 0.0, 1.0);",
    "    } else {",
    "        v_fogFactor = 1.0;",
    "    }",
    "}",
  ].join("\n");

  const SCENE_POINTS_FRAGMENT_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "precision highp int;",
    "",
    "in vec4 v_color;",
    "in float v_fogFactor;",
    "in float v_pointSize;",
    "",
    "uniform float u_opacity;",
    "uniform vec3 u_fogColor;",
    "uniform int u_hasFog;",
    "uniform int u_pointStyle;",
    "",
    "out vec4 fragColor;",
    "",
    "void main() {",
    "    float alpha = 1.0;",
    "    vec3 color = v_color.rgb;",
    "    if (u_pointStyle == 1) {",
    "        vec2 centered = gl_PointCoord - vec2(0.5);",
    "        float radial = length(centered);",
    "        float square = max(abs(centered.x), abs(centered.y));",
    "        float focus = clamp((v_pointSize - 1.0) / 10.0, 0.0, 1.0);",
    "        float coreRadius = mix(0.49, 0.18, focus);",
    "        float core = 1.0 - smoothstep(coreRadius, coreRadius + 0.05, square);",
    "        float halo = (1.0 - smoothstep(0.12, 0.72, radial)) * focus;",
    "        float streakX = 1.0 - smoothstep(0.02, 0.16, abs(centered.x));",
    "        float streakY = 1.0 - smoothstep(0.02, 0.16, abs(centered.y));",
    "        float streak = max(streakX, streakY) * focus;",
    "        alpha = clamp(core + halo * 0.5 + streak * 0.2, 0.0, 1.0);",
    "        color = mix(color, vec3(1.0), clamp(focus * 0.22 + core * focus * 0.28, 0.0, 0.4));",
    "    } else if (u_pointStyle == 2) {",
    "        // glow: pure radial gaussian falloff — soft gas cloud, no core, no streaks",
    "        vec2 centered = gl_PointCoord - vec2(0.5);",
    "        float radial = length(centered) * 2.0;",
    "        if (radial > 1.0) discard;",
    "        float g = exp(-radial * radial * 3.5);",
    "        alpha = g;",
    "    }",
    "",
    "    // Apply fog",
    "    if (u_hasFog != 0) {",
    "        color = mix(u_fogColor, color, v_fogFactor);",
    "    }",
    "",
    "    fragColor = vec4(color, alpha * v_color.a * u_opacity);",
    "}",
  ].join("\n");

	  const SCENE_PBR_INSTANCED_VERTEX_SOURCE = [
	    "#version 300 es",
	    "precision highp float;",
	    "precision highp int;",
	    "",
    "in vec3 a_position;",
    "in vec3 a_normal;",
    "in vec2 a_uv;",
    "in vec4 a_tangent;",
    "in mat4 a_instanceMatrix;",
    "in vec4 a_instanceColor;",
    "",
    "uniform mat4 u_viewMatrix;",
    "uniform mat4 u_projectionMatrix;",
    "uniform bool u_hasInstanceColor;",
    "",
    "out vec3 v_worldPosition;",
    "out vec3 v_normal;",
    "out vec2 v_uv;",
    "out vec3 v_tangent;",
    "out vec3 v_bitangent;",
    "out vec4 v_instanceColor;",
    "",
    "void main() {",
    "    vec4 worldPos = a_instanceMatrix * vec4(a_position, 1.0);",
    "    v_worldPosition = worldPos.xyz;",
    "    mat3 normalMatrix = mat3(a_instanceMatrix);",
    "    v_normal = normalize(normalMatrix * a_normal);",
    "    v_uv = a_uv;",
    "    vec3 T = normalize(normalMatrix * a_tangent.xyz);",
    "    vec3 N = v_normal;",
    "    v_bitangent = cross(N, T) * a_tangent.w;",
    "    v_tangent = T;",
    "    v_instanceColor = u_hasInstanceColor ? a_instanceColor : vec4(1.0);",
    "    gl_Position = u_projectionMatrix * u_viewMatrix * worldPos;",
    "}",
  ].join("\n");

	  const SCENE_PBR_SKINNED_VERTEX_SOURCE = [
	    "#version 300 es",
	    "precision highp float;",
	    "precision highp int;",
	    "",
    "in vec3 a_position;",
    "in vec3 a_normal;",
    "in vec2 a_uv;",
    "in vec4 a_tangent;",
    "in vec4 a_joints;",
    "in vec4 a_weights;",
    "",
	    "uniform mat4 u_viewMatrix;",
	    "uniform mat4 u_projectionMatrix;",
	    "uniform mat4 u_modelMatrix;",
	    "uniform mat4 u_jointMatrices[64];",
	    "uniform bool u_hasSkin;",
    "",
    "out vec3 v_worldPosition;",
    "out vec3 v_normal;",
    "out vec2 v_uv;",
    "out vec3 v_tangent;",
    "out vec3 v_bitangent;",
    "out vec4 v_instanceColor;",
    "",
    "void main() {",
    "    vec4 pos = vec4(a_position, 1.0);",
    "    vec3 norm = a_normal;",
    "    vec3 tang = a_tangent.xyz;",
    "",
    "    if (u_hasSkin) {",
    "        mat4 skinMatrix =",
    "            a_weights.x * u_jointMatrices[int(a_joints.x)] +",
    "            a_weights.y * u_jointMatrices[int(a_joints.y)] +",
    "            a_weights.z * u_jointMatrices[int(a_joints.z)] +",
    "            a_weights.w * u_jointMatrices[int(a_joints.w)];",
    "",
    "        pos = skinMatrix * pos;",
    "        norm = mat3(skinMatrix) * norm;",
    "        tang = mat3(skinMatrix) * tang;",
    "    }",
    "",
	    "    vec4 worldPos = u_modelMatrix * pos;",
	    "    mat3 normalMatrix = mat3(u_modelMatrix);",
	    "    v_worldPosition = worldPos.xyz;",
	    "    v_normal = normalize(normalMatrix * norm);",
	    "    v_uv = a_uv;",
	    "",
	    "    vec3 T = normalize(normalMatrix * tang);",
	    "    vec3 N = v_normal;",
    "    vec3 B = cross(N, T) * a_tangent.w;",
    "    v_tangent = T;",
    "    v_bitangent = B;",
    "    v_instanceColor = vec4(1.0);",
    "",
	    "    gl_Position = u_projectionMatrix * u_viewMatrix * worldPos;",
    "}",
  ].join("\n");

  function scenePBRViewMatrix(camera, out) {
    const cam = sceneRenderCamera(camera);
    const tx = -cam.x;
    const ty = -cam.y;
    const tz = -cam.z;

    const sx = Math.sin(-cam.rotationX);
    const cx = Math.cos(-cam.rotationX);
    const sy = Math.sin(-cam.rotationY);
    const cy = Math.cos(-cam.rotationY);
    const sz = Math.sin(-cam.rotationZ);
    const cz = Math.cos(-cam.rotationZ);

    const r00 = cy * cz;
    const r01 = cy * sz;
    const r02 = -sy;

    const r10 = sx * sy * cz - cx * sz;
    const r11 = sx * sy * sz + cx * cz;
    const r12 = sx * cy;

    const r20 = cx * sy * cz + sx * sz;
    const r21 = cx * sy * sz - sx * cz;
    const r22 = cx * cy;

    const d0 = r00 * tx + r01 * ty + r02 * tz;
    const d1 = r10 * tx + r11 * ty + r12 * tz;
    const d2 = r20 * tx + r21 * ty + r22 * tz;

    var m = out || new Float32Array(16);
    m[0] = r00; m[1] = r10; m[2] = r20; m[3] = 0;
    m[4] = r01; m[5] = r11; m[6] = r21; m[7] = 0;
    m[8] = r02; m[9] = r12; m[10] = r22; m[11] = 0;
    m[12] = d0; m[13] = d1; m[14] = d2; m[15] = 1;
    return m;
  }

  function scenePBRProjectionMatrix(fov, aspect, near, far, out) {
    const fovRad = (fov * Math.PI) / 180;
    const f = 1 / Math.tan(fovRad * 0.5);
    const rangeInv = 1 / (near - far);

    var m = out || new Float32Array(16);
    m[0] = f / aspect; m[1] = 0; m[2] = 0; m[3] = 0;
    m[4] = 0; m[5] = f; m[6] = 0; m[7] = 0;
    m[8] = 0; m[9] = 0; m[10] = (near + far) * rangeInv; m[11] = -1;
    m[12] = 0; m[13] = 0; m[14] = 2 * near * far * rangeInv; m[15] = 0;
    return m;
  }

  function scenePBROrthographicProjectionMatrix(left, right, top, bottom, near, far, out) {
    var m = out || new Float32Array(16);
    const width = Math.max(0.000001, right - left);
    const height = Math.max(0.000001, top - bottom);
    const depth = Math.max(0.000001, far - near);
    m[0] = 2 / width; m[1] = 0; m[2] = 0; m[3] = 0;
    m[4] = 0; m[5] = 2 / height; m[6] = 0; m[7] = 0;
    m[8] = 0; m[9] = 0; m[10] = -2 / depth; m[11] = 0;
    m[12] = -(right + left) / width; m[13] = -(top + bottom) / height; m[14] = -(far + near) / depth; m[15] = 1;
    return m;
  }

  function scenePBRProjectionMatrixForCamera(camera, aspect, out) {
    const cam = sceneRenderCamera(camera);
    if (cam.kind === "orthographic") {
      const bounds = sceneOrthographicBounds(cam, Math.max(1, aspect * 1000), 1000);
      return scenePBROrthographicProjectionMatrix(bounds.left, bounds.right, bounds.top, bounds.bottom, cam.near, cam.far, out);
    }
    return scenePBRProjectionMatrix(cam.fov, aspect, cam.near, cam.far, out);
  }

  function createSceneShadowResources(gl, size) {
    const framebuffer = gl.createFramebuffer();
    const depthTexture = gl.createTexture();

    gl.bindTexture(gl.TEXTURE_2D, depthTexture);
    gl.texImage2D(
      gl.TEXTURE_2D, 0, gl.DEPTH_COMPONENT24,
      size, size, 0,
      gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, null
    );
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

    gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer);
    gl.framebufferTexture2D(
      gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, depthTexture, 0
    );
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);

    return { framebuffer: framebuffer, depthTexture: depthTexture, size: size };
  }

  function createSceneShadowSlot(gl, size, numCascades) {
    var n = Math.max(1, Math.min(4, numCascades | 0));
    var cascades = [];
    for (var i = 0; i < n; i++) {
      var res = createSceneShadowResources(gl, size);
      cascades.push({
        framebuffer: res.framebuffer,
        depthTexture: res.depthTexture,
        size: size,
        cascadeIndex: i,
        splitNear: 0,
        splitFar: 0,
        lightMatrix: null,
        _lastPassHash: null,
      });
    }
    return {
      size: size,
      numCascades: n,
      cascades: cascades,
    };
  }

  function disposeShadowSlot(gl, slot) {
    if (!slot) return;
    if (Array.isArray(slot.cascades)) {
      for (var i = 0; i < slot.cascades.length; i++) {
        var c = slot.cascades[i];
        if (c && c.framebuffer) gl.deleteFramebuffer(c.framebuffer);
        if (c && c.depthTexture) gl.deleteTexture(c.depthTexture);
      }
    } else {
      if (slot.framebuffer) gl.deleteFramebuffer(slot.framebuffer);
      if (slot.depthTexture) gl.deleteTexture(slot.depthTexture);
    }
  }

  function computeShadowSlotCascadeMatrices(light, slot, sceneBounds, viewMatrix, fovDeg, aspect, camNear, camFar) {
    var n = slot.numCascades;
    if (n <= 1) {
      var m = sceneShadowLightSpaceMatrix(light, sceneBounds);
      slot.cascades[0].lightMatrix = m;
      slot.cascades[0].splitNear = 0;
      slot.cascades[0].splitFar = camFar || 100;
      return;
    }

    var lambda = sceneNumber(light.shadowCascadeLambda, 0.5);
    var splits = sceneShadowComputeCascadeSplits(camNear || 0.1, camFar || 100, n, lambda);

    var dx = sceneNumber(light.directionX, 0);
    var dy = sceneNumber(light.directionY, -1);
    var dz = sceneNumber(light.directionZ, 0);
    var len = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (len < 0.0001) { dx = 0; dy = -1; dz = 0; len = 1; }
    dx /= len; dy /= len; dz /= len;

    var ex = (sceneBounds.maxX - sceneBounds.minX) * 0.5;
    var ey = (sceneBounds.maxY - sceneBounds.minY) * 0.5;
    var ez = (sceneBounds.maxZ - sceneBounds.minZ) * 0.5;
    var sceneRadius = Math.sqrt(ex * ex + ey * ey + ez * ez);

    var prevSplit = camNear || 0.1;
    for (var i = 0; i < n; i++) {
      var splitFar = splits[i];
      var corners = sceneShadowFrustumSubCorners(viewMatrix, fovDeg, aspect, prevSplit, splitFar);
      var matrix = sceneShadowFitLightSpaceOrtho([dx, dy, dz], corners, sceneRadius, slot.size);
      slot.cascades[i].lightMatrix = matrix;
      slot.cascades[i].splitNear = prevSplit;
      slot.cascades[i].splitFar = splitFar;
      prevSplit = splitFar;
    }
  }

  function sceneShadowComputeCascadeSplits(near, far, numCascades, lambda) {
    var n = Math.max(0.0001, near || 0.1);
    var f = Math.max(n + 0.0001, far || 100);
    var count = Math.max(1, Math.min(4, numCascades | 0));
    var lam = Math.max(0, Math.min(1, typeof lambda === "number" ? lambda : 0.5));
    var ratio = f / n;
    var splits = new Array(count);
    for (var i = 0; i < count; i++) {
      var p = (i + 1) / count;
      var logSplit = n * Math.pow(ratio, p);
      var uniSplit = n + (f - n) * p;
      splits[i] = lam * logSplit + (1 - lam) * uniSplit;
    }
    return splits;
  }

  function sceneShadowFrustumSubCorners(viewMatrix, fovDeg, aspect, splitNear, splitFar) {
    var fovY = (fovDeg * Math.PI) / 180;
    var tanY = Math.tan(fovY * 0.5);
    var tanX = tanY * (aspect || 1);

    var hNearY = splitNear * tanY;
    var hNearX = splitNear * tanX;
    var hFarY = splitFar * tanY;
    var hFarX = splitFar * tanX;

    var viewCorners = [
      -hNearX,  hNearY, -splitNear,
       hNearX,  hNearY, -splitNear,
      -hNearX, -hNearY, -splitNear,
       hNearX, -hNearY, -splitNear,
      -hFarX,   hFarY,  -splitFar,
       hFarX,   hFarY,  -splitFar,
      -hFarX,  -hFarY,  -splitFar,
       hFarX,  -hFarY,  -splitFar,
    ];

    var invView = sceneInvertOrthonormalView(viewMatrix);

    var corners = new Float32Array(24);
    for (var i = 0; i < 8; i++) {
      var x = viewCorners[i * 3];
      var y = viewCorners[i * 3 + 1];
      var z = viewCorners[i * 3 + 2];
      corners[i * 3]     = invView[0] * x + invView[4] * y + invView[8]  * z + invView[12];
      corners[i * 3 + 1] = invView[1] * x + invView[5] * y + invView[9]  * z + invView[13];
      corners[i * 3 + 2] = invView[2] * x + invView[6] * y + invView[10] * z + invView[14];
    }
    return corners;
  }

  function sceneInvertOrthonormalView(view) {
    var out = new Float32Array(16);
    out[0]  = view[0];  out[1]  = view[4];  out[2]  = view[8];   out[3]  = 0;
    out[4]  = view[1];  out[5]  = view[5];  out[6]  = view[9];   out[7]  = 0;
    out[8]  = view[2];  out[9]  = view[6];  out[10] = view[10];  out[11] = 0;
    var tx = view[12], ty = view[13], tz = view[14];
    out[12] = -(out[0]  * tx + out[4]  * ty + out[8]  * tz);
    out[13] = -(out[1]  * tx + out[5]  * ty + out[9]  * tz);
    out[14] = -(out[2]  * tx + out[6]  * ty + out[10] * tz);
    out[15] = 1;
    return out;
  }

  function sceneShadowFitLightSpaceOrtho(lightDir, worldCorners, sceneBoundsRadius, shadowMapSize) {
    var dx = lightDir[0], dy = lightDir[1], dz = lightDir[2];
    var len = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (len < 0.0001) { dx = 0; dy = -1; dz = 0; len = 1; }
    dx /= len; dy /= len; dz /= len;

    var cx = 0, cy = 0, cz = 0;
    for (var i = 0; i < 8; i++) {
      cx += worldCorners[i * 3];
      cy += worldCorners[i * 3 + 1];
      cz += worldCorners[i * 3 + 2];
    }
    cx /= 8; cy /= 8; cz /= 8;

    var fx = dx, fy = dy, fz = dz; // forward in view = lightDir

    var upX = 0, upY = 1, upZ = 0;
    if (Math.abs(fy) > 0.99) { upX = 0; upY = 0; upZ = 1; }

    var rx = fy * upZ - fz * upY;
    var ry = fz * upX - fx * upZ;
    var rz = fx * upY - fy * upX;
    var rLen = Math.sqrt(rx * rx + ry * ry + rz * rz);
    if (rLen < 0.0001) rLen = 1;
    rx /= rLen; ry /= rLen; rz /= rLen;
    upX = ry * fz - rz * fy;
    upY = rz * fx - rx * fz;
    upZ = rx * fy - ry * fx;

    var minR = Infinity, maxR = -Infinity;
    var minU = Infinity, maxU = -Infinity;
    var minF = Infinity, maxF = -Infinity;
    for (var j = 0; j < 8; j++) {
      var px = worldCorners[j * 3] - cx;
      var py = worldCorners[j * 3 + 1] - cy;
      var pz = worldCorners[j * 3 + 2] - cz;
      var pr = rx * px + ry * py + rz * pz;
      var pu = upX * px + upY * py + upZ * pz;
      var pf = fx * px + fy * py + fz * pz;
      if (pr < minR) minR = pr; if (pr > maxR) maxR = pr;
      if (pu < minU) minU = pu; if (pu > maxU) maxU = pu;
      if (pf < minF) minF = pf; if (pf > maxF) maxF = pf;
    }

    var snapSize = Math.max(0, shadowMapSize | 0);
    if (snapSize > 0 && isFinite(minR) && isFinite(maxR) && isFinite(minU) && isFinite(maxU)) {
      var width = maxR - minR;
      var height = maxU - minU;
      if (width > 0.000001 && height > 0.000001) {
        var texelR = width / snapSize;
        var texelU = height / snapSize;
        var centerWorldR = rx * cx + ry * cy + rz * cz;
        var centerWorldU = upX * cx + upY * cy + upZ * cz;
        var centerR = (minR + maxR) * 0.5;
        var centerU = (minU + maxU) * 0.5;
        var snappedCenterR = Math.round((centerWorldR + centerR) / texelR) * texelR;
        var snappedCenterU = Math.round((centerWorldU + centerU) / texelU) * texelU;
        var halfR = width * 0.5 + texelR;
        var halfU = height * 0.5 + texelU;
        centerR = snappedCenterR - centerWorldR;
        centerU = snappedCenterU - centerWorldU;
        minR = centerR - halfR;
        maxR = centerR + halfR;
        minU = centerU - halfU;
        maxU = centerU + halfU;
      }
    }

    var extend = Math.max(0.0, sceneBoundsRadius || 0.0);
    minF -= extend;

    var eyeX = cx - fx * maxF;
    var eyeY = cy - fy * maxF;
    var eyeZ = cz - fz * maxF;

    var tx = -(rx * eyeX + ry * eyeY + rz * eyeZ);
    var ty = -(upX * eyeX + upY * eyeY + upZ * eyeZ);
    var tz = -(-fx * eyeX + -fy * eyeY + -fz * eyeZ);

    var view = new Float32Array([
      rx,  upX, -fx, 0,
      ry,  upY, -fy, 0,
      rz,  upZ, -fz, 0,
      tx,  ty,   tz, 1,
    ]);

    var l = minR, rr = maxR, b = minU, t = maxU;
    var near = 0.0;
    var far = (maxF - minF);
    if (far <= near) far = near + 1;

    var proj = new Float32Array([
      2 / (rr - l),            0,                       0,                            0,
      0,                       2 / (t - b),             0,                            0,
      0,                       0,                       -2 / (far - near),            0,
      -(rr + l) / (rr - l),   -(t + b) / (t - b),       -(far + near) / (far - near), 1,
    ]);

    return sceneMat4Multiply(proj, view);
  }

  function sceneShadowLightSpaceMatrix(light, sceneBounds) {
    var dx = sceneNumber(light.directionX, 0);
    var dy = sceneNumber(light.directionY, -1);
    var dz = sceneNumber(light.directionZ, 0);
    var len = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (len < 0.0001) {
      dx = 0; dy = -1; dz = 0; len = 1;
    }
    dx /= len; dy /= len; dz /= len;

    var cx = (sceneBounds.minX + sceneBounds.maxX) * 0.5;
    var cy = (sceneBounds.minY + sceneBounds.maxY) * 0.5;
    var cz = (sceneBounds.minZ + sceneBounds.maxZ) * 0.5;
    var ex = (sceneBounds.maxX - sceneBounds.minX) * 0.5;
    var ey = (sceneBounds.maxY - sceneBounds.minY) * 0.5;
    var ez = (sceneBounds.maxZ - sceneBounds.minZ) * 0.5;
    var radius = Math.sqrt(ex * ex + ey * ey + ez * ez);
    if (radius < 0.01) radius = 10;

    var eyeX = cx - dx * radius * 2;
    var eyeY = cy - dy * radius * 2;
    var eyeZ = cz - dz * radius * 2;

    var fx = dx, fy = dy, fz = dz;

    var upX = 0, upY = 1, upZ = 0;
    if (Math.abs(fy) > 0.99) {
      upX = 0; upY = 0; upZ = 1;
    }

    var rx = fy * upZ - fz * upY;
    var ry = fz * upX - fx * upZ;
    var rz = fx * upY - fy * upX;
    var rLen = Math.sqrt(rx * rx + ry * ry + rz * rz);
    if (rLen < 0.0001) rLen = 1;
    rx /= rLen; ry /= rLen; rz /= rLen;

    upX = ry * fz - rz * fy;
    upY = rz * fx - rx * fz;
    upZ = rx * fy - ry * fx;

    var tx = -(rx * eyeX + ry * eyeY + rz * eyeZ);
    var ty = -(upX * eyeX + upY * eyeY + upZ * eyeZ);
    var tz = -(fx * eyeX + fy * eyeY + fz * eyeZ);

    var view = new Float32Array([
      rx,  upX, fx,  0,
      ry,  upY, fy,  0,
      rz,  upZ, fz,  0,
      tx,  ty,  tz,  1,
    ]);

    var near = 0.01;
    var far = radius * 4;
    var l = -radius, rr = radius, b = -radius, t = radius;
    var proj = new Float32Array([
      2 / (rr - l),     0,              0,                    0,
      0,                2 / (t - b),    0,                    0,
      0,                0,              -2 / (far - near),    0,
      -(rr + l) / (rr - l), -(t + b) / (t - b), -(far + near) / (far - near), 1,
    ]);

    return sceneMat4Multiply(proj, view);
  }

  function sceneShadowComputeBounds(bundle) {
    var minX = Infinity, minY = Infinity, minZ = Infinity;
    var maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    var positions = bundle.worldMeshPositions;
    var objects = Array.isArray(bundle.meshObjects) ? bundle.meshObjects : [];

    for (var i = 0; i < objects.length; i++) {
      var obj = objects[i];
      if (!obj || obj.viewCulled) continue;
      if (obj.directVertices) continue;
      var offset = obj.vertexOffset;
      var count = obj.vertexCount;
      if (!Number.isFinite(offset) || !Number.isFinite(count) || count <= 0) continue;

      for (var v = 0; v < count; v++) {
        var idx = (offset + v) * 3;
        var px = positions[idx];
        var py = positions[idx + 1];
        var pz = positions[idx + 2];
        if (px < minX) minX = px;
        if (py < minY) minY = py;
        if (pz < minZ) minZ = pz;
        if (px > maxX) maxX = px;
        if (py > maxY) maxY = py;
        if (pz > maxZ) maxZ = pz;
      }
    }

    if (!isFinite(minX)) {
      return { minX: -10, minY: -10, minZ: -10, maxX: 10, maxY: 10, maxZ: 10 };
    }
    return { minX: minX, minY: minY, minZ: minZ, maxX: maxX, maxY: maxY, maxZ: maxZ };
  }

  function sceneShadowPassHash(lightMatrix, meshObjects, options) {
    var opts = options || {};
    var h = 0;
    if (lightMatrix) {
      for (var i = 0; i < 16; i++) h += lightMatrix[i] || 0;
    }
    h += sceneFiniteNumber(opts.cascadeIndex, 0) * 101.0;
    h += sceneFiniteNumber(opts.splitNear, 0) * 103.0;
    h += sceneFiniteNumber(opts.splitFar, 0) * 107.0;
    h += sceneFiniteNumber(opts.shadowSize, 0) * 109.0;
    var casterCount = 0;
    for (var j = 0; j < meshObjects.length; j++) {
      var o = meshObjects[j];
      if (!o || !o.castShadow || o.viewCulled) continue;
      h += (o.vertexOffset || 0) + (o.vertexCount || 0)
         + (o.depthNear || 0) + (o.depthFar || 0);
      casterCount++;
    }
    h += casterCount * 17.0;
    return h;
  }

  function renderSceneShadowPass(gl, shadowProgram, shadowResources, lightMatrix, bundle, shadowState) {
    var meshObjectsForHash = Array.isArray(bundle.meshObjects) ? bundle.meshObjects : [];
    var passHash = sceneShadowPassHash(lightMatrix, meshObjectsForHash, {
      cascadeIndex: shadowResources && typeof shadowResources.cascadeIndex === "number" ? shadowResources.cascadeIndex : 0,
      splitNear: shadowResources && typeof shadowResources.splitNear === "number" ? shadowResources.splitNear : 0,
      splitFar: shadowResources && typeof shadowResources.splitFar === "number" ? shadowResources.splitFar : 0,
      shadowSize: shadowResources && typeof shadowResources.size === "number" ? shadowResources.size : 0,
    });
    if (shadowResources._lastPassHash === passHash) {
      return;
    }
    shadowResources._lastPassHash = passHash;

    gl.bindFramebuffer(gl.FRAMEBUFFER, shadowResources.framebuffer);
    gl.viewport(0, 0, shadowResources.size, shadowResources.size);
    gl.clearDepth(1);
    gl.clear(gl.DEPTH_BUFFER_BIT);

    gl.useProgram(shadowProgram.program);
    gl.uniformMatrix4fv(shadowProgram.uniforms.lightViewProjection, false, lightMatrix);

    gl.enable(gl.DEPTH_TEST);
    gl.depthMask(true);
    gl.depthFunc(gl.LEQUAL);
    gl.disable(gl.BLEND);

    gl.enable(gl.CULL_FACE);
    gl.cullFace(gl.FRONT);

    var objects = Array.isArray(bundle.meshObjects) ? bundle.meshObjects : [];

    for (var i = 0; i < objects.length; i++) {
      var obj = objects[i];
      if (!obj || obj.viewCulled) continue;
      if (obj.directVertices) continue;
      if (!obj.castShadow) continue;
      if (!Number.isFinite(obj.vertexOffset) || !Number.isFinite(obj.vertexCount) || obj.vertexCount <= 0) continue;

      var offset = obj.vertexOffset;
      var count = obj.vertexCount;

      var length = count * 3;
      var start = offset * 3;
      if (!shadowState.scratch || shadowState.scratch.length < length) {
        shadowState.scratch = new Float32Array(length);
      }
      var positions = shadowState.scratch;
      for (var vi = 0; vi < length; vi++) {
        positions[vi] = bundle.worldMeshPositions[start + vi] || 0;
      }

      gl.bindBuffer(gl.ARRAY_BUFFER, shadowState.buffer);
      gl.bufferData(gl.ARRAY_BUFFER, positions.subarray(0, length), gl.DYNAMIC_DRAW);
      gl.enableVertexAttribArray(shadowProgram.attributes.position);
      gl.vertexAttribPointer(shadowProgram.attributes.position, 3, gl.FLOAT, false, 0, 0);

      gl.drawArrays(gl.TRIANGLES, 0, count);
    }

    gl.cullFace(gl.BACK);
    gl.disable(gl.CULL_FACE);

    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  function createSceneShadowProgram(gl) {
    var vertexShader = scenePBRCompileShader(gl, gl.VERTEX_SHADER, SCENE_SHADOW_VERTEX_SOURCE);
    if (!vertexShader) return null;
    var fragmentShader = scenePBRCompileShader(gl, gl.FRAGMENT_SHADER, SCENE_SHADOW_FRAGMENT_SOURCE);
    if (!fragmentShader) {
      gl.deleteShader(vertexShader);
      return null;
    }

    var program = scenePBRLinkProgram(gl, vertexShader, fragmentShader, "Shadow shader");
    if (!program) return null;

    return {
      program: program,
      vertexShader: vertexShader,
      fragmentShader: fragmentShader,
      attributes: {
        position: gl.getAttribLocation(program, "a_position"),
      },
      uniforms: {
        lightViewProjection: gl.getUniformLocation(program, "u_lightViewProjection"),
      },
    };
  }

  const SCENE_POST_VERTEX_SOURCE = [
    "#version 300 es",
    "in vec2 a_position;",
    "in vec2 a_uv;",
    "out vec2 v_uv;",
    "void main() {",
    "    v_uv = a_uv;",
    "    gl_Position = vec4(a_position, 0.0, 1.0);",
    "}",
  ].join("\n");

  const SCENE_POST_TONEMAPPING_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "in vec2 v_uv;",
    "uniform sampler2D u_texture;",
    "uniform float u_exposure;",
    "uniform int u_toneMapMode;",
    "out vec4 fragColor;",
    "",
    "vec3 aces(vec3 x) {",
    "    float a = 2.51;",
    "    float b = 0.03;",
    "    float c = 2.43;",
    "    float d = 0.59;",
    "    float e = 0.14;",
    "    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);",
    "}",
    "",
    "vec3 reinhard(vec3 x) {",
    "    return x / (x + vec3(1.0));",
    "}",
    "",
    "vec3 filmic(vec3 x) {",
    "    x = max(vec3(0.0), x - vec3(0.004));",
    "    return clamp((x * (6.2 * x + 0.5)) / (x * (6.2 * x + 1.7) + 0.06), 0.0, 1.0);",
    "}",
    "",
    "void main() {",
    "    vec3 color = texture(u_texture, v_uv).rgb;",
    "    color *= u_exposure;",
    "    if (u_toneMapMode == 0) {",
    "        color = clamp(color, 0.0, 1.0);",
    "    } else if (u_toneMapMode == 2) {",
    "        color = reinhard(color);",
    "    } else if (u_toneMapMode == 3) {",
    "        color = filmic(color);",
    "    } else {",
    "        color = aces(color);",
    "    }",
    "    fragColor = vec4(color, 1.0);",
    "}",
  ].join("\n");

  const SCENE_POST_BLOOM_BRIGHT_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "in vec2 v_uv;",
    "uniform sampler2D u_texture;",
    "uniform float u_threshold;",
    "out vec4 fragColor;",
    "",
    "void main() {",
    "    vec3 color = texture(u_texture, v_uv).rgb;",
    "    float brightness = dot(color, vec3(0.2126, 0.7152, 0.0722));",
    "    fragColor = vec4(brightness > u_threshold ? color : vec3(0.0), 1.0);",
    "}",
  ].join("\n");

  const SCENE_POST_BLUR_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "in vec2 v_uv;",
    "uniform sampler2D u_texture;",
    "uniform vec2 u_direction;",
    "uniform float u_radius;",
    "out vec4 fragColor;",
    "",
    "void main() {",
    "    vec2 texelSize = 1.0 / vec2(textureSize(u_texture, 0));",
    "    vec3 result = texture(u_texture, v_uv).rgb * 0.227027;",
    "",
    "    float offsets[4] = float[](1.0, 2.0, 3.0, 4.0);",
    "    float weights[4] = float[](0.1945946, 0.1216216, 0.054054, 0.016216);",
    "",
    "    for (int i = 0; i < 4; i++) {",
    "        vec2 offset = u_direction * texelSize * offsets[i] * u_radius;",
    "        result += texture(u_texture, v_uv + offset).rgb * weights[i];",
    "        result += texture(u_texture, v_uv - offset).rgb * weights[i];",
    "    }",
    "    fragColor = vec4(result, 1.0);",
    "}",
  ].join("\n");

  const SCENE_POST_BLOOM_COMPOSITE_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "in vec2 v_uv;",
    "uniform sampler2D u_texture;",
    "uniform sampler2D u_bloomTexture;",
    "uniform float u_intensity;",
    "out vec4 fragColor;",
    "",
    "void main() {",
    "    vec3 scene = texture(u_texture, v_uv).rgb;",
    "    vec3 bloom = texture(u_bloomTexture, v_uv).rgb;",
    "    fragColor = vec4(scene + bloom * u_intensity, 1.0);",
    "}",
  ].join("\n");

  const SCENE_POST_VIGNETTE_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "in vec2 v_uv;",
    "uniform sampler2D u_texture;",
    "uniform float u_intensity;",
    "out vec4 fragColor;",
    "",
    "void main() {",
    "    vec3 color = texture(u_texture, v_uv).rgb;",
    "    vec2 center = v_uv - 0.5;",
    "    float dist = length(center);",
    "    float vignette = 1.0 - smoothstep(0.3, 0.7, dist * u_intensity);",
    "    fragColor = vec4(color * vignette, 1.0);",
    "}",
  ].join("\n");

  const SCENE_POST_SSAO_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "in vec2 v_uv;",
    "uniform sampler2D u_texture;",
    "uniform float u_radius;",
    "uniform float u_intensity;",
    "out vec4 fragColor;",
    "",
    "float luminance(vec3 color) { return dot(color, vec3(0.2126, 0.7152, 0.0722)); }",
    "",
    "void main() {",
    "    vec2 texel = 1.0 / vec2(textureSize(u_texture, 0));",
    "    vec3 color = texture(u_texture, v_uv).rgb;",
    "    float center = luminance(color);",
    "    float r = max(1.0, u_radius);",
    "    float neighbor = 0.0;",
    "    neighbor += luminance(texture(u_texture, v_uv + texel * vec2( r,  0.0)).rgb);",
    "    neighbor += luminance(texture(u_texture, v_uv + texel * vec2(-r,  0.0)).rgb);",
    "    neighbor += luminance(texture(u_texture, v_uv + texel * vec2(0.0,  r)).rgb);",
    "    neighbor += luminance(texture(u_texture, v_uv + texel * vec2(0.0, -r)).rgb);",
    "    neighbor += luminance(texture(u_texture, v_uv + texel * vec2( r,  r)).rgb);",
    "    neighbor += luminance(texture(u_texture, v_uv + texel * vec2(-r,  r)).rgb);",
    "    neighbor += luminance(texture(u_texture, v_uv + texel * vec2( r, -r)).rgb);",
    "    neighbor += luminance(texture(u_texture, v_uv + texel * vec2(-r, -r)).rgb);",
    "    neighbor *= 0.125;",
    "    float crease = clamp((neighbor - center) * 2.25, 0.0, 1.0);",
    "    float occlusion = 1.0 - crease * clamp(u_intensity, 0.0, 2.0);",
    "    fragColor = vec4(color * occlusion, 1.0);",
    "}",
  ].join("\n");

  const SCENE_POST_DOF_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "in vec2 v_uv;",
    "uniform sampler2D u_texture;",
    "uniform sampler2D u_depthTexture;",
    "uniform float u_focusDistance;",
    "uniform float u_aperture;",
    "uniform float u_maxBlur;",
    "uniform float u_near;",
    "uniform float u_far;",
    "out vec4 fragColor;",
    "",
    "float linearDepth(float depth) {",
    "    float z = depth * 2.0 - 1.0;",
    "    return (2.0 * u_near * u_far) / max(0.0001, u_far + u_near - z * (u_far - u_near));",
    "}",
    "",
    "void main() {",
    "    vec2 texel = 1.0 / vec2(textureSize(u_texture, 0));",
    "    float depth = linearDepth(texture(u_depthTexture, v_uv).r);",
    "    float blur = clamp(abs(depth - u_focusDistance) * u_aperture * u_maxBlur, 0.0, u_maxBlur);",
    "    vec3 color = texture(u_texture, v_uv).rgb * 0.22;",
    "    color += texture(u_texture, v_uv + texel * vec2( blur,  0.0)).rgb * 0.10;",
    "    color += texture(u_texture, v_uv + texel * vec2(-blur,  0.0)).rgb * 0.10;",
    "    color += texture(u_texture, v_uv + texel * vec2(0.0,  blur)).rgb * 0.10;",
    "    color += texture(u_texture, v_uv + texel * vec2(0.0, -blur)).rgb * 0.10;",
    "    color += texture(u_texture, v_uv + texel * vec2( blur,  blur)).rgb * 0.095;",
    "    color += texture(u_texture, v_uv + texel * vec2(-blur,  blur)).rgb * 0.095;",
    "    color += texture(u_texture, v_uv + texel * vec2( blur, -blur)).rgb * 0.095;",
    "    color += texture(u_texture, v_uv + texel * vec2(-blur, -blur)).rgb * 0.095;",
    "    fragColor = vec4(color, 1.0);",
    "}",
  ].join("\n");

  const SCENE_POST_COLORGRADE_SOURCE = [
    "#version 300 es",
    "precision highp float;",
    "in vec2 v_uv;",
    "uniform sampler2D u_texture;",
    "uniform float u_exposure;",
    "uniform float u_contrast;",
    "uniform float u_saturation;",
    "out vec4 fragColor;",
    "",
    "void main() {",
    "    vec3 color = texture(u_texture, v_uv).rgb;",
    "    color *= u_exposure;",
    "    color = mix(vec3(0.5), color, u_contrast);",
    "    float gray = dot(color, vec3(0.2126, 0.7152, 0.0722));",
    "    color = mix(vec3(gray), color, u_saturation);",
    "    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);",
    "}",
  ].join("\n");

  function createScenePostFBO(gl, width, height, depthTexture) {
    var hdrSupported = Boolean(gl.getExtension("EXT_color_buffer_float"));
    var internalFormat = hdrSupported ? gl.RGBA16F : gl.RGBA8;
    var dataType = hdrSupported ? gl.FLOAT : gl.UNSIGNED_BYTE;

    var fbo = gl.createFramebuffer();
    var colorTex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, colorTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, internalFormat, width, height, 0, gl.RGBA, dataType, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

    var depthRB = null;
    var depthTex = null;
    if (depthTexture) {
      depthTex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, depthTex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.DEPTH_COMPONENT24, width, height, 0, gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, null);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    } else {
      depthRB = gl.createRenderbuffer();
      gl.bindRenderbuffer(gl.RENDERBUFFER, depthRB);
      gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, width, height);
    }

    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, colorTex, 0);
    if (depthTex) {
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, depthTex, 0);
    } else {
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, depthRB);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);

    return { fbo: fbo, colorTex: colorTex, depthRB: depthRB, depthTex: depthTex, width: width, height: height };
  }

  function createScenePostPingPong(gl, width, height) {
    return {
      a: createScenePostFBO(gl, width, height),
      b: createScenePostFBO(gl, width, height),
    };
  }

  function createSceneFullscreenQuad(gl) {
    var vao = gl.createVertexArray();
    var vbo = gl.createBuffer();
    gl.bindVertexArray(vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
      -1, -1,  0, 0,
       1, -1,  1, 0,
      -1,  1,  0, 1,
       1,  1,  1, 1,
    ]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 16, 0);
    gl.enableVertexAttribArray(1);
    gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 16, 8);
    gl.bindVertexArray(null);
    return { vao: vao, vbo: vbo };
  }

  function drawSceneFullscreenQuad(gl, quadVAO) {
    gl.bindVertexArray(quadVAO);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    gl.bindVertexArray(null);
  }

  function createScenePostProgram(gl, fragmentSource) {
    var vs = scenePBRCompileShader(gl, gl.VERTEX_SHADER, SCENE_POST_VERTEX_SOURCE);
    if (!vs) return null;
    var fs = scenePBRCompileShader(gl, gl.FRAGMENT_SHADER, fragmentSource);
    if (!fs) {
      gl.deleteShader(vs);
      return null;
    }

    var prog = scenePBRLinkProgram(gl, vs, fs, "Post-process shader");
    if (!prog) return null;

    return { program: prog, vertexShader: vs, fragmentShader: fs };
  }

  function disposeScenePostFBO(gl, fboObj) {
    if (!fboObj) return;
    if (fboObj.colorTex) gl.deleteTexture(fboObj.colorTex);
    if (fboObj.depthTex) gl.deleteTexture(fboObj.depthTex);
    if (fboObj.depthRB) gl.deleteRenderbuffer(fboObj.depthRB);
    if (fboObj.fbo) gl.deleteFramebuffer(fboObj.fbo);
  }

  function createScenePostProcessor(gl) {
    var quad = createSceneFullscreenQuad(gl);
    var sceneFBO = null;
    var auxFBO = null;
    var scratchFBO = null;
    var pingPong = null;
    var currentWidth = 0;
    var currentHeight = 0;

    var programs = {};

    function getProgram(name, fragmentSource) {
      if (programs[name]) return programs[name];
      var prog = createScenePostProgram(gl, fragmentSource);
      if (prog) programs[name] = prog;
      return prog;
    }

	    function clearPostTextureBindings() {
	      for (var unit = 0; unit < 4; unit++) {
	        gl.activeTexture(gl.TEXTURE0 + unit);
	        gl.bindTexture(gl.TEXTURE_2D, null);
	      }
	    }

	    function beginPostPass(prog, inputTex, targetFBO, w, h) {
	      if (targetFBO) {
	        clearPostTextureBindings();
	      }
	      gl.bindFramebuffer(gl.FRAMEBUFFER, targetFBO);
	      gl.viewport(0, 0, w, h);
	      gl.useProgram(prog.program);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, inputTex);
      gl.uniform1i(gl.getUniformLocation(prog.program, "u_texture"), 0);
    }

    function postPass(prog, inputTex, targetFBO, w, h) {
      beginPostPass(prog, inputTex, targetFBO ? targetFBO.fbo : null, w, h);
      drawSceneFullscreenQuad(gl, quad.vao);
      return targetFBO ? targetFBO.colorTex : null;
    }

    function scenePostToneMapMode(mode) {
      if (typeof mode === "string") {
        var normalized = mode.trim().toLowerCase();
        if (normalized === "linear" || normalized === "none") return 0;
        if (normalized === "reinhard") return 2;
        if (normalized === "filmic") return 3;
      }
      return 1;
    }

    function applyToneMapping(inputTex, effect, targetFBO, w, h) {
      var prog = getProgram("toneMapping", SCENE_POST_TONEMAPPING_SOURCE);
      if (!prog) return inputTex;
      beginPostPass(prog, inputTex, targetFBO ? targetFBO.fbo : null, w, h);
      gl.uniform1f(gl.getUniformLocation(prog.program, "u_exposure"), sceneNumber(effect.exposure, 1.0));
      gl.uniform1i(gl.getUniformLocation(prog.program, "u_toneMapMode"), scenePostToneMapMode(effect.mode));
      drawSceneFullscreenQuad(gl, quad.vao);
      return targetFBO ? targetFBO.colorTex : null;
    }

    function applyBloom(inputTex, effect, targetFBO, passW, passH, scaledW, scaledH) {
      var brightProg = getProgram("bloomBright", SCENE_POST_BLOOM_BRIGHT_SOURCE);
      var blurProg = getProgram("bloomBlur", SCENE_POST_BLUR_SOURCE);
      var compositeProg = getProgram("bloomComposite", SCENE_POST_BLOOM_COMPOSITE_SOURCE);
      if (!brightProg || !blurProg || !compositeProg) return inputTex;

      var bloomScale = (effect.scale > 0 && effect.scale <= 1) ? effect.scale : 0.5;
      var halfW = Math.max(1, Math.floor(scaledW * bloomScale));
      var halfH = Math.max(1, Math.floor(scaledH * bloomScale));

      if (!pingPong || pingPong.a.width !== halfW || pingPong.a.height !== halfH) {
        if (pingPong) {
          disposeScenePostFBO(gl, pingPong.a);
          disposeScenePostFBO(gl, pingPong.b);
        }
        pingPong = createScenePostPingPong(gl, halfW, halfH);
      }

      var threshold = sceneNumber(effect.threshold, 0.8);
      var radius = sceneNumber(effect.radius, 5.0);
      var intensity = sceneNumber(effect.intensity, 0.5);

      beginPostPass(brightProg, inputTex, pingPong.a.fbo, halfW, halfH);
      gl.uniform1f(gl.getUniformLocation(brightProg.program, "u_threshold"), threshold);
      drawSceneFullscreenQuad(gl, quad.vao);

      beginPostPass(blurProg, pingPong.a.colorTex, pingPong.b.fbo, halfW, halfH);
      gl.uniform2f(gl.getUniformLocation(blurProg.program, "u_direction"), 1.0, 0.0);
      gl.uniform1f(gl.getUniformLocation(blurProg.program, "u_radius"), radius);
      drawSceneFullscreenQuad(gl, quad.vao);

      beginPostPass(blurProg, pingPong.b.colorTex, pingPong.a.fbo, halfW, halfH);
      gl.uniform2f(gl.getUniformLocation(blurProg.program, "u_direction"), 0.0, 1.0);
      gl.uniform1f(gl.getUniformLocation(blurProg.program, "u_radius"), radius);
      drawSceneFullscreenQuad(gl, quad.vao);

      beginPostPass(compositeProg, inputTex, targetFBO ? targetFBO.fbo : null, passW, passH);
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, pingPong.a.colorTex);
      gl.uniform1i(gl.getUniformLocation(compositeProg.program, "u_bloomTexture"), 1);
      gl.uniform1f(gl.getUniformLocation(compositeProg.program, "u_intensity"), intensity);
      drawSceneFullscreenQuad(gl, quad.vao);

      return targetFBO ? targetFBO.colorTex : null;
    }

    function applyVignette(inputTex, effect, targetFBO, w, h) {
      var prog = getProgram("vignette", SCENE_POST_VIGNETTE_SOURCE);
      if (!prog) return inputTex;
      beginPostPass(prog, inputTex, targetFBO ? targetFBO.fbo : null, w, h);
      gl.uniform1f(gl.getUniformLocation(prog.program, "u_intensity"), sceneNumber(effect.intensity, 1.0));
      drawSceneFullscreenQuad(gl, quad.vao);
      return targetFBO ? targetFBO.colorTex : null;
    }

    function applyColorGrade(inputTex, effect, targetFBO, w, h) {
      var prog = getProgram("colorGrade", SCENE_POST_COLORGRADE_SOURCE);
      if (!prog) return inputTex;
      beginPostPass(prog, inputTex, targetFBO ? targetFBO.fbo : null, w, h);
      gl.uniform1f(gl.getUniformLocation(prog.program, "u_exposure"), sceneNumber(effect.exposure, 1.0));
      gl.uniform1f(gl.getUniformLocation(prog.program, "u_contrast"), sceneNumber(effect.contrast, 1.0));
      gl.uniform1f(gl.getUniformLocation(prog.program, "u_saturation"), sceneNumber(effect.saturation, 1.0));
      drawSceneFullscreenQuad(gl, quad.vao);
      return targetFBO ? targetFBO.colorTex : null;
    }

    function applySSAO(inputTex, effect, targetFBO, w, h) {
      var prog = getProgram("ssao", SCENE_POST_SSAO_SOURCE);
      if (!prog) return inputTex;
      beginPostPass(prog, inputTex, targetFBO ? targetFBO.fbo : null, w, h);
      gl.uniform1f(gl.getUniformLocation(prog.program, "u_radius"), sceneNumber(effect.radius, 4.0));
      gl.uniform1f(gl.getUniformLocation(prog.program, "u_intensity"), sceneNumber(effect.intensity, 0.55));
      drawSceneFullscreenQuad(gl, quad.vao);
      return targetFBO ? targetFBO.colorTex : null;
    }

    function applyDOF(inputTex, effect, targetFBO, w, h, camera) {
      if (!sceneFBO || !sceneFBO.depthTex) return inputTex;
      var prog = getProgram("dof", SCENE_POST_DOF_SOURCE);
      if (!prog) return inputTex;
      beginPostPass(prog, inputTex, targetFBO ? targetFBO.fbo : null, w, h);
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, sceneFBO.depthTex);
      gl.uniform1i(gl.getUniformLocation(prog.program, "u_depthTexture"), 1);
      gl.uniform1f(gl.getUniformLocation(prog.program, "u_focusDistance"), sceneNumber(effect.focusDistance, 8.0));
      gl.uniform1f(gl.getUniformLocation(prog.program, "u_aperture"), sceneNumber(effect.aperture, 0.04));
      gl.uniform1f(gl.getUniformLocation(prog.program, "u_maxBlur"), sceneNumber(effect.maxBlur, 8.0));
      gl.uniform1f(gl.getUniformLocation(prog.program, "u_near"), Math.max(0.0001, sceneNumber(camera && camera.near, 0.05)));
      gl.uniform1f(gl.getUniformLocation(prog.program, "u_far"), Math.max(0.1, sceneNumber(camera && camera.far, 128)));
      drawSceneFullscreenQuad(gl, quad.vao);
      return targetFBO ? targetFBO.colorTex : null;
    }

    var blitProg = null;
    var SCENE_POST_BLIT_SOURCE = [
      "#version 300 es",
      "precision highp float;",
      "in vec2 v_uv;",
      "uniform sampler2D u_texture;",
      "out vec4 fragColor;",
      "void main() {",
      "    fragColor = texture(u_texture, v_uv);",
      "}",
    ].join("\n");

    function blitToScreen(inputTex, w, h) {
      if (!blitProg) {
        blitProg = createScenePostProgram(gl, SCENE_POST_BLIT_SOURCE);
      }
      if (!blitProg) return;
      postPass(blitProg, inputTex, null, w, h);
    }

    return {
	      begin: function(canvasW, canvasH, maxPixels) {
        var factor = resolvePostFXFactor(maxPixels, canvasW * canvasH);
        var sw = Math.max(1, Math.floor(canvasW * factor));
        var sh = Math.max(1, Math.floor(canvasH * factor));

        if (sw !== currentWidth || sh !== currentHeight) {
          if (sceneFBO) disposeScenePostFBO(gl, sceneFBO);
          sceneFBO = createScenePostFBO(gl, sw, sh, true);
          if (auxFBO) disposeScenePostFBO(gl, auxFBO);
          auxFBO = null;
          if (scratchFBO) disposeScenePostFBO(gl, scratchFBO);
          scratchFBO = null;
          currentWidth = sw;
          currentHeight = sh;
        }
	        clearPostTextureBindings();
	        gl.bindFramebuffer(gl.FRAMEBUFFER, sceneFBO.fbo);
	        return { width: sw, height: sh, factor: factor };
	      },

      apply: function(effects, scaledW, scaledH, canvasW, canvasH, camera) {
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        gl.disable(gl.DEPTH_TEST);

        var currentTexture = sceneFBO.colorTex;

        if (effects.length > 1 && !auxFBO) {
          auxFBO = createScenePostFBO(gl, scaledW, scaledH);
        }

        for (var i = 0; i < effects.length; i++) {
          var effect = effects[i];
          var isLast = (i === effects.length - 1);

          var targetFBO = null;
          if (!isLast) {
            targetFBO = (currentTexture === sceneFBO.colorTex) ? auxFBO : sceneFBO;
            if (effect.kind === SCENE_POST_DOF && targetFBO === sceneFBO) {
              if (!scratchFBO || scratchFBO.width !== scaledW || scratchFBO.height !== scaledH) {
                if (scratchFBO) disposeScenePostFBO(gl, scratchFBO);
                scratchFBO = createScenePostFBO(gl, scaledW, scaledH);
              }
              targetFBO = scratchFBO;
            }
          }

          var passW = isLast ? canvasW : scaledW;
          var passH = isLast ? canvasH : scaledH;

          switch (effect.kind) {
            case SCENE_POST_TONE_MAPPING:
              currentTexture = applyToneMapping(currentTexture, effect, targetFBO, passW, passH);
              break;
            case SCENE_POST_BLOOM:
              currentTexture = applyBloom(currentTexture, effect, targetFBO, passW, passH, scaledW, scaledH);
              break;
            case SCENE_POST_VIGNETTE:
              currentTexture = applyVignette(currentTexture, effect, targetFBO, passW, passH);
              break;
            case SCENE_POST_COLOR_GRADE:
              currentTexture = applyColorGrade(currentTexture, effect, targetFBO, passW, passH);
              break;
            case SCENE_POST_SSAO:
              currentTexture = applySSAO(currentTexture, effect, targetFBO, passW, passH);
              break;
            case SCENE_POST_DOF:
              currentTexture = applyDOF(currentTexture, effect, targetFBO, passW, passH, camera);
              break;
            default:
              break;
          }

          if (isLast && currentTexture === null) break;
        }

        if (currentTexture !== null && effects.length > 0) {
          blitToScreen(currentTexture, canvasW, canvasH);
        } else if (effects.length === 0) {
          blitToScreen(sceneFBO.colorTex, canvasW, canvasH);
        }

        gl.enable(gl.DEPTH_TEST);
      },

      dispose: function() {
        if (sceneFBO) {
          disposeScenePostFBO(gl, sceneFBO);
          sceneFBO = null;
        }
        if (auxFBO) {
          disposeScenePostFBO(gl, auxFBO);
          auxFBO = null;
        }
        if (scratchFBO) {
          disposeScenePostFBO(gl, scratchFBO);
          scratchFBO = null;
        }
        if (pingPong) {
          disposeScenePostFBO(gl, pingPong.a);
          disposeScenePostFBO(gl, pingPong.b);
          pingPong = null;
        }
        for (var key in programs) {
          if (programs[key]) {
            gl.deleteShader(programs[key].vertexShader);
            gl.deleteShader(programs[key].fragmentShader);
            gl.deleteProgram(programs[key].program);
          }
        }
        programs = {};
        if (blitProg) {
          gl.deleteShader(blitProg.vertexShader);
          gl.deleteShader(blitProg.fragmentShader);
          gl.deleteProgram(blitProg.program);
          blitProg = null;
        }
        if (quad) {
          gl.deleteBuffer(quad.vbo);
          gl.deleteVertexArray(quad.vao);
        }
        currentWidth = 0;
        currentHeight = 0;
      },
    };
  }

  function scenePBRTextureLooksHDR(url) {
    var key = typeof url === "string" ? url.trim().toLowerCase() : "";
    return key.endsWith(".hdr") || key.indexOf(".hdr?") >= 0 || key.indexOf(".hdr#") >= 0;
  }

  function scenePBRTonemapHDRPixels(parsed) {
    var width = Math.max(1, Math.floor(sceneNumber(parsed && parsed.width, 1)));
    var height = Math.max(1, Math.floor(sceneNumber(parsed && parsed.height, 1)));
    var source = parsed && parsed.data;
    var pixels = new Uint8Array(width * height * 4);
    for (var i = 0, j = 0; i < width * height; i++, j += 3) {
      var r = Math.max(0, sceneNumber(source && source[j], 0));
      var g = Math.max(0, sceneNumber(source && source[j + 1], 0));
      var b = Math.max(0, sceneNumber(source && source[j + 2], 0));
      pixels[i * 4] = Math.max(0, Math.min(255, Math.round(Math.pow(r / (1 + r), 1 / 2.2) * 255)));
      pixels[i * 4 + 1] = Math.max(0, Math.min(255, Math.round(Math.pow(g / (1 + g), 1 / 2.2) * 255)));
      pixels[i * 4 + 2] = Math.max(0, Math.min(255, Math.round(Math.pow(b / (1 + b), 1 / 2.2) * 255)));
      pixels[i * 4 + 3] = 255;
    }
    return { width: width, height: height, pixels: pixels };
  }

  function scenePBRLoadHDRTexture(gl, key, texture, record) {
    if (typeof fetch !== "function" || typeof sceneParseRadianceHDR !== "function") {
      return false;
    }
    fetch(key)
      .then(function(response) {
        if (!response || response.ok === false) {
          throw new Error("failed to fetch HDR environment map");
        }
        return response.arrayBuffer();
      })
      .then(function(buffer) {
        var parsed = sceneParseRadianceHDR(buffer);
        var ldr = scenePBRTonemapHDRPixels(parsed);
        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, ldr.width, ldr.height, 0, gl.RGBA, gl.UNSIGNED_BYTE, ldr.pixels);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        record.loaded = true;
        record.width = ldr.width;
        record.height = ldr.height;
        record.hdr = true;
      })
      .catch(function() {
        record.failed = true;
      });
    return true;
  }

  function scenePBRLoadTexture(gl, url, cache) {
    if (!cache) return null;
    const textureMap = cache;
    const key = typeof url === "string" ? url.trim() : "";
    if (!key) {
      return null;
    }
    if (textureMap.has(key)) {
      return textureMap.get(key);
    }

    const texture = gl.createTexture();
    const record = { texture: texture, src: key, loaded: false, failed: false };
    textureMap.set(key, record);

    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([255, 255, 255, 255]));
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

    if (scenePBRTextureLooksHDR(key) && scenePBRLoadHDRTexture(gl, key, texture, record)) {
      return record;
    }

    if (typeof Image === "function") {
      const image = new Image();
      image.onload = function() {
        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
        if (typeof gl.generateMipmap === "function" && gl.LINEAR_MIPMAP_LINEAR !== undefined) {
          gl.generateMipmap(gl.TEXTURE_2D);
          gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
        } else {
          gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        }
        record.loaded = true;
      };
      image.onerror = function() {
        record.failed = true;
      };
      image.src = key;
    }

    return record;
  }

  function scenePBRBindTexture(gl, unit, texture) {
    gl.activeTexture(gl.TEXTURE0 + unit);
    gl.bindTexture(gl.TEXTURE_2D, texture);
  }

  function scenePBRCacheBaseUniforms(gl, program) {
    var uniforms = {
      viewMatrix: gl.getUniformLocation(program, "u_viewMatrix"),
      projectionMatrix: gl.getUniformLocation(program, "u_projectionMatrix"),
      cameraPosition: gl.getUniformLocation(program, "u_cameraPosition"),

      albedo: gl.getUniformLocation(program, "u_albedo"),
      roughness: gl.getUniformLocation(program, "u_roughness"),
      metalness: gl.getUniformLocation(program, "u_metalness"),
      clearcoat: gl.getUniformLocation(program, "u_clearcoat"),
      sheen: gl.getUniformLocation(program, "u_sheen"),
      transmission: gl.getUniformLocation(program, "u_transmission"),
      iridescence: gl.getUniformLocation(program, "u_iridescence"),
      anisotropy: gl.getUniformLocation(program, "u_anisotropy"),
      emissive: gl.getUniformLocation(program, "u_emissive"),
      opacity: gl.getUniformLocation(program, "u_opacity"),
      unlit: gl.getUniformLocation(program, "u_unlit"),

      albedoMap: gl.getUniformLocation(program, "u_albedoMap"),
      normalMap: gl.getUniformLocation(program, "u_normalMap"),
      roughnessMap: gl.getUniformLocation(program, "u_roughnessMap"),
      metalnessMap: gl.getUniformLocation(program, "u_metalnessMap"),
      emissiveMap: gl.getUniformLocation(program, "u_emissiveMap"),
      hasAlbedoMap: gl.getUniformLocation(program, "u_hasAlbedoMap"),
      hasNormalMap: gl.getUniformLocation(program, "u_hasNormalMap"),
      hasRoughnessMap: gl.getUniformLocation(program, "u_hasRoughnessMap"),
      hasMetalnessMap: gl.getUniformLocation(program, "u_hasMetalnessMap"),
      hasEmissiveMap: gl.getUniformLocation(program, "u_hasEmissiveMap"),

      lightCount: gl.getUniformLocation(program, "u_lightCount"),
      lightTypes: [],
      lightPositions: [],
      lightDirections: [],
      lightColors: [],
      lightIntensities: [],
      lightRanges: [],
      lightDecays: [],
      lightAngles: [],
      lightPenumbras: [],
      lightGroundColors: [],

      ambientColor: gl.getUniformLocation(program, "u_ambientColor"),
      ambientIntensity: gl.getUniformLocation(program, "u_ambientIntensity"),
      skyColor: gl.getUniformLocation(program, "u_skyColor"),
      skyIntensity: gl.getUniformLocation(program, "u_skyIntensity"),
      groundColor: gl.getUniformLocation(program, "u_groundColor"),
      groundIntensity: gl.getUniformLocation(program, "u_groundIntensity"),
      envMap: gl.getUniformLocation(program, "u_envMap"),
      hasEnvMap: gl.getUniformLocation(program, "u_hasEnvMap"),
      envIntensity: gl.getUniformLocation(program, "u_envIntensity"),
      envRotation: gl.getUniformLocation(program, "u_envRotation"),

      shadowMap0_0: gl.getUniformLocation(program, "u_shadowMap0_0"),
      shadowMap0_1: gl.getUniformLocation(program, "u_shadowMap0_1"),
      shadowMap0_2: gl.getUniformLocation(program, "u_shadowMap0_2"),
      shadowMap0_3: gl.getUniformLocation(program, "u_shadowMap0_3"),
      lightSpaceMatrices0: gl.getUniformLocation(program, "u_lightSpaceMatrices0"),
      shadowCascadeSplits0: gl.getUniformLocation(program, "u_shadowCascadeSplits0"),
      shadowCascades0: gl.getUniformLocation(program, "u_shadowCascades0"),
      hasShadow0: gl.getUniformLocation(program, "u_hasShadow0"),
      shadowBias0: gl.getUniformLocation(program, "u_shadowBias0"),
      shadowSoftness0: gl.getUniformLocation(program, "u_shadowSoftness0"),
      shadowLightIndex0: gl.getUniformLocation(program, "u_shadowLightIndex0"),

      shadowMap1_0: gl.getUniformLocation(program, "u_shadowMap1_0"),
      shadowMap1_1: gl.getUniformLocation(program, "u_shadowMap1_1"),
      shadowMap1_2: gl.getUniformLocation(program, "u_shadowMap1_2"),
      shadowMap1_3: gl.getUniformLocation(program, "u_shadowMap1_3"),
      lightSpaceMatrices1: gl.getUniformLocation(program, "u_lightSpaceMatrices1"),
      shadowCascadeSplits1: gl.getUniformLocation(program, "u_shadowCascadeSplits1"),
      shadowCascades1: gl.getUniformLocation(program, "u_shadowCascades1"),
      hasShadow1: gl.getUniformLocation(program, "u_hasShadow1"),
      shadowBias1: gl.getUniformLocation(program, "u_shadowBias1"),
      shadowSoftness1: gl.getUniformLocation(program, "u_shadowSoftness1"),
      shadowLightIndex1: gl.getUniformLocation(program, "u_shadowLightIndex1"),

      receiveShadow: gl.getUniformLocation(program, "u_receiveShadow"),

      exposure: gl.getUniformLocation(program, "u_exposure"),
      toneMapMode: gl.getUniformLocation(program, "u_toneMapMode"),

      hasFog: gl.getUniformLocation(program, "u_hasFog"),
      fogDensity: gl.getUniformLocation(program, "u_fogDensity"),
      fogColor: gl.getUniformLocation(program, "u_fogColor"),
    };

    for (var i = 0; i < 8; i++) {
      uniforms.lightTypes.push(gl.getUniformLocation(program, "u_lightTypes[" + i + "]"));
      uniforms.lightPositions.push(gl.getUniformLocation(program, "u_lightPositions[" + i + "]"));
      uniforms.lightDirections.push(gl.getUniformLocation(program, "u_lightDirections[" + i + "]"));
      uniforms.lightColors.push(gl.getUniformLocation(program, "u_lightColors[" + i + "]"));
      uniforms.lightIntensities.push(gl.getUniformLocation(program, "u_lightIntensities[" + i + "]"));
      uniforms.lightRanges.push(gl.getUniformLocation(program, "u_lightRanges[" + i + "]"));
      uniforms.lightDecays.push(gl.getUniformLocation(program, "u_lightDecays[" + i + "]"));
      uniforms.lightAngles.push(gl.getUniformLocation(program, "u_lightAngles[" + i + "]"));
      uniforms.lightPenumbras.push(gl.getUniformLocation(program, "u_lightPenumbras[" + i + "]"));
      uniforms.lightGroundColors.push(gl.getUniformLocation(program, "u_lightGroundColors[" + i + "]"));
    }

    return uniforms;
  }

  function scenePBRCustomUniformName(name) {
    const value = typeof name === "string" ? name.trim() : "";
    return /^[A-Za-z_][A-Za-z0-9_]*$/.test(value) ? value : "";
  }

  function scenePBRCustomUniformDeclaration(name, value) {
    const uniformName = scenePBRCustomUniformName(name);
    if (!uniformName) {
      return "";
    }
    if (typeof value === "number" || typeof value === "boolean") {
      return "uniform float " + uniformName + ";";
    }
    if (Array.isArray(value) || (value && typeof value.length === "number")) {
      const len = Math.max(0, Math.floor(sceneNumber(value.length, 0)));
      if (len >= 4) return "uniform vec4 " + uniformName + ";";
      if (len === 3) return "uniform vec3 " + uniformName + ";";
      if (len === 2) return "uniform vec2 " + uniformName + ";";
    }
    return "";
  }

  function scenePBRCustomUniformDeclarations(uniforms) {
    if (!uniforms || typeof uniforms !== "object") {
      return "";
    }
    const lines = [];
    const names = Object.keys(uniforms).sort();
    for (var i = 0; i < names.length; i++) {
      const declaration = scenePBRCustomUniformDeclaration(names[i], uniforms[names[i]]);
      if (declaration) {
        lines.push(declaration);
      }
    }
    return lines.join("\n");
  }

  function scenePBRCustomHookSource(source, functionName, signature) {
    const body = typeof source === "string" ? source.trim() : "";
    if (!body) {
      return "";
    }
    if (body.indexOf(functionName) >= 0) {
      return body;
    }
    return "void " + functionName + signature + " {\n" + body + "\n}";
  }

  function scenePBRBuildCustomVertexSource(material) {
    const uniforms = scenePBRCustomUniformDeclarations(material && material.customUniforms);
    const custom = scenePBRCustomHookSource(
      material && material.customVertex,
      "gosxApplyCustomVertex",
      "(inout vec3 position, inout vec3 normal, inout vec2 uv)",
    );
    if (!uniforms && !custom) {
      return SCENE_PBR_VERTEX_SOURCE;
    }
    const hook = custom || "void gosxApplyCustomVertex(inout vec3 position, inout vec3 normal, inout vec2 uv) {}";
    return SCENE_PBR_VERTEX_SOURCE.replace(
      "void gosxApplyCustomVertex(inout vec3 position, inout vec3 normal, inout vec2 uv) {}",
      [uniforms, hook].filter(Boolean).join("\n\n"),
    );
  }

  function scenePBRBuildCustomFragmentSource(material) {
    const uniforms = scenePBRCustomUniformDeclarations(material && material.customUniforms);
    const custom = scenePBRCustomHookSource(
      material && material.customFragment,
      "gosxApplyCustomFragment",
      "(inout vec3 color, inout float opacity, vec3 normal, vec3 worldPosition, vec2 uv)",
    );
    if (!uniforms && !custom) {
      return SCENE_PBR_FRAGMENT_SOURCE;
    }
    const hook = custom || "void gosxApplyCustomFragment(inout vec3 color, inout float opacity, vec3 normal, vec3 worldPosition, vec2 uv) {}";
    const replacement = [uniforms, hook].filter(Boolean).join("\n\n");
    return SCENE_PBR_FRAGMENT_SOURCE.replace(
      "void gosxApplyCustomFragment(inout vec3 color, inout float opacity, vec3 normal, vec3 worldPosition, vec2 uv) {}",
      replacement,
    );
  }

  function scenePBRCustomUniformLocations(gl, program, values) {
    const out = {};
    if (!values || typeof values !== "object") {
      return out;
    }
    const names = Object.keys(values);
    for (var i = 0; i < names.length; i++) {
      const name = scenePBRCustomUniformName(names[i]);
      if (!name) {
        continue;
      }
      const location = gl.getUniformLocation(program, name);
      if (location) {
        out[name] = location;
      }
    }
    return out;
  }

  function scenePBRHasCustomHooks(material) {
    return Boolean(
      material &&
      normalizeSceneMaterialKind(material.kind) === "custom" &&
      (
        (typeof material.customVertex === "string" && material.customVertex.trim()) ||
        (typeof material.customFragment === "string" && material.customFragment.trim()) ||
        (material.customUniforms && typeof material.customUniforms === "object" && Object.keys(material.customUniforms).length > 0)
      )
    );
  }

  function createScenePBRProgram(gl) {
    const vertexShader = scenePBRCompileShader(gl, gl.VERTEX_SHADER, SCENE_PBR_VERTEX_SOURCE);
    if (!vertexShader) {
      return null;
    }
    const fragmentShader = scenePBRCompileShader(gl, gl.FRAGMENT_SHADER, SCENE_PBR_FRAGMENT_SOURCE);
    if (!fragmentShader) {
      gl.deleteShader(vertexShader);
      return null;
    }

    const program = scenePBRLinkProgram(gl, vertexShader, fragmentShader, "PBR shader");
    if (!program) return null;

    const attributes = {
      position: gl.getAttribLocation(program, "a_position"),
      normal: gl.getAttribLocation(program, "a_normal"),
      uv: gl.getAttribLocation(program, "a_uv"),
      tangent: gl.getAttribLocation(program, "a_tangent"),
    };

    const uniforms = scenePBRCacheBaseUniforms(gl, program);

    return {
      program: program,
      vertexShader: vertexShader,
      fragmentShader: fragmentShader,
      attributes: attributes,
      uniforms: uniforms,
    };
  }

  function createScenePBRCustomProgram(gl, material) {
    const vertexSource = scenePBRBuildCustomVertexSource(material);
    const fragmentSource = scenePBRBuildCustomFragmentSource(material);
    const vertexShader = scenePBRCompileShader(gl, gl.VERTEX_SHADER, vertexSource);
    if (!vertexShader) {
      return null;
    }
    const fragmentShader = scenePBRCompileShader(gl, gl.FRAGMENT_SHADER, fragmentSource);
    if (!fragmentShader) {
      gl.deleteShader(vertexShader);
      return null;
    }
    const program = scenePBRLinkProgram(gl, vertexShader, fragmentShader, "Custom PBR shader");
    if (!program) return null;
    const attributes = {
      position: gl.getAttribLocation(program, "a_position"),
      normal: gl.getAttribLocation(program, "a_normal"),
      uv: gl.getAttribLocation(program, "a_uv"),
      tangent: gl.getAttribLocation(program, "a_tangent"),
    };
    const uniforms = scenePBRCacheBaseUniforms(gl, program);
    uniforms.customUniforms = scenePBRCustomUniformLocations(gl, program, material && material.customUniforms);
    return {
      program: program,
      vertexShader: vertexShader,
      fragmentShader: fragmentShader,
      attributes: attributes,
      uniforms: uniforms,
    };
  }

  function createScenePBRSkinnedProgram(gl) {
    var vertexShader = scenePBRCompileShader(gl, gl.VERTEX_SHADER, SCENE_PBR_SKINNED_VERTEX_SOURCE);
    if (!vertexShader) return null;
    var fragmentShader = scenePBRCompileShader(gl, gl.FRAGMENT_SHADER, SCENE_PBR_FRAGMENT_SOURCE);
    if (!fragmentShader) {
      gl.deleteShader(vertexShader);
      return null;
    }

    var program = scenePBRLinkProgram(gl, vertexShader, fragmentShader, "Skinned PBR shader");
    if (!program) return null;

    var attributes = {
      position: gl.getAttribLocation(program, "a_position"),
      normal: gl.getAttribLocation(program, "a_normal"),
      uv: gl.getAttribLocation(program, "a_uv"),
      tangent: gl.getAttribLocation(program, "a_tangent"),
      joints: gl.getAttribLocation(program, "a_joints"),
      weights: gl.getAttribLocation(program, "a_weights"),
    };

    var uniforms = scenePBRCacheBaseUniforms(gl, program);
    uniforms.modelMatrix = gl.getUniformLocation(program, "u_modelMatrix");
    uniforms.hasSkin = gl.getUniformLocation(program, "u_hasSkin");
    uniforms.jointMatrices = gl.getUniformLocation(program, "u_jointMatrices[0]");

    return {
      program: program,
      vertexShader: vertexShader,
      fragmentShader: fragmentShader,
      attributes: attributes,
      uniforms: uniforms,
    };
  }

  function createScenePointsProgram(gl) {
    var vertexShader = scenePBRCompileShader(gl, gl.VERTEX_SHADER, SCENE_POINTS_VERTEX_SOURCE);
    if (!vertexShader) return null;
    var fragmentShader = scenePBRCompileShader(gl, gl.FRAGMENT_SHADER, SCENE_POINTS_FRAGMENT_SOURCE);
    if (!fragmentShader) {
      gl.deleteShader(vertexShader);
      return null;
    }

    var program = scenePBRLinkProgram(gl, vertexShader, fragmentShader, "Points shader");
    if (!program) return null;

    var attributes = {
      position: gl.getAttribLocation(program, "a_position"),
      size: gl.getAttribLocation(program, "a_size"),
      color: gl.getAttribLocation(program, "a_color"),
    };

    var uniforms = {
      viewMatrix: gl.getUniformLocation(program, "u_viewMatrix"),
      projectionMatrix: gl.getUniformLocation(program, "u_projectionMatrix"),
      modelMatrix: gl.getUniformLocation(program, "u_modelMatrix"),
      defaultSize: gl.getUniformLocation(program, "u_defaultSize"),
      defaultColor: gl.getUniformLocation(program, "u_defaultColor"),
      hasPerVertexColor: gl.getUniformLocation(program, "u_hasPerVertexColor"),
      hasPerVertexSize: gl.getUniformLocation(program, "u_hasPerVertexSize"),
      sizeAttenuation: gl.getUniformLocation(program, "u_sizeAttenuation"),
      pointStyle: gl.getUniformLocation(program, "u_pointStyle"),
      viewportHeight: gl.getUniformLocation(program, "u_viewportHeight"),
      opacity: gl.getUniformLocation(program, "u_opacity"),
      hasFog: gl.getUniformLocation(program, "u_hasFog"),
      fogDensity: gl.getUniformLocation(program, "u_fogDensity"),
      fogColor: gl.getUniformLocation(program, "u_fogColor"),
    };

    return {
      program: program,
      vertexShader: vertexShader,
      fragmentShader: fragmentShader,
      attributes: attributes,
      uniforms: uniforms,
    };
  }

  function createScenePBRInstancedProgram(gl) {
    var vertexShader = scenePBRCompileShader(gl, gl.VERTEX_SHADER, SCENE_PBR_INSTANCED_VERTEX_SOURCE);
    if (!vertexShader) return null;
    var fragmentShader = scenePBRCompileShader(gl, gl.FRAGMENT_SHADER, SCENE_PBR_FRAGMENT_SOURCE);
    if (!fragmentShader) {
      gl.deleteShader(vertexShader);
      return null;
    }

    var program = scenePBRLinkProgram(gl, vertexShader, fragmentShader, "Instanced PBR shader");
    if (!program) return null;

    var attributes = {
      position: gl.getAttribLocation(program, "a_position"),
      normal: gl.getAttribLocation(program, "a_normal"),
      uv: gl.getAttribLocation(program, "a_uv"),
      tangent: gl.getAttribLocation(program, "a_tangent"),
      instanceMatrix: gl.getAttribLocation(program, "a_instanceMatrix"),
      instanceColor: gl.getAttribLocation(program, "a_instanceColor"),
    };

    var uniforms = scenePBRCacheBaseUniforms(gl, program);
    uniforms.hasInstanceColor = gl.getUniformLocation(program, "u_hasInstanceColor");

    return {
      program: program,
      vertexShader: vertexShader,
      fragmentShader: fragmentShader,
      attributes: attributes,
      uniforms: uniforms,
    };
  }

  function generateInstancedGeometry(kind, dims) {
    var w = sceneNumber(dims && dims.width, 1);
    var h = sceneNumber(dims && dims.height, 1);
    var d = sceneNumber(dims && dims.depth, 1);

    if (kind === "sphere") {
      return generateInstancedSphereGeometry(
        sceneNumber(dims && dims.radius, 0.5),
        sceneNumber(dims && dims.segments, 16)
      );
    }
    if (kind === "plane") {
      return generateInstancedPlaneGeometry(w, d);
    }

    return generateInstancedBoxGeometry(w, h, d);
  }

  function generateInstancedBoxGeometry(w, h, d) {
    var hw = w * 0.5, hh = h * 0.5, hd = d * 0.5;

    var faces = [
      { n: [0, 0, 1], t: [1, 0, 0, 1], v: [[-hw,-hh,hd],[hw,-hh,hd],[hw,hh,hd],[-hw,hh,hd]] },
      { n: [0, 0,-1], t: [-1, 0, 0, 1], v: [[hw,-hh,-hd],[-hw,-hh,-hd],[-hw,hh,-hd],[hw,hh,-hd]] },
      { n: [1, 0, 0], t: [0, 0,-1, 1], v: [[hw,-hh,hd],[hw,-hh,-hd],[hw,hh,-hd],[hw,hh,hd]] },
      { n: [-1, 0, 0], t: [0, 0, 1, 1], v: [[-hw,-hh,-hd],[-hw,-hh,hd],[-hw,hh,hd],[-hw,hh,-hd]] },
      { n: [0, 1, 0], t: [1, 0, 0, 1], v: [[-hw,hh,hd],[hw,hh,hd],[hw,hh,-hd],[-hw,hh,-hd]] },
      { n: [0,-1, 0], t: [1, 0, 0, 1], v: [[-hw,-hh,-hd],[hw,-hh,-hd],[hw,-hh,hd],[-hw,-hh,hd]] },
    ];

    var quadUVs = [[0,0],[1,0],[1,1],[0,1]];
    var triIndices = [0,1,2, 0,2,3];

    var vertexCount = 36;
    var positions = new Float32Array(vertexCount * 3);
    var normals = new Float32Array(vertexCount * 3);
    var uvs = new Float32Array(vertexCount * 2);
    var tangents = new Float32Array(vertexCount * 4);

    var vi = 0;
    for (var fi = 0; fi < 6; fi++) {
      var face = faces[fi];
      for (var ti = 0; ti < 6; ti++) {
        var ci = triIndices[ti];
        var p = face.v[ci];
        positions[vi * 3]     = p[0];
        positions[vi * 3 + 1] = p[1];
        positions[vi * 3 + 2] = p[2];
        normals[vi * 3]     = face.n[0];
        normals[vi * 3 + 1] = face.n[1];
        normals[vi * 3 + 2] = face.n[2];
        uvs[vi * 2]     = quadUVs[ci][0];
        uvs[vi * 2 + 1] = quadUVs[ci][1];
        tangents[vi * 4]     = face.t[0];
        tangents[vi * 4 + 1] = face.t[1];
        tangents[vi * 4 + 2] = face.t[2];
        tangents[vi * 4 + 3] = face.t[3];
        vi++;
      }
    }

    return { positions: positions, normals: normals, uvs: uvs, tangents: tangents, vertexCount: vertexCount };
  }

  function generateInstancedPlaneGeometry(w, d) {
    var hw = w * 0.5, hd = d * 0.5;
    var vertexCount = 6;
    var positions = new Float32Array(vertexCount * 3);
    var normals = new Float32Array(vertexCount * 3);
    var uvs = new Float32Array(vertexCount * 2);
    var tangents = new Float32Array(vertexCount * 4);

    var corners = [[-hw, 0, hd], [hw, 0, hd], [hw, 0, -hd], [-hw, 0, -hd]];
    var cornerUVs = [[0, 0], [1, 0], [1, 1], [0, 1]];
    var triIndices = [0, 1, 2, 0, 2, 3];

    for (var i = 0; i < 6; i++) {
      var ci = triIndices[i];
      var p = corners[ci];
      positions[i * 3] = p[0]; positions[i * 3 + 1] = p[1]; positions[i * 3 + 2] = p[2];
      normals[i * 3] = 0; normals[i * 3 + 1] = 1; normals[i * 3 + 2] = 0;
      uvs[i * 2] = cornerUVs[ci][0]; uvs[i * 2 + 1] = cornerUVs[ci][1];
      tangents[i * 4] = 1; tangents[i * 4 + 1] = 0; tangents[i * 4 + 2] = 0; tangents[i * 4 + 3] = 1;
    }

    return { positions: positions, normals: normals, uvs: uvs, tangents: tangents, vertexCount: vertexCount };
  }

  function generateInstancedSphereGeometry(radius, segments) {
    var rings = Math.max(4, segments);
    var slices = Math.max(4, segments * 2);

    var vertexCount = rings * slices * 6;
    var positions = new Float32Array(vertexCount * 3);
    var normals = new Float32Array(vertexCount * 3);
    var uvs = new Float32Array(vertexCount * 2);
    var tangents = new Float32Array(vertexCount * 4);
    var vi = 0;

    function spherePoint(ring, slice) {
      var phi = (ring / rings) * Math.PI;
      var theta = (slice / slices) * Math.PI * 2;
      var sp = Math.sin(phi);
      var nx = sp * Math.cos(theta);
      var ny = Math.cos(phi);
      var nz = sp * Math.sin(theta);
      return {
        px: nx * radius, py: ny * radius, pz: nz * radius,
        nx: nx, ny: ny, nz: nz,
        u: slice / slices, v: ring / rings,
        tx: -Math.sin(theta), ty: 0, tz: Math.cos(theta),
      };
    }

    function pushVert(pt) {
      positions[vi * 3] = pt.px; positions[vi * 3 + 1] = pt.py; positions[vi * 3 + 2] = pt.pz;
      normals[vi * 3] = pt.nx; normals[vi * 3 + 1] = pt.ny; normals[vi * 3 + 2] = pt.nz;
      uvs[vi * 2] = pt.u; uvs[vi * 2 + 1] = pt.v;
      tangents[vi * 4] = pt.tx; tangents[vi * 4 + 1] = pt.ty; tangents[vi * 4 + 2] = pt.tz; tangents[vi * 4 + 3] = 1;
      vi++;
    }

    for (var r = 0; r < rings; r++) {
      for (var s = 0; s < slices; s++) {
        var a = spherePoint(r, s);
        var b = spherePoint(r, s + 1);
        var c = spherePoint(r + 1, s + 1);
        var dd = spherePoint(r + 1, s);
        pushVert(a); pushVert(b); pushVert(c);
        pushVert(a); pushVert(c); pushVert(dd);
      }
    }

    return { positions: positions, normals: normals, uvs: uvs, tangents: tangents, vertexCount: vi };
  }

  function scenePBRCompileShader(gl, type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      const label = type === gl.VERTEX_SHADER ? "vertex" : "fragment";
      console.warn("[gosx] PBR " + label + " shader compile failed:", gl.getShaderInfoLog(shader));
      gl.deleteShader(shader);
      return null;
    }
    return shader;
  }

  function scenePBRLinkProgram(gl, vertexShader, fragmentShader, label) {
    var program = gl.createProgram();
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      console.warn("[gosx] " + label + " program link failed:", gl.getProgramInfoLog(program));
      gl.deleteProgram(program);
      gl.deleteShader(vertexShader);
      gl.deleteShader(fragmentShader);
      return null;
    }
    return program;
  }

  var _scenePBRLightsHashBuf = new ArrayBuffer(4);
  var _scenePBRLightsHashFloat = new Float32Array(_scenePBRLightsHashBuf);
  var _scenePBRLightsHashInt = new Uint32Array(_scenePBRLightsHashBuf);

  function scenePBRLightsHashNumber(h, n) {
    _scenePBRLightsHashFloat[0] = (typeof n === "number" && n === n) ? n : 0;
    return Math.imul((h ^ _scenePBRLightsHashInt[0]) >>> 0, 16777619) >>> 0;
  }

  function scenePBRLightsHashString(h, s) {
    var str = (typeof s === "string") ? s : "";
    var len = str.length;
    for (var i = 0; i < len; i++) {
      h = Math.imul((h ^ str.charCodeAt(i)) >>> 0, 16777619) >>> 0;
    }
    return Math.imul((h ^ (len + 1)) >>> 0, 16777619) >>> 0;
  }

  function hashLightContent(l) {
    if (!l) return 0;
    var h = 2166136261;
    h = scenePBRLightsHashString(h, l.kind);
    h = scenePBRLightsHashNumber(h, sceneNumber(l.x, 0));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.y, 0));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.z, 0));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.directionX, 0));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.directionY, -1));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.directionZ, 0));
    h = scenePBRLightsHashString(h, l.color);
    h = scenePBRLightsHashNumber(h, sceneNumber(l.intensity, 1));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.range, 0));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.decay, 2));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.angle, 0));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.penumbra, 0));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.width, 0));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.height, 0));
    h = scenePBRLightsHashString(h, l.groundColor);
    h = scenePBRLightsHashNumber(h, sceneNumber(l.shadowBias, 0));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.shadowSize, 0));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.shadowCascades, 0));
    h = scenePBRLightsHashNumber(h, sceneNumber(l.shadowSoftness, 0));
    return h;
  }

  function hashEnvironmentContent(env) {
    if (!env) return 0;
    var h = 2166136261;
    h = scenePBRLightsHashString(h, env.ambientColor);
    h = scenePBRLightsHashNumber(h, sceneNumber(env.ambientIntensity, 0));
    h = scenePBRLightsHashString(h, env.skyColor);
    h = scenePBRLightsHashNumber(h, sceneNumber(env.skyIntensity, 0));
    h = scenePBRLightsHashString(h, env.groundColor);
    h = scenePBRLightsHashNumber(h, sceneNumber(env.groundIntensity, 0));
    h = scenePBRLightsHashString(h, env.envMap);
    h = scenePBRLightsHashNumber(h, sceneNumber(env.envIntensity, 1));
    h = scenePBRLightsHashNumber(h, sceneNumber(env.envRotation, 0));
    h = scenePBRLightsHashNumber(h, sceneNumber(env.fogDensity, 0));
    h = scenePBRLightsHashString(h, env.fogColor);
    return h;
  }

  function scenePBRLightsHash(lights, environment) {
    var h = 2166136261;
    var lightArray = Array.isArray(lights) ? lights : [];
    var count = Math.min(lightArray.length, 8);
    h = Math.imul((h ^ count) >>> 0, 16777619) >>> 0;
    for (var i = 0; i < count; i++) {
      var l = lightArray[i];
      var sub = (l && typeof l._lightHash === "number") ? l._lightHash : hashLightContent(l);
      h = Math.imul((h ^ (sub >>> 0)) >>> 0, 16777619) >>> 0;
    }
    var envSub = (environment && typeof environment._envHash === "number")
      ? environment._envHash
      : hashEnvironmentContent(environment);
    h = Math.imul((h ^ (envSub >>> 0)) >>> 0, 16777619) >>> 0;
    return h;
  }

  function scenePBRUploadLights(gl, uniforms, lights, environment, precomputedHash) {
    const contentHash = (typeof precomputedHash === "number")
      ? precomputedHash
      : scenePBRLightsHash(lights, environment);
    if (uniforms._lastLightsHash === contentHash) {
      return;
    }
    uniforms._lastLightsHash = contentHash;

    const lightArray = Array.isArray(lights) ? lights : [];
    const count = Math.min(lightArray.length, 8);

    var colorCache = {};

    gl.uniform1i(uniforms.lightCount, count);

    for (var i = 0; i < count; i++) {
      const light = lightArray[i];
      const kind = typeof light.kind === "string" ? light.kind.toLowerCase() : "";

      var lightType = 2; // default: point
      if (kind === "ambient") {
        lightType = 0;
      } else if (kind === "directional") {
        lightType = 1;
      } else if (kind === "spot") {
        lightType = 3;
      } else if (kind === "hemisphere") {
        lightType = 4;
      } else if (kind === "rect-area") {
        lightType = 2;
      } else if (kind === "light-probe") {
        lightType = 0;
      }

      gl.uniform1i(uniforms.lightTypes[i], lightType);
      gl.uniform3f(
        uniforms.lightPositions[i],
        sceneNumber(light.x, 0),
        sceneNumber(light.y, 0),
        sceneNumber(light.z, 0)
      );
      gl.uniform3f(
        uniforms.lightDirections[i],
        sceneNumber(light.directionX, 0),
        sceneNumber(light.directionY, -1),
        sceneNumber(light.directionZ, 0)
      );

      var colorKey = light.color;
      var lightColorRGBA = typeof colorKey === "string" && colorCache[colorKey];
      if (!lightColorRGBA) {
        lightColorRGBA = sceneColorRGBA(light.color, [1, 1, 1, 1]);
        if (typeof colorKey === "string") colorCache[colorKey] = lightColorRGBA;
      }
      gl.uniform3f(uniforms.lightColors[i], lightColorRGBA[0], lightColorRGBA[1], lightColorRGBA[2]);
      gl.uniform1f(uniforms.lightIntensities[i], sceneNumber(light.intensity, 1));
      gl.uniform1f(uniforms.lightRanges[i], sceneNumber(light.range, 0));
      gl.uniform1f(uniforms.lightDecays[i], sceneNumber(light.decay, 2));
      gl.uniform1f(uniforms.lightAngles[i], sceneNumber(light.angle, 0));
      gl.uniform1f(uniforms.lightPenumbras[i], sceneNumber(light.penumbra, 0));

      var gcKey = light.groundColor;
      var gcRGBA = typeof gcKey === "string" && colorCache[gcKey];
      if (!gcRGBA) {
        gcRGBA = sceneColorRGBA(light.groundColor, [0, 0, 0, 1]);
        if (typeof gcKey === "string") colorCache[gcKey] = gcRGBA;
      }
      gl.uniform3f(uniforms.lightGroundColors[i], gcRGBA[0], gcRGBA[1], gcRGBA[2]);
    }

    for (var j = count; j < 8; j++) {
      gl.uniform1i(uniforms.lightTypes[j], 0);
      gl.uniform3f(uniforms.lightPositions[j], 0, 0, 0);
      gl.uniform3f(uniforms.lightDirections[j], 0, -1, 0);
      gl.uniform3f(uniforms.lightColors[j], 0, 0, 0);
      gl.uniform1f(uniforms.lightIntensities[j], 0);
      gl.uniform1f(uniforms.lightRanges[j], 0);
      gl.uniform1f(uniforms.lightDecays[j], 2);
      gl.uniform1f(uniforms.lightAngles[j], 0);
      gl.uniform1f(uniforms.lightPenumbras[j], 0);
      gl.uniform3f(uniforms.lightGroundColors[j], 0, 0, 0);
    }

    const env = environment || {};
    var ambientKey = env.ambientColor;
    var ambientColorRGBA = typeof ambientKey === "string" && colorCache[ambientKey];
    if (!ambientColorRGBA) {
      ambientColorRGBA = sceneColorRGBA(env.ambientColor, [1, 1, 1, 1]);
      if (typeof ambientKey === "string") colorCache[ambientKey] = ambientColorRGBA;
    }
    gl.uniform3f(uniforms.ambientColor, ambientColorRGBA[0], ambientColorRGBA[1], ambientColorRGBA[2]);
    gl.uniform1f(uniforms.ambientIntensity, sceneNumber(env.ambientIntensity, 0));

    var skyKey = env.skyColor;
    var skyColorRGBA = typeof skyKey === "string" && colorCache[skyKey];
    if (!skyColorRGBA) {
      skyColorRGBA = sceneColorRGBA(env.skyColor, [0.88, 0.94, 1, 1]);
      if (typeof skyKey === "string") colorCache[skyKey] = skyColorRGBA;
    }
    gl.uniform3f(uniforms.skyColor, skyColorRGBA[0], skyColorRGBA[1], skyColorRGBA[2]);
    gl.uniform1f(uniforms.skyIntensity, sceneNumber(env.skyIntensity, 0));

    var groundKey = env.groundColor;
    var groundColorRGBA = typeof groundKey === "string" && colorCache[groundKey];
    if (!groundColorRGBA) {
      groundColorRGBA = sceneColorRGBA(env.groundColor, [0.12, 0.16, 0.22, 1]);
      if (typeof groundKey === "string") colorCache[groundKey] = groundColorRGBA;
    }
    gl.uniform3f(uniforms.groundColor, groundColorRGBA[0], groundColorRGBA[1], groundColorRGBA[2]);
    gl.uniform1f(uniforms.groundIntensity, sceneNumber(env.groundIntensity, 0));

    var fogDensity = sceneNumber(env.fogDensity, 0);
    gl.uniform1i(uniforms.hasFog, fogDensity > 0 ? 1 : 0);
    gl.uniform1f(uniforms.fogDensity, fogDensity);
    var fogKey = env.fogColor;
    var fogColorRGBA = typeof fogKey === "string" && colorCache[fogKey];
    if (!fogColorRGBA) {
      fogColorRGBA = sceneColorRGBA(env.fogColor, [0.5, 0.5, 0.5, 1]);
      if (typeof fogKey === "string") colorCache[fogKey] = fogColorRGBA;
    }
    gl.uniform3f(uniforms.fogColor, fogColorRGBA[0], fogColorRGBA[1], fogColorRGBA[2]);
  }

  function sceneToneMapMode(str) {
    if (typeof str === "string") {
      var s = str.toLowerCase();
      if (s === "linear") return 0;
      if (s === "reinhard") return 2;
    }
    return 1; // default: ACES
  }

  function scenePBRUploadExposure(gl, uniforms, environment, usePostProcessing) {
    var env = environment || {};
    var exposure = sceneNumber(env.exposure, 0);
    if (exposure <= 0) exposure = 1.0;
    var toneMapMode = usePostProcessing ? 0 : sceneToneMapMode(env.toneMapping);
    if (uniforms._lastExposure === exposure && uniforms._lastToneMapMode === toneMapMode) {
      return;
    }
    uniforms._lastExposure = exposure;
    uniforms._lastToneMapMode = toneMapMode;
    gl.uniform1f(uniforms.exposure, exposure);
    gl.uniform1i(uniforms.toneMapMode, toneMapMode);
  }

  var _scenePBRCascadeMatScratch = new Float32Array(64);
  var _scenePBRCascadeSplitScratch = new Float32Array(4);

  function scenePBREnvironmentHasMap(environment) {
    return Boolean(environment && typeof environment.envMap === "string" && environment.envMap.trim());
  }

  function scenePBRSlotCascadeCount(slot, lightIndex) {
    if (!slot || lightIndex < 0) {
      return 0;
    }
    return Math.max(1, Math.min(4, slot.numCascades | 0));
  }

  function scenePBRShadowTextureCount(shadowSlots, shadowLightIndices) {
    var slots = Array.isArray(shadowSlots) ? shadowSlots : [];
    var indices = Array.isArray(shadowLightIndices) ? shadowLightIndices : [];
    var count = 0;
    for (var i = 0; i < slots.length; i++) {
      count += scenePBRSlotCascadeCount(slots[i], indices[i]);
    }
    return count;
  }

  function scenePBRTextureLayoutForFrame(shadowSlots, shadowLightIndices, environment) {
    var shadowCount = scenePBRShadowTextureCount(shadowSlots, shadowLightIndices);
    if (scenePBREnvironmentHasMap(environment)) {
      shadowCount = Math.max(2, shadowCount);
    }
    return sceneAllocateTextureUnits({
      shadowCount: shadowCount,
      ibl: scenePBREnvironmentHasMap(environment),
    });
  }

  function scenePBRUploadShadowUniforms(gl, uniforms, shadowSlots, shadowLightIndices, lights, environment) {
    var lightArray = Array.isArray(lights) ? lights : [];
    var layout = scenePBRTextureLayoutForFrame(shadowSlots, shadowLightIndices, environment);
    var shadowUnits = layout.shadows;

    var unitBase = 0;
    uploadCascadedSlot(gl, uniforms, 0, shadowSlots[0], shadowLightIndices[0],
      lightArray, shadowUnits, unitBase);
    unitBase += scenePBRSlotCascadeCount(shadowSlots[0], shadowLightIndices[0]);
    uploadCascadedSlot(gl, uniforms, 1, shadowSlots[1], shadowLightIndices[1],
      lightArray, shadowUnits, unitBase);
  }

  function uploadCascadedSlot(gl, uniforms, slotIndex, slot, lightIndex, lightArray, shadowUnits, unitBase) {
    var samplerKeys = slotIndex === 0
      ? ["shadowMap0_0", "shadowMap0_1", "shadowMap0_2", "shadowMap0_3"]
      : ["shadowMap1_0", "shadowMap1_1", "shadowMap1_2", "shadowMap1_3"];
    var matricesKey = slotIndex === 0 ? "lightSpaceMatrices0" : "lightSpaceMatrices1";
    var splitsKey = slotIndex === 0 ? "shadowCascadeSplits0" : "shadowCascadeSplits1";
    var cascadesKey = slotIndex === 0 ? "shadowCascades0" : "shadowCascades1";
    var hasKey = slotIndex === 0 ? "hasShadow0" : "hasShadow1";
    var biasKey = slotIndex === 0 ? "shadowBias0" : "shadowBias1";
    var softKey = slotIndex === 0 ? "shadowSoftness0" : "shadowSoftness1";
    var indexKey = slotIndex === 0 ? "shadowLightIndex0" : "shadowLightIndex1";
    var base = Math.max(0, unitBase | 0);

    if (!slot || lightIndex < 0) {
      gl.uniform1i(uniforms[hasKey], 0);
      gl.uniform1f(uniforms[softKey], 0);
      gl.uniform1i(uniforms[indexKey], -1);
      gl.uniform1i(uniforms[cascadesKey], 1);
      return;
    }

    var light = lightArray[lightIndex] || {};
    var numCascades = Math.max(1, Math.min(4, slot.numCascades | 0));

    for (var ci = 0; ci < 4; ci++) {
      var effectiveCascade = ci < numCascades ? slot.cascades[ci] : slot.cascades[0];
      var unit = shadowUnits[base + ci];
      if (unit == null) unit = shadowUnits[base] || shadowUnits[0] || null;
      if (unit == null) continue;
      scenePBRBindTexture(gl, unit, effectiveCascade.depthTexture);
      gl.uniform1i(uniforms[samplerKeys[ci]], unit);
    }

    for (var mi = 0; mi < 4; mi++) {
      var src = (mi < numCascades ? slot.cascades[mi] : slot.cascades[0]).lightMatrix;
      for (var k = 0; k < 16; k++) {
        _scenePBRCascadeMatScratch[mi * 16 + k] = src ? src[k] : 0;
      }
    }
    for (var si = 0; si < 4; si++) {
      _scenePBRCascadeSplitScratch[si] = si < numCascades
        ? (slot.cascades[si].splitFar || 0)
        : Infinity;
    }

    gl.uniformMatrix4fv(uniforms[matricesKey], false, _scenePBRCascadeMatScratch);
    gl.uniform1fv(uniforms[splitsKey], _scenePBRCascadeSplitScratch);
    gl.uniform1i(uniforms[cascadesKey], numCascades);
    gl.uniform1i(uniforms[hasKey], 1);
    gl.uniform1f(uniforms[biasKey], sceneNumber(light.shadowBias, 0.005));
    gl.uniform1f(uniforms[softKey], Math.max(0, sceneNumber(light.shadowSoftness, 0)));
    gl.uniform1i(uniforms[indexKey], lightIndex);
  }

  function scenePBRUploadEnvironmentMap(gl, uniforms, environment, textureCache, shadowSlots, shadowLightIndices) {
    var env = environment || {};
    var envMap = typeof env.envMap === "string" ? env.envMap.trim() : "";
    if (!envMap) {
      gl.uniform1i(uniforms.hasEnvMap, 0);
      gl.uniform1f(uniforms.envIntensity, 0);
      gl.uniform1f(uniforms.envRotation, 0);
      return;
    }

    var layout = scenePBRTextureLayoutForFrame(shadowSlots, shadowLightIndices, env);
    var unit = layout && layout.ibl ? layout.ibl.irradiance : null;
    var record = scenePBRLoadTexture(gl, envMap, textureCache);
    var available = Boolean(record && record.texture && !record.failed);
    gl.uniform1i(uniforms.hasEnvMap, available ? 1 : 0);
    var envIntensity = Object.prototype.hasOwnProperty.call(env, "envIntensity")
      ? sceneNumber(env.envIntensity, 1)
      : 1;
    gl.uniform1f(uniforms.envIntensity, Math.max(0, envIntensity));
    gl.uniform1f(uniforms.envRotation, sceneNumber(env.envRotation, 0));
    if (available && unit != null) {
      scenePBRBindTexture(gl, unit, record.texture);
      gl.uniform1i(uniforms.envMap, unit);
    }
  }

  function createScenePBRRenderer(gl, canvas) {
    const pbrProgram = createScenePBRProgram(gl);
    if (!pbrProgram) {
      return null;
    }

    const program = pbrProgram.program;
    const attribs = pbrProgram.attributes;
    const uniforms = pbrProgram.uniforms;
    const lineProgram = typeof createSceneWebGLProgram === "function" ? createSceneWebGLProgram(gl) : null;
    const lineResources = lineProgram && typeof createSceneWebGLResources === "function"
      ? createSceneWebGLResources(gl, lineProgram, null)
      : null;

	    var skinnedProgram = null;
	    var skinnedProgramFailed = false;
    var customProgramCache = new Map();

    const shadowProgram = createSceneShadowProgram(gl);

    var shadowSlots = [null, null];

    var postProcessor = null;

    var shadowLightIndices = [-1, -1];

    const positionBuffer = gl.createBuffer();
    const normalBuffer = gl.createBuffer();
    const uvBuffer = gl.createBuffer();
    const tangentBuffer = gl.createBuffer();
    const jointsBuffer = gl.createBuffer();
    const weightsBuffer = gl.createBuffer();

    var pointsProgram = null;

    const staticMeshArrayVBOs = new WeakMap();
    const pointsEntryBuffers = new Set();
    const staticPointEntries = new Set();
    const activeStaticPointEntries = new Set();
    const staticPointKeyedVBOs = new Map();
    const activeStaticPointKeys = new Set();
    var computeParticleSystems = new Map();
    var lastComputeParticleTimeSeconds = null;
    var lastPreparedScene = null;

    function ensureStaticArrayVBO(cache, typedArray) {
      return sceneCachedBuffer(cache, typedArray, function() {
        var buf = gl.createBuffer();
        pointsEntryBuffers.add(buf);
        return buf;
      }, function(buf, data) {
        gl.bindBuffer(gl.ARRAY_BUFFER, buf);
        gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
      });
    }

    function releaseEntryBufferSlot(entry, bufferSlot, keySlot) {
      if (!entry) return;
      var buf = entry[bufferSlot];
      if (buf) {
        gl.deleteBuffer(buf);
        pointsEntryBuffers.delete(buf);
        entry[bufferSlot] = null;
      }
      if (keySlot) {
        entry[keySlot] = null;
      }
    }

    function releaseStaticPointEntryBuffers(entry) {
      if (!entry) return;
      releaseEntryBufferSlot(entry, "_vboPos", "_vboPosSource");
      releaseEntryBufferSlot(entry, "_vboSizes", "_vboSizesSource");
      releaseEntryBufferSlot(entry, "_vboColors", "_vboColorsSource");
      staticPointEntries.delete(entry);
    }

    function staticPointVBOKey(entry, bufferSlot) {
      var id = entry && typeof entry.id === "string" ? entry.id.trim() : "";
      return id ? id + ":" + String(bufferSlot || "") : "";
    }

    function staticPointSourceToken(entry, keySlot, typedArray) {
      if (!entry) return typedArray;
      if (keySlot === "_vboPosSource" && entry.positions) return entry.positions;
      if (keySlot === "_vboSizesSource" && entry.sizes) return entry.sizes;
      if (keySlot === "_vboColorsSource" && entry.colors) return entry.colors;
      return typedArray;
    }

    function releaseStaticPointKeyedBuffer(key, record) {
      if (record && record.buffer) {
        gl.deleteBuffer(record.buffer);
        pointsEntryBuffers.delete(record.buffer);
      }
      if (key) {
        staticPointKeyedVBOs.delete(key);
      }
    }

    function ensureKeyedStaticPointVBO(entry, bufferSlot, keySlot, typedArray) {
      var key = staticPointVBOKey(entry, bufferSlot);
      if (!key) return null;
      activeStaticPointKeys.add(key);
      var source = staticPointSourceToken(entry, keySlot, typedArray);
      var byteLength = typedArray && Number.isFinite(typedArray.byteLength) ? typedArray.byteLength : 0;
      var record = staticPointKeyedVBOs.get(key);
      if (
        !record ||
        !record.buffer ||
        record.source !== source ||
        record.byteLength !== byteLength
      ) {
        releaseStaticPointKeyedBuffer(key, record);
        var buf = gl.createBuffer();
        pointsEntryBuffers.add(buf);
        gl.bindBuffer(gl.ARRAY_BUFFER, buf);
        gl.bufferData(gl.ARRAY_BUFFER, typedArray, gl.STATIC_DRAW);
        record = {
          buffer: buf,
          source: source,
          byteLength: byteLength,
        };
        staticPointKeyedVBOs.set(key, record);
      }
      return record.buffer;
    }

    function ensureStaticPointVBO(entry, bufferSlot, keySlot, typedArray) {
      if (!entry || !typedArray) return null;
      var keyed = ensureKeyedStaticPointVBO(entry, bufferSlot, keySlot, typedArray);
      if (keyed) return keyed;
      staticPointEntries.add(entry);
      activeStaticPointEntries.add(entry);
      if (entry[keySlot] !== typedArray || !entry[bufferSlot]) {
        releaseEntryBufferSlot(entry, bufferSlot, keySlot);
        var buf = gl.createBuffer();
        pointsEntryBuffers.add(buf);
        gl.bindBuffer(gl.ARRAY_BUFFER, buf);
        gl.bufferData(gl.ARRAY_BUFFER, typedArray, gl.STATIC_DRAW);
        entry[bufferSlot] = buf;
        entry[keySlot] = typedArray;
      }
      return entry[bufferSlot];
    }

    function releaseInactiveStaticPointBuffers() {
      for (const entry of Array.from(staticPointEntries)) {
        if (!activeStaticPointEntries.has(entry)) {
          releaseStaticPointEntryBuffers(entry);
        }
      }
      activeStaticPointEntries.clear();
      for (const key of Array.from(staticPointKeyedVBOs.keys())) {
        if (!activeStaticPointKeys.has(key)) {
          releaseStaticPointKeyedBuffer(key, staticPointKeyedVBOs.get(key));
        }
      }
      activeStaticPointKeys.clear();
    }

    function ensureDynamicPointsVBO(entry, slot, typedArray) {
      return sceneCachedBuffer(entry, typedArray, function() {
        var buf = gl.createBuffer();
        pointsEntryBuffers.add(buf);
        return buf;
      }, function(buf, data, state) {
        gl.bindBuffer(gl.ARRAY_BUFFER, buf);
        if (!state || state.bytesChanged) {
          gl.bufferData(gl.ARRAY_BUFFER, data, gl.DYNAMIC_DRAW);
        } else {
          gl.bufferSubData(gl.ARRAY_BUFFER, 0, data);
        }
      }, { slot: slot, dynamic: true });
    }

	    var instancedProgram = null;
	    var instancedProgramFailed = false;

    var instancedGeometryCache = {};

    const textureCache = new Map();

    var shadowState = { buffer: gl.createBuffer(), scratch: null };

	    var scratchViewMatrix = new Float32Array(16);
	    var scratchProjMatrix = new Float32Array(16);
	    var identityModelMatrix = new Float32Array([
	      1, 0, 0, 0,
	      0, 1, 0, 0,
	      0, 0, 1, 0,
	      0, 0, 0, 1,
	    ]);

    var _frameCam = {
      x: 0, y: 0, z: 0,
      rotationX: 0, rotationY: 0, rotationZ: 0,
      fov: 0, near: 0, far: 0,
    };
    var _frameLightsHash = 0;

    var scratchPositions = null;
    var scratchNormals = null;
    var scratchUVs = null;
    var scratchTangents = null;

    function ensureScratch(name, length) {
      if (name === "positions") {
        if (!scratchPositions || scratchPositions.length < length) {
          scratchPositions = new Float32Array(length);
        }
        return scratchPositions;
      }
      if (name === "normals") {
        if (!scratchNormals || scratchNormals.length < length) {
          scratchNormals = new Float32Array(length);
        }
        return scratchNormals;
      }
      if (name === "uvs") {
        if (!scratchUVs || scratchUVs.length < length) {
          scratchUVs = new Float32Array(length);
        }
        return scratchUVs;
      }
      if (name === "tangents") {
        if (!scratchTangents || scratchTangents.length < length) {
          scratchTangents = new Float32Array(length);
        }
        return scratchTangents;
      }
      return new Float32Array(length);
    }

    function sliceToFloat32(source, offset, count, stride, scratchName) {
      const length = count * stride;
      const start = offset * stride;
      const buf = ensureScratch(scratchName, length);
      for (var i = 0; i < length; i++) {
        buf[i] = source && source[start + i] !== undefined ? +source[start + i] : 0;
      }
      return buf.subarray(0, length);
    }

    function uploadCustomUniforms(gl, uniforms, values) {
      const locations = uniforms && uniforms.customUniforms;
      if (!locations || !values || typeof values !== "object") {
        return;
      }
      const names = Object.keys(locations);
      for (var i = 0; i < names.length; i++) {
        const name = names[i];
        const loc = locations[name];
        if (!loc) {
          continue;
        }
        const value = values[name];
        if (typeof value === "number" || typeof value === "boolean") {
          gl.uniform1f(loc, sceneNumber(value, 0));
        } else if ((Array.isArray(value) || (value && typeof value.length === "number")) && value.length >= 4) {
          gl.uniform4f(loc, sceneNumber(value[0], 0), sceneNumber(value[1], 0), sceneNumber(value[2], 0), sceneNumber(value[3], 0));
        } else if ((Array.isArray(value) || (value && typeof value.length === "number")) && value.length === 3) {
          gl.uniform3f(loc, sceneNumber(value[0], 0), sceneNumber(value[1], 0), sceneNumber(value[2], 0));
        } else if ((Array.isArray(value) || (value && typeof value.length === "number")) && value.length === 2) {
          gl.uniform2f(loc, sceneNumber(value[0], 0), sceneNumber(value[1], 0));
        }
      }
    }

    function uploadMaterial(gl, uniforms, material, textureCache) {
      const mat = material || {};
      if (uniforms._lastMaterial === material) {
        uploadCustomUniforms(gl, uniforms, mat.customUniforms);
        return;
      }
      uniforms._lastMaterial = material;
      const albedoRGBA = sceneColorRGBA(mat.color, [0.8, 0.8, 0.8, 1]);
      gl.uniform3f(uniforms.albedo, albedoRGBA[0], albedoRGBA[1], albedoRGBA[2]);
      gl.uniform1f(uniforms.roughness, sceneNumber(mat.roughness, 0.5));
      gl.uniform1f(uniforms.metalness, sceneNumber(mat.metalness, 0));
      gl.uniform1f(uniforms.clearcoat, clamp01(sceneNumber(mat.clearcoat, 0)));
      gl.uniform1f(uniforms.sheen, clamp01(sceneNumber(mat.sheen, 0)));
      gl.uniform1f(uniforms.transmission, clamp01(sceneNumber(mat.transmission, 0)));
      gl.uniform1f(uniforms.iridescence, clamp01(sceneNumber(mat.iridescence, 0)));
      gl.uniform1f(uniforms.anisotropy, Math.max(-1, Math.min(1, sceneNumber(mat.anisotropy, 0))));
      gl.uniform1f(uniforms.emissive, sceneNumber(mat.emissive, 0));
      gl.uniform1f(uniforms.opacity, clamp01(sceneNumber(mat.opacity, 1)));
      gl.uniform1i(uniforms.unlit, mat.unlit ? 1 : 0);

      var textureMaps = [
        { prop: "texture",      has: "hasAlbedoMap",    sampler: "albedoMap",    unit: 0 },
        { prop: "normalMap",    has: "hasNormalMap",     sampler: "normalMap",    unit: 1 },
        { prop: "roughnessMap", has: "hasRoughnessMap",  sampler: "roughnessMap", unit: 2 },
        { prop: "metalnessMap", has: "hasMetalnessMap",  sampler: "metalnessMap", unit: 3 },
        { prop: "emissiveMap",  has: "hasEmissiveMap",   sampler: "emissiveMap",  unit: 4 },
      ];
      for (var ti = 0; ti < textureMaps.length; ti++) {
        var tm = textureMaps[ti];
        var record = mat[tm.prop] ? scenePBRLoadTexture(gl, mat[tm.prop], textureCache) : null;
        var loaded = Boolean(record && record.texture && record.loaded);
        gl.uniform1i(uniforms[tm.has], loaded ? 1 : 0);
        if (loaded) {
          scenePBRBindTexture(gl, tm.unit, record.texture);
          gl.uniform1i(uniforms[tm.sampler], tm.unit);
        }
      }
      uploadCustomUniforms(gl, uniforms, mat.customUniforms);
    }

    function applyBlendMode(gl, renderPass) {
      if (renderPass === "alpha") {
        gl.enable(gl.BLEND);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      } else if (renderPass === "additive") {
        gl.enable(gl.BLEND);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
      } else {
        gl.disable(gl.BLEND);
      }
    }

    function applyDepthMode(gl, renderPass) {
      gl.enable(gl.DEPTH_TEST);
      if (renderPass === "opaque") {
        gl.depthMask(true);
        gl.depthFunc(gl.LEQUAL);
      } else {
        gl.depthMask(false);
        gl.depthFunc(gl.LEQUAL);
      }
    }

    const _drawListOpaque = [];
    const _drawListAlpha = [];
    const _drawListAdditive = [];
    const _drawListResult = { opaque: _drawListOpaque, alpha: _drawListAlpha, additive: _drawListAdditive };

    function buildPBRDrawList(bundle) {
      const objects = Array.isArray(bundle && bundle.meshObjects) ? bundle.meshObjects : [];
      const materials = Array.isArray(bundle.materials) ? bundle.materials : [];
      _drawListOpaque.length = 0;
      _drawListAlpha.length = 0;
      _drawListAdditive.length = 0;

      for (var i = 0; i < objects.length; i++) {
        const obj = objects[i];
        if (!obj || obj.viewCulled) {
          continue;
        }
        if (!Number.isFinite(obj.vertexOffset) || !Number.isFinite(obj.vertexCount) || obj.vertexCount <= 0) {
          continue;
        }
        const mat = materials[obj.materialIndex] || null;
        const pass = scenePBRObjectRenderPass(obj, mat);
        if (pass === "alpha") {
          _drawListAlpha.push(obj);
        } else if (pass === "additive") {
          _drawListAdditive.push(obj);
        } else {
          _drawListOpaque.push(obj);
        }
      }

      _drawListAlpha.sort(scenePBRDepthSort);
      _drawListAdditive.sort(scenePBRDepthSort);

      return _drawListResult;
    }

    function render(bundle, viewport) {
      if (!bundle) {
        return;
      }

      var perfEnabled = typeof window !== "undefined" && window.__gosx_scene3d_perf === true;
      if (perfEnabled) {
        performance.mark("scene3d-render-start");
      }

      const hasPBRData = Boolean(
        bundle.worldMeshPositions &&
        bundle.worldMeshNormals &&
        Array.isArray(bundle.meshObjects) &&
        bundle.meshObjects.length > 0
      );
      const hasPointsData = (Array.isArray(bundle.points) && bundle.points.length > 0) ||
        (Array.isArray(bundle.computeParticles) && bundle.computeParticles.length > 0);
      const hasInstancedData = Array.isArray(bundle.instancedMeshes) && bundle.instancedMeshes.length > 0;
      const hasLineData = bundle.worldVertexCount > 0 ||
        (Array.isArray(bundle.surfaces) && bundle.surfaces.length > 0);
      if (!hasPBRData && !hasPointsData && !hasInstancedData && !hasLineData) {
        return;
      }
      const preparedScene = typeof prepareScene === "function"
        ? prepareScene(bundle, bundle.camera, viewport, lastPreparedScene, {
          mount: canvas && canvas.parentNode || null,
          sentinels: canvas && canvas.parentNode && canvas.parentNode.__gosxScene3DSentinels || null,
        })
        : null;
      if (preparedScene) {
        lastPreparedScene = preparedScene;
        bundle = preparedScene.ir || bundle;
        if (canvas && canvas.parentNode) {
          canvas.parentNode.__gosxScene3DCSSDynamic = Boolean(preparedScene.cssDynamic);
        }
      }

      sceneRenderCamera(bundle.camera, _frameCam);
      const cam = _frameCam;
      const aspect = Math.max(0.0001, canvas.width / Math.max(1, canvas.height));
      const viewMatrix = scenePBRViewMatrix(cam, scratchViewMatrix);
      const projMatrix = scenePBRProjectionMatrixForCamera(cam, aspect, scratchProjMatrix);

      shadowLightIndices[0] = -1; shadowLightIndices[1] = -1;
      var activeShadowCount = 0;

      if (shadowProgram) {
        var lightArray = Array.isArray(bundle.lights) ? bundle.lights : [];
        var sceneBounds = null;
        var shadowMaxPixels = (typeof bundle.shadowMaxPixels === "number") ? bundle.shadowMaxPixels : 0;

        for (var li = 0; li < lightArray.length && activeShadowCount < 2; li++) {
          var light = lightArray[li];
          if (!light || !light.castShadow) continue;
          var kind = typeof light.kind === "string" ? light.kind.toLowerCase() : "";
          if (kind !== "directional") continue;

          if (!sceneBounds) {
            sceneBounds = sceneShadowComputeBounds(bundle);
          }

          var slot = activeShadowCount;
          var numCascades = Math.max(1, Math.min(4, (light.shadowCascades | 0) || 1));
          var shadowSize = sceneNumber(light.shadowSize, 1024);
          shadowSize = Math.max(256, Math.min(4096, shadowSize));
          shadowSize = resolveShadowSize(shadowSize, shadowMaxPixels);

          if (!shadowSlots[slot] ||
              shadowSlots[slot].size !== shadowSize ||
              shadowSlots[slot].numCascades !== numCascades) {
            disposeShadowSlot(gl, shadowSlots[slot]);
            shadowSlots[slot] = createSceneShadowSlot(gl, shadowSize, numCascades);
          }

          shadowLightIndices[slot] = li;

          computeShadowSlotCascadeMatrices(light, shadowSlots[slot], sceneBounds,
            viewMatrix, cam.fov, aspect, cam.near, cam.far);

          for (var ci = 0; ci < shadowSlots[slot].numCascades; ci++) {
            var cascade = shadowSlots[slot].cascades[ci];
            renderSceneShadowPass(gl, shadowProgram, cascade, cascade.lightMatrix, bundle, shadowState);
          }
          activeShadowCount++;
        }
      }

      var postEffects = Array.isArray(bundle.postEffects) ? bundle.postEffects : [];
      var postFXMaxPixels = (typeof bundle.postFXMaxPixels === "number") ? bundle.postFXMaxPixels : 0;
      var usePostProcessing = postEffects.length > 0;

      var renderW = canvas.width;
      var renderH = canvas.height;

      if (usePostProcessing) {
        if (!postProcessor) {
          postProcessor = createScenePostProcessor(gl);
        }
        var scaled = postProcessor.begin(canvas.width, canvas.height, postFXMaxPixels);
        renderW = scaled.width;
        renderH = scaled.height;
      }

      gl.viewport(0, 0, renderW, renderH);

      var bgStr = typeof bundle.background === "string" ? bundle.background.trim().toLowerCase() : "";
      const bg = bgStr === "transparent" ? [0, 0, 0, 0] : sceneColorRGBA(bundle.background, [0.03, 0.08, 0.12, 1]);
      gl.clearColor(bg[0], bg[1], bg[2], bg[3]);
      gl.clearDepth(1);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

      _frameLightsHash = scenePBRLightsHash(bundle.lights, bundle.environment);

      if (hasPBRData) {
      gl.useProgram(program);
      gl.uniformMatrix4fv(uniforms.viewMatrix, false, viewMatrix);
      gl.uniformMatrix4fv(uniforms.projectionMatrix, false, projMatrix);
      gl.uniform3f(uniforms.cameraPosition, cam.x, cam.y, -cam.z);

      scenePBRUploadExposure(gl, uniforms, bundle.environment, usePostProcessing);

      scenePBRUploadLights(gl, uniforms, bundle.lights, bundle.environment, _frameLightsHash);
      scenePBRUploadEnvironmentMap(gl, uniforms, bundle.environment, textureCache, shadowSlots, shadowLightIndices);

      scenePBRUploadShadowUniforms(gl, uniforms, shadowSlots, shadowLightIndices, bundle.lights, bundle.environment);

      const drawList = preparedScene && preparedScene.pbrPasses
        ? preparedScene.pbrPasses
        : buildPBRDrawList(bundle);
      const materials = Array.isArray(bundle.materials) ? bundle.materials : [];

      applyBlendMode(gl, "opaque");
      applyDepthMode(gl, "opaque");
      drawPBRObjectList(gl, drawList.opaque, bundle, materials);

      if (drawList.alpha.length > 0) {
        applyBlendMode(gl, "alpha");
        applyDepthMode(gl, "alpha");
        drawPBRObjectList(gl, drawList.alpha, bundle, materials);
      }

      if (drawList.additive.length > 0) {
        applyBlendMode(gl, "additive");
        applyDepthMode(gl, "additive");
        drawPBRObjectList(gl, drawList.additive, bundle, materials);
      }

      } // end if (hasPBRData)

      if (lineResources && bundle.worldVertexCount > 0) {
        renderSceneWebGLWorldBundle(gl, bundle, canvas, lineResources);
      }

      drawInstancedMeshes(gl, bundle, viewMatrix, projMatrix);

      var frameTimeSeconds = performance.now() / 1000;
      activeStaticPointEntries.clear();
      activeStaticPointKeys.clear();
      drawPointsEntries(gl, Array.isArray(bundle.points) ? bundle.points : [], bundle.environment, viewMatrix, projMatrix, frameTimeSeconds, renderH);
      drawPointsEntries(gl, buildComputePointsEntries(bundle.computeParticles, frameTimeSeconds), bundle.environment, viewMatrix, projMatrix, frameTimeSeconds, renderH);
      releaseInactiveStaticPointBuffers();

      gl.depthMask(true);
      gl.disable(gl.BLEND);

      if (usePostProcessing && postProcessor) {
        postProcessor.apply(postEffects, renderW, renderH, canvas.width, canvas.height, bundle.camera);
        gl.useProgram(program);
      }

      if (perfEnabled) {
        performance.mark("scene3d-render-end");
        performance.measure("scene3d-render", "scene3d-render-start", "scene3d-render-end");
        performance.clearMarks("scene3d-render-start");
        performance.clearMarks("scene3d-render-end");
      }
    }

    function objectIsSkinned(obj) {
      return Boolean(
        obj && obj.skin &&
        obj.vertices && obj.vertices.joints && obj.vertices.weights
      );
    }

	    function ensureSkinnedProgram() {
	      if (skinnedProgram) return skinnedProgram;
	      if (skinnedProgramFailed) return null;
	      skinnedProgram = createScenePBRSkinnedProgram(gl);
	      if (!skinnedProgram) {
	        skinnedProgramFailed = true;
	        console.warn("[gosx] Skinned PBR shader compilation failed; skinned objects will use static path.");
	      }
	      return skinnedProgram;
	    }

    function ensureCustomProgram(material) {
      if (!scenePBRHasCustomHooks(material)) {
        return null;
      }
      const key = material && material.key ? material.key : sceneMaterialProfileKey(material);
      const cached = customProgramCache.get(key);
      if (cached) {
        return cached.failed ? null : cached.program;
      }
      const customProgram = createScenePBRCustomProgram(gl, material);
      customProgramCache.set(key, customProgram ? { program: customProgram } : { failed: true });
      if (!customProgram) {
        console.warn("[gosx] CustomMaterial shader compilation failed; object will use the standard PBR shader.");
      }
      return customProgram;
    }

	    function scenePBRDirectAttribute(vertices, key, count, tupleSize) {
	      const data = vertices && vertices[key];
	      const required = Math.max(0, Math.floor(sceneNumber(count, 0))) * tupleSize;
	      if (!(data instanceof Float32Array) || data.length < required) {
	        return null;
	      }
	      if (data.length === required) {
	        return data;
	      }
	      let views = vertices._pbrAttributeViews;
	      if (!views) {
	        views = Object.create(null);
	        vertices._pbrAttributeViews = views;
	      }
	      let record = views[key];
	      if (!record || record.source !== data || record.length !== required) {
	        record = {
	          source: data,
	          length: required,
	          view: data.subarray(0, required),
	        };
	        views[key] = record;
	      }
	      return record.view;
	    }

    function bindScenePBRDirectAttribute(vertices, key, attrib, size, data) {
      if (!vertices || !Number.isFinite(attrib) || attrib < 0 || !(data instanceof Float32Array)) {
        return false;
      }
      let buffers = vertices._pbrAttributeBuffers;
      if (!buffers) {
        buffers = Object.create(null);
        vertices._pbrAttributeBuffers = buffers;
      }
	      let record = buffers[key];
	      if (!record || record.gl !== gl || record.data !== data) {
	        if (record && record.buffer && record.gl === gl) {
	          gl.deleteBuffer(record.buffer);
	          pointsEntryBuffers.delete(record.buffer);
	        }
	        record = {
	          gl,
	          data,
	          buffer: gl.createBuffer(),
	        };
	        pointsEntryBuffers.add(record.buffer);
        buffers[key] = record;
        gl.bindBuffer(gl.ARRAY_BUFFER, record.buffer);
        gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
      } else {
        gl.bindBuffer(gl.ARRAY_BUFFER, record.buffer);
      }
      gl.enableVertexAttribArray(attrib);
      gl.vertexAttribPointer(attrib, size, gl.FLOAT, false, 0, 0);
      return true;
    }

    function drawPBRObjectList(gl, objectList, bundle, materials) {
      var lastMaterialIndex = -1;
      var currentProgram = program;       // the static PBR gl program
      var currentAttribs = attribs;
      var currentUniforms = uniforms;

      function uploadFrameUniformsForProgram(targetUniforms) {
        gl.uniformMatrix4fv(targetUniforms.viewMatrix, false, scratchViewMatrix);
        gl.uniformMatrix4fv(targetUniforms.projectionMatrix, false, scratchProjMatrix);
        gl.uniform3f(targetUniforms.cameraPosition, _frameCam.x, _frameCam.y, -_frameCam.z);

        var postEffects = Array.isArray(bundle.postEffects) ? bundle.postEffects : [];
        scenePBRUploadExposure(gl, targetUniforms, bundle.environment, postEffects.length > 0);

        scenePBRUploadLights(gl, targetUniforms, bundle.lights, bundle.environment, _frameLightsHash);
        scenePBRUploadEnvironmentMap(gl, targetUniforms, bundle.environment, textureCache, shadowSlots, shadowLightIndices);
        scenePBRUploadShadowUniforms(gl, targetUniforms, shadowSlots, shadowLightIndices, bundle.lights, bundle.environment);
      }

      for (var i = 0; i < objectList.length; i++) {
        const obj = objectList[i];
        const matIndex = sceneNumber(obj.materialIndex, 0);
        const mat = materials[matIndex] || null;
        var isSkinned = objectIsSkinned(obj);
        var customProgram = !isSkinned ? ensureCustomProgram(mat) : null;

        if (customProgram) {
          if (currentProgram !== customProgram.program) {
            gl.useProgram(customProgram.program);
            currentProgram = customProgram.program;
            currentAttribs = customProgram.attributes;
            currentUniforms = customProgram.uniforms;
            uploadFrameUniformsForProgram(currentUniforms);
            lastMaterialIndex = -1;
          }
        } else if (isSkinned) {
          var sp = ensureSkinnedProgram();
          if (sp && currentProgram !== sp.program) {
            gl.useProgram(sp.program);
            currentProgram = sp.program;
            currentAttribs = sp.attributes;
            currentUniforms = sp.uniforms;
            uploadFrameUniformsForProgram(currentUniforms);
            lastMaterialIndex = -1;
          }
          if (!sp) isSkinned = false;
        } else if (currentProgram !== program) {
          gl.useProgram(program);
          currentProgram = program;
          currentAttribs = attribs;
          currentUniforms = uniforms;
          lastMaterialIndex = -1;
        }

        if (matIndex !== lastMaterialIndex) {
          uploadMaterial(gl, currentUniforms, mat, textureCache);
          lastMaterialIndex = matIndex;
        }

        gl.uniform1i(currentUniforms.receiveShadow, obj.receiveShadow ? 1 : 0);

        var objDepthWriteOverride = obj.depthWrite !== undefined && obj.depthWrite !== null;
        if (objDepthWriteOverride) {
          gl.depthMask(obj.depthWrite !== false);
        }

	        if (isSkinned) {
	          gl.uniform1i(currentUniforms.hasSkin, 1);
	          if (currentUniforms.modelMatrix) {
	            gl.uniformMatrix4fv(currentUniforms.modelMatrix, false, obj.modelMatrix || identityModelMatrix);
	          }

          var jointMatrices = obj.skin.jointMatrices;
          if (jointMatrices) {
            var jointCount = Math.min(Math.floor(jointMatrices.length / 16), 64);
            if (jointCount > 0 && currentUniforms.jointMatrices) {
              var jointUpload = jointMatrices;
              var requiredJointFloats = jointCount * 16;
              if (jointMatrices.length !== requiredJointFloats) {
                var jointViews = obj.skin._jointMatrixUploadViews;
                if (!jointViews) {
                  jointViews = Object.create(null);
                  obj.skin._jointMatrixUploadViews = jointViews;
                }
                var jointView = jointViews[requiredJointFloats];
                if (!jointView || jointView.source !== jointMatrices) {
                  jointView = {
                    source: jointMatrices,
                    view: jointMatrices.subarray(0, requiredJointFloats),
                  };
                  jointViews[requiredJointFloats] = jointView;
                }
                jointUpload = jointView.view;
              }
              gl.uniformMatrix4fv(currentUniforms.jointMatrices, false, jointUpload);
            }
          }
        } else if (currentUniforms.hasSkin) {
          gl.uniform1i(currentUniforms.hasSkin, 0);
        }

        const offset = obj.vertexOffset;
        const count = obj.vertexCount;
        const directVertices = Boolean(obj.directVertices && obj.vertices);
        const directPositions = directVertices ? scenePBRDirectAttribute(obj.vertices, "positions", count, 3) : null;
        const directNormals = directVertices ? scenePBRDirectAttribute(obj.vertices, "normals", count, 3) : null;
        const directUVs = directVertices ? scenePBRDirectAttribute(obj.vertices, "uvs", count, 2) : null;
        const directTangents = directVertices ? scenePBRDirectAttribute(obj.vertices, "tangents", count, 4) : null;

        if (!bindScenePBRDirectAttribute(obj.vertices, "positions", currentAttribs.position, 3, directPositions)) {
          const positions = sliceToFloat32(bundle.worldMeshPositions, offset, count, 3, "positions");
          gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
          gl.bufferData(gl.ARRAY_BUFFER, positions, gl.DYNAMIC_DRAW);
          gl.enableVertexAttribArray(currentAttribs.position);
          gl.vertexAttribPointer(currentAttribs.position, 3, gl.FLOAT, false, 0, 0);
        }

        if (!bindScenePBRDirectAttribute(obj.vertices, "normals", currentAttribs.normal, 3, directNormals)) {
          const normals = sliceToFloat32(bundle.worldMeshNormals, offset, count, 3, "normals");
          gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
          gl.bufferData(gl.ARRAY_BUFFER, normals, gl.DYNAMIC_DRAW);
          gl.enableVertexAttribArray(currentAttribs.normal);
          gl.vertexAttribPointer(currentAttribs.normal, 3, gl.FLOAT, false, 0, 0);
        }

        if (bindScenePBRDirectAttribute(obj.vertices, "uvs", currentAttribs.uv, 2, directUVs)) {
        } else if (bundle.worldMeshUVs && !directVertices) {
          const uvs = sliceToFloat32(bundle.worldMeshUVs, offset, count, 2, "uvs");
          gl.bindBuffer(gl.ARRAY_BUFFER, uvBuffer);
          gl.bufferData(gl.ARRAY_BUFFER, uvs, gl.DYNAMIC_DRAW);
          gl.enableVertexAttribArray(currentAttribs.uv);
          gl.vertexAttribPointer(currentAttribs.uv, 2, gl.FLOAT, false, 0, 0);
        } else if (currentAttribs.uv >= 0) {
          gl.disableVertexAttribArray(currentAttribs.uv);
          gl.vertexAttrib2f(currentAttribs.uv, 0, 0);
        }

        if (bindScenePBRDirectAttribute(obj.vertices, "tangents", currentAttribs.tangent, 4, directTangents)) {
        } else if (bundle.worldMeshTangents && !directVertices) {
          const tangents = sliceToFloat32(bundle.worldMeshTangents, offset, count, 4, "tangents");
          gl.bindBuffer(gl.ARRAY_BUFFER, tangentBuffer);
          gl.bufferData(gl.ARRAY_BUFFER, tangents, gl.DYNAMIC_DRAW);
          gl.enableVertexAttribArray(currentAttribs.tangent);
          gl.vertexAttribPointer(currentAttribs.tangent, 4, gl.FLOAT, false, 0, 0);
        } else if (currentAttribs.tangent >= 0) {
          gl.disableVertexAttribArray(currentAttribs.tangent);
          gl.vertexAttrib4f(currentAttribs.tangent, 1, 0, 0, 1);
        }

        if (isSkinned && currentAttribs.joints >= 0 && currentAttribs.weights >= 0) {
          var joints = obj.vertices.joints;
          var weights = obj.vertices.weights;

          const directJoints = directVertices ? scenePBRDirectAttribute(obj.vertices, "joints", count, 4) : null;
          const directWeights = directVertices ? scenePBRDirectAttribute(obj.vertices, "weights", count, 4) : null;
          if (!bindScenePBRDirectAttribute(obj.vertices, "joints", currentAttribs.joints, 4, directJoints)) {
            gl.bindBuffer(gl.ARRAY_BUFFER, jointsBuffer);
            gl.bufferData(gl.ARRAY_BUFFER, joints instanceof Float32Array ? joints : new Float32Array(joints), gl.DYNAMIC_DRAW);
            gl.enableVertexAttribArray(currentAttribs.joints);
            gl.vertexAttribPointer(currentAttribs.joints, 4, gl.FLOAT, false, 0, 0);
          }

          if (!bindScenePBRDirectAttribute(obj.vertices, "weights", currentAttribs.weights, 4, directWeights)) {
            gl.bindBuffer(gl.ARRAY_BUFFER, weightsBuffer);
            gl.bufferData(gl.ARRAY_BUFFER, weights instanceof Float32Array ? weights : new Float32Array(weights), gl.DYNAMIC_DRAW);
            gl.enableVertexAttribArray(currentAttribs.weights);
            gl.vertexAttribPointer(currentAttribs.weights, 4, gl.FLOAT, false, 0, 0);
          }
        } else if (currentAttribs.joints >= 0) {
          gl.disableVertexAttribArray(currentAttribs.joints);
          gl.vertexAttrib4f(currentAttribs.joints, 0, 0, 0, 0);
          gl.disableVertexAttribArray(currentAttribs.weights);
          gl.vertexAttrib4f(currentAttribs.weights, 0, 0, 0, 0);
        }

        gl.drawArrays(gl.TRIANGLES, 0, count);

        if (objDepthWriteOverride) {
          var mat2 = materials[sceneNumber(obj.materialIndex, 0)] || null;
          var pass2 = scenePBRObjectRenderPass(obj, mat2);
          gl.depthMask(pass2 === "opaque");
        }
      }

      if (currentProgram !== program) {
        gl.useProgram(program);
      }
    }

    function ensurePointsProgram() {
      if (pointsProgram) return pointsProgram;
      pointsProgram = createScenePointsProgram(gl);
      if (!pointsProgram) {
        console.warn("[gosx] Points shader compilation failed; points will not render.");
      }
      return pointsProgram;
    }

    function disposeComputeParticleSystemRecord(record) {
      if (record && record.system && typeof record.system.dispose === "function") {
        record.system.dispose();
      }
      if (record && record.pointsEntry) {
        var ce = record.pointsEntry;
        if (ce._vboPos) { gl.deleteBuffer(ce._vboPos); pointsEntryBuffers.delete(ce._vboPos); ce._vboPos = null; }
        if (ce._vboSizes) { gl.deleteBuffer(ce._vboSizes); pointsEntryBuffers.delete(ce._vboSizes); ce._vboSizes = null; }
        if (ce._vboColors) { gl.deleteBuffer(ce._vboColors); pointsEntryBuffers.delete(ce._vboColors); ce._vboColors = null; }
        record.pointsEntry = null;
      }
    }

    function syncComputeParticleSystems(entries) {
      var activeIds = new Set();
      var records = [];
      var sourceEntries = Array.isArray(entries) ? entries : [];
      for (var i = 0; i < sourceEntries.length; i++) {
        var entry = sourceEntries[i];
        if (!entry || typeof entry !== "object") continue;
        var id = typeof entry.id === "string" && entry.id ? entry.id : ("scene-particles-" + i);
        var signature = sceneComputeSystemSignature(entry);
        activeIds.add(id);
        var record = computeParticleSystems.get(id);
        if (!record || record.signature !== signature) {
          disposeComputeParticleSystemRecord(record);
          record = {
            signature: signature,
            system: createSceneParticleSystem(null, entry),
            colorBuffer: null,
          };
          computeParticleSystems.set(id, record);
        } else if (record.system) {
          record.system.entry = entry;
        }
        if (record && record.system) {
          records.push(record);
        }
      }
      for (const [id, record] of computeParticleSystems.entries()) {
        if (!activeIds.has(id)) {
          disposeComputeParticleSystemRecord(record);
          computeParticleSystems.delete(id);
        }
      }
      return records;
    }

    function buildComputePointsEntries(entries, timeSeconds) {
      var currentTime = Number.isFinite(timeSeconds) ? timeSeconds : 0;
      var deltaTime = lastComputeParticleTimeSeconds == null
        ? 0
        : Math.max(0, Math.min(0.1, currentTime - lastComputeParticleTimeSeconds));
      lastComputeParticleTimeSeconds = currentTime;
      var records = syncComputeParticleSystems(entries);
      var pointsEntries = [];
      for (var i = 0; i < records.length; i++) {
        var record = records[i];
        var system = record.system;
        if (!system) continue;
        system.update(deltaTime, currentTime);
        if (!record.colorBuffer || record.colorBuffer.length !== system.count * 4) {
          record.colorBuffer = new Float32Array(system.count * 4);
        }
        for (var pi = 0; pi < system.count; pi++) {
          var rgbBase = pi * 3;
          var rgbaBase = pi * 4;
          record.colorBuffer[rgbaBase] = system.colors[rgbBase];
          record.colorBuffer[rgbaBase + 1] = system.colors[rgbBase + 1];
          record.colorBuffer[rgbaBase + 2] = system.colors[rgbBase + 2];
          record.colorBuffer[rgbaBase + 3] = system.opacities[pi];
        }
        var material = system.entry && system.entry.material && typeof system.entry.material === "object"
          ? system.entry.material
          : {};
        var emitter = system.entry && system.entry.emitter && typeof system.entry.emitter === "object"
          ? system.entry.emitter
          : {};
        if (!record.pointsEntry) {
          record.pointsEntry = { _dynamic: true };
        }
        var computeEntry = record.pointsEntry;
        computeEntry.id = system.entry && system.entry.id ? system.entry.id : ("scene-compute-points-" + i);
        computeEntry.count = system.count;
        computeEntry.color = typeof material.color === "string" ? material.color : "#ffffff";
        computeEntry.style = material.style;
        computeEntry.size = sceneNumber(material.size, 1);
        computeEntry.opacity = 1;
        computeEntry.blendMode = material.blendMode;
        computeEntry.attenuation = !!material.attenuation;
        computeEntry.x = sceneNumber(emitter.x, 0);
        computeEntry.y = sceneNumber(emitter.y, 0);
        computeEntry.z = sceneNumber(emitter.z, 0);
        computeEntry.rotationX = sceneNumber(emitter.rotationX, 0);
        computeEntry.rotationY = sceneNumber(emitter.rotationY, 0);
        computeEntry.rotationZ = sceneNumber(emitter.rotationZ, 0);
        computeEntry.spinX = sceneNumber(emitter.spinX, 0);
        computeEntry.spinY = sceneNumber(emitter.spinY, 0);
        computeEntry.spinZ = sceneNumber(emitter.spinZ, 0);
        computeEntry._cachedPos = system.positions;
        computeEntry._cachedSizes = system.sizes;
        computeEntry._cachedColors = record.colorBuffer;
        pointsEntries.push(computeEntry);
      }
      return pointsEntries;
    }

    function drawPointsEntries(gl, pointsArray, environment, viewMatrix, projMatrix, timeSeconds, renderH) {
      if (pointsArray.length === 0) {
        return;
      }

      var pp = ensurePointsProgram();
      if (!pp) {
        return;
      }

      gl.useProgram(pp.program);

      gl.uniformMatrix4fv(pp.uniforms.viewMatrix, false, viewMatrix);
      gl.uniformMatrix4fv(pp.uniforms.projectionMatrix, false, projMatrix);
      gl.uniform1f(pp.uniforms.viewportHeight, renderH);

      var env = environment || {};
      var fogDensity = sceneNumber(env.fogDensity, 0);
      gl.uniform1i(pp.uniforms.hasFog, fogDensity > 0 ? 1 : 0);
      gl.uniform1f(pp.uniforms.fogDensity, fogDensity);
      var fogColorRGBA = sceneColorRGBA(env.fogColor, [0.5, 0.5, 0.5, 1]);
      gl.uniform3f(pp.uniforms.fogColor, fogColorRGBA[0], fogColorRGBA[1], fogColorRGBA[2]);

      gl.enable(gl.DEPTH_TEST);
      var _pointsModelMat = new Float32Array(16);
      var _pointsTilt = new Float32Array(16);
      var _pointsSpin = new Float32Array(16);

      for (var i = 0; i < pointsArray.length; i++) {
        var entry = pointsArray[i];

        var px = sceneNumber(entry.x, 0);
        var py = sceneNumber(entry.y, 0);
        var pz = sceneNumber(entry.z, 0);
        var hasSpin = sceneNumber(entry.spinX, 0) !== 0 || sceneNumber(entry.spinY, 0) !== 0 || sceneNumber(entry.spinZ, 0) !== 0;

        if (hasSpin) {

          var spx = sceneNumber(entry.spinX, 0) * timeSeconds;
          var spy = sceneNumber(entry.spinY, 0) * timeSeconds;
          var spz = sceneNumber(entry.spinZ, 0) * timeSeconds;
          var csx = Math.cos(spx), ssx = Math.sin(spx);
          var csy = Math.cos(spy), ssy = Math.sin(spy);
          var csz = Math.cos(spz), ssz = Math.sin(spz);
          _pointsSpin[0] = csy*csz; _pointsSpin[4] = ssx*ssy*csz-csx*ssz; _pointsSpin[8]  = csx*ssy*csz+ssx*ssz; _pointsSpin[12] = 0;
          _pointsSpin[1] = csy*ssz; _pointsSpin[5] = ssx*ssy*ssz+csx*csz; _pointsSpin[9]  = csx*ssy*ssz-ssx*csz; _pointsSpin[13] = 0;
          _pointsSpin[2] = -ssy;    _pointsSpin[6] = ssx*csy;             _pointsSpin[10] = csx*csy;             _pointsSpin[14] = 0;
          _pointsSpin[3] = 0;       _pointsSpin[7] = 0;                   _pointsSpin[11] = 0;                   _pointsSpin[15] = 1;

          var rx = sceneNumber(entry.rotationX, 0);
          var ry = sceneNumber(entry.rotationY, 0);
          var rz = sceneNumber(entry.rotationZ, 0);
          var cxr = Math.cos(rx), sxr = Math.sin(rx);
          var cyr = Math.cos(ry), syr = Math.sin(ry);
          var czr = Math.cos(rz), szr = Math.sin(rz);
          _pointsTilt[0] = cyr*czr; _pointsTilt[4] = sxr*syr*czr-cxr*szr; _pointsTilt[8]  = cxr*syr*czr+sxr*szr; _pointsTilt[12] = px;
          _pointsTilt[1] = cyr*szr; _pointsTilt[5] = sxr*syr*szr+cxr*czr; _pointsTilt[9]  = cxr*syr*szr-sxr*czr; _pointsTilt[13] = py;
          _pointsTilt[2] = -syr;    _pointsTilt[6] = sxr*cyr;             _pointsTilt[10] = cxr*cyr;             _pointsTilt[14] = pz;
          _pointsTilt[3] = 0;       _pointsTilt[7] = 0;                   _pointsTilt[11] = 0;                   _pointsTilt[15] = 1;

          sceneMat4MultiplyInto(_pointsModelMat, _pointsTilt, _pointsSpin);
        } else {
          var rx = sceneNumber(entry.rotationX, 0);
          var ry = sceneNumber(entry.rotationY, 0);
          var rz = sceneNumber(entry.rotationZ, 0);
          var cxr = Math.cos(rx), sxr = Math.sin(rx);
          var cyr = Math.cos(ry), syr = Math.sin(ry);
          var czr = Math.cos(rz), szr = Math.sin(rz);
          _pointsModelMat[0] = cyr*czr; _pointsModelMat[4] = sxr*syr*czr-cxr*szr; _pointsModelMat[8]  = cxr*syr*czr+sxr*szr; _pointsModelMat[12] = px;
          _pointsModelMat[1] = cyr*szr; _pointsModelMat[5] = sxr*syr*szr+cxr*czr; _pointsModelMat[9]  = cxr*syr*szr-sxr*czr; _pointsModelMat[13] = py;
          _pointsModelMat[2] = -syr;    _pointsModelMat[6] = sxr*cyr;             _pointsModelMat[10] = cxr*cyr;             _pointsModelMat[14] = pz;
          _pointsModelMat[3] = 0;       _pointsModelMat[7] = 0;                   _pointsModelMat[11] = 0;                   _pointsModelMat[15] = 1;
        }
        gl.uniformMatrix4fv(pp.uniforms.modelMatrix, false, _pointsModelMat);
        var count = sceneNumber(entry.count, 0);
        if (count <= 0) continue;

        var blendMode = typeof entry.blendMode === "string" ? entry.blendMode.toLowerCase() : "";
        if (blendMode === "additive") {
          gl.enable(gl.BLEND);
          gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
        } else if (blendMode === "alpha") {
          gl.enable(gl.BLEND);
          gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
        } else {
          gl.disable(gl.BLEND);
        }

        var depthWrite = entry.depthWrite !== false;
        gl.depthMask(depthWrite);
        gl.depthFunc(gl.LEQUAL);

        gl.uniform1f(pp.uniforms.opacity, clamp01(sceneNumber(entry.opacity, 1)));

        var defaultColorRGBA = sceneColorRGBA(entry.color, [1, 1, 1, 1]);
        gl.uniform4f(pp.uniforms.defaultColor, defaultColorRGBA[0], defaultColorRGBA[1], defaultColorRGBA[2], 1);
        gl.uniform1f(pp.uniforms.defaultSize, sceneNumber(entry.size, 1));
        gl.uniform1i(pp.uniforms.sizeAttenuation, entry.attenuation ? 1 : 0);
        gl.uniform1i(pp.uniforms.pointStyle, scenePointStyleCode(entry.style));

        var rawPositions = entry.positions;
        if (!entry._cachedPos && rawPositions && (Array.isArray(rawPositions) || sceneIsNumericTypedArray(rawPositions)) && rawPositions.length >= count * 3) {
          entry._cachedPos = rawPositions instanceof Float32Array ? rawPositions : new Float32Array(rawPositions);
        }
        var rawSizes = entry.sizes;
        if (!entry._cachedSizes && rawSizes && (Array.isArray(rawSizes) || sceneIsNumericTypedArray(rawSizes)) && rawSizes.length >= count) {
          entry._cachedSizes = rawSizes instanceof Float32Array ? rawSizes : new Float32Array(rawSizes);
        }
        var rawColors = entry.colors;
        if (!entry._cachedColors && rawColors && (Array.isArray(rawColors) || sceneIsNumericTypedArray(rawColors)) && rawColors.length >= count) {
          if (Array.isArray(rawColors) && typeof rawColors[0] === "string") {
            entry._cachedColors = new Float32Array(count * 4);
            for (var ci = 0; ci < count; ci++) {
              var crgba = sceneColorRGBA(rawColors[ci], [1, 1, 1, 1]);
              entry._cachedColors[ci * 4] = crgba[0];
              entry._cachedColors[ci * 4 + 1] = crgba[1];
              entry._cachedColors[ci * 4 + 2] = crgba[2];
              entry._cachedColors[ci * 4 + 3] = crgba[3];
            }
          } else if (rawColors.length >= count * 4) {
            entry._cachedColors = new Float32Array(rawColors);
          } else if (rawColors.length >= count * 3) {
            entry._cachedColors = new Float32Array(count * 4);
            for (var ci2 = 0; ci2 < count; ci2++) {
              entry._cachedColors[ci2 * 4] = rawColors[ci2 * 3];
              entry._cachedColors[ci2 * 4 + 1] = rawColors[ci2 * 3 + 1];
              entry._cachedColors[ci2 * 4 + 2] = rawColors[ci2 * 3 + 2];
              entry._cachedColors[ci2 * 4 + 3] = 1;
            }
          }
        }
        if (!entry._cachedPos) continue;
        var posBuf = entry._dynamic
          ? ensureDynamicPointsVBO(entry, "_vboPos", entry._cachedPos)
          : ensureStaticPointVBO(entry, "_vboPos", "_vboPosSource", entry._cachedPos);
        gl.bindBuffer(gl.ARRAY_BUFFER, posBuf);
        gl.enableVertexAttribArray(pp.attributes.position);
        gl.vertexAttribPointer(pp.attributes.position, 3, gl.FLOAT, false, 0, 0);

        var hasSizes = !!entry._cachedSizes;
        gl.uniform1i(pp.uniforms.hasPerVertexSize, hasSizes ? 1 : 0);
        if (hasSizes && pp.attributes.size >= 0) {
          var sizeBuf = entry._dynamic
            ? ensureDynamicPointsVBO(entry, "_vboSizes", entry._cachedSizes)
            : ensureStaticPointVBO(entry, "_vboSizes", "_vboSizesSource", entry._cachedSizes);
          gl.bindBuffer(gl.ARRAY_BUFFER, sizeBuf);
          gl.enableVertexAttribArray(pp.attributes.size);
          gl.vertexAttribPointer(pp.attributes.size, 1, gl.FLOAT, false, 0, 0);
        } else if (pp.attributes.size >= 0) {
          gl.disableVertexAttribArray(pp.attributes.size);
          gl.vertexAttrib1f(pp.attributes.size, sceneNumber(entry.size, 1));
        }

        var hasColors = !!entry._cachedColors;
        gl.uniform1i(pp.uniforms.hasPerVertexColor, hasColors ? 1 : 0);
        if (hasColors && pp.attributes.color >= 0) {
          var colorBuf = entry._dynamic
            ? ensureDynamicPointsVBO(entry, "_vboColors", entry._cachedColors)
            : ensureStaticPointVBO(entry, "_vboColors", "_vboColorsSource", entry._cachedColors);
          gl.bindBuffer(gl.ARRAY_BUFFER, colorBuf);
          gl.enableVertexAttribArray(pp.attributes.color);
          gl.vertexAttribPointer(pp.attributes.color, 4, gl.FLOAT, false, 0, 0);
        } else if (pp.attributes.color >= 0) {
          gl.disableVertexAttribArray(pp.attributes.color);
          gl.vertexAttrib4f(pp.attributes.color, defaultColorRGBA[0], defaultColorRGBA[1], defaultColorRGBA[2], 1);
        }

        gl.drawArrays(gl.POINTS, 0, count);
      }

      gl.depthMask(true);
      gl.disable(gl.BLEND);

      gl.useProgram(program);
    }

	    function ensureInstancedProgram() {
	      if (instancedProgram) return instancedProgram;
	      if (instancedProgramFailed) return null;
	      instancedProgram = createScenePBRInstancedProgram(gl);
	      if (!instancedProgram) {
	        instancedProgramFailed = true;
	        console.warn("[gosx] Instanced PBR shader compilation failed; instanced meshes will not render.");
	      }
	      return instancedProgram;
	    }

    function getInstancedGeometry(mesh) {
      var kind = typeof mesh.kind === "string" ? mesh.kind.toLowerCase() : "box";
      var w = sceneNumber(mesh.width, 1);
      var h = sceneNumber(mesh.height, 1);
      var d = sceneNumber(mesh.depth, 1);
      var r = sceneNumber(mesh.radius, 0.5);
      var s = sceneNumber(mesh.segments, 16);
      var key = kind + ":" + w + ":" + h + ":" + d + ":" + r + ":" + s;
      if (instancedGeometryCache[key]) return instancedGeometryCache[key];
      var geom = generateInstancedGeometry(kind, { width: w, height: h, depth: d, radius: r, segments: s });
      instancedGeometryCache[key] = geom;
      return geom;
    }

    function sceneInstancedColorBuffer(mesh, count) {
      if (!mesh || count <= 0) {
        return null;
      }
      if (mesh._cachedInstanceColors) {
        return mesh._cachedInstanceColors;
      }
      var rawColors = mesh.colors;
      if (!rawColors || typeof rawColors.length !== "number") {
        return null;
      }
      if (Array.isArray(rawColors) && typeof rawColors[0] === "string") {
        mesh._cachedInstanceColors = new Float32Array(count * 4);
        for (var ci = 0; ci < count; ci++) {
          var rgba = sceneColorRGBA(rawColors[ci] || rawColors[rawColors.length - 1], [1, 1, 1, 1]);
          mesh._cachedInstanceColors[ci * 4] = rgba[0];
          mesh._cachedInstanceColors[ci * 4 + 1] = rgba[1];
          mesh._cachedInstanceColors[ci * 4 + 2] = rgba[2];
          mesh._cachedInstanceColors[ci * 4 + 3] = rgba[3];
        }
        return mesh._cachedInstanceColors;
      }
      if (rawColors.length >= count * 4) {
        mesh._cachedInstanceColors = rawColors instanceof Float32Array ? rawColors : new Float32Array(rawColors);
        return mesh._cachedInstanceColors;
      }
      if (rawColors.length >= count * 3) {
        mesh._cachedInstanceColors = new Float32Array(count * 4);
        for (var ni = 0; ni < count; ni++) {
          mesh._cachedInstanceColors[ni * 4] = rawColors[ni * 3];
          mesh._cachedInstanceColors[ni * 4 + 1] = rawColors[ni * 3 + 1];
          mesh._cachedInstanceColors[ni * 4 + 2] = rawColors[ni * 3 + 2];
          mesh._cachedInstanceColors[ni * 4 + 3] = 1;
        }
        return mesh._cachedInstanceColors;
      }
      return null;
    }

    function drawInstancedMeshes(gl, bundle, viewMatrix, projMatrix) {
      var meshes = Array.isArray(bundle.instancedMeshes) ? bundle.instancedMeshes : [];
      if (meshes.length === 0) return;

      var ip = ensureInstancedProgram();
      if (!ip) return;

      gl.useProgram(ip.program);

      gl.enable(gl.DEPTH_TEST);
      gl.depthMask(true);
      gl.depthFunc(gl.LEQUAL);
      gl.disable(gl.BLEND);

      gl.uniformMatrix4fv(ip.uniforms.viewMatrix, false, viewMatrix);
      gl.uniformMatrix4fv(ip.uniforms.projectionMatrix, false, projMatrix);
      gl.uniform3f(ip.uniforms.cameraPosition, _frameCam.x, _frameCam.y, -_frameCam.z);

      var postEffects = Array.isArray(bundle.postEffects) ? bundle.postEffects : [];
      scenePBRUploadExposure(gl, ip.uniforms, bundle.environment, postEffects.length > 0);

      scenePBRUploadLights(gl, ip.uniforms, bundle.lights, bundle.environment, _frameLightsHash);
      scenePBRUploadEnvironmentMap(gl, ip.uniforms, bundle.environment, textureCache, shadowSlots, shadowLightIndices);
      scenePBRUploadShadowUniforms(gl, ip.uniforms, shadowSlots, shadowLightIndices, bundle.lights, bundle.environment);

      var materials = Array.isArray(bundle.materials) ? bundle.materials : [];

      for (var i = 0; i < meshes.length; i++) {
        var mesh = meshes[i];
        if (!mesh.transforms || mesh.instanceCount <= 0) continue;

        var instanceCount = sceneNumber(mesh.instanceCount, 0);
        if (instanceCount <= 0) continue;

        var geom = getInstancedGeometry(mesh);
        if (!geom || geom.vertexCount <= 0) continue;

        var mat = materials[sceneNumber(mesh.materialIndex, 0)] || null;
        if (!mat && mesh.color) {
          mat = {
            color: mesh.color,
            roughness: sceneNumber(mesh.roughness, 0.5),
            metalness: sceneNumber(mesh.metalness, 0),
          };
        }
        uploadMaterial(gl, ip.uniforms, mat, textureCache);

        gl.uniform1i(ip.uniforms.receiveShadow, mesh.receiveShadow ? 1 : 0);

        gl.bindBuffer(gl.ARRAY_BUFFER, ensureStaticArrayVBO(staticMeshArrayVBOs, geom.positions));
        gl.enableVertexAttribArray(ip.attributes.position);
        gl.vertexAttribPointer(ip.attributes.position, 3, gl.FLOAT, false, 0, 0);

        gl.bindBuffer(gl.ARRAY_BUFFER, ensureStaticArrayVBO(staticMeshArrayVBOs, geom.normals));
        gl.enableVertexAttribArray(ip.attributes.normal);
        gl.vertexAttribPointer(ip.attributes.normal, 3, gl.FLOAT, false, 0, 0);

        gl.bindBuffer(gl.ARRAY_BUFFER, ensureStaticArrayVBO(staticMeshArrayVBOs, geom.uvs));
        gl.enableVertexAttribArray(ip.attributes.uv);
        gl.vertexAttribPointer(ip.attributes.uv, 2, gl.FLOAT, false, 0, 0);

        gl.bindBuffer(gl.ARRAY_BUFFER, ensureStaticArrayVBO(staticMeshArrayVBOs, geom.tangents));
        gl.enableVertexAttribArray(ip.attributes.tangent);
        gl.vertexAttribPointer(ip.attributes.tangent, 4, gl.FLOAT, false, 0, 0);

        if (!mesh._cachedTransforms) {
          if (mesh.transforms instanceof Float32Array) {
            mesh._cachedTransforms = mesh.transforms;
          } else if (Array.isArray(mesh.transforms)) {
            mesh._cachedTransforms = new Float32Array(mesh.transforms);
          }
        }
        var transformData = mesh._cachedTransforms;
        if (!transformData) continue;

        var instanceColorData = sceneInstancedColorBuffer(mesh, instanceCount);
        var hasInstanceColor = !!(instanceColorData && ip.attributes.instanceColor >= 0);
        if (ip.uniforms.hasInstanceColor) {
          gl.uniform1i(ip.uniforms.hasInstanceColor, hasInstanceColor ? 1 : 0);
        }

        gl.bindBuffer(gl.ARRAY_BUFFER, ensureStaticArrayVBO(staticMeshArrayVBOs, transformData));

        var baseLoc = ip.attributes.instanceMatrix;
        for (var col = 0; col < 4; col++) {
          var loc = baseLoc + col;
          gl.enableVertexAttribArray(loc);
          gl.vertexAttribPointer(loc, 4, gl.FLOAT, false, 64, col * 16);
          gl.vertexAttribDivisor(loc, 1);
        }

        if (hasInstanceColor) {
          gl.bindBuffer(gl.ARRAY_BUFFER, ensureStaticArrayVBO(staticMeshArrayVBOs, instanceColorData));
          gl.enableVertexAttribArray(ip.attributes.instanceColor);
          gl.vertexAttribPointer(ip.attributes.instanceColor, 4, gl.FLOAT, false, 0, 0);
          gl.vertexAttribDivisor(ip.attributes.instanceColor, 1);
        }

        gl.drawArraysInstanced(gl.TRIANGLES, 0, geom.vertexCount, instanceCount);

        if (hasInstanceColor) {
          gl.vertexAttribDivisor(ip.attributes.instanceColor, 0);
          gl.disableVertexAttribArray(ip.attributes.instanceColor);
        }

        for (var col = 0; col < 4; col++) {
          var loc2 = baseLoc + col;
          gl.vertexAttribDivisor(loc2, 0);
          gl.disableVertexAttribArray(loc2);
        }
      }

      gl.useProgram(program);
    }

    function dispose() {
      gl.deleteBuffer(positionBuffer);
      gl.deleteBuffer(normalBuffer);
      gl.deleteBuffer(uvBuffer);
      gl.deleteBuffer(tangentBuffer);
      gl.deleteBuffer(jointsBuffer);
      gl.deleteBuffer(weightsBuffer);
      for (const buf of pointsEntryBuffers) {
        gl.deleteBuffer(buf);
      }
      pointsEntryBuffers.clear();
      staticPointEntries.clear();
      activeStaticPointEntries.clear();
      staticPointKeyedVBOs.clear();
      activeStaticPointKeys.clear();
      for (const record of computeParticleSystems.values()) {
        disposeComputeParticleSystemRecord(record);
      }
      computeParticleSystems.clear();
      lastComputeParticleTimeSeconds = null;
      if (shadowState.buffer) gl.deleteBuffer(shadowState.buffer);

      for (const record of textureCache.values()) {
        if (record && record.texture) {
          gl.deleteTexture(record.texture);
        }
      }
      textureCache.clear();

      for (var si = 0; si < shadowSlots.length; si++) {
        disposeShadowSlot(gl, shadowSlots[si]);
        shadowSlots[si] = null;
      }

      if (postProcessor) {
        postProcessor.dispose();
        postProcessor = null;
      }

      if (shadowProgram) {
        gl.deleteShader(shadowProgram.vertexShader);
        gl.deleteShader(shadowProgram.fragmentShader);
        gl.deleteProgram(shadowProgram.program);
      }

      if (skinnedProgram) {
        gl.deleteShader(skinnedProgram.vertexShader);
        gl.deleteShader(skinnedProgram.fragmentShader);
        gl.deleteProgram(skinnedProgram.program);
        skinnedProgram = null;
      }

      if (pointsProgram) {
        gl.deleteShader(pointsProgram.vertexShader);
        gl.deleteShader(pointsProgram.fragmentShader);
        gl.deleteProgram(pointsProgram.program);
        pointsProgram = null;
      }

      if (instancedProgram) {
        gl.deleteShader(instancedProgram.vertexShader);
        gl.deleteShader(instancedProgram.fragmentShader);
        gl.deleteProgram(instancedProgram.program);
        instancedProgram = null;
      }
      instancedGeometryCache = {};

      for (const record of customProgramCache.values()) {
        const cp = record && record.program;
        if (cp) {
          gl.deleteShader(cp.vertexShader);
          gl.deleteShader(cp.fragmentShader);
          gl.deleteProgram(cp.program);
        }
      }
      customProgramCache.clear();

      if (lineProgram && lineResources) {
        disposeSceneWebGLRenderer(gl, lineProgram, lineResources);
      }

      gl.deleteShader(pbrProgram.vertexShader);
      gl.deleteShader(pbrProgram.fragmentShader);
      gl.deleteProgram(program);
    }

    return {
      kind: "webgl",
      render: render,
      dispose: dispose,
      type: "webgl-pbr",
    };
  }

  function scenePBRObjectRenderPass(obj, material) {
    if (obj && typeof obj.renderPass === "string" && obj.renderPass) {
      const pass = obj.renderPass.toLowerCase();
      if (pass === "alpha" || pass === "additive" || pass === "opaque") {
        return pass;
      }
    }
    if (material && typeof material.renderPass === "string" && material.renderPass) {
      const pass = material.renderPass.toLowerCase();
      if (pass === "alpha" || pass === "additive" || pass === "opaque") {
        return pass;
      }
    }
    if (material && sceneNumber(material.opacity, 1) < 1) {
      return "alpha";
    }
    return "opaque";
  }

  function scenePBRDepthSort(a, b) {
    const da = sceneNumber(a && a.depthCenter, 0);
    const db = sceneNumber(b && b.depthCenter, 0);
    if (da !== db) {
      return db - da;
    }
    return String(a && a.id || "").localeCompare(String(b && b.id || ""));
  }

  function sceneWebGLCommandSequence(bundle, viewport, previousPrepared) {
    const prepared = prepareScene(
      bundle || {},
      bundle && bundle.camera || {},
      viewport || {},
      previousPrepared || null
    );
    return scenePreparedCommandSequence(prepared);
  }

  function createScenePBRRendererOrFallback(gl, canvas, options) {
    if (!gl || !canvas) {
      return null;
    }
    if (typeof WebGL2RenderingContext === "undefined" || !(gl instanceof WebGL2RenderingContext)) {
      return null;
    }
    var renderer = null;
    try {
      renderer = createScenePBRRenderer(gl, canvas);
    } catch (e) {
      console.warn("[gosx] PBR renderer creation failed:", e);
      return null;
    }
    return renderer;
  }

  if (typeof window !== "undefined") {
    window.__gosx_scene3d_resource_api = Object.assign(window.__gosx_scene3d_resource_api || {}, {
      shadowPassHash: sceneShadowPassHash,
      computeCascadeSplits: sceneShadowComputeCascadeSplits,
      frustumSubCorners: sceneShadowFrustumSubCorners,
      fitLightSpaceOrtho: sceneShadowFitLightSpaceOrtho,
    });
  }

  if (typeof sceneBackendRegistry !== "undefined" && sceneBackendRegistry) {
    sceneBackendRegistry.register("webgl", {
      capabilities: ["webgl", "webgl2", "shaders", "instancing", "shadows"],
      create: function(canvas, props, capability) {
        const caps = capability || {};
        if (typeof createScenePBRRendererOrFallback === "function") {
          const useCanvasAlpha = sceneCanvasAlpha(props);
          const gl = typeof canvas.getContext === "function" ? canvas.getContext("webgl2", {
            alpha: useCanvasAlpha,
            premultipliedAlpha: useCanvasAlpha,
            antialias: caps.tier === "full" && !caps.lowPower && !caps.reducedData,
            powerPreference: caps.lowPower || caps.tier === "constrained" ? "low-power" : "high-performance",
          }) : null;
          if (gl) {
            const pbrRenderer = createScenePBRRendererOrFallback(gl, canvas, {});
            if (pbrRenderer) {
              return pbrRenderer;
            }
          }
        }
        return createSceneWebGLRenderer(canvas, {
          antialias: caps.tier === "full" && !caps.lowPower && !caps.reducedData,
          powerPreference: caps.lowPower || caps.tier === "constrained" ? "low-power" : "high-performance",
        });
      },
    });
  }

  var _webgpuAdapterProbe = null; // null = unprobed, false = unavailable, GPUAdapter = ready
  var _webgpuDeviceProbe = null;  // null = unprobed, false = unavailable, GPUDevice = ready
  var _webgpuAdapterReady = false;
  var _webgpuProbePromise = Promise.resolve(false);
  var _webgpuSupportedFeatures = [];
  var _webgpuRequestedFeatures = [];
  var _webgpuRequiredFeatures = [];
  var _webgpuRequiredLimits = {};
  var _webgpuAdapterLimits = {};
  var _webgpuDeviceLimits = {};
  var _webgpuAdapterInfo = {};
  var _webgpuProbeError = "";
  var _webgpuDeviceLostInfo = null;
  var _webgpuProbeOptions = {};

  var WEBGPU_OPTIONAL_FEATURES = [
    "timestamp-query",
    "indirect-first-instance",
    "shader-f16",
    "texture-compression-bc",
    "texture-compression-bc-sliced-3d",
    "texture-compression-etc2",
    "texture-compression-astc",
    "texture-compression-astc-sliced-3d",
    "depth-clip-control",
    "depth32float-stencil8",
    "float32-filterable",
    "float32-blendable",
    "rg11b10ufloat-renderable",
    "bgra8unorm-storage",
    "clip-distances",
    "dual-source-blending",
    "subgroups",
    "subgroups-f16",
  ];

  var WEBGPU_LIMIT_NAMES = [
    "maxTextureDimension1D",
    "maxTextureDimension2D",
    "maxTextureDimension3D",
    "maxTextureArrayLayers",
    "maxBindGroups",
    "maxBindGroupsPlusVertexBuffers",
    "maxBindingsPerBindGroup",
    "maxDynamicUniformBuffersPerPipelineLayout",
    "maxDynamicStorageBuffersPerPipelineLayout",
    "maxSampledTexturesPerShaderStage",
    "maxSamplersPerShaderStage",
    "maxStorageBuffersPerShaderStage",
    "maxStorageTexturesPerShaderStage",
    "maxUniformBuffersPerShaderStage",
    "maxUniformBufferBindingSize",
    "maxStorageBufferBindingSize",
    "minUniformBufferOffsetAlignment",
    "minStorageBufferOffsetAlignment",
    "maxVertexBuffers",
    "maxBufferSize",
    "maxVertexAttributes",
    "maxVertexBufferArrayStride",
    "maxInterStageShaderComponents",
    "maxInterStageShaderVariables",
    "maxColorAttachments",
    "maxColorAttachmentBytesPerSample",
    "maxComputeWorkgroupStorageSize",
    "maxComputeInvocationsPerWorkgroup",
    "maxComputeWorkgroupSizeX",
    "maxComputeWorkgroupSizeY",
    "maxComputeWorkgroupSizeZ",
    "maxComputeWorkgroupsPerDimension",
  ];

  function sceneWebGPUFeatureList(features) {
    var out = [];
    if (!features) return out;
    if (typeof features.forEach === "function") {
      features.forEach(function(value) {
        if (typeof value === "string") out.push(value);
      });
    } else if (typeof features[Symbol.iterator] === "function") {
      for (var entry of features) {
        if (typeof entry === "string") out.push(entry);
      }
    } else if (Array.isArray(features)) {
      out = features.filter(function(value) { return typeof value === "string"; });
    }
    out.sort();
    return out.filter(function(value, index) { return index === 0 || out[index - 1] !== value; });
  }

  function sceneWebGPUFeatureSupported(adapter, feature) {
    var features = adapter && adapter.features;
    if (!features) return false;
    if (typeof features.has === "function") {
      return features.has(feature);
    }
    return sceneWebGPUFeatureList(features).indexOf(feature) >= 0;
  }

  function sceneWebGPURequestedFeatureList(adapter) {
    var out = [];
    for (var i = 0; i < WEBGPU_OPTIONAL_FEATURES.length; i++) {
      var feature = WEBGPU_OPTIONAL_FEATURES[i];
      if (!sceneWebGPUFeatureSupported(adapter, feature)) continue;
      if (feature === "texture-compression-bc-sliced-3d" && !sceneWebGPUFeatureSupported(adapter, "texture-compression-bc")) continue;
      if (feature === "texture-compression-astc-sliced-3d" && !sceneWebGPUFeatureSupported(adapter, "texture-compression-astc")) continue;
      if (feature === "subgroups-f16" && (!sceneWebGPUFeatureSupported(adapter, "subgroups") || !sceneWebGPUFeatureSupported(adapter, "shader-f16"))) continue;
      out.push(feature);
    }
    return out;
  }

  function sceneWebGPUMergeFeatureLists() {
    var out = [];
    var seen = {};
    for (var listIndex = 0; listIndex < arguments.length; listIndex++) {
      var list = arguments[listIndex];
      if (!Array.isArray(list)) {
        continue;
      }
      for (var i = 0; i < list.length; i++) {
        var feature = sceneWebGPUNormalizeFeatureName(list[i]);
        if (!feature || seen[feature]) {
          continue;
        }
        seen[feature] = true;
        out.push(feature);
      }
    }
    return out;
  }

  function sceneWebGPULimitsSnapshot(limits) {
    var out = {};
    if (!limits) return out;
    for (var i = 0; i < WEBGPU_LIMIT_NAMES.length; i++) {
      var name = WEBGPU_LIMIT_NAMES[i];
      var value = limits[name];
      if (Number.isFinite(Number(value))) {
        out[name] = Number(value);
      }
    }
    return out;
  }

  function sceneWebGPUAdapterInfoSnapshot(adapter) {
    var info = adapter && adapter.info;
    var out = {};
    if (!info || typeof info !== "object") return out;
    var keys = ["vendor", "architecture", "device", "description", "subgroupMinSize", "subgroupMaxSize"];
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      var value = info[key];
      if (typeof value === "string" && value) {
        out[key] = value;
      } else if (Number.isFinite(Number(value))) {
        out[key] = Number(value);
      }
    }
    return out;
  }

  function sceneWebGPUProbeSnapshot() {
    return {
      ready: !!_webgpuAdapterReady,
      adapterAvailable: _webgpuAdapterProbe !== false && _webgpuAdapterProbe !== null,
      deviceAvailable: _webgpuDeviceProbe !== false && _webgpuDeviceProbe !== null,
      supportedFeatures: _webgpuSupportedFeatures.slice(),
      requestedFeatures: _webgpuRequestedFeatures.slice(),
      requiredFeatures: _webgpuRequiredFeatures.slice(),
      deviceFeatures: sceneWebGPUFeatureList(_webgpuDeviceProbe && _webgpuDeviceProbe.features),
      requiredLimits: Object.assign({}, _webgpuRequiredLimits),
      adapterLimits: Object.assign({}, _webgpuAdapterLimits),
      deviceLimits: Object.assign({}, _webgpuDeviceLimits),
      adapterInfo: Object.assign({}, _webgpuAdapterInfo),
      error: _webgpuProbeError,
      lost: _webgpuDeviceLostInfo,
      probeOptions: Object.assign({}, _webgpuProbeOptions),
    };
  }

  function sceneWebGPUDiagnostics() {
    return sceneWebGPUProbeSnapshot();
  }

  function _externalProbe() {
    if (typeof window !== "undefined" && typeof window.__gosx_scene3d_webgpu_probe === "function") {
      return window.__gosx_scene3d_webgpu_probe();
    }
    return { adapter: null, device: null, ready: false };
  }

  function _publishWebGPUProbeGlobals() {
    if (typeof window === "undefined") {
      return;
    }
    window.__gosx_scene3d_webgpu_probe = function() {
      return {
        adapter: _webgpuAdapterProbe,
        device: _webgpuDeviceProbe,
        ready: _webgpuAdapterReady,
        supportedFeatures: _webgpuSupportedFeatures.slice(),
        requestedFeatures: _webgpuRequestedFeatures.slice(),
        requiredFeatures: _webgpuRequiredFeatures.slice(),
        requiredLimits: Object.assign({}, _webgpuRequiredLimits),
        limits: Object.assign({}, _webgpuAdapterLimits),
        adapterInfo: Object.assign({}, _webgpuAdapterInfo),
        error: _webgpuProbeError,
        lost: _webgpuDeviceLostInfo,
        probeOptions: Object.assign({}, _webgpuProbeOptions),
      };
    };
    window.__gosx_scene3d_webgpu_diagnostics = sceneWebGPUDiagnostics;
    window.__gosx_scene3d_webgpu_probe_ready = function() {
      return _webgpuProbePromise.then(function() {
        return _webgpuAdapterReady;
      }).catch(function() {
        return false;
      });
    };
  }

  function sceneWebGPUPowerPreference(value) {
    var normalized = String(value || "").trim().toLowerCase();
    if (normalized === "high-performance" || normalized === "low-power") {
      return normalized;
    }
    return "";
  }

  function sceneWebGPUProbeOptionsFromManifest() {
    var manifest = sceneWebGPUManifest();
    var engines = manifest && Array.isArray(manifest.engines) ? manifest.engines : [];
    var powerPreference = "";
    for (var i = 0; i < engines.length; i++) {
      var entry = engines[i];
      if (!entry || entry.component !== "GoSXScene3D") {
        continue;
      }
      var props = entry.props && typeof entry.props === "object" ? entry.props : {};
      var requested = sceneWebGPUPowerPreference(
        props.webgpuPowerPreference ||
        props.webGPUPowerPreference ||
        props.webgpuAdapterPowerPreference ||
        props.webGPUAdapterPowerPreference
      );
      if (requested === "high-performance") {
        powerPreference = requested;
        break;
      }
      if (requested === "low-power") {
        powerPreference = requested;
      }
    }
    return powerPreference ? { powerPreference: powerPreference } : {};
  }

  function sceneWebGPUManifest() {
    if (typeof loadManifest === "function") {
      return loadManifest();
    }
    return null;
  }

  function sceneWebGPURequiredLimitsFromManifest() {
    var manifest = sceneWebGPUManifest();
    var limits = {};
    var groups = [
      manifest && Array.isArray(manifest.engines) ? manifest.engines : [],
      manifest && Array.isArray(manifest.computeIslands) ? manifest.computeIslands : [],
      manifest && Array.isArray(manifest.islands) ? manifest.islands : [],
    ];
    for (var groupIndex = 0; groupIndex < groups.length; groupIndex++) {
      var group = groups[groupIndex];
      for (var i = 0; i < group.length; i++) {
        var entry = group[i];
        var required = entry && Array.isArray(entry.requiredCapabilities) ? entry.requiredCapabilities : [];
        sceneWebGPUCollectRequiredLimits(required, limits);
      }
    }
    return limits;
  }

  function sceneWebGPURequiredFeaturesFromManifest(adapter) {
    var manifest = sceneWebGPUManifest();
    var out = [];
    var seen = {};
    var groups = [
      manifest && Array.isArray(manifest.engines) ? manifest.engines : [],
      manifest && Array.isArray(manifest.computeIslands) ? manifest.computeIslands : [],
      manifest && Array.isArray(manifest.islands) ? manifest.islands : [],
    ];
    for (var groupIndex = 0; groupIndex < groups.length; groupIndex++) {
      var group = groups[groupIndex];
      for (var i = 0; i < group.length; i++) {
        var entry = group[i];
        var required = entry && Array.isArray(entry.requiredCapabilities) ? entry.requiredCapabilities : [];
        for (var j = 0; j < required.length; j++) {
          var feature = sceneWebGPUFeatureFromCapability(required[j]);
          if (!feature || seen[feature] || !sceneWebGPUFeatureSupported(adapter, feature)) {
            continue;
          }
          seen[feature] = true;
          out.push(feature);
        }
      }
    }
    out.sort();
    return out;
  }

  function sceneWebGPUFeatureFromCapability(capability) {
    var raw = String(capability || "").trim();
    var lower = raw.toLowerCase();
    var feature = "";
    if (lower.indexOf("webgpu-feature:") === 0) {
      feature = raw.slice("webgpu-feature:".length);
    } else if (lower.indexOf("webgpu:") === 0) {
      feature = raw.slice("webgpu:".length);
    } else {
      return "";
    }
    feature = sceneWebGPUNormalizeFeatureName(feature);
    if (!feature || feature === "webgpu" || feature.indexOf("limit:") === 0 || feature.indexOf("device-limit:") === 0 || feature.indexOf("adapter-limit:") === 0) {
      return "";
    }
    return feature;
  }

  function sceneWebGPUNormalizeFeatureName(feature) {
    var normalized = String(feature || "").trim().toLowerCase();
    return /^[a-z0-9-]+$/.test(normalized) ? normalized : "";
  }

  function sceneWebGPUCollectRequiredLimits(required, out) {
    for (var i = 0; i < required.length; i++) {
      var raw = String(required[i] || "").trim();
      var lower = raw.toLowerCase();
      var body = "";
      if (lower.indexOf("webgpu:device-limit:") === 0) {
        body = raw.slice("webgpu:device-limit:".length);
      } else if (lower.indexOf("webgpu:limit:") === 0) {
        body = raw.slice("webgpu:limit:".length);
      } else if (lower.indexOf("webgpu-limit:") === 0) {
        body = raw.slice("webgpu-limit:".length);
      } else {
        continue;
      }
      var parsed = sceneWebGPUParseLimitRequirement(body);
      if (!parsed) {
        continue;
      }
      var name = sceneWebGPUCanonicalLimitName(parsed.name);
      if (!name) {
        continue;
      }
      var value = sceneWebGPURequiredLimitValue(parsed);
      if (!Number.isFinite(value)) {
        continue;
      }
      if (!Number.isFinite(Number(out[name])) || value > Number(out[name])) {
        out[name] = value;
      }
    }
  }

  function sceneWebGPUParseLimitRequirement(requirement) {
    var text = String(requirement || "").trim();
    var match = text.match(/^([a-z0-9_.:-]+)\s*(>=|<=|==|>|<|=|:)\s*([0-9]+(?:\.[0-9]+)?)$/i);
    if (!match) {
      return null;
    }
    var value = Number(match[3]);
    if (!Number.isFinite(value)) {
      return null;
    }
    return {
      name: match[1],
      operator: match[2] === ":" ? ">=" : match[2],
      value: value,
    };
  }

  function sceneWebGPURequiredLimitValue(parsed) {
    if (!parsed) {
      return NaN;
    }
    switch (parsed.operator) {
      case ">":
        return Math.floor(parsed.value) + 1;
      case "<":
      case "<=":
        return NaN;
      default:
        return Math.ceil(parsed.value);
    }
  }

  function sceneWebGPUCanonicalLimitName(name) {
    var wanted = sceneWebGPUNormalizedLimitName(name);
    if (!wanted) {
      return "";
    }
    for (var i = 0; i < WEBGPU_LIMIT_NAMES.length; i++) {
      var candidate = WEBGPU_LIMIT_NAMES[i];
      if (sceneWebGPUNormalizedLimitName(candidate) === wanted) {
        return candidate;
      }
    }
    return "";
  }

  function sceneWebGPUNormalizedLimitName(name) {
    return String(name || "").trim().toLowerCase().replace(/[^a-z0-9]/g, "");
  }

  if (typeof navigator !== "undefined" && navigator.gpu && typeof navigator.gpu.requestAdapter === "function") {
    _webgpuProbeOptions = sceneWebGPUProbeOptionsFromManifest();
    var adapterRequest = _webgpuProbeOptions && _webgpuProbeOptions.powerPreference ? _webgpuProbeOptions : undefined;
    _webgpuProbePromise = navigator.gpu.requestAdapter(adapterRequest).then(function(adapter) {
      if (!adapter) {
        _webgpuProbeError = "requestAdapter returned null";
        console.warn("[gosx] WebGPU probe: " + _webgpuProbeError);
        _webgpuAdapterProbe = false;
        _webgpuDeviceProbe = false;
        return false;
      }
      _webgpuAdapterProbe = adapter;
      _webgpuSupportedFeatures = sceneWebGPUFeatureList(adapter.features);
      _webgpuRequiredFeatures = sceneWebGPURequiredFeaturesFromManifest(adapter);
      _webgpuRequestedFeatures = sceneWebGPUMergeFeatureLists(sceneWebGPURequestedFeatureList(adapter), _webgpuRequiredFeatures);
      _webgpuRequiredLimits = sceneWebGPURequiredLimitsFromManifest();
      _webgpuAdapterLimits = sceneWebGPULimitsSnapshot(adapter.limits);
      _webgpuAdapterInfo = sceneWebGPUAdapterInfoSnapshot(adapter);
      var descriptor = {};
      if (_webgpuRequestedFeatures.length > 0) {
        descriptor.requiredFeatures = _webgpuRequestedFeatures;
      }
      if (Object.keys(_webgpuRequiredLimits).length > 0) {
        descriptor.requiredLimits = Object.assign({}, _webgpuRequiredLimits);
      }
      return adapter.requestDevice(descriptor);
    }).then(function(device) {
      if (device === false) {
        return;
      }
      if (!device) {
        _webgpuProbeError = "requestDevice returned null";
        console.warn("[gosx] WebGPU probe: " + _webgpuProbeError);
        _webgpuDeviceProbe = false;
        return;
      }
      _webgpuDeviceProbe = device;
      _webgpuDeviceLimits = sceneWebGPULimitsSnapshot(device.limits);
      _webgpuAdapterReady = true;
      device.lost.then(function(info) {
        _webgpuDeviceLostInfo = {
          reason: info && info.reason || "",
          message: info && info.message || "",
        };
        console.warn("[gosx] WebGPU probe device lost:", info && info.message);
        _webgpuAdapterReady = false;
        _webgpuDeviceProbe = false;
      }).catch(function() {});
      return true;
    }).catch(function(err) {
      _webgpuProbeError = String(err && (err.message || err) || "unknown error");
      console.warn("[gosx] WebGPU probe failed:", _webgpuProbeError);
      _webgpuAdapterProbe = false;
      _webgpuDeviceProbe = false;
      return false;
    });
  } else {
    _webgpuAdapterProbe = false;
    _webgpuDeviceProbe = false;
  }
  _publishWebGPUProbeGlobals();

  function sceneWebGPUAvailable() {
    return _webgpuAdapterReady
      && _webgpuAdapterProbe !== false
      && _webgpuAdapterProbe !== null
      && _webgpuDeviceProbe !== false
      && _webgpuDeviceProbe !== null
      && !!(window.__gosx_scene3d_webgpu_api
        && typeof window.__gosx_scene3d_webgpu_api.createRenderer === "function");
  }

  function createSceneWebGPURendererOrFallback(canvas, options) {
    if (!sceneWebGPUAvailable()) return null;
    if (!canvas || typeof canvas.getContext !== "function") return null;
    try {
      var renderer = window.__gosx_scene3d_webgpu_api.createRenderer(canvas, options || {});
      if (!renderer) {
        console.warn("[gosx] WebGPU factory returned null after probe success; canvas may be tainted");
      }
      return renderer;
    } catch (e) {
      console.warn("[gosx] WebGPU renderer creation failed:", e);
      return null;
    }
  }

  if (typeof sceneBackendRegistry !== "undefined" && sceneBackendRegistry) {
    sceneBackendRegistry.register("webgpu", {
      capabilities: ["webgpu", "shaders", "instancing", "compute", "shadows"],
      available: function() {
        return sceneWebGPUAvailable();
      },
      create: function(canvas, props, capability) {
        var options = typeof sceneWebGPUOptions === "function" ? sceneWebGPUOptions(props, capability) : {};
        return createSceneWebGPURendererOrFallback(canvas, options);
      },
    });
  }

  if (typeof window !== "undefined" && window.__gosx_scene3d_api) {
    window.__gosx_scene3d_api.sceneWebGPUDiagnostics = sceneWebGPUDiagnostics;
  }

  var SCENE_DRAG_MIN_EXTENT_X = 0.6;
  var SCENE_DRAG_MIN_EXTENT_Y = 0.35;
  var SCENE_PICK_MIN_EXTENT_X = 0.12;
  var SCENE_PICK_MIN_EXTENT_Y = 0.08;
  var SCENE_ORBIT_PITCH_MIN = -1.35;
  var SCENE_ORBIT_PITCH_MAX = 1.35;
  var SCENE_ORBIT_YAW_MIN = -1.1;
  var SCENE_ORBIT_YAW_MAX = 1.1;
  var SCENE_POINTER_PAD_MIN = 12;
  var SCENE_POINTER_PAD_RANGE = 22;
  var SCENE_POINTER_PAD_SCALE = 0.08;

  function sceneLocalPointerPoint(event, canvas, width, height) {
    const rect = canvas.getBoundingClientRect();
    const safeWidth = Math.max(rect.width || 0, 1);
    const safeHeight = Math.max(rect.height || 0, 1);
    return {
      x: sceneClamp(((sceneNumber(event && event.clientX, rect.left) - rect.left) / safeWidth) * width, 0, width),
      y: sceneClamp(((sceneNumber(event && event.clientY, rect.top) - rect.top) / safeHeight) * height, 0, height),
    };
  }

  function sceneLocalPointerSample(event, canvas, width, height, state, phase) {
    const previousX = state.lastX == null ? width / 2 : state.lastX;
    const previousY = state.lastY == null ? height / 2 : state.lastY;
    const hasPointerPosition = Number.isFinite(sceneNumber(event && event.clientX, NaN)) && Number.isFinite(sceneNumber(event && event.clientY, NaN));
    const point = hasPointerPosition ? sceneLocalPointerPoint(event, canvas, width, height) : { x: previousX, y: previousY };
    const sample = {
      x: point.x,
      y: point.y,
      deltaX: point.x - previousX,
      deltaY: point.y - previousY,
      buttons: phase === "end" ? 0 : 1,
      button: phase === "start" || phase === "end" ? 0 : null,
      active: phase !== "end",
    };
    state.lastX = point.x;
    state.lastY = point.y;
    return sample;
  }

  function resetScenePointerSample(width, height, state) {
    state.lastX = width / 2;
    state.lastY = height / 2;
    publishPointerSignals({
      x: state.lastX,
      y: state.lastY,
      deltaX: 0,
      deltaY: 0,
      buttons: 0,
      button: 0,
      active: false,
    });
  }

  function sceneDragSignalNamespace(props) {
    const value = props && props.dragSignalNamespace;
    return typeof value === "string" ? value.trim() : "";
  }

  function scenePickSignalNamespace(props) {
    const value = props && props.pickSignalNamespace;
    return typeof value === "string" ? value.trim() : "";
  }

  function sceneEventSignalNamespace(props) {
    const value = props && props.eventSignalNamespace;
    return typeof value === "string" ? value.trim() : "";
  }

  function sceneSignalSegment(value, fallback) {
    const source = typeof value === "string" ? value.trim().toLowerCase() : "";
    if (!source) {
      return fallback;
    }
    const normalized = source
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");
    return normalized || fallback;
  }

  function sceneTargetIndex(target) {
    return target && target.index != null ? Math.max(-1, Math.floor(sceneNumber(target.index, -1))) : -1;
  }

  function sceneTargetID(target) {
    return target && target.object && typeof target.object.id === "string" ? target.object.id : "";
  }

  function sceneTargetKind(target) {
    return target && target.object && typeof target.object.kind === "string" ? target.object.kind : "";
  }

  function sceneObjectSignalSlug(index, id, kind) {
    const targetID = typeof id === "string" ? id.trim() : "";
    if (targetID) {
      return sceneSignalSegment(targetID, "object");
    }
    const targetKind = typeof kind === "string" ? kind.trim() : "";
    if (targetKind && index >= 0) {
      return sceneSignalSegment(targetKind + "-" + index, "object-" + index);
    }
    if (index >= 0) {
      return "object-" + index;
    }
    return "";
  }

  function publishSceneDragSignals(namespace, state, active) {
    if (!namespace) {
      return;
    }
    queueInputSignal(namespace + ".x", sceneNumber(state.orbitX, 0));
    queueInputSignal(namespace + ".y", sceneNumber(state.orbitY, 0));
    queueInputSignal(namespace + ".targetIndex", Math.max(-1, Math.floor(sceneNumber(state.targetIndex, -1))));
    queueInputSignal(namespace + ".active", Boolean(active));
  }

  function publishScenePickSignals(namespace, state) {
    if (!namespace) {
      return;
    }
    const snapshot = scenePickSignalSnapshot(state);
    const nextKey = scenePickSignalSnapshotKey(snapshot);
    if (nextKey === state.publishedKey) {
      return;
    }
    state.publishedKey = nextKey;
    queueInputSignal(namespace + ".hovered", snapshot.hovered);
    queueInputSignal(namespace + ".hoverIndex", snapshot.hoverIndex);
    queueInputSignal(namespace + ".hoverID", snapshot.hoverID);
    queueInputSignal(namespace + ".down", snapshot.down);
    queueInputSignal(namespace + ".downIndex", snapshot.downIndex);
    queueInputSignal(namespace + ".downID", snapshot.downID);
    queueInputSignal(namespace + ".selected", snapshot.selected);
    queueInputSignal(namespace + ".selectedIndex", snapshot.selectedIndex);
    queueInputSignal(namespace + ".selectedID", snapshot.selectedID);
    queueInputSignal(namespace + ".clickCount", snapshot.clickCount);
    queueInputSignal(namespace + ".pointerX", snapshot.pointerX);
    queueInputSignal(namespace + ".pointerY", snapshot.pointerY);
  }

  function publishSceneEventSignals(namespace, state) {
    if (!namespace) {
      return;
    }
    const snapshot = sceneInteractionSnapshot(state);
    const nextKey = sceneInteractionSnapshotKey(snapshot);
    if (nextKey === state.publishedEventKey) {
      return;
    }
    state.publishedEventKey = nextKey;
    queueInputSignal(namespace + ".revision", snapshot.revision);
    queueInputSignal(namespace + ".type", snapshot.type);
    queueInputSignal(namespace + ".targetIndex", snapshot.targetIndex);
    queueInputSignal(namespace + ".targetID", snapshot.targetID);
    queueInputSignal(namespace + ".targetKind", snapshot.targetKind);
    queueInputSignal(namespace + ".hovered", snapshot.hovered);
    queueInputSignal(namespace + ".hoverIndex", snapshot.hoverIndex);
    queueInputSignal(namespace + ".hoverID", snapshot.hoverID);
    queueInputSignal(namespace + ".hoverKind", snapshot.hoverKind);
    queueInputSignal(namespace + ".down", snapshot.down);
    queueInputSignal(namespace + ".downIndex", snapshot.downIndex);
    queueInputSignal(namespace + ".downID", snapshot.downID);
    queueInputSignal(namespace + ".downKind", snapshot.downKind);
    queueInputSignal(namespace + ".selected", snapshot.selected);
    queueInputSignal(namespace + ".selectedIndex", snapshot.selectedIndex);
    queueInputSignal(namespace + ".selectedID", snapshot.selectedID);
    queueInputSignal(namespace + ".selectedKind", snapshot.selectedKind);
    queueInputSignal(namespace + ".clickCount", snapshot.clickCount);
    queueInputSignal(namespace + ".pointerX", snapshot.pointerX);
    queueInputSignal(namespace + ".pointerY", snapshot.pointerY);
    publishSceneObjectEventSignals(namespace, state, snapshot);
  }

  function scenePickSignalSnapshot(state) {
    return {
      hovered: Boolean(state.hoverIndex >= 0),
      hoverIndex: Math.max(-1, Math.floor(sceneNumber(state.hoverIndex, -1))),
      hoverID: state.hoverID || "",
      down: Boolean(state.downIndex >= 0),
      downIndex: Math.max(-1, Math.floor(sceneNumber(state.downIndex, -1))),
      downID: state.downID || "",
      selected: Boolean(state.selectedIndex >= 0),
      selectedIndex: Math.max(-1, Math.floor(sceneNumber(state.selectedIndex, -1))),
      selectedID: state.selectedID || "",
      clickCount: Math.max(0, Math.floor(sceneNumber(state.clickCount, 0))),
      pointerX: sceneNumber(state.pointerX, 0),
      pointerY: sceneNumber(state.pointerY, 0),
    };
  }

  function sceneInteractionSnapshot(state) {
    var pick = scenePickSignalSnapshot(state);
    pick.revision = Math.max(0, Math.floor(sceneNumber(state.eventRevision, 0)));
    pick.type = state.eventType || "";
    pick.targetIndex = Math.max(-1, Math.floor(sceneNumber(state.eventTargetIndex, -1)));
    pick.targetID = state.eventTargetID || "";
    pick.targetKind = state.eventTargetKind || "";
    pick.hoverKind = state.hoverKind || "";
    pick.downKind = state.downKind || "";
    pick.selectedKind = state.selectedKind || "";
    return pick;
  }

  function scenePickSignalSnapshotKey(snapshot) {
    return [
      snapshot.hovered ? 1 : 0,
      snapshot.hoverIndex,
      snapshot.hoverID,
      snapshot.down ? 1 : 0,
      snapshot.downIndex,
      snapshot.downID,
      snapshot.selected ? 1 : 0,
      snapshot.selectedIndex,
      snapshot.selectedID,
      snapshot.clickCount,
      snapshot.pointerX,
      snapshot.pointerY,
    ].join("|");
  }

  function sceneInteractionSnapshotKey(snapshot) {
    return [
      snapshot.revision,
      snapshot.type,
      snapshot.targetIndex,
      snapshot.targetID,
      snapshot.targetKind,
      snapshot.hovered ? 1 : 0,
      snapshot.hoverIndex,
      snapshot.hoverID,
      snapshot.hoverKind,
      snapshot.down ? 1 : 0,
      snapshot.downIndex,
      snapshot.downID,
      snapshot.downKind,
      snapshot.selected ? 1 : 0,
      snapshot.selectedIndex,
      snapshot.selectedID,
      snapshot.selectedKind,
      snapshot.clickCount,
      snapshot.pointerX,
      snapshot.pointerY,
    ].join("|");
  }

  function publishSceneObjectEventSignals(namespace, state, snapshot) {
    publishSceneObjectBoolSignal(namespace, "hovered", state.publishedHoverSlug, sceneObjectSignalSlug(snapshot.hoverIndex, snapshot.hoverID, snapshot.hoverKind));
    state.publishedHoverSlug = sceneObjectSignalSlug(snapshot.hoverIndex, snapshot.hoverID, snapshot.hoverKind);
    publishSceneObjectBoolSignal(namespace, "down", state.publishedDownSlug, sceneObjectSignalSlug(snapshot.downIndex, snapshot.downID, snapshot.downKind));
    state.publishedDownSlug = sceneObjectSignalSlug(snapshot.downIndex, snapshot.downID, snapshot.downKind);
    publishSceneObjectBoolSignal(namespace, "selected", state.publishedSelectedSlug, sceneObjectSignalSlug(snapshot.selectedIndex, snapshot.selectedID, snapshot.selectedKind));
    state.publishedSelectedSlug = sceneObjectSignalSlug(snapshot.selectedIndex, snapshot.selectedID, snapshot.selectedKind);

    const nextCounts = state.objectClickCounts || Object.create(null);
    const previousCounts = state.publishedObjectClickCounts || Object.create(null);
    const slugs = new Set(Object.keys(previousCounts).concat(Object.keys(nextCounts)));
    slugs.forEach(function(slug) {
      const nextCount = Math.max(0, Math.floor(sceneNumber(nextCounts[slug], 0)));
      const previousCount = Math.max(0, Math.floor(sceneNumber(previousCounts[slug], 0)));
      if (nextCount === previousCount) {
        return;
      }
      queueInputSignal(namespace + ".object." + slug + ".clickCount", nextCount);
    });
    state.publishedObjectClickCounts = Object.assign(Object.create(null), nextCounts);
  }

  function publishSceneObjectBoolSignal(namespace, key, previousSlug, nextSlug) {
    if (previousSlug && previousSlug !== nextSlug) {
      queueInputSignal(namespace + ".object." + previousSlug + "." + key, false);
    }
    if (nextSlug && nextSlug !== previousSlug) {
      queueInputSignal(namespace + ".object." + nextSlug + "." + key, true);
    }
  }

  function sceneBoundsSize(bounds) {
    if (!bounds || typeof bounds !== "object") return [0, 0, 0];
    return [
      Math.abs(sceneNumber(bounds.maxX, 0) - sceneNumber(bounds.minX, 0)),
      Math.abs(sceneNumber(bounds.maxY, 0) - sceneNumber(bounds.minY, 0)),
      Math.abs(sceneNumber(bounds.maxZ, 0) - sceneNumber(bounds.minZ, 0)),
    ].sort(function(a, b) { return b - a; });
  }

  function sceneObjectAllowsPointerDrag(object) {
    if (!object || object.kind === "plane" || object.viewCulled) {
      return false;
    }
    const extents = sceneBoundsSize(object.bounds);
    return extents[0] > SCENE_DRAG_MIN_EXTENT_X && extents[1] > SCENE_DRAG_MIN_EXTENT_Y;
  }

  function sceneObjectAllowsPointerPick(object) {
    if (!object || object.viewCulled) {
      return false;
    }
    if (typeof object.pickable === "boolean") {
      return object.pickable;
    }
    if (object.kind === "plane") {
      return false;
    }
    const extents = sceneBoundsSize(object.bounds);
    return extents[0] > SCENE_PICK_MIN_EXTENT_X && extents[1] > SCENE_PICK_MIN_EXTENT_Y;
  }

  function sceneWorldPointAt(source, vertexIndex) {
    if (!source || typeof source.length !== "number") {
      return null;
    }
    const offset = Math.max(0, vertexIndex * 3);
    if (offset + 2 >= source.length) {
      return null;
    }
    return {
      x: sceneNumber(source[offset], 0),
      y: sceneNumber(source[offset + 1], 0),
      z: sceneNumber(source[offset + 2], 0),
    };
  }

  function sceneProjectedObjectSegments(bundle, object, width, height) {
    if (!bundle || !bundle.camera || !object) {
      return [];
    }
    const vertexOffset = Math.max(0, Math.floor(sceneNumber(object.vertexOffset, 0)));
    const vertexCount = Math.max(0, Math.floor(sceneNumber(object.vertexCount, 0)));
    if (vertexCount < 2) {
      return [];
    }
    const source = bundle.worldPositions;
    if (!source || typeof source.length !== "number") {
      return [];
    }
    const segments = [];
    for (let i = 0; i + 1 < vertexCount; i += 2) {
      const fromWorld = sceneWorldPointAt(source, vertexOffset + i);
      const toWorld = sceneWorldPointAt(source, vertexOffset + i + 1);
      if (!fromWorld || !toWorld) {
        continue;
      }
      const from = sceneProjectPoint(fromWorld, bundle.camera, width, height);
      const to = sceneProjectPoint(toWorld, bundle.camera, width, height);
      if (!from || !to) {
        continue;
      }
      segments.push([from, to]);
    }
    return segments;
  }

  function sceneProjectedSegmentsBounds(segments) {
    if (!Array.isArray(segments) || !segments.length) {
      return null;
    }
    let minX = segments[0][0].x;
    let maxX = segments[0][0].x;
    let minY = segments[0][0].y;
    let maxY = segments[0][0].y;
    for (const segment of segments) {
      for (const point of segment) {
        minX = Math.min(minX, point.x);
        maxX = Math.max(maxX, point.x);
        minY = Math.min(minY, point.y);
        maxY = Math.max(maxY, point.y);
      }
    }
    return { minX, maxX, minY, maxY };
  }

  function scenePointerPadding(bounds) {
    if (!bounds) {
      return SCENE_POINTER_PAD_MIN;
    }
    const span = Math.max(bounds.maxX - bounds.minX, bounds.maxY - bounds.minY);
    return sceneClamp(span * SCENE_POINTER_PAD_SCALE, SCENE_POINTER_PAD_MIN, SCENE_POINTER_PAD_RANGE);
  }

  function sceneDistanceToSegment(point, from, to) {
    const deltaX = to.x - from.x;
    const deltaY = to.y - from.y;
    const lengthSquared = deltaX * deltaX + deltaY * deltaY;
    if (lengthSquared <= 0.0001) {
      return Math.hypot(point.x - from.x, point.y - from.y);
    }
    const t = sceneClamp(((point.x - from.x) * deltaX + (point.y - from.y) * deltaY) / lengthSquared, 0, 1);
    const closestX = from.x + deltaX * t;
    const closestY = from.y + deltaY * t;
    return Math.hypot(point.x - closestX, point.y - closestY);
  }

  function sceneProjectedObjectHull(segments) {
    const points = [];
    const seen = new Set();
    for (const segment of segments) {
      for (const point of segment) {
        const key = point.x.toFixed(3) + ":" + point.y.toFixed(3);
        if (seen.has(key)) {
          continue;
        }
        seen.add(key);
        points.push({ x: point.x, y: point.y });
      }
    }
    if (points.length < 3) {
      return points;
    }
    points.sort(function(a, b) {
      return a.x === b.x ? a.y - b.y : a.x - b.x;
    });
    const lower = [];
    for (const point of points) {
      while (lower.length >= 2 && sceneTurnDirection(lower[lower.length - 2], lower[lower.length - 1], point) <= 0) {
        lower.pop();
      }
      lower.push(point);
    }
    const upper = [];
    for (let i = points.length - 1; i >= 0; i -= 1) {
      const point = points[i];
      while (upper.length >= 2 && sceneTurnDirection(upper[upper.length - 2], upper[upper.length - 1], point) <= 0) {
        upper.pop();
      }
      upper.push(point);
    }
    lower.pop();
    upper.pop();
    return lower.concat(upper);
  }

  function sceneTurnDirection(a, b, c) {
    return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
  }

  function scenePointInPolygon(point, polygon) {
    if (!Array.isArray(polygon) || polygon.length < 3) {
      return false;
    }
    let inside = false;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i, i += 1) {
      const xi = polygon[i].x;
      const yi = polygon[i].y;
      const xj = polygon[j].x;
      const yj = polygon[j].y;
      const intersects = ((yi > point.y) !== (yj > point.y)) &&
        (point.x < ((xj - xi) * (point.y - yi)) / ((yj - yi) || 0.000001) + xi);
      if (intersects) {
        inside = !inside;
      }
    }
    return inside;
  }

  function sceneObjectDepthCenter(object, camera) {
    const bounds = object && object.bounds;
    if (!bounds) {
      return sceneWorldPointDepth(0, camera);
    }
    return sceneBoundsDepthMetrics(bounds, camera).center;
  }

  function sceneObjectPointerCapture(bundle, object, point, width, height) {
    const segments = sceneProjectedObjectSegments(bundle, object, width, height);
    if (!segments.length) {
      return null;
    }
    const bounds = sceneProjectedSegmentsBounds(segments);
    if (!bounds) {
      return null;
    }
    const padding = scenePointerPadding(bounds);
    if (
      point.x < bounds.minX - padding ||
      point.x > bounds.maxX + padding ||
      point.y < bounds.minY - padding ||
      point.y > bounds.maxY + padding
    ) {
      return null;
    }
    let minDistance = Number.POSITIVE_INFINITY;
    for (const segment of segments) {
      minDistance = Math.min(minDistance, sceneDistanceToSegment(point, segment[0], segment[1]));
    }
    const inside = scenePointInPolygon(point, sceneProjectedObjectHull(segments));
    if (!inside && minDistance > padding) {
      return null;
    }
    return {
      inside,
      distance: inside ? 0 : minDistance,
      depth: sceneObjectDepthCenter(object, bundle.camera),
      area: Math.max(1, (bounds.maxX - bounds.minX) * (bounds.maxY - bounds.minY)),
    };
  }

  function scenePointerCaptureIsBetter(candidate, current) {
    if (!current) {
      return true;
    }
    if (candidate.inside !== current.inside) {
      return candidate.inside;
    }
    if (Math.abs(candidate.distance - current.distance) > 0.5) {
      return candidate.distance < current.distance;
    }
    if (Math.abs(candidate.depth - current.depth) > 0.01) {
      return candidate.depth < current.depth;
    }
    return candidate.area < current.area;
  }

  function sceneRaycastPick(pointerX, pointerY, width, height, camera, bundle) {
    if (!bundle) {
      return null;
    }

    var ray = sceneScreenToRay(pointerX, pointerY, width, height, camera);
    var closest = sceneRaycastPickGroup(ray, bundle.meshObjects, bundle.worldMeshPositions, 0);
    if (closest) {
      return closest;
    }
    return sceneRaycastPickGroup(ray, bundle.objects, bundle.worldPositions, 0);
  }

  function sceneRaycastPickGroup(ray, objects, positions, indexOffset) {
    if (!Array.isArray(objects) || !objects.length || !positions || typeof positions.length !== "number") {
      return null;
    }
    var closest = null;
    var safeIndexOffset = Math.max(0, Math.floor(sceneNumber(indexOffset, 0)));

    for (var i = 0; i < objects.length; i++) {
      var obj = objects[i];

      if (!sceneObjectAllowsPointerPick(obj)) continue;
      if (obj.viewCulled) continue;

      var bounds = obj.bounds;
      if (!bounds) continue;

      var boundsMin = { x: sceneNumber(bounds.minX, 0), y: sceneNumber(bounds.minY, 0), z: sceneNumber(bounds.minZ, 0) };
      var boundsMax = { x: sceneNumber(bounds.maxX, 0), y: sceneNumber(bounds.maxY, 0), z: sceneNumber(bounds.maxZ, 0) };

      var aabbDist = sceneRayIntersectsAABB(ray.origin, ray.dir, boundsMin, boundsMax);
      if (aabbDist < 0) continue;

      var vertexOffset = Math.max(0, Math.floor(sceneNumber(obj.vertexOffset, 0)));
      var vertexCount = Math.max(0, Math.floor(sceneNumber(obj.vertexCount, 0)));

      for (var tri = 0; tri + 2 < vertexCount; tri += 3) {
        var v0 = sceneWorldPointAt(positions, vertexOffset + tri);
        var v1 = sceneWorldPointAt(positions, vertexOffset + tri + 1);
        var v2 = sceneWorldPointAt(positions, vertexOffset + tri + 2);
        if (!v0 || !v1 || !v2) continue;

        var hit = sceneRayIntersectsTriangle(ray.origin, ray.dir, v0, v1, v2);
        if (hit && (!closest || hit.distance < closest.distance)) {
          closest = {
            index: safeIndexOffset + i,
            object: obj,
            distance: hit.distance,
            inside: true,
            depth: hit.distance,
            area: Math.max(1, (boundsMax.x - boundsMin.x) * (boundsMax.y - boundsMin.y)),
            point: {
              x: ray.origin.x + ray.dir.x * hit.distance,
              y: ray.origin.y + ray.dir.y * hit.distance,
              z: ray.origin.z + ray.dir.z * hit.distance,
            },
          };
        }
      }
    }

    return closest;
  }

  function sceneBundlePointerTarget(bundle, point, width, height, allowObject) {
    if (!bundle || !bundle.camera || !Array.isArray(bundle.objects) || !bundle.objects.length) {
      return null;
    }
    let best = null;
    for (let index = 0; index < bundle.objects.length; index += 1) {
      const object = bundle.objects[index];
      if (typeof allowObject === "function" && !allowObject(object)) {
        continue;
      }
      const capture = sceneObjectPointerCapture(bundle, object, point, width, height);
      if (!capture) {
        continue;
      }
      const candidate = {
        index,
        object,
        inside: capture.inside,
        distance: capture.distance,
        depth: capture.depth,
        area: capture.area,
      };
      if (scenePointerCaptureIsBetter(candidate, best)) {
        best = candidate;
      }
    }
    return best;
  }

  function sceneBundlePointerDragTarget(bundle, point, width, height) {
    return sceneBundlePointerTarget(bundle, point, width, height, sceneObjectAllowsPointerDrag);
  }

  function sceneBundlePointerPickTarget(bundle, point, width, height) {
    if (bundle && bundle.camera && bundle.worldPositions) {
      var rayHit = sceneRaycastPick(point.x, point.y, width, height, bundle.camera, bundle);
      if (rayHit) {
        return rayHit;
      }
    }
    return sceneBundlePointerTarget(bundle, point, width, height, sceneObjectAllowsPointerPick);
  }

  function sceneViewportValue(viewport, key, fallback) {
    return sceneNumber(viewport && viewport[key], fallback);
  }

  function sceneDragViewportMetrics(readViewport, initialWidth, initialHeight) {
    const viewport = typeof readViewport === "function" ? readViewport() : null;
    return {
      width: Math.max(1, sceneViewportValue(viewport, "cssWidth", initialWidth)),
      height: Math.max(1, sceneViewportValue(viewport, "cssHeight", initialHeight)),
    };
  }

  function createSceneDragState(initialWidth, initialHeight) {
    return {
      active: false,
      orbitX: 0,
      orbitY: 0,
      pointerId: null,
      targetIndex: -1,
      lastX: initialWidth / 2,
      lastY: initialHeight / 2,
    };
  }

  function createScenePickState(initialWidth, initialHeight) {
    return {
      pointerId: null,
      hoverIndex: -1,
      hoverID: "",
      hoverKind: "",
      downIndex: -1,
      downID: "",
      downKind: "",
      selectedIndex: -1,
      selectedID: "",
      selectedKind: "",
      clickCount: 0,
      pointerX: initialWidth / 2,
      pointerY: initialHeight / 2,
      eventRevision: 0,
      eventType: "",
      eventTargetIndex: -1,
      eventTargetID: "",
      eventTargetKind: "",
      publishedKey: "",
      publishedEventKey: "",
      publishedHoverSlug: "",
      publishedDownSlug: "",
      publishedSelectedSlug: "",
      objectClickCounts: Object.create(null),
      publishedObjectClickCounts: Object.create(null),
    };
  }

  function sceneDragMatchesActivePointer(state, event) {
    if (!state.active || state.pointerId == null) {
      return state.active;
    }
    if (!event || event.type === "lostpointercapture") {
      return true;
    }
    if (event.pointerId == null) {
      return true;
    }
    return event.pointerId === state.pointerId;
  }

  function scenePointerCanStartDrag(state, event) {
    if (state.active) {
      return false;
    }
    if (!event) {
      return false;
    }
    if (event.pointerType === "mouse") {
      return event.button === 0;
    }
    return event.button == null || event.button === 0;
  }

  function sceneDragTargetAtEvent(event, canvas, readViewport, readSceneBundle, initialWidth, initialHeight) {
    const metrics = sceneDragViewportMetrics(readViewport, initialWidth, initialHeight);
    const pointer = sceneLocalPointerPoint(event, canvas, metrics.width, metrics.height);
    return sceneBundlePointerDragTarget(readSceneBundle && readSceneBundle(), pointer, metrics.width, metrics.height);
  }

  function scenePickMetricsAtEvent(event, canvas, readViewport, initialWidth, initialHeight) {
    const metrics = sceneDragViewportMetrics(readViewport, initialWidth, initialHeight);
    return {
      metrics,
      pointer: sceneLocalPointerPoint(event, canvas, metrics.width, metrics.height),
    };
  }

  function scenePickTargetAtEvent(event, canvas, readViewport, readSceneBundle, initialWidth, initialHeight) {
    const sample = scenePickMetricsAtEvent(event, canvas, readViewport, initialWidth, initialHeight);
    return {
      metrics: sample.metrics,
      pointer: sample.pointer,
      target: sceneBundlePointerPickTarget(readSceneBundle && readSceneBundle(), sample.pointer, sample.metrics.width, sample.metrics.height),
    };
  }

  function updateSceneDragOrbit(state, sample, width, height) {
    state.orbitX = sceneClamp(state.orbitX + sample.deltaX / Math.max(width / 2, 1), SCENE_ORBIT_PITCH_MIN, SCENE_ORBIT_PITCH_MAX);
    state.orbitY = sceneClamp(state.orbitY - sample.deltaY / Math.max(height / 2, 1), SCENE_ORBIT_YAW_MIN, SCENE_ORBIT_YAW_MAX);
  }

  function publishSceneDragInteraction(canvas, event, phase, state, dragNamespace, readViewport, initialWidth, initialHeight) {
    const metrics = sceneDragViewportMetrics(readViewport, initialWidth, initialHeight);
    const sample = sceneLocalPointerSample(event, canvas, metrics.width, metrics.height, state, phase);
    if (!dragNamespace) {
      publishPointerSignals(sample);
      return;
    }
    if (phase === "move") {
      updateSceneDragOrbit(state, sample, metrics.width, metrics.height);
    }
    publishSceneDragSignals(dragNamespace, state, phase !== "end");
  }

  function resetSceneDragInteraction(state, dragNamespace, readViewport, initialWidth, initialHeight) {
    state.pointerId = null;
    state.targetIndex = -1;
    if (dragNamespace) {
      return;
    }
    const metrics = sceneDragViewportMetrics(readViewport, initialWidth, initialHeight);
    resetScenePointerSample(metrics.width, metrics.height, state);
  }

  function scenePrimaryPointerEvent(event) {
    if (!event) {
      return false;
    }
    if (event.pointerType === "mouse") {
      return event.button === 0 || event.button == null;
    }
    return event.button == null || event.button === 0;
  }

  function scenePickMatchesPointer(state, event) {
    if (state.pointerId == null) {
      return true;
    }
    if (!event || event.type === "lostpointercapture") {
      return true;
    }
    if (event.pointerId == null) {
      return true;
    }
    return event.pointerId === state.pointerId;
  }

  function sceneApplyPickTarget(state, sample) {
    const target = sample && sample.target ? sample.target : null;
    const pointer = sample && sample.pointer ? sample.pointer : { x: 0, y: 0 };
    state.pointerX = sceneNumber(pointer.x, 0);
    state.pointerY = sceneNumber(pointer.y, 0);
    state.hoverIndex = target ? target.index : -1;
    state.hoverID = sceneTargetID(target);
    state.hoverKind = sceneTargetKind(target);
    return target;
  }

  function sceneClearPickDown(state) {
    state.pointerId = null;
    state.downIndex = -1;
    state.downID = "";
    state.downKind = "";
  }

  function sceneSelectPickTarget(state, target) {
    state.selectedIndex = target ? target.index : -1;
    state.selectedID = sceneTargetID(target);
    state.selectedKind = sceneTargetKind(target);
  }

  function scenePickTargetsMatch(target, index, id) {
    if (!target) {
      return false;
    }
    const targetID = target.object && typeof target.object.id === "string" ? target.object.id : "";
    return target.index === index && targetID === id;
  }

  function scenePointerID(event) {
    return event && event.pointerId != null ? event.pointerId : null;
  }

  function sceneCapturePointer(canvas, pointerID) {
    if (pointerID == null || !canvas || typeof canvas.setPointerCapture !== "function") {
      return;
    }
    try {
      canvas.setPointerCapture(pointerID);
    } catch (_) {}
  }

  function sceneReleasePointer(canvas, pointerID) {
    if (pointerID == null || !canvas || typeof canvas.releasePointerCapture !== "function") {
      return;
    }
    try {
      canvas.releasePointerCapture(pointerID);
    } catch (_) {}
  }

  function sceneSnapshotTarget(index, id, kind) {
    const targetIndex = Math.max(-1, Math.floor(sceneNumber(index, -1)));
    const targetID = typeof id === "string" ? id : "";
    const targetKind = typeof kind === "string" ? kind : "";
    if (targetIndex < 0 && !targetID && !targetKind) {
      return null;
    }
    return {
      index: targetIndex,
      object: {
        id: targetID,
        kind: targetKind,
      },
    };
  }

  function scenePickStateSnapshot(state) {
    return {
      hover: sceneSnapshotTarget(state.hoverIndex, state.hoverID, state.hoverKind),
      down: sceneSnapshotTarget(state.downIndex, state.downID, state.downKind),
      selected: sceneSnapshotTarget(state.selectedIndex, state.selectedID, state.selectedKind),
      clickCount: Math.max(0, Math.floor(sceneNumber(state.clickCount, 0))),
      pointerX: sceneNumber(state.pointerX, 0),
      pointerY: sceneNumber(state.pointerY, 0),
    };
  }

  function sceneTargetsEqual(left, right) {
    if (!left || !right) {
      return left === right;
    }
    return sceneTargetIndex(left) === sceneTargetIndex(right) &&
      sceneTargetID(left) === sceneTargetID(right) &&
      sceneTargetKind(left) === sceneTargetKind(right);
  }

  function sceneDeriveInteractionEvent(action, before, after) {
    switch (action) {
      case "move":
        if (!sceneTargetsEqual(before.hover, after.hover)) {
          return after.hover ? { type: "hover", target: after.hover } : before.hover ? { type: "leave", target: before.hover } : null;
        }
        return null;
      case "down":
        if (after.down) {
          return { type: "down", target: after.down };
        }
        if (before.selected && !after.selected) {
          return { type: "deselect", target: before.selected };
        }
        return null;
      case "up":
        if (after.selected && (!sceneTargetsEqual(before.selected, after.selected) || after.clickCount !== before.clickCount)) {
          return { type: "select", target: after.selected };
        }
        if (before.selected && !after.selected) {
          return { type: "deselect", target: before.selected };
        }
        return null;
      case "cancel":
        return before.down ? { type: "cancel", target: before.down } : null;
      case "leave":
        return before.hover && !after.hover ? { type: "leave", target: before.hover } : null;
      default:
        return null;
    }
  }

  function sceneRecordInteractionEvent(state, interaction) {
    if (!state || !interaction || !interaction.type) {
      return null;
    }
    state.eventRevision = Math.max(0, Math.floor(sceneNumber(state.eventRevision, 0))) + 1;
    state.eventType = interaction.type;
    state.eventTargetIndex = sceneTargetIndex(interaction.target);
    state.eventTargetID = sceneTargetID(interaction.target);
    state.eventTargetKind = sceneTargetKind(interaction.target);
    const detail = sceneInteractionSnapshot(state);
    return {
      type: detail.type,
      revision: detail.revision,
      targetIndex: detail.targetIndex,
      targetID: detail.targetID,
      targetKind: detail.targetKind,
      hovered: detail.hovered,
      hoverIndex: detail.hoverIndex,
      hoverID: detail.hoverID,
      hoverKind: detail.hoverKind,
      down: detail.down,
      downIndex: detail.downIndex,
      downID: detail.downID,
      downKind: detail.downKind,
      selected: detail.selected,
      selectedIndex: detail.selectedIndex,
      selectedID: detail.selectedID,
      selectedKind: detail.selectedKind,
      clickCount: detail.clickCount,
      pointerX: detail.pointerX,
      pointerY: detail.pointerY,
    };
  }

  function publishSceneInteractionState(pickNamespace, eventNamespace, state) {
    publishScenePickSignals(pickNamespace, state);
    publishSceneEventSignals(eventNamespace, state);
  }

  function sceneHandlePickMove(state, event, canvas, readViewport, readSceneBundle, initialWidth, initialHeight) {
    if (!scenePickMatchesPointer(state, event)) {
      return false;
    }
    sceneApplyPickTarget(state, scenePickTargetAtEvent(event, canvas, readViewport, readSceneBundle, initialWidth, initialHeight));
    return true;
  }

  function sceneHandlePickDown(state, event, canvas, readViewport, readSceneBundle, initialWidth, initialHeight) {
    if (!scenePrimaryPointerEvent(event)) {
      return false;
    }
    const sample = scenePickTargetAtEvent(event, canvas, readViewport, readSceneBundle, initialWidth, initialHeight);
    const target = sceneApplyPickTarget(state, sample);
    if (!target) {
      sceneClearPickDown(state);
      sceneSelectPickTarget(state, null);
      return false;
    }
    state.pointerId = scenePointerID(event);
    state.downIndex = target.index;
    state.downID = sceneTargetID(target);
    state.downKind = sceneTargetKind(target);
    return true;
  }

  function sceneHandlePickUp(state, event, canvas, readViewport, readSceneBundle, initialWidth, initialHeight) {
    if (!scenePickMatchesPointer(state, event)) {
      return { handled: false, pointerId: null };
    }
    const downIndex = state.downIndex;
    const downID = state.downID;
    const pointerID = state.pointerId;
    const sample = scenePickTargetAtEvent(event, canvas, readViewport, readSceneBundle, initialWidth, initialHeight);
    const target = sceneApplyPickTarget(state, sample);
    if (downIndex >= 0) {
      if (scenePickTargetsMatch(target, downIndex, downID)) {
        state.clickCount += 1;
        sceneSelectPickTarget(state, target);
        const selectedSlug = sceneObjectSignalSlug(state.selectedIndex, state.selectedID, state.selectedKind);
        if (selectedSlug) {
          const previousCount = state.objectClickCounts && state.objectClickCounts[selectedSlug];
          state.objectClickCounts[selectedSlug] = Math.max(0, Math.floor(sceneNumber(previousCount, 0))) + 1;
        }
      } else if (!target) {
        sceneSelectPickTarget(state, null);
      }
    }
    sceneClearPickDown(state);
    return { handled: pointerID != null || downIndex >= 0, pointerId: pointerID };
  }

  function sceneHandlePickCancel(state, event) {
    if (!scenePickMatchesPointer(state, event)) {
      return { handled: false, pointerId: null };
    }
    const pointerID = state.pointerId;
    const handled = pointerID != null || state.downIndex >= 0;
    sceneClearPickDown(state);
    return { handled, pointerId: pointerID };
  }

  function sceneHandlePickLeave(state) {
    if (state.pointerId != null) {
      return false;
    }
    state.hoverIndex = -1;
    state.hoverID = "";
    state.hoverKind = "";
    return true;
  }

  function setupSceneDragInteractions(canvas, props, readViewport, readSceneBundle) {
    if (!canvas || !sceneBool(props.dragToRotate, false)) {
      return { dispose() {} };
    }

    const dragNamespace = sceneDragSignalNamespace(props);
    const initialMetrics = sceneDragViewportMetrics(readViewport, sceneNumber(props.width, 720), sceneNumber(props.height, 420));
    const initialWidth = initialMetrics.width;
    const initialHeight = initialMetrics.height;
    const state = createSceneDragState(initialWidth, initialHeight);
    let documentListenersAttached = false;

    canvas.style.cursor = "grab";
    canvas.style.touchAction = "none";

    function attachDocumentListeners() {
      if (documentListenersAttached) {
        return;
      }
      documentListenersAttached = true;
      document.addEventListener("pointermove", onPointerMove);
      document.addEventListener("pointerup", finishDrag);
      document.addEventListener("pointercancel", finishDrag);
    }

    function detachDocumentListeners() {
      if (!documentListenersAttached) {
        return;
      }
      documentListenersAttached = false;
      document.removeEventListener("pointermove", onPointerMove);
      document.removeEventListener("pointerup", finishDrag);
      document.removeEventListener("pointercancel", finishDrag);
    }

    function onPointerDown(event) {
      if (!scenePointerCanStartDrag(state, event)) {
        return;
      }
      const target = sceneDragTargetAtEvent(event, canvas, readViewport, readSceneBundle, initialWidth, initialHeight);
      if (!target) {
        return;
      }
      state.active = true;
      state.pointerId = event.pointerId;
      state.targetIndex = target.index;
      canvas.style.cursor = "grabbing";
      attachDocumentListeners();
      if (typeof canvas.setPointerCapture === "function") {
        canvas.setPointerCapture(event.pointerId);
      }
      event.preventDefault();
      event.stopPropagation();
      publishSceneDragInteraction(canvas, event, "start", state, dragNamespace, readViewport, initialWidth, initialHeight);
    }

    function onPointerMove(event) {
      if (!sceneDragMatchesActivePointer(state, event)) {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      publishSceneDragInteraction(canvas, event, "move", state, dragNamespace, readViewport, initialWidth, initialHeight);
    }

    function finishDrag(event) {
      if (!sceneDragMatchesActivePointer(state, event)) {
        return;
      }
      const wasActive = state.active;
      state.active = false;
      canvas.style.cursor = "grab";
      detachDocumentListeners();
      if (!wasActive) {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      if (state.pointerId != null && typeof canvas.releasePointerCapture === "function") {
        try {
          canvas.releasePointerCapture(state.pointerId);
        } catch (_) {}
      }
      state.pointerId = null;
      state.targetIndex = -1;
      publishSceneDragInteraction(canvas, event, "end", state, dragNamespace, readViewport, initialWidth, initialHeight);
      resetSceneDragInteraction(state, dragNamespace, readViewport, initialWidth, initialHeight);
    }

    canvas.addEventListener("pointerdown", onPointerDown);
    canvas.addEventListener("pointermove", onPointerMove);
    canvas.addEventListener("pointerup", finishDrag);
    canvas.addEventListener("pointercancel", finishDrag);
    canvas.addEventListener("lostpointercapture", finishDrag);

    return {
      dispose() {
        canvas.removeEventListener("pointerdown", onPointerDown);
        canvas.removeEventListener("pointermove", onPointerMove);
        canvas.removeEventListener("pointerup", finishDrag);
        canvas.removeEventListener("pointercancel", finishDrag);
        canvas.removeEventListener("lostpointercapture", finishDrag);
        detachDocumentListeners();
        canvas.style.cursor = "";
        canvas.style.touchAction = "";
        if (state.active && dragNamespace) {
          state.active = false;
          state.pointerId = null;
          state.targetIndex = -1;
          publishSceneDragSignals(dragNamespace, state, false);
        } else {
          state.active = false;
        }
        resetSceneDragInteraction(state, dragNamespace, readViewport, initialWidth, initialHeight);
      },
    };
  }

  function setupScenePickInteractions(canvas, props, readViewport, readSceneBundle, emitInteraction) {
    const pickNamespace = scenePickSignalNamespace(props);
    const eventNamespace = sceneEventSignalNamespace(props);
    if (!canvas || (!pickNamespace && !eventNamespace)) {
      return { dispose() {} };
    }

    const initialMetrics = sceneDragViewportMetrics(readViewport, sceneNumber(props.width, 720), sceneNumber(props.height, 420));
    const initialWidth = initialMetrics.width;
    const initialHeight = initialMetrics.height;
    const state = createScenePickState(initialWidth, initialHeight);
    let documentListenersAttached = false;

    function publish() {
      publishSceneInteractionState(pickNamespace, eventNamespace, state);
    }

    function emit(action, before) {
      const interaction = sceneDeriveInteractionEvent(action, before, scenePickStateSnapshot(state));
      const detail = sceneRecordInteractionEvent(state, interaction);
      if (detail && typeof emitInteraction === "function") {
        emitInteraction(detail);
      }
    }

    function attachDocumentListeners() {
      if (documentListenersAttached) {
        return;
      }
      documentListenersAttached = true;
      document.addEventListener("pointermove", onPointerMove);
      document.addEventListener("pointerup", onPointerUp);
      document.addEventListener("pointercancel", onPointerCancel);
    }

    function detachDocumentListeners() {
      if (!documentListenersAttached) {
        return;
      }
      documentListenersAttached = false;
      document.removeEventListener("pointermove", onPointerMove);
      document.removeEventListener("pointerup", onPointerUp);
      document.removeEventListener("pointercancel", onPointerCancel);
    }

    function onPointerMove(event) {
      const before = scenePickStateSnapshot(state);
      if (!sceneHandlePickMove(state, event, canvas, readViewport, readSceneBundle, initialWidth, initialHeight)) {
        return;
      }
      emit("move", before);
      publish();
    }

    function onPointerDown(event) {
      const before = scenePickStateSnapshot(state);
      const handled = sceneHandlePickDown(state, event, canvas, readViewport, readSceneBundle, initialWidth, initialHeight);
      emit("down", before);
      if (handled) {
        attachDocumentListeners();
        sceneCapturePointer(canvas, state.pointerId);
        if (typeof event.preventDefault === "function") {
          event.preventDefault();
        }
        if (typeof event.stopPropagation === "function") {
          event.stopPropagation();
        }
      }
      publish();
    }

    function onPointerUp(event) {
      const before = scenePickStateSnapshot(state);
      const result = sceneHandlePickUp(state, event, canvas, readViewport, readSceneBundle, initialWidth, initialHeight);
      if (!result.handled) {
        return;
      }
      emit("up", before);
      detachDocumentListeners();
      sceneReleasePointer(canvas, result.pointerId);
      if (typeof event.preventDefault === "function") {
        event.preventDefault();
      }
      if (typeof event.stopPropagation === "function") {
        event.stopPropagation();
      }
      publish();
    }

    function onPointerCancel(event) {
      const before = scenePickStateSnapshot(state);
      const result = sceneHandlePickCancel(state, event);
      if (!result.handled) {
        return;
      }
      emit("cancel", before);
      detachDocumentListeners();
      sceneReleasePointer(canvas, result.pointerId);
      publish();
    }

    function onPointerLeave() {
      const before = scenePickStateSnapshot(state);
      if (!sceneHandlePickLeave(state)) {
        return;
      }
      emit("leave", before);
      publish();
    }

    canvas.addEventListener("pointermove", onPointerMove);
    canvas.addEventListener("pointerdown", onPointerDown);
    canvas.addEventListener("pointerup", onPointerUp);
    canvas.addEventListener("pointercancel", onPointerCancel);
    canvas.addEventListener("pointerleave", onPointerLeave);
    canvas.addEventListener("lostpointercapture", onPointerCancel);
    publish();

    return {
      dispose() {
        canvas.removeEventListener("pointermove", onPointerMove);
        canvas.removeEventListener("pointerdown", onPointerDown);
        canvas.removeEventListener("pointerup", onPointerUp);
        canvas.removeEventListener("pointercancel", onPointerCancel);
        canvas.removeEventListener("pointerleave", onPointerLeave);
        canvas.removeEventListener("lostpointercapture", onPointerCancel);
        detachDocumentListeners();
        sceneReleasePointer(canvas, state.pointerId);
        state.pointerId = null;
        state.hoverIndex = -1;
        state.hoverID = "";
        state.hoverKind = "";
        state.downIndex = -1;
        state.downID = "";
        state.downKind = "";
        state.selectedIndex = -1;
        state.selectedID = "";
        state.selectedKind = "";
        state.clickCount = 0;
        state.eventType = "";
        state.eventTargetIndex = -1;
        state.eventTargetID = "";
        state.eventTargetKind = "";
        state.objectClickCounts = Object.create(null);
        publish();
      },
    };
  }

  if (window.__gosx_scene3d_api) {
    window.__gosx_scene3d_api.sceneRaycastPick = sceneRaycastPick;
    window.__gosx_scene3d_api.sceneRaycastPickGroup = sceneRaycastPickGroup;
  }
  window.__gosx_scene3d_raycast = sceneRaycastPick;

  function createSceneCanvasLineBatch(ctx2d) {
    let active = false;
    let strokeStyle = "";
    let lineWidth = 0;
    let lineDashKey = "";
    function flush() {
      if (!active) {
        return;
      }
      ctx2d.stroke();
      active = false;
    }
    return {
      line(from, to, color, width, dash) {
        const nextStrokeStyle = color || "#8de1ff";
        const nextLineWidth = Math.max(0.1, sceneNumber(width, 1.8));
        const dashed = dash && dash.dashed;
        const dashSize = Math.max(0.1, sceneNumber(dash && dash.dashSize, nextLineWidth * 2.5));
        const gapSize = Math.max(0.1, sceneNumber(dash && dash.gapSize, dashSize));
        const nextDashKey = dashed ? (dashSize + ":" + gapSize) : "";
        if (!active || nextStrokeStyle !== strokeStyle || nextLineWidth !== lineWidth || nextDashKey !== lineDashKey) {
          flush();
          strokeStyle = nextStrokeStyle;
          lineWidth = nextLineWidth;
          lineDashKey = nextDashKey;
          ctx2d.strokeStyle = strokeStyle;
          ctx2d.lineWidth = lineWidth;
          if (typeof ctx2d.setLineDash === "function") {
            ctx2d.setLineDash(dashed ? [dashSize, gapSize] : []);
          }
          ctx2d.beginPath();
          active = true;
        }
        ctx2d.moveTo(from.x, from.y);
        ctx2d.lineTo(to.x, to.y);
      },
      flush,
    };
  }

  function sceneBundleUsesWorldProjection(bundle) {
    return Boolean(
      bundle &&
      bundle.camera &&
      bundle.sourceCamera &&
      !sceneCameraEquivalent(bundle.sourceCamera, bundle.camera) &&
      bundle.worldVertexCount > 0 &&
      bundle.worldPositions &&
      bundle.worldColors
    );
  }

  function renderSceneCanvasWorldBundle(ctx2d, bundle, width, height) {
    const positions = bundle && bundle.worldPositions;
    const colors = bundle && bundle.worldColors;
    const widths = bundle && bundle.worldLineWidths;
    const dashes = bundle && bundle.worldLineDashes;
    const dashSizes = bundle && bundle.worldLineDashSizes;
    const gapSizes = bundle && bundle.worldLineGapSizes;
    const vertexCount = Math.max(0, Math.floor(sceneNumber(bundle && bundle.worldVertexCount, 0)));
    const batch = createSceneCanvasLineBatch(ctx2d);
    for (let index = 0; index + 1 < vertexCount; index += 2) {
      const fromWorld = sceneWorldPointAt(positions, index);
      const toWorld = sceneWorldPointAt(positions, index + 1);
      if (!fromWorld || !toWorld) {
        continue;
      }
      const from = sceneProjectPoint(fromWorld, bundle.camera, width, height);
      const to = sceneProjectPoint(toWorld, bundle.camera, width, height);
      if (!from || !to) {
        continue;
      }
      const colorOffset = index * 4;
      const color = sceneRGBAString([
        sceneNumber(colors && colors[colorOffset], 0.55),
        sceneNumber(colors && colors[colorOffset + 1], 0.88),
        sceneNumber(colors && colors[colorOffset + 2], 1),
        sceneNumber(colors && colors[colorOffset + 3], 1),
      ]);
      const segmentIndex = index / 2;
      const segmentWidth = widths && segmentIndex < widths.length ? widths[segmentIndex] : 0;
      batch.line(from, to, color, segmentWidth > 0 ? segmentWidth : 1.8, {
        dashed: Boolean(dashes && dashes[segmentIndex]),
        dashSize: dashSizes && segmentIndex < dashSizes.length ? dashSizes[segmentIndex] : 0,
        gapSize: gapSizes && segmentIndex < gapSizes.length ? gapSizes[segmentIndex] : 0,
      });
    }
    batch.flush();
  }

  function createSceneCanvasRenderer(ctx2d, canvas) {
    return {
      kind: "canvas",
      render(bundle, viewport) {
        const devicePixelRatio = Math.max(1, sceneViewportValue(viewport, "devicePixelRatio", 1));
        const lines = Array.isArray(bundle && bundle.lines) ? bundle.lines : [];
        ctx2d.clearRect(0, 0, canvas.width, canvas.height);
        ctx2d.fillStyle = bundle && bundle.background ? bundle.background : "#08151f";
        ctx2d.fillRect(0, 0, canvas.width, canvas.height);
        if (typeof ctx2d.save === "function") {
          ctx2d.save();
        }
        if (devicePixelRatio !== 1 && typeof ctx2d.scale === "function") {
          ctx2d.scale(devicePixelRatio, devicePixelRatio);
        }
        if (sceneBundleUsesWorldProjection(bundle)) {
          renderSceneCanvasWorldBundle(ctx2d, bundle, sceneViewportValue(viewport, "cssWidth", canvas.width), sceneViewportValue(viewport, "cssHeight", canvas.height));
        } else {
          const batch = createSceneCanvasLineBatch(ctx2d);
          for (const line of lines) {
            batch.line(line.from, line.to, line.color, line.lineWidth, {
              dashed: Boolean(line.lineDash),
              dashSize: line.dashSize,
              gapSize: line.gapSize,
            });
          }
          batch.flush();
        }
        if (typeof ctx2d.restore === "function") {
          ctx2d.restore();
        }
      },
      dispose() {},
    };
  }

  if (typeof sceneBackendRegistry !== "undefined" && sceneBackendRegistry) {
    sceneBackendRegistry.register("canvas2d", {
      capabilities: ["canvas"],
      create: function(canvas) {
        const ctx2d = typeof canvas.getContext === "function" ? canvas.getContext("2d") : null;
        return ctx2d ? createSceneCanvasRenderer(ctx2d, canvas) : null;
      },
    });
  }

  function gosxSceneEmit(level, msg, fields) {
    try {
      if (typeof window !== "undefined" && typeof window.__gosx_emit === "function") {
        window.__gosx_emit(level, "scene3d", msg, fields || {});
      }
    } catch (_err) {
      /* telemetry must never surface to users */
    }
  }

  function sceneReadWebGLRendererMetadata(gl) {
    if (!gl || typeof gl.getParameter !== "function") {
      return { vendor: "", renderer: "" };
    }
    let vendor = "";
    let renderer = "";
    try {
      const debugInfo = typeof gl.getExtension === "function"
        ? gl.getExtension("WEBGL_debug_renderer_info")
        : null;
      if (debugInfo) {
        vendor = String(gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) || "");
        renderer = String(gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || "");
      }
    } catch (_error) {
      vendor = "";
      renderer = "";
    }
    if (!vendor) {
      try {
        vendor = String(gl.getParameter(gl.VENDOR) || "");
      } catch (_error) {
        vendor = "";
      }
    }
    if (!renderer) {
      try {
        renderer = String(gl.getParameter(gl.RENDERER) || "");
      } catch (_error) {
        renderer = "";
      }
    }
    return {
      vendor: vendor.trim(),
      renderer: renderer.trim(),
    };
  }

  function sceneWebGLRendererLooksSoftware(metadata) {
    const vendor = metadata && typeof metadata.vendor === "string" ? metadata.vendor : "";
    const renderer = metadata && typeof metadata.renderer === "string" ? metadata.renderer : "";
    const text = (vendor + " " + renderer).trim().toLowerCase();
    if (!text) {
      return false;
    }
    return text.indexOf("swiftshader") !== -1
      || text.indexOf("llvmpipe") !== -1
      || text.indexOf("softpipe") !== -1
      || text.indexOf("lavapipe") !== -1
      || text.indexOf("software") !== -1
      || text.indexOf("microsoft basic render") !== -1
      || text.indexOf("basic render driver") !== -1;
  }

  function sceneProbeWebGLRenderer() {
    if (typeof window === "undefined" || typeof document === "undefined" || !document || typeof document.createElement !== "function") {
      return { available: false, software: false, vendor: "", renderer: "" };
    }
    window.__gosx = window.__gosx || {};
    if (window.__gosx.scene3dWebGLProbe) {
      return window.__gosx.scene3dWebGLProbe;
    }
    const probeCanvas = document.createElement("canvas");
    let gl = null;
    try {
      if (probeCanvas && typeof probeCanvas.getContext === "function") {
        const probeOptions = {
          alpha: false,
          antialias: false,
          preserveDrawingBuffer: false,
          powerPreference: "low-power",
        };
        gl =
          probeCanvas.getContext("webgl2", probeOptions) ||
          probeCanvas.getContext("webgl", probeOptions) ||
          probeCanvas.getContext("experimental-webgl", probeOptions);
      }
      const metadata = sceneReadWebGLRendererMetadata(gl);
      window.__gosx.scene3dWebGLProbe = {
        available: Boolean(gl),
        software: sceneWebGLRendererLooksSoftware(metadata),
        vendor: metadata.vendor,
        renderer: metadata.renderer,
      };
    } catch (_error) {
      window.__gosx.scene3dWebGLProbe = { available: false, software: false, vendor: "", renderer: "" };
    }
    return window.__gosx.scene3dWebGLProbe;
  }

  function sceneRequiresWebGL(props) {
    return sceneBool(props && props.requireWebGL, false);
  }

  function sceneWebGPUOptions(props, capability) {
    const caps = capability && typeof capability === "object" ? capability : {};
    const requestedSamples = Math.max(0, Math.floor(sceneNumber(props && props.msaaSamples, 0)));
    const tierAllowsMSAA = caps.tier === "full" && !caps.lowPower && !caps.reducedData;
    const antialias = requestedSamples > 1
      ? true
      : sceneBool(props && props.antialias, tierAllowsMSAA);
    return {
      antialias,
      msaaSamples: requestedSamples > 1 ? 4 : (antialias ? 4 : 1),
      powerPreference: sceneWebGPUPowerPreference(props && (props.webgpuPowerPreference || props.webGPUPowerPreference || props.webgpuAdapterPowerPreference || props.webGPUAdapterPowerPreference)),
      presentation: sceneWebGPUPresentationOptions(props),
    };
  }

  function sceneWebGPUPresentationOptions(props) {
    const alphaMode = sceneWebGPUAlphaMode(props && (props.webgpuAlphaMode || props.webGPUAlphaMode || props.webgpuCanvasAlphaMode || props.webGPUCanvasAlphaMode));
    const colorSpace = sceneWebGPUColorSpace(props && (props.webgpuColorSpace || props.webGPUColorSpace));
    const toneMappingMode = sceneWebGPUToneMappingMode(props && (props.webgpuToneMapping || props.webGPUToneMapping || props.webgpuToneMappingMode || props.webGPUToneMappingMode));
    return {
      alphaMode,
      colorSpace,
      toneMappingMode,
    };
  }

  function sceneWebGPUAlphaMode(value) {
    const normalized = String(value || "").trim().toLowerCase();
    if (normalized === "opaque" || normalized === "premultiplied") {
      return normalized;
    }
    return "premultiplied";
  }

  function sceneWebGPUColorSpace(value) {
    const normalized = String(value || "").trim().toLowerCase();
    if (normalized === "display-p3" || normalized === "srgb") {
      return normalized;
    }
    return "srgb";
  }

  function sceneWebGPUToneMappingMode(value) {
    const normalized = String(value || "").trim().toLowerCase();
    if (normalized === "extended" || normalized === "standard") {
      return normalized;
    }
    return "";
  }

  function sceneWebGPUPowerPreference(value) {
    const normalized = String(value || "").trim().toLowerCase();
    if (normalized === "high-performance" || normalized === "low-power") {
      return normalized;
    }
    return "";
  }

  function sceneWebGPUUnsupportedLineStyle(entry) {
    if (!entry || typeof entry !== "object") {
      return false;
    }
    const material = entry.material && typeof entry.material === "object" ? entry.material : null;
    const materialKind = String(entry.materialKind || entry.kind || material && material.kind || "").toLowerCase();
    return entry.lineDash === true ||
      material && material.lineDash === true ||
      materialKind === "line-dashed" ||
      materialKind === "dashed";
  }

  function sceneWebGPUUnsupportedLineCollection(list) {
    if (!Array.isArray(list)) {
      return false;
    }
    for (let i = 0; i < list.length; i += 1) {
      const entry = list[i];
      if (!entry || typeof entry !== "object") {
        continue;
      }
      if (sceneWebGPUUnsupportedLineStyle(entry)) {
        return true;
      }
      if (Array.isArray(entry.children) && sceneWebGPUUnsupportedLineCollection(entry.children)) {
        return true;
      }
    }
    return false;
  }

  function sceneWebGPUUnsupportedLineBundle(source) {
    const dashes = source && source.worldLineDashes;
    if (dashes && typeof dashes.length === "number") {
      for (let i = 0; i < dashes.length; i += 1) {
        if (dashes[i]) {
          return true;
        }
      }
    }
    return false;
  }

  function sceneWebGPUFeatureGap(source) {
    const root = source && typeof source === "object" ? source : {};
    const scene = root.scene && typeof root.scene === "object" ? root.scene : null;
    const candidates = scene ? [root, scene] : [root];
    if (sceneWebGPUUnsupportedLineBundle(root)) {
      return "line-styles";
    }
    for (let i = 0; i < candidates.length; i += 1) {
      const item = candidates[i] || {};
      if (
        sceneWebGPUUnsupportedLineCollection(item.lines) ||
        sceneWebGPUUnsupportedLineCollection(item.objects)
      ) {
        return "line-styles";
      }
    }
    return "";
  }

  function sceneNeedsWebGLForWebGPUCoverage(source) {
    return sceneWebGPUFeatureGap(source) !== "";
  }

  function createSceneRenderer(canvas, props, capability) {
    const registryResult = createSceneRendererFromRegistry(canvas, props, capability);
    if (registryResult) {
      return registryResult;
    }

    const webglPreference = sceneCapabilityWebGLPreference(props, capability);
    const webgpuFeatureGap = sceneNeedsWebGLForWebGPUCoverage(props);
    if (webglPreference === "prefer" || webglPreference === "force") {
      if (!webgpuFeatureGap && webglPreference !== "force" && typeof sceneWebGPUAvailable === "function" && sceneWebGPUAvailable()) {
        var gpuRenderer = createSceneWebGPURendererOrFallback(canvas, sceneWebGPUOptions(props, capability));
        if (gpuRenderer) {
          return {
            renderer: gpuRenderer,
            fallbackReason: "",
          };
        }
      }
      if (typeof createScenePBRRendererOrFallback === "function") {
        const useCanvasAlpha = sceneCanvasAlpha(props);
        const gl = typeof canvas.getContext === "function" ? canvas.getContext("webgl2", {
          alpha: useCanvasAlpha,
          premultipliedAlpha: useCanvasAlpha,
          antialias: capability.tier === "full" && !capability.lowPower && !capability.reducedData,
          powerPreference: capability.lowPower || capability.tier === "constrained" ? "low-power" : "high-performance",
        }) : null;
        if (gl) {
          const pbrRenderer = createScenePBRRendererOrFallback(gl, canvas, {});
          if (pbrRenderer) {
            return {
              renderer: pbrRenderer,
              fallbackReason: webgpuFeatureGap ? "webgpu-feature-gap" : "",
            };
          }
        }
      }
      const webglRenderer = createSceneWebGLRenderer(canvas, {
        antialias: capability.tier === "full" && !capability.lowPower && !capability.reducedData,
        powerPreference: capability.lowPower || capability.tier === "constrained" ? "low-power" : "high-performance",
      });
      if (webglRenderer) {
        return {
          renderer: webglRenderer,
          fallbackReason: webgpuFeatureGap ? "webgpu-feature-gap" : "",
        };
      }
    }
    if (sceneRequiresWebGL(props)) {
      return null;
    }
    const ctx2d = typeof canvas.getContext === "function" ? canvas.getContext("2d") : null;
    if (!ctx2d) {
      return null;
    }
    return {
      renderer: createSceneCanvasRenderer(ctx2d, canvas),
      fallbackReason: sceneRendererFallbackReason(props, capability, "canvas"),
    };
  }

  function createSceneRendererFromRegistry(canvas, props, capability) {
    if (typeof sceneBackendRegistry === "undefined" || !sceneBackendRegistry || typeof sceneBackendRegistry.candidates !== "function") {
      return null;
    }
    const webglPreference = sceneCapabilityWebGLPreference(props, capability);
    const requireWebGL = sceneRequiresWebGL(props);
    const webgpuFeatureGap = sceneNeedsWebGLForWebGPUCoverage(props);
    const request = {
      props,
      capability,
      webgpu: webglPreference === "prefer" && !webgpuFeatureGap,
      webgl: webglPreference === "prefer" || webglPreference === "force",
      webgl2: webglPreference === "prefer" || webglPreference === "force",
      canvas2d: !requireWebGL,
      preferWebGPU: webglPreference === "prefer" && !webgpuFeatureGap,
      forceWebGL: webglPreference === "force",
    };
    const candidates = sceneBackendRegistry.candidates(request);
    for (const entry of candidates) {
      if (!entry || typeof entry.create !== "function") {
        continue;
      }
      const renderer = entry.create(canvas, props, capability);
      if (renderer) {
        return {
          renderer,
          fallbackReason: entry.kind === "canvas2d" || renderer.kind === "canvas"
            ? sceneRendererFallbackReason(props, capability, "canvas")
            : (webgpuFeatureGap && renderer.kind === "webgl" ? "webgpu-feature-gap" : ""),
        };
      }
    }
    return null;
  }

  const sceneModelAssetCache = new Map();

  function resolveSceneModelAssetURL(baseSrc, value) {
    const raw = typeof value === "string" ? value.trim() : "";
    if (!raw) {
      return "";
    }
    try {
      const baseURL = new URL(baseSrc || "", window.location.href).toString();
      return new URL(raw, baseURL).toString();
    } catch (_error) {
      return raw;
    }
  }

  function resolveSceneModelObjectURLs(baseSrc, rawObject) {
    if (!rawObject || typeof rawObject !== "object") {
      return rawObject;
    }
    const resolved = Object.assign({}, rawObject);
    if (typeof resolved.texture === "string" && resolved.texture.trim()) {
      resolved.texture = resolveSceneModelAssetURL(baseSrc, resolved.texture);
    }
    if (resolved.material && typeof resolved.material === "object") {
      const material = Object.assign({}, resolved.material);
      if (typeof material.texture === "string" && material.texture.trim()) {
        material.texture = resolveSceneModelAssetURL(baseSrc, material.texture);
      }
      resolved.material = material;
    }
    return resolved;
  }

  function sceneModelTransformPoint(point, model) {
    const local = point && typeof point === "object" ? point : { x: 0, y: 0, z: 0 };
    const scaleX = sceneNumber(model && model.scaleX, 1);
    const scaleY = sceneNumber(model && model.scaleY, 1);
    const scaleZ = sceneNumber(model && model.scaleZ, 1);
    const rotated = sceneRotatePoint(
      {
        x: local.x * scaleX,
        y: local.y * scaleY,
        z: local.z * scaleZ,
      },
      sceneNumber(model && model.rotationX, 0),
      sceneNumber(model && model.rotationY, 0),
      sceneNumber(model && model.rotationZ, 0),
    );
    return {
      x: rotated.x + sceneNumber(model && model.x, 0),
      y: rotated.y + sceneNumber(model && model.y, 0),
      z: rotated.z + sceneNumber(model && model.z, 0),
    };
  }

  function sceneModelTransformVector(point, model) {
    const local = point && typeof point === "object" ? point : { x: 0, y: 0, z: 0 };
    return sceneRotatePoint(
      {
        x: local.x * sceneNumber(model && model.scaleX, 1),
        y: local.y * sceneNumber(model && model.scaleY, 1),
        z: local.z * sceneNumber(model && model.scaleZ, 1),
      },
      sceneNumber(model && model.rotationX, 0),
      sceneNumber(model && model.rotationY, 0),
      sceneNumber(model && model.rotationZ, 0),
    );
  }

  function sceneModelMaxScale(model) {
    return Math.max(
      Math.abs(sceneNumber(model && model.scaleX, 1)),
      Math.abs(sceneNumber(model && model.scaleY, 1)),
      Math.abs(sceneNumber(model && model.scaleZ, 1)),
    );
  }

  function sceneModelRotateDirection(point, model) {
    return sceneRotatePoint(
      point && typeof point === "object" ? point : { x: 0, y: 0, z: 0 },
      sceneNumber(model && model.rotationX, 0),
      sceneNumber(model && model.rotationY, 0),
      sceneNumber(model && model.rotationZ, 0),
    );
  }

  function sceneModelTransformMatrix(model) {
    const rx = sceneNumber(model && model.rotationX, 0);
    const ry = sceneNumber(model && model.rotationY, 0);
    const rz = sceneNumber(model && model.rotationZ, 0);
    const basisX = sceneRotatePoint({ x: sceneNumber(model && model.scaleX, 1), y: 0, z: 0 }, rx, ry, rz);
    const basisY = sceneRotatePoint({ x: 0, y: sceneNumber(model && model.scaleY, 1), z: 0 }, rx, ry, rz);
    const basisZ = sceneRotatePoint({ x: 0, y: 0, z: sceneNumber(model && model.scaleZ, 1) }, rx, ry, rz);
    return new Float32Array([
      basisX.x, basisX.y, basisX.z, 0,
      basisY.x, basisY.y, basisY.z, 0,
      basisZ.x, basisZ.y, basisZ.z, 0,
      sceneNumber(model && model.x, 0), sceneNumber(model && model.y, 0), sceneNumber(model && model.z, 0), 1,
    ]);
  }

  function sceneModelIdentityBindMatrices(jointCount) {
    const matrices = new Float32Array(Math.max(0, jointCount) * 16);
    for (let index = 0; index < jointCount; index += 1) {
      matrices[index * 16] = 1;
      matrices[index * 16 + 5] = 1;
      matrices[index * 16 + 10] = 1;
      matrices[index * 16 + 15] = 1;
    }
    return matrices;
  }

  function sceneCloneModelSkin(skin) {
    if (!skin || typeof skin !== "object") {
      return null;
    }
    const joints = Array.isArray(skin.joints) ? skin.joints.slice() : [];
    if (!joints.length || joints.length > 64) {
      return null;
    }
    let inverseBindMatrices = skin.inverseBindMatrices instanceof Float32Array
      ? new Float32Array(skin.inverseBindMatrices)
      : sceneTypedFloatArray(skin.inverseBindMatrices);
    if (inverseBindMatrices.length < joints.length * 16) {
      inverseBindMatrices = sceneModelIdentityBindMatrices(joints.length);
    } else if (inverseBindMatrices.length !== joints.length * 16) {
      inverseBindMatrices = inverseBindMatrices.slice(0, joints.length * 16);
    }
    return {
      index: typeof skin.index === "number" ? skin.index : null,
      name: typeof skin.name === "string" ? skin.name : "",
      joints,
      inverseBindMatrices,
      skeleton: skin.skeleton != null ? skin.skeleton : null,
    };
  }

  function sceneCloneModelSkins(skins) {
    return Array.isArray(skins) ? skins.map(sceneCloneModelSkin) : [];
  }

  function sceneCloneModelAnimations(animations) {
    if (!Array.isArray(animations)) {
      return [];
    }
    return animations.map(function(clip, index) {
      const source = clip && typeof clip === "object" ? clip : {};
      const channels = Array.isArray(source.channels) ? source.channels.map(function(channel) {
        const ch = channel && typeof channel === "object" ? channel : {};
        return {
          targetID: ch.targetID != null ? ch.targetID : ch.targetNode,
          targetNode: ch.targetNode != null ? ch.targetNode : ch.targetID,
          property: typeof ch.property === "string" ? ch.property : "translation",
          interpolation: typeof ch.interpolation === "string" && ch.interpolation ? ch.interpolation : "LINEAR",
          times: ch.times instanceof Float32Array ? new Float32Array(ch.times) : sceneTypedFloatArray(ch.times),
          values: ch.values instanceof Float32Array ? new Float32Array(ch.values) : sceneTypedFloatArray(ch.values),
        };
      }) : [];
      return {
        name: typeof source.name === "string" && source.name ? source.name : ("clip-" + index),
        duration: sceneNumber(source.duration, 0),
        channels,
      };
    });
  }

  function sceneModelMaterialOverrideSource(model) {
    if (!model || typeof model !== "object") {
      return null;
    }
    if (model.materialOverride && typeof model.materialOverride === "object") {
      return model.materialOverride;
    }
    const keys = ["materialKind", "color", "texture", "opacity", "emissive", "blendMode", "renderPass", "wireframe", "roughness", "metalness", "clearcoat", "sheen", "transmission", "iridescence", "anisotropy"];
    for (let index = 0; index < keys.length; index += 1) {
      if (Object.prototype.hasOwnProperty.call(model, keys[index])) {
        return model;
      }
    }
    return null;
  }

  function sceneAssignMaterialOverride(next, material, sourceKey, targetKey, override) {
    if (!override || !Object.prototype.hasOwnProperty.call(override, sourceKey)) {
      return;
    }
    const key = targetKey || sourceKey;
    next[key] = override[sourceKey];
    if (material) {
      material[key] = override[sourceKey];
    }
  }

  function sceneApplyMaterialOverride(raw, model) {
    const override = sceneModelMaterialOverrideSource(model);
    if (!override) {
      return raw && typeof raw === "object" ? Object.assign({}, raw) : {};
    }
    const next = raw && typeof raw === "object" ? Object.assign({}, raw) : {};
    const material = next.material && typeof next.material === "object"
      ? Object.assign({}, next.material)
      : null;
    if (typeof override.materialKind === "string" && override.materialKind) {
      next.materialKind = override.materialKind;
      if (typeof next.material === "string") {
        next.material = override.materialKind;
      }
      if (material) {
        material.kind = override.materialKind;
      }
    }
    sceneAssignMaterialOverride(next, material, "color", "color", override);
    sceneAssignMaterialOverride(next, material, "texture", "texture", override);
    sceneAssignMaterialOverride(next, material, "opacity", "opacity", override);
    sceneAssignMaterialOverride(next, material, "emissive", "emissive", override);
    sceneAssignMaterialOverride(next, material, "blendMode", "blendMode", override);
    sceneAssignMaterialOverride(next, material, "renderPass", "renderPass", override);
    sceneAssignMaterialOverride(next, material, "wireframe", "wireframe", override);
    sceneAssignMaterialOverride(next, material, "roughness", "roughness", override);
    sceneAssignMaterialOverride(next, material, "metalness", "metalness", override);
    sceneAssignMaterialOverride(next, material, "clearcoat", "clearcoat", override);
    sceneAssignMaterialOverride(next, material, "sheen", "sheen", override);
    sceneAssignMaterialOverride(next, material, "transmission", "transmission", override);
    sceneAssignMaterialOverride(next, material, "iridescence", "iridescence", override);
    sceneAssignMaterialOverride(next, material, "anisotropy", "anisotropy", override);
    if (material) {
      next.material = material;
    }
    return next;
  }

  function sceneApplyModelLOD(instanced, model) {
    if (!instanced || !model || !model.lodGroup) {
      return;
    }
    instanced.lodGroup = model.lodGroup;
    instanced.lodLevel = model.lodLevel;
    instanced.lodMinDistance = model.lodMinDistance;
    instanced.lodMaxDistance = model.lodMaxDistance;
  }

  function sceneModelPrimitiveObject(object, model, prefix) {
    const instanced = Object.assign({}, object, {
      id: prefix + "/" + (object.id || "object"),
      x: 0,
      y: 0,
      z: 0,
      rotationX: sceneNumber(object.rotationX, 0) + sceneNumber(model && model.rotationX, 0),
      rotationY: sceneNumber(object.rotationY, 0) + sceneNumber(model && model.rotationY, 0),
      rotationZ: sceneNumber(object.rotationZ, 0) + sceneNumber(model && model.rotationZ, 0),
    });
    const positioned = sceneModelTransformPoint({ x: object.x, y: object.y, z: object.z }, model);
    instanced.x = positioned.x;
    instanced.y = positioned.y;
    instanced.z = positioned.z;
    const scaleX = Math.abs(sceneNumber(model && model.scaleX, 1));
    const scaleY = Math.abs(sceneNumber(model && model.scaleY, 1));
    const scaleZ = Math.abs(sceneNumber(model && model.scaleZ, 1));
    switch (object.kind) {
      case "cube":
        if (Math.abs(scaleX - scaleY) > 0.0001 || Math.abs(scaleX - scaleZ) > 0.0001) {
          instanced.kind = "box";
          instanced.width = sceneNumber(object.size, 1.2) * scaleX;
          instanced.height = sceneNumber(object.size, 1.2) * scaleY;
          instanced.depth = sceneNumber(object.size, 1.2) * scaleZ;
        } else {
          instanced.size = sceneNumber(object.size, 1.2) * scaleX;
        }
        break;
      case "sphere":
        instanced.radius = sceneNumber(object.radius, sceneNumber(object.size, 1.2) / 2) * Math.max(scaleX, scaleY, scaleZ);
        break;
      default:
        instanced.width = sceneNumber(object.width, sceneNumber(object.size, 1.2)) * scaleX;
        instanced.height = sceneNumber(object.height, sceneNumber(object.size, 1.2)) * scaleY;
        instanced.depth = sceneNumber(object.depth, sceneNumber(object.size, 1.2)) * scaleZ;
        break;
    }
    if (model && model.static !== null) {
      instanced.static = Boolean(model.static);
    }
    if (model && typeof model.pickable === "boolean") {
      instanced.pickable = model.pickable;
    }
    sceneApplyModelLOD(instanced, model);
    return normalizeSceneObject(instanced, prefix);
  }

  function sceneModelLineObject(object, model, prefix) {
    const scaleX = sceneNumber(model && model.scaleX, 1);
    const scaleY = sceneNumber(model && model.scaleY, 1);
    const scaleZ = sceneNumber(model && model.scaleZ, 1);
    const scaled = sceneScaleModelLinePoints(object.points, scaleX, scaleY, scaleZ);
    const positioned = sceneModelTransformPoint({ x: object.x, y: object.y, z: object.z }, model);
    const instanced = Object.assign({}, object, {
      id: prefix + "/" + (object.id || "object"),
      points: scaled,
      lineSegments: sceneCloneModelLineSegments(object.lineSegments),
      x: positioned.x,
      y: positioned.y,
      z: positioned.z,
      rotationX: sceneNumber(object.rotationX, 0) + sceneNumber(model && model.rotationX, 0),
      rotationY: sceneNumber(object.rotationY, 0) + sceneNumber(model && model.rotationY, 0),
      rotationZ: sceneNumber(object.rotationZ, 0) + sceneNumber(model && model.rotationZ, 0),
    });
    if (model && model.static !== null) {
      instanced.static = Boolean(model.static);
    }
    if (model && typeof model.pickable === "boolean") {
      instanced.pickable = model.pickable;
    }
    sceneApplyModelLOD(instanced, model);
    return normalizeSceneObject(instanced, prefix);
  }

  function sceneScaleModelLinePoints(points, scaleX, scaleY, scaleZ) {
    return Array.isArray(points) ? points.map(function(point) {
      return {
        x: sceneNumber(point && point.x, 0) * scaleX,
        y: sceneNumber(point && point.y, 0) * scaleY,
        z: sceneNumber(point && point.z, 0) * scaleZ,
      };
    }) : [];
  }

  function sceneCloneModelLineSegments(segments) {
    return Array.isArray(segments) ? segments.map(function(pair) {
      return Array.isArray(pair) ? pair.slice(0, 2) : pair;
    }) : [];
  }

  function sceneScaleModelPointPositions(positions, scaleX, scaleY, scaleZ) {
    const source = positions instanceof Float32Array ? positions : sceneTypedFloatArray(positions);
    if (!source.length) {
      return source;
    }
    if (Math.abs(scaleX - 1) < 0.000001 && Math.abs(scaleY - 1) < 0.000001 && Math.abs(scaleZ - 1) < 0.000001) {
      return source;
    }
    const scaled = new Float32Array(source.length);
    for (let i = 0; i + 2 < source.length; i += 3) {
      scaled[i] = source[i] * scaleX;
      scaled[i + 1] = source[i + 1] * scaleY;
      scaled[i + 2] = source[i + 2] * scaleZ;
    }
    return scaled;
  }

  function sceneApplyModelPointOverride(point, model) {
    const override = Object.assign({}, point);
    if (!model || typeof model !== "object") {
      return override;
    }
    if (typeof model.material === "string" && model.material.trim()) {
      override.material = model.material.trim();
    }
    if (typeof model.color === "string" && model.color) {
      override.color = model.color;
    }
    if (typeof model.style === "string" && model.style) {
      override.style = model.style;
    }
    if (model.size != null) {
      override.size = model.size;
    }
    if (model.opacity != null) {
      override.opacity = model.opacity;
    }
    if (typeof model.blendMode === "string" && model.blendMode) {
      override.blendMode = model.blendMode;
    }
    if (model.depthWrite != null) {
      override.depthWrite = model.depthWrite;
    }
    if (model.attenuation != null) {
      override.attenuation = model.attenuation;
    }
    return override;
  }

  function sceneInstantiateModelPointsEntry(rawPoint, model, prefix, index) {
    const source = sceneApplyModelPointOverride(rawPoint, model);
    const normalized = normalizeScenePointsEntry(source, index, null);
    const scaleX = sceneNumber(model && model.scaleX, 1);
    const scaleY = sceneNumber(model && model.scaleY, 1);
    const scaleZ = sceneNumber(model && model.scaleZ, 1);
    const positions = sceneScaleModelPointPositions(normalized._cachedPos || normalized.positions, scaleX, scaleY, scaleZ);
    const positioned = sceneModelTransformPoint({ x: normalized.x, y: normalized.y, z: normalized.z }, model);
    const instanced = Object.assign({}, normalized, {
      id: prefix + "/" + normalized.id,
      positions,
      x: positioned.x,
      y: positioned.y,
      z: positioned.z,
      rotationX: sceneNumber(normalized.rotationX, 0) + sceneNumber(model && model.rotationX, 0),
      rotationY: sceneNumber(normalized.rotationY, 0) + sceneNumber(model && model.rotationY, 0),
      rotationZ: sceneNumber(normalized.rotationZ, 0) + sceneNumber(model && model.rotationZ, 0),
    });
    if (positions instanceof Float32Array) {
      instanced._cachedPos = positions;
    }
    if (normalized._cachedSizes) {
      instanced._cachedSizes = normalized._cachedSizes;
    }
    if (normalized._cachedColors) {
      instanced._cachedColors = normalized._cachedColors;
    }
    return normalizeScenePointsEntry(instanced, instanced.id, normalized);
  }

  function sceneInstantiateModelObject(rawObject, model, prefix, index, skinInstances) {
    const source = sceneApplyMaterialOverride(rawObject, model);
    if (skinInstances && source && source.skinIndex != null && skinInstances[source.skinIndex]) {
      source.skin = skinInstances[source.skinIndex];
    }
    const normalized = normalizeSceneObject(source, index);
    if (normalized.vertices && normalized.vertices.positions && normalized.vertices.count > 0) {
      return sceneModelMeshObject(normalized, model, prefix);
    }
    if (normalized.kind === "lines") {
      return sceneModelLineObject(normalized, model, prefix);
    }
    return sceneModelPrimitiveObject(normalized, model, prefix);
  }

  function sceneModelTransformMeshFloats(values, tupleSize, mapper) {
    const source = values instanceof Float32Array ? values : sceneTypedFloatArray(values);
    const typed = new Float32Array(source.length);
    const safeTupleSize = Math.max(1, Math.floor(sceneNumber(tupleSize, 1)));
    for (let index = 0; index + safeTupleSize - 1 < source.length; index += safeTupleSize) {
      const mapped = mapper(
        sceneNumber(source[index], 0),
        sceneNumber(source[index + 1], 0),
        sceneNumber(source[index + 2], 0),
        safeTupleSize > 3 ? sceneNumber(source[index + 3], 1) : undefined
      );
      typed[index] = sceneNumber(mapped && mapped.x, 0);
      typed[index + 1] = sceneNumber(mapped && mapped.y, 0);
      typed[index + 2] = sceneNumber(mapped && mapped.z, 0);
      if (safeTupleSize > 3) {
        typed[index + 3] = sceneNumber(mapped && mapped.w, 1);
      }
    }
    return typed;
  }

  function sceneModelMeshObject(object, model, prefix) {
    const vertices = object && object.vertices && typeof object.vertices === "object" ? object.vertices : null;
    if (!vertices || !vertices.positions || !vertices.count) {
      return null;
    }
    const instanced = Object.assign({}, object, {
      id: prefix + "/" + (object.id || "object"),
      x: 0,
      y: 0,
      z: 0,
      rotationX: 0,
      rotationY: 0,
      rotationZ: 0,
      spinX: 0,
      spinY: 0,
      spinZ: 0,
      shiftX: 0,
      shiftY: 0,
      shiftZ: 0,
      driftSpeed: 0,
      driftPhase: 0,
    });
    const hasSkin = instanced.skin && typeof instanced.skin === "object";
    if (hasSkin) {
      instanced.vertices = {
        count: Math.max(0, Math.floor(sceneNumber(vertices.count, 0))),
        positions: vertices.positions instanceof Float32Array ? new Float32Array(vertices.positions) : sceneTypedFloatArray(vertices.positions),
        normals: vertices.normals instanceof Float32Array ? new Float32Array(vertices.normals) : sceneTypedFloatArray(vertices.normals),
        uvs: vertices.uvs instanceof Float32Array ? new Float32Array(vertices.uvs) : sceneTypedFloatArray(vertices.uvs),
        tangents: vertices.tangents instanceof Float32Array ? new Float32Array(vertices.tangents) : sceneTypedFloatArray(vertices.tangents),
        joints: vertices.joints instanceof Float32Array ? new Float32Array(vertices.joints) : sceneTypedFloatArray(vertices.joints),
        weights: vertices.weights instanceof Float32Array ? new Float32Array(vertices.weights) : sceneTypedFloatArray(vertices.weights),
      };
    } else {
      instanced.vertices = {
        count: Math.max(0, Math.floor(sceneNumber(vertices.count, 0))),
        positions: sceneModelTransformMeshFloats(vertices.positions, 3, function(x, y, z) {
          return sceneModelTransformPoint({ x: x, y: y, z: z }, model);
        }),
        normals: sceneModelTransformMeshFloats(vertices.normals, 3, function(x, y, z) {
          return sceneNormalizeDirection(sceneModelTransformVector({ x: x, y: y, z: z }, model));
        }),
        uvs: vertices.uvs instanceof Float32Array ? new Float32Array(vertices.uvs) : sceneTypedFloatArray(vertices.uvs),
        tangents: sceneModelTransformMeshFloats(vertices.tangents, 4, function(x, y, z, w) {
          const rotated = sceneNormalizeDirection(sceneModelTransformVector({ x: x, y: y, z: z }, model));
          return { x: rotated.x, y: rotated.y, z: rotated.z, w: sceneNumber(w, 1) };
        }),
        joints: vertices.joints instanceof Float32Array ? new Float32Array(vertices.joints) : sceneTypedFloatArray(vertices.joints),
        weights: vertices.weights instanceof Float32Array ? new Float32Array(vertices.weights) : sceneTypedFloatArray(vertices.weights),
      };
    }
    if (model && model.static !== null) {
      instanced.static = Boolean(model.static);
    }
    if (hasSkin && model && model.animation) {
      instanced.static = false;
    }
    if (model && typeof model.pickable === "boolean") {
      instanced.pickable = model.pickable;
    }
    sceneApplyModelLOD(instanced, model);
    return normalizeSceneObject(instanced, prefix);
  }

  function sceneSkinnedModelLocalBounds(vertices) {
    if (!vertices || !vertices.positions || !vertices.count) {
      return null;
    }
    const cached = vertices._skinnedLocalBounds;
    if (cached) {
      return cached;
    }
    const positions = vertices.positions instanceof Float32Array ? vertices.positions : sceneTypedFloatArray(vertices.positions);
    let minX = Infinity;
    let minY = Infinity;
    let minZ = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    let maxZ = -Infinity;
    const limit = Math.min(positions.length, Math.max(0, Math.floor(sceneNumber(vertices.count, 0))) * 3);
    for (let index = 0; index + 2 < limit; index += 3) {
      const x = positions[index];
      const y = positions[index + 1];
      const z = positions[index + 2];
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (z < minZ) minZ = z;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
      if (z > maxZ) maxZ = z;
    }
    const bounds = Number.isFinite(minX)
      ? { minX, minY, minZ, maxX, maxY, maxZ }
      : { minX: -1, minY: -1, minZ: -1, maxX: 1, maxY: 1, maxZ: 1 };
    vertices._skinnedLocalBounds = bounds;
    return bounds;
  }

  function sceneInstantiateModelLabel(rawLabel, model, prefix, index) {
    const normalized = normalizeSceneLabel(rawLabel, index);
    const position = sceneModelTransformPoint({ x: normalized.x, y: normalized.y, z: normalized.z }, model);
    return Object.assign({}, normalized, {
      id: prefix + "/" + normalized.id,
      x: position.x,
      y: position.y,
      z: position.z,
    });
  }

  function sceneInstantiateModelLight(rawLight, model, prefix, index) {
    const normalized = normalizeSceneLight(rawLight, index, null);
    if (!normalized) {
      return null;
    }
    const next = Object.assign({}, normalized, {
      id: prefix + "/" + normalized.id,
    });
    if (next.kind === "directional") {
      const rotated = sceneModelRotateDirection({
        x: next.directionX,
        y: next.directionY,
        z: next.directionZ,
      }, model);
      next.directionX = rotated.x;
      next.directionY = rotated.y;
      next.directionZ = rotated.z;
      if (typeof hashLightContent === "function") {
        next._lightHash = hashLightContent(next);
      }
      return next;
    }
    const position = sceneModelTransformPoint({ x: next.x, y: next.y, z: next.z }, model);
    next.x = position.x;
    next.y = position.y;
    next.z = position.z;
    if (next.kind === "point") {
      next.range = sceneNumber(next.range, 0) * Math.max(
        Math.abs(sceneNumber(model && model.scaleX, 1)),
        Math.abs(sceneNumber(model && model.scaleY, 1)),
        Math.abs(sceneNumber(model && model.scaleZ, 1)),
      );
    }
    if (typeof hashLightContent === "function") {
      next._lightHash = hashLightContent(next);
    }
    return next;
  }

  function sceneInstantiateModelSprite(rawSprite, model, prefix, index) {
    const normalized = normalizeSceneSprite(rawSprite, index);
    if (!normalized || !normalized.src) {
      return null;
    }
    const position = sceneModelTransformPoint({ x: normalized.x, y: normalized.y, z: normalized.z }, model);
    const shift = sceneModelTransformVector({ x: normalized.shiftX, y: normalized.shiftY, z: normalized.shiftZ }, model);
    const modelScale = sceneModelMaxScale(model);
    return Object.assign({}, normalized, {
      id: prefix + "/" + normalized.id,
      x: position.x,
      y: position.y,
      z: position.z,
      shiftX: shift.x,
      shiftY: shift.y,
      shiftZ: shift.z,
      width: normalized.width * modelScale,
      height: normalized.height * modelScale,
    });
  }

  function sceneInstantiateModelHTML(rawHTML, model, prefix, index) {
    const normalized = normalizeSceneHTML(rawHTML, index);
    if (!normalized || !normalized.html.trim()) {
      return null;
    }
    const position = sceneModelTransformPoint({ x: normalized.x, y: normalized.y, z: normalized.z }, model);
    const shift = sceneModelTransformVector({ x: normalized.shiftX, y: normalized.shiftY, z: normalized.shiftZ }, model);
    const modelScale = sceneModelMaxScale(model);
    return Object.assign({}, normalized, {
      id: prefix + "/" + normalized.id,
      x: position.x,
      y: position.y,
      z: position.z,
      shiftX: shift.x,
      shiftY: shift.y,
      shiftZ: shift.z,
      width: normalized.width * modelScale,
      height: normalized.height * modelScale,
    });
  }

  function parseSceneModelAsset(raw, src) {
    let payload = raw;
    if (payload && typeof payload === "object" && payload.scene && typeof payload.scene === "object") {
      payload = payload.scene;
    }
    if (Array.isArray(payload)) {
      payload = { objects: payload };
    }
    const record = payload && typeof payload === "object" ? payload : {};
    const sprites = Array.isArray(record.sprites) ? record.sprites.map(function(sprite) {
      if (!sprite || typeof sprite !== "object") {
        return sprite;
      }
      const resolved = Object.assign({}, sprite);
      resolved.src = resolveSceneModelAssetURL(src, sprite.src);
      return resolved;
    }) : [];
    return {
      src,
      objects: Array.isArray(record.objects) ? record.objects.map(function(object) {
        return resolveSceneModelObjectURLs(src, object);
      }) : [],
      points: Array.isArray(record.points) ? record.points : [],
      labels: Array.isArray(record.labels) ? record.labels : [],
      sprites,
      html: Array.isArray(record.html) ? record.html : (Array.isArray(record.htmlOverlays) ? record.htmlOverlays : []),
      lights: Array.isArray(record.lights) ? record.lights : [],
      animations: Array.isArray(record.animations) ? record.animations : [],
      skins: Array.isArray(record.skins) ? record.skins : [],
      nodes: Array.isArray(record.nodes) ? record.nodes : [],
    };
  }

  function sceneModelAssetFormat(src) {
    const raw = typeof src === "string" ? src.trim() : "";
    if (!raw) {
      return "";
    }
    let pathname = raw;
    try {
      pathname = new URL(raw, window.location.href).pathname;
    } catch (_error) {
      pathname = raw.split(/[?#]/, 1)[0];
    }
    const normalized = pathname.toLowerCase();
    if (normalized.endsWith(".glb")) {
      return "glb";
    }
    if (normalized.endsWith(".gltf")) {
      return "gltf";
    }
    return "json";
  }

  function resolveSceneSubFeatureURL(datasetKey, fallback) {
    try {
      var tag = document.querySelector('script[data-gosx-script="feature-scene3d"]');
      if (tag && tag.dataset && tag.dataset[datasetKey]) {
        return tag.dataset[datasetKey];
      }
    } catch (_e) {}
    return fallback;
  }

  var sceneWebGPUFeaturePromise = null;

  function sceneHasNavigatorWebGPU() {
    return typeof navigator !== "undefined"
      && navigator.gpu
      && typeof navigator.gpu.requestAdapter === "function";
  }

  function ensureWebGPUFeatureLoaded() {
    if (!sceneHasNavigatorWebGPU()) {
      return Promise.resolve(null);
    }
    if (window.__gosx_scene3d_webgpu_api) {
      return Promise.resolve(window.__gosx_scene3d_webgpu_api);
    }
    if (window.__gosx_scene3d_webgpu_feature_promise) {
      return window.__gosx_scene3d_webgpu_feature_promise;
    }
    if (sceneWebGPUFeaturePromise) {
      return sceneWebGPUFeaturePromise;
    }
    sceneWebGPUFeaturePromise = new Promise(function(resolve, reject) {
      var s = document.createElement("script");
      s.async = false;
      s.dataset.gosxScript = "feature-scene3d-webgpu";
      s.src = resolveSceneSubFeatureURL("gosxScene3dWebgpuUrl", "/gosx/bootstrap-feature-scene3d-webgpu.js");
      s.onload = function() {
        if (window.__gosx_scene3d_webgpu_api) {
          resolve(window.__gosx_scene3d_webgpu_api);
        } else {
          sceneWebGPUFeaturePromise = null;
          window.__gosx_scene3d_webgpu_feature_promise = null;
          reject(new Error("scene3d-webgpu chunk loaded but did not publish API"));
        }
      };
      s.onerror = function() {
        sceneWebGPUFeaturePromise = null;
        window.__gosx_scene3d_webgpu_feature_promise = null;
        reject(new Error("failed to load scene3d-webgpu chunk"));
      };
      document.head.appendChild(s);
    });
    window.__gosx_scene3d_webgpu_feature_promise = sceneWebGPUFeaturePromise;
    return sceneWebGPUFeaturePromise;
  }

  async function ensurePreferredWebGPUBackend(props, capability) {
    if (sceneCapabilityWebGLPreference(props, capability) !== "prefer") {
      return false;
    }
    if (sceneNeedsWebGLForWebGPUCoverage(props)) {
      return false;
    }
    try {
      var api = await ensureWebGPUFeatureLoaded();
      if (!api) {
        return false;
      }
      if (typeof window.__gosx_scene3d_webgpu_probe_ready === "function") {
        await window.__gosx_scene3d_webgpu_probe_ready();
      }
      return typeof sceneWebGPUAvailable === "function" && sceneWebGPUAvailable();
    } catch (error) {
      console.warn("[gosx] failed to prepare Scene3D WebGPU backend:", error && error.message ? error.message : error);
      return false;
    }
  }

  var sceneGLTFFeaturePromise = null;

  function ensureGLTFFeatureLoaded() {
    if (window.__gosx_scene3d_gltf_api) {
      return Promise.resolve(window.__gosx_scene3d_gltf_api);
    }
    if (sceneGLTFFeaturePromise) {
      return sceneGLTFFeaturePromise;
    }
    sceneGLTFFeaturePromise = new Promise(function(resolve, reject) {
      var s = document.createElement("script");
      s.async = false;
      s.dataset.gosxScript = "feature-scene3d-gltf";
      s.src = resolveSceneSubFeatureURL("gosxScene3dGltfUrl", "/gosx/bootstrap-feature-scene3d-gltf.js");
      s.onload = function() {
        if (window.__gosx_scene3d_gltf_api) {
          resolve(window.__gosx_scene3d_gltf_api);
        } else {
          reject(new Error("scene3d-gltf chunk loaded but did not publish API"));
        }
      };
      s.onerror = function() {
        sceneGLTFFeaturePromise = null; // allow retry on next attempt
        reject(new Error("failed to load scene3d-gltf chunk"));
      };
      document.head.appendChild(s);
    });
    return sceneGLTFFeaturePromise;
  }

  var sceneAnimationFeaturePromise = null;

  function ensureAnimationFeatureLoaded() {
    if (window.__gosx_scene3d_animation_api) {
      return Promise.resolve(window.__gosx_scene3d_animation_api);
    }
    if (sceneAnimationFeaturePromise) {
      return sceneAnimationFeaturePromise;
    }
    sceneAnimationFeaturePromise = new Promise(function(resolve, reject) {
      var s = document.createElement("script");
      s.async = false;
      s.dataset.gosxScript = "feature-scene3d-animation";
      s.src = resolveSceneSubFeatureURL("gosxScene3dAnimationUrl", "/gosx/bootstrap-feature-scene3d-animation.js");
      s.onload = function() {
        if (window.__gosx_scene3d_animation_api) {
          resolve(window.__gosx_scene3d_animation_api);
        } else {
          reject(new Error("scene3d-animation chunk loaded but did not publish API"));
        }
      };
      s.onerror = function() {
        sceneAnimationFeaturePromise = null;
        reject(new Error("failed to load scene3d-animation chunk"));
      };
      document.head.appendChild(s);
    });
    return sceneAnimationFeaturePromise;
  }

  window.__gosx_ensure_scene3d_animation_loaded = ensureAnimationFeatureLoaded;

  async function loadSceneModelAsset(src) {
    const key = String(src || "").trim();
    if (!key) {
      return parseSceneModelAsset({}, key);
    }
    if (!sceneModelAssetCache.has(key)) {
      sceneModelAssetCache.set(key, (async function() {
        try {
          const format = sceneModelAssetFormat(key);
          if (format === "glb" || format === "gltf") {
            var gltfApi = await ensureGLTFFeatureLoaded();
            return parseSceneModelAsset(gltfApi.gltfSceneToModelAsset(await gltfApi.sceneLoadGLTFModel(key), key), key);
          }
          const response = await fetch(key, { credentials: "same-origin" });
          if (!response || !response.ok) {
            throw new Error("HTTP " + String(response && response.status || 0));
          }
          return parseSceneModelAsset(await response.json(), key);
        } catch (error) {
          console.warn("[gosx] failed to load Scene3D model asset:", key, error && error.message ? error.message : error);
          gosxSceneEmit("warn", "model-asset-load-failed", {
            asset: String(key || ""),
            error: error && error.message ? String(error.message) : String(error),
          });
          return parseSceneModelAsset({}, key);
        }
      })());
    }
    return sceneModelAssetCache.get(key);
  }

  function sceneModelHasSkins(skins) {
    return Array.isArray(skins) && skins.some(function(skin) {
      return Boolean(skin && skin.joints && skin.inverseBindMatrices);
    });
  }

  function sceneModelRootNodes(nodes) {
    if (!Array.isArray(nodes) || !nodes.length) {
      return [];
    }
    const childSet = new Set();
    for (let index = 0; index < nodes.length; index += 1) {
      const children = nodes[index] && nodes[index].children;
      if (!Array.isArray(children)) {
        continue;
      }
      for (let childIndex = 0; childIndex < children.length; childIndex += 1) {
        childSet.add(children[childIndex]);
      }
    }
    const roots = [];
    for (let index = 0; index < nodes.length; index += 1) {
      if (!childSet.has(index)) {
        roots.push(index);
      }
    }
    return roots;
  }

  function sceneApplyModelSkinPose(record, deltaTime) {
    if (!record || !record.animationApi || !record.nodes || !record.skins) {
      return;
    }
    const animatedTransforms = record.animatedTransforms;
    if (animatedTransforms && typeof animatedTransforms.clear === "function") {
      animatedTransforms.clear();
    }
    if (record.mixer) {
      record.mixer.update(deltaTime, function(targetNode, property, value) {
        let entry = animatedTransforms.get(targetNode);
        if (!entry) {
          entry = {};
          animatedTransforms.set(targetNode, entry);
        }
        entry[property] = Array.isArray(value) ? value.slice() : Array.from(value || []);
      });
    }
    const nodeTransforms = record.animationApi.buildNodeTransforms(record.nodes, animatedTransforms, record.rootTransform, record.rootNodes);
    for (let index = 0; index < record.skins.length; index += 1) {
      const skin = record.skins[index];
      if (!skin) {
        continue;
      }
      skin.jointMatrices = record.animationApi.computeJointMatrices(skin, nodeTransforms);
    }
  }

  async function scenePrepareModelSkinPlayback(state, asset, model, skinInstances, objectIDs) {
    if (!sceneModelHasSkins(skinInstances) || !Array.isArray(asset.nodes) || !asset.nodes.length) {
      return;
    }

    let animationApi = null;
    try {
      animationApi = await ensureAnimationFeatureLoaded();
    } catch (error) {
      console.warn("[gosx] failed to load Scene3D animation support:", error && error.message ? error.message : error);
      return;
    }
    if (!animationApi || typeof animationApi.buildNodeTransforms !== "function" || typeof animationApi.computeJointMatrices !== "function") {
      return;
    }

    const record = {
      id: typeof model.id === "string" ? model.id : "",
      model: Object.assign({}, model || {}),
      live: Array.isArray(model && model._live) ? model._live.slice() : [],
      objectIDs: Array.isArray(objectIDs) ? objectIDs.slice() : [],
      nodes: asset.nodes,
      rootNodes: sceneModelRootNodes(asset.nodes),
      skins: skinInstances,
      animatedTransforms: new Map(),
      rootTransform: sceneModelTransformMatrix(model),
      animationApi,
      mixer: null,
      animation: "",
      poseDirty: false,
    };
    if (!Array.isArray(state._modelSkins)) {
      state._modelSkins = [];
    }
    state._modelSkins.push(record);

    const requestedAnimation = typeof model.animation === "string" ? model.animation.trim() : "";
    if (requestedAnimation && typeof animationApi.createMixer === "function") {
      const clips = sceneCloneModelAnimations(asset.animations);
      if (clips.length) {
        const mixer = animationApi.createMixer();
        for (let index = 0; index < clips.length; index += 1) {
          const clip = clips[index];
          mixer.addClip(clip.name, clip);
        }
        mixer.play(requestedAnimation, { loop: model.loop !== false, fadeIn: 0 });
        if (mixer.isPlaying(requestedAnimation)) {
          record.mixer = mixer;
          record.animation = requestedAnimation;
          if (!Array.isArray(state._modelAnimations)) {
            state._modelAnimations = [];
          }
          state._modelAnimations.push(record);
        }
      }
    }

    sceneApplyModelSkinPose(record, 0);
  }

  function sceneHasActiveModelAnimations(state) {
    const records = state && Array.isArray(state._modelAnimations) ? state._modelAnimations : [];
    return records.some(function(record) {
      return Boolean(record && record.mixer && record.animation && record.mixer.isPlaying(record.animation));
    });
  }

  function sceneAdvanceModelAnimations(state, deltaTime) {
    const records = state && Array.isArray(state._modelAnimations) ? state._modelAnimations : [];
    for (let index = 0; index < records.length; index += 1) {
      const record = records[index];
      if (!record) {
        continue;
      }
      const playing = Boolean(record && record.mixer && record.animation && record.mixer.isPlaying(record.animation));
      if (!playing && !record.poseDirty) {
        continue;
      }
      record.poseDirty = false;
      sceneApplyModelSkinPose(record, deltaTime);
    }
  }

  function sceneModelRecordListensToEvent(record, eventName) {
    return Boolean(record && Array.isArray(record.live) && record.live.indexOf(eventName) >= 0);
  }

  function sceneModelLivePatchForRecord(record, payload) {
    if (!sceneIsPlainObject(payload)) {
      return null;
    }
    if (record && record.id && sceneIsPlainObject(payload[record.id])) {
      return payload[record.id];
    }
    return payload;
  }

  function sceneApplyModelLiveOpacity(state, record, patch) {
    if (!state || !record || !sceneIsPlainObject(patch) || !Object.prototype.hasOwnProperty.call(patch, "opacity")) {
      return false;
    }
    const opacity = Math.max(0, Math.min(1, sceneNumber(patch.opacity, sceneNumber(record.model && record.model.opacity, 1))));
    if (record.model) {
      record.model.opacity = opacity;
    }
    const objectIDs = Array.isArray(record.objectIDs) ? record.objectIDs : [];
    let changed = false;
    for (let index = 0; index < objectIDs.length; index += 1) {
      const object = state.objects && state.objects.get ? state.objects.get(objectIDs[index]) : null;
      if (!object || object.opacity === opacity) {
        continue;
      }
      object.opacity = opacity;
      if (opacity < 1 && (!object.blendMode || object.blendMode === "opaque")) {
        object.blendMode = "alpha";
      }
      changed = true;
    }
    return changed;
  }

  function sceneApplyModelLivePatch(state, record, patch) {
    if (!record || !record.model || !sceneIsPlainObject(patch)) {
      return false;
    }
    const keys = ["x", "y", "z", "rotationX", "rotationY", "rotationZ", "scaleX", "scaleY", "scaleZ"];
    let changed = sceneApplyModelLiveOpacity(state, record, patch);
    for (let index = 0; index < keys.length; index += 1) {
      const key = keys[index];
      if (!Object.prototype.hasOwnProperty.call(patch, key)) {
        continue;
      }
      const next = sceneNumber(patch[key], sceneNumber(record.model[key], key.indexOf("scale") === 0 ? 1 : 0));
      if (record.model[key] === next) {
        continue;
      }
      record.model[key] = next;
      changed = true;
    }
    if (!changed) {
      return false;
    }
    record.rootTransform = sceneModelTransformMatrix(record.model);
    record.poseDirty = true;
    return true;
  }

  function sceneApplyModelLiveAnimation(record, patch) {
    if (!record || !record.mixer || !sceneIsPlainObject(patch) || !Object.prototype.hasOwnProperty.call(patch, "animation")) {
      return false;
    }
    const animation = typeof patch.animation === "string" ? patch.animation.trim() : "";
    if (!animation || (record.animation === animation && record.mixer.isPlaying(animation))) {
      return false;
    }
    if (record.animation && record.mixer.isPlaying(record.animation)) {
      record.mixer.stop(record.animation, { fadeOut: 0.05 });
    }
    record.mixer.play(animation, {
      loop: Object.prototype.hasOwnProperty.call(patch, "loop") ? patch.loop !== false : true,
      fadeIn: 0.04,
    });
    if (!record.mixer.isPlaying(animation)) {
      return false;
    }
    record.animation = animation;
    record.poseDirty = true;
    return true;
  }

  function sceneApplyModelLiveEvent(state, eventName, payload) {
    const event = typeof eventName === "string" ? eventName.trim() : "";
    if (!event) {
      return false;
    }
    const records = state && Array.isArray(state._modelSkins) ? state._modelSkins : [];
    let changed = false;
    for (let index = 0; index < records.length; index += 1) {
      const record = records[index];
      if (!sceneModelRecordListensToEvent(record, event)) {
        continue;
      }
      const patch = sceneModelLivePatchForRecord(record, payload);
      changed = sceneApplyModelLivePatch(state, record, patch) || changed;
      changed = sceneApplyModelLiveAnimation(record, patch) || changed;
    }
    return changed;
  }

  function sceneApplyCameraLiveEvent(state, payload) {
    if (!state || !sceneIsPlainObject(payload) || !sceneIsPlainObject(payload.camera)) {
      return false;
    }
    const nextCamera = normalizeSceneCamera(payload.camera, state.camera);
    if (sceneCameraEquivalent(state.camera, nextCamera)) {
      return false;
    }
    state.camera = nextCamera;
    return true;
  }

  async function hydrateSceneStateModels(state, props) {
    const models = sceneModels(props);
    state._modelAnimations = [];
    state._modelSkins = [];
    if (!models.length) {
      return { models: 0, objects: 0, points: 0, labels: 0, sprites: 0, html: 0, lights: 0 };
    }
    let objectCount = 0;
    let pointCount = 0;
    let labelCount = 0;
    let spriteCount = 0;
    let htmlCount = 0;
    let lightCount = 0;
    await Promise.all(models.map(async function(model, modelIndex) {
      const asset = await loadSceneModelAsset(model.src);
      const prefix = model.id || ("scene-model-" + modelIndex);
      const skinInstances = sceneCloneModelSkins(asset.skins);
      const objectIDs = [];
      for (let i = 0; i < asset.objects.length; i += 1) {
        const object = sceneInstantiateModelObject(asset.objects[i], model, prefix, i, skinInstances);
        if (!object) {
          continue;
        }
        state.objects.set(object.id, object);
        objectIDs.push(object.id);
        objectCount += 1;
      }
      for (let i = 0; i < asset.points.length; i += 1) {
        const point = sceneInstantiateModelPointsEntry(asset.points[i], model, prefix, i);
        if (!point || point.count <= 0) {
          continue;
        }
        state.points.push(point);
        pointCount += 1;
      }
      for (let i = 0; i < asset.labels.length; i += 1) {
        const label = sceneInstantiateModelLabel(asset.labels[i], model, prefix, i);
        if (!label || !label.text.trim()) {
          continue;
        }
        state.labels.set(label.id, label);
        labelCount += 1;
      }
      for (let i = 0; i < asset.sprites.length; i += 1) {
        const sprite = sceneInstantiateModelSprite(asset.sprites[i], model, prefix, i);
        if (!sprite) {
          continue;
        }
        state.sprites.set(sprite.id, sprite);
        spriteCount += 1;
      }
      for (let i = 0; i < asset.html.length; i += 1) {
        const entry = sceneInstantiateModelHTML(asset.html[i], model, prefix, i);
        if (!entry) {
          continue;
        }
        state.html.set(entry.id, entry);
        htmlCount += 1;
      }
      for (let i = 0; i < asset.lights.length; i += 1) {
        const light = sceneInstantiateModelLight(asset.lights[i], model, prefix, i);
        if (!light) {
          continue;
        }
        state.lights.set(light.id, light);
        lightCount += 1;
      }
      await scenePrepareModelSkinPlayback(state, asset, model, skinInstances, objectIDs);
    }));
    return { models: models.length, objects: objectCount, points: pointCount, labels: labelCount, sprites: spriteCount, html: htmlCount, lights: lightCount };
  }

  function normalizeSceneCapabilityTier(value) {
    switch (String(value || "").trim().toLowerCase()) {
      case "constrained":
      case "balanced":
      case "full":
        return String(value).trim().toLowerCase();
      default:
        return "";
    }
  }

  function sceneMediaQueryMatches(query) {
    if (!query || typeof window.matchMedia !== "function") {
      return false;
    }
    try {
      return Boolean(window.matchMedia(query).matches);
    } catch (_error) {
      return false;
    }
  }

  function sceneEnvironmentState() {
    if (window.__gosx
      && window.__gosx.environment
      && typeof window.__gosx.environment.get === "function") {
      return window.__gosx.environment.get();
    }
    return null;
  }

  function sceneExtractCSSVarTransitionTiming(props) {
    var scene = props && props.scene;
    if (!scene || typeof scene !== "object") return null;
    var materials = Array.isArray(scene.materials) ? scene.materials : [];
    for (var i = 0; i < materials.length; i++) {
      var m = materials[i];
      if (m && m.transition && typeof m.transition === "object") {
        var update = m.transition.update || m.transition;
        var duration = typeof update.duration === "number" ? update.duration
          : typeof update.duration === "string" ? parseFloat(update.duration) * (update.duration.indexOf("ms") >= 0 ? 1 : 1000)
          : 0;
        if (duration > 0) {
          return { duration: duration, easing: update.easing || "ease-in-out" };
        }
      }
    }
    var env = scene.environment;
    if (env && env.transition && typeof env.transition === "object") {
      var envUpdate = env.transition.update || env.transition;
      var envDuration = typeof envUpdate.duration === "number" ? envUpdate.duration : 0;
      if (envDuration > 0) {
        return { duration: envDuration, easing: envUpdate.easing || "ease-in-out" };
      }
    }
    return null;
  }

  function sceneCapabilityProfile(props) {
    const requestedTier = normalizeSceneCapabilityTier(props && props.capabilityTier);
    const environment = sceneEnvironmentState();
    const navigatorRef = window && window.navigator ? window.navigator : {};
    const webglProbe = sceneBool(props && props.preferWebGL, true) ? sceneProbeWebGLRenderer() : null;
    const softwareWebGL = Boolean(webglProbe && webglProbe.available && webglProbe.software);
    const coarsePointer = environment ? Boolean(environment.coarsePointer) : (sceneMediaQueryMatches("(pointer: coarse)") || sceneMediaQueryMatches("(any-pointer: coarse)"));
    const hover = environment ? Boolean(environment.hover) : (sceneMediaQueryMatches("(hover: hover)") || sceneMediaQueryMatches("(any-hover: hover)"));
    const reducedData = environment ? Boolean(environment.reducedData) : sceneMediaQueryMatches("(prefers-reduced-data: reduce)");
    const lowPower = (environment ? Boolean(environment.lowPower) : false) || softwareWebGL;
    const visualViewportActive = environment ? Boolean(environment.visualViewportActive) : Boolean(window.visualViewport);
    const deviceMemory = sceneNumber(environment && environment.deviceMemory, sceneNumber(navigatorRef && navigatorRef.deviceMemory, 0));
    const hardwareConcurrency = Math.max(0, Math.floor(sceneNumber(environment && environment.hardwareConcurrency, sceneNumber(navigatorRef && navigatorRef.hardwareConcurrency, 0))));
    const constrainedHardware = lowPower || reducedData || (deviceMemory > 0 && deviceMemory <= 4) || (hardwareConcurrency > 0 && hardwareConcurrency <= 4);

    let tier = requestedTier;
    if (!tier) {
      if ((coarsePointer && constrainedHardware) || reducedData || lowPower) {
        tier = "constrained";
      } else if (coarsePointer) {
        tier = "balanced";
      } else {
        tier = "full";
      }
    }

    return {
      tier,
      coarsePointer,
      hover,
      reducedData,
      lowPower,
      softwareWebGL,
      visualViewportActive,
      deviceMemory,
      hardwareConcurrency,
    };
  }

  function sceneCapabilityWebGLPreference(props, capability) {
    if (sceneRequiresWebGL(props) || sceneBool(props && props.forceWebGL, false)) {
      return "force";
    }
    if (!sceneBool(props && props.preferWebGL, true)) {
      return "disabled";
    }
    if (sceneBool(props && props.preferCanvas, false)) {
      return "avoid";
    }
    if (!capability) {
      return "prefer";
    }
    if (capability.reducedData || capability.lowPower) {
      return "avoid";
    }
    if (capability.tier === "constrained" && capability.coarsePointer) {
      return "avoid";
    }
    return "prefer";
  }

  function sceneRendererFallbackReason(props, capability, rendererKind) {
    if (rendererKind === "webgl") {
      return "";
    }
    switch (sceneCapabilityWebGLPreference(props, capability)) {
      case "disabled":
        return "webgl-disabled";
      case "avoid":
        return "environment-constrained";
      default:
        return sceneBool(props && props.preferWebGL, true) ? "webgl-unavailable" : "";
    }
  }

  function sceneCapabilityChanged(prev, next) {
    if (!prev || !next) {
      return true;
    }
    return prev.tier !== next.tier
      || prev.coarsePointer !== next.coarsePointer
      || prev.hover !== next.hover
      || prev.reducedData !== next.reducedData
      || prev.lowPower !== next.lowPower
      || prev.softwareWebGL !== next.softwareWebGL
      || prev.visualViewportActive !== next.visualViewportActive
      || prev.deviceMemory !== next.deviceMemory
      || prev.hardwareConcurrency !== next.hardwareConcurrency;
  }

  function defaultSceneMaxDevicePixelRatio(capability) {
    if (capability && (capability.reducedData || capability.lowPower)) {
      switch (capability.tier) {
        case "constrained":
          return 1.25;
        case "balanced":
          return 1.5;
        default:
          return 1.75;
      }
    }
    switch (capability && capability.tier) {
      case "constrained":
        return 1.5;
      case "balanced":
        return 1.75;
      default:
        return 2;
    }
  }

  function applySceneCapabilityState(mount, props, capability) {
    if (!mount || !capability) {
      return;
    }
    setAttrValue(mount, "data-gosx-scene3d-capability-tier", capability.tier);
    setAttrValue(mount, "data-gosx-scene3d-coarse-pointer", capability.coarsePointer ? "true" : "false");
    setAttrValue(mount, "data-gosx-scene3d-hover", capability.hover ? "true" : "false");
    setAttrValue(mount, "data-gosx-scene3d-reduced-data", capability.reducedData ? "true" : "false");
    setAttrValue(mount, "data-gosx-scene3d-low-power", capability.lowPower ? "true" : "false");
    setAttrValue(mount, "data-gosx-scene3d-software-webgl", capability.softwareWebGL ? "true" : "false");
    setAttrValue(mount, "data-gosx-scene3d-require-webgl", sceneRequiresWebGL(props) ? "true" : "false");
    setAttrValue(mount, "data-gosx-scene3d-visual-viewport", capability.visualViewportActive ? "true" : "false");
    setAttrValue(mount, "data-gosx-scene3d-webgl-preference", sceneCapabilityWebGLPreference(props, capability));
    setAttrValue(mount, "data-gosx-scene3d-device-memory", capability.deviceMemory > 0 ? capability.deviceMemory : "");
    setAttrValue(mount, "data-gosx-scene3d-hardware-concurrency", capability.hardwareConcurrency > 0 ? capability.hardwareConcurrency : "");
  }

  function sceneWebGPULimitKey(name) {
    return String(name || "").trim().toLowerCase().replace(/[^a-z0-9]/g, "");
  }

  function sceneWebGPULimitValue(limits, name) {
    if (!limits || typeof limits !== "object") {
      return "";
    }
    const wanted = sceneWebGPULimitKey(name);
    for (const key of Object.keys(limits)) {
      if (sceneWebGPULimitKey(key) !== wanted) {
        continue;
      }
      const value = Number(limits[key]);
      return Number.isFinite(value) ? value : "";
    }
    return "";
  }

  function sceneWebGPULimitList(limits) {
    if (!limits || typeof limits !== "object") {
      return "";
    }
    return Object.keys(limits).sort().map(function(key) {
      const value = Number(limits[key]);
      return Number.isFinite(value) ? key + "=" + value : "";
    }).filter(Boolean).join(",");
  }

  function applySceneRendererState(mount, renderer, fallbackReason) {
    if (!mount) {
      return;
    }
    setAttrValue(mount, "data-gosx-scene3d-renderer", renderer && renderer.kind ? renderer.kind : "");
    setAttrValue(mount, "data-gosx-scene3d-renderer-fallback", fallbackReason || "");
    const webgpuDiagnostics = renderer && renderer.kind === "webgpu" && typeof renderer.diagnostics === "function"
      ? renderer.diagnostics()
      : null;
    const webgpuAdapterLimits = webgpuDiagnostics && webgpuDiagnostics.adapterLimits ? webgpuDiagnostics.adapterLimits : null;
    const webgpuDeviceLimits = webgpuDiagnostics && webgpuDiagnostics.deviceLimits ? webgpuDiagnostics.deviceLimits : null;
    const webgpuRequiredLimits = webgpuDiagnostics && webgpuDiagnostics.requiredLimits ? webgpuDiagnostics.requiredLimits : null;
    setAttrValue(mount, "data-gosx-scene3d-webgpu-features", webgpuDiagnostics && Array.isArray(webgpuDiagnostics.requestedFeatures) ? webgpuDiagnostics.requestedFeatures.join(",") : "");
    setAttrValue(mount, "data-gosx-scene3d-webgpu-required-features", webgpuDiagnostics && Array.isArray(webgpuDiagnostics.requiredFeatures) ? webgpuDiagnostics.requiredFeatures.join(",") : "");
    setAttrValue(mount, "data-gosx-scene3d-webgpu-device-features", webgpuDiagnostics && Array.isArray(webgpuDiagnostics.deviceFeatures) ? webgpuDiagnostics.deviceFeatures.join(",") : "");
    setAttrValue(mount, "data-gosx-scene3d-webgpu-required-limits", sceneWebGPULimitList(webgpuRequiredLimits));
    setAttrValue(mount, "data-gosx-scene3d-webgpu-sample-count", webgpuDiagnostics && webgpuDiagnostics.activeSampleCount > 0 ? webgpuDiagnostics.activeSampleCount : "");
    setAttrValue(mount, "data-gosx-scene3d-webgpu-target-format", webgpuDiagnostics && webgpuDiagnostics.targetFormat ? webgpuDiagnostics.targetFormat : "");
    setAttrValue(mount, "data-gosx-scene3d-webgpu-presentation-alpha-mode", webgpuDiagnostics && webgpuDiagnostics.presentationAlphaMode ? webgpuDiagnostics.presentationAlphaMode : "");
    setAttrValue(mount, "data-gosx-scene3d-webgpu-presentation-color-space", webgpuDiagnostics && webgpuDiagnostics.presentationColorSpace ? webgpuDiagnostics.presentationColorSpace : "");
    setAttrValue(mount, "data-gosx-scene3d-webgpu-presentation-tone-mapping", webgpuDiagnostics && webgpuDiagnostics.presentationToneMappingMode ? webgpuDiagnostics.presentationToneMappingMode : "");
    setAttrValue(mount, "data-gosx-scene3d-webgpu-power-preference", webgpuDiagnostics && webgpuDiagnostics.powerPreference ? webgpuDiagnostics.powerPreference : "");
    setAttrValue(mount, "data-gosx-scene3d-webgpu-adapter-limits", sceneWebGPULimitList(webgpuAdapterLimits));
    setAttrValue(mount, "data-gosx-scene3d-webgpu-device-limits", sceneWebGPULimitList(webgpuDeviceLimits));
    setAttrValue(mount, "data-gosx-scene3d-webgpu-adapter-max-texture-2d", sceneWebGPULimitValue(webgpuAdapterLimits, "maxTextureDimension2D"));
    setAttrValue(mount, "data-gosx-scene3d-webgpu-device-max-texture-2d", sceneWebGPULimitValue(webgpuDeviceLimits, "maxTextureDimension2D"));
    setAttrValue(mount, "data-gosx-scene3d-webgpu-adapter-max-buffer-size", sceneWebGPULimitValue(webgpuAdapterLimits, "maxBufferSize"));
    setAttrValue(mount, "data-gosx-scene3d-webgpu-device-max-buffer-size", sceneWebGPULimitValue(webgpuDeviceLimits, "maxBufferSize"));
    setAttrValue(mount, "data-gosx-scene3d-webgpu-adapter-max-compute-workgroup-size-x", sceneWebGPULimitValue(webgpuAdapterLimits, "maxComputeWorkgroupSizeX"));
    setAttrValue(mount, "data-gosx-scene3d-webgpu-device-max-compute-workgroup-size-x", sceneWebGPULimitValue(webgpuDeviceLimits, "maxComputeWorkgroupSizeX"));
    setAttrValue(mount, "data-gosx-scene3d-webgpu-adapter-max-compute-workgroups-per-dimension", sceneWebGPULimitValue(webgpuAdapterLimits, "maxComputeWorkgroupsPerDimension"));
    setAttrValue(mount, "data-gosx-scene3d-webgpu-device-max-compute-workgroups-per-dimension", sceneWebGPULimitValue(webgpuDeviceLimits, "maxComputeWorkgroupsPerDimension"));
    setAttrValue(mount, "data-gosx-scene3d-webgpu-adapter", webgpuDiagnostics && webgpuDiagnostics.adapterInfo ? [
      webgpuDiagnostics.adapterInfo.vendor || "",
      webgpuDiagnostics.adapterInfo.architecture || "",
      webgpuDiagnostics.adapterInfo.device || "",
    ].filter(Boolean).join(" ") : "");
  }

  function showSceneRequiredRendererMessage(mount, props, reason) {
    if (!mount || typeof document === "undefined" || !document || typeof document.createElement !== "function") {
      return;
    }
    const defaultMessage = sceneRequiresWebGL(props)
      ? "Accelerated WebGL is required. Update your browser or enable hardware acceleration."
      : "Scene rendering is unavailable in this browser.";
    const message = String(
      props && props.unsupportedMessage
        ? props.unsupportedMessage
        : defaultMessage
    );
    const wrapper = document.createElement("div");
    wrapper.setAttribute("class", "gosx-scene3d-unsupported");
    wrapper.setAttribute("data-gosx-scene3d-unsupported", "true");
    wrapper.setAttribute("data-gosx-scene3d-unsupported-reason", reason || "webgl-required");
    wrapper.setAttribute("role", "status");
    const text = document.createElement("p");
    text.textContent = message;
    wrapper.appendChild(text);
    mount.appendChild(wrapper);
  }

  function observeSceneCapability(mount, props, capability, onChange) {
    if (!mount || !capability || typeof onChange !== "function") {
      return function() {};
    }
    applySceneCapabilityState(mount, props, capability);
    if (!(window.__gosx.environment && typeof window.__gosx.environment.observe === "function")) {
      return function() {};
    }
    return window.__gosx.environment.observe(function() {
      const next = sceneCapabilityProfile(props);
      if (!sceneCapabilityChanged(capability, next)) {
        return;
      }
      capability.tier = next.tier;
      capability.coarsePointer = next.coarsePointer;
      capability.hover = next.hover;
      capability.reducedData = next.reducedData;
      capability.lowPower = next.lowPower;
      capability.softwareWebGL = next.softwareWebGL;
      capability.visualViewportActive = next.visualViewportActive;
      capability.deviceMemory = next.deviceMemory;
      capability.hardwareConcurrency = next.hardwareConcurrency;
      applySceneCapabilityState(mount, props, capability);
      onChange("capability");
    }, { immediate: false });
  }

  function sceneViewportBase(props) {
    const width = Math.max(240, sceneNumber(props && props.width, 720));
    const height = Math.max(180, sceneNumber(props && props.height, 420));
    const explicitMaxDevicePixelRatio = sceneNumber(props && (props.maxDevicePixelRatio || props.maxPixelRatio), 0);
    return {
      baseWidth: width,
      baseHeight: height,
      aspectRatio: width / Math.max(1, height),
      responsive: sceneBool(props && props.responsive, true),
      explicitMaxDevicePixelRatio,
    };
  }

  function scheduleSceneIdleTask(callback, delayMS) {
    if (typeof callback !== "function") {
      return;
    }
    const delay = Math.max(0, sceneNumber(delayMS, 0));
    const runIdle = function() {
      if (typeof requestIdleCallback === "function") {
        let fired = false;
        const invoke = function(deadline) {
          if (fired) {
            return;
          }
          fired = true;
          callback(deadline);
        };
        requestIdleCallback(invoke, { timeout: 1000 });
        setTimeout(invoke, 1200);
      } else {
        setTimeout(callback, 0);
      }
    };
    if (delay > 0) {
      setTimeout(runIdle, delay);
      return;
    }
    runIdle();
  }

  function sceneCompressionProgressiveDelay(props) {
    const comp = props && props.compression && typeof props.compression === "object" ? props.compression : null;
    if (!comp) {
      return 0;
    }
    return Math.max(0, sceneNumber(
      comp.progressiveDelayMS != null ? comp.progressiveDelayMS : comp.upgradeDelayMS,
      0,
    ));
  }

  function sceneDeferredPostFXDelay(props) {
    return Math.max(0, sceneNumber(
      props && (props.deferPostFXDelayMS != null ? props.deferPostFXDelayMS : props.postFXDelayMS),
      0,
    ));
  }

  function applyScenePostFXState(mount, state) {
    if (!mount || !state) {
      return;
    }
    const deferred = Array.isArray(state._deferredPostEffects) && state._deferredPostEffects.length > 0;
    const enabled = Array.isArray(state.postEffects) && state.postEffects.length > 0;
    setAttrValue(mount, "data-gosx-scene3d-postfx", deferred ? "deferred" : (enabled ? "enabled" : "none"));
  }

  function createSceneStatsOverlay(mount, enabled) {
    if (!mount || !enabled || typeof document.createElement !== "function") {
      return null;
    }
    const element = document.createElement("div");
    element.setAttribute("data-gosx-scene3d-stats", "true");
    element.setAttribute("aria-hidden", "true");
    element.style.position = "absolute";
    element.style.left = "8px";
    element.style.top = "8px";
    element.style.zIndex = "8";
    element.style.pointerEvents = "none";
    element.style.font = "11px/1.35 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace";
    element.style.color = "#d9f7ff";
    element.style.background = "rgba(4, 10, 16, 0.72)";
    element.style.border = "1px solid rgba(141, 225, 255, 0.22)";
    element.style.borderRadius = "6px";
    element.style.padding = "6px 7px";
    element.style.whiteSpace = "pre";
    element.style.backdropFilter = "blur(6px)";
    mount.appendChild(element);
    return {
      element,
      update(bundle, frameStart, renderer, viewport) {
        const now = typeof performance !== "undefined" && performance.now ? performance.now() : Date.now();
        const frameMS = Math.max(0, now - sceneNumber(frameStart, now));
        const fps = frameMS > 0 ? Math.min(999, 1000 / frameMS) : 0;
        const meshes = Array.isArray(bundle && bundle.meshObjects) ? bundle.meshObjects.length : 0;
        const world = Array.isArray(bundle && bundle.objects) ? bundle.objects.length : 0;
        const points = Array.isArray(bundle && bundle.points) ? bundle.points.length : 0;
        const instanced = Array.isArray(bundle && bundle.instancedMeshes) ? bundle.instancedMeshes.length : 0;
        const surfaces = Array.isArray(bundle && bundle.surfaces) ? bundle.surfaces.length : 0;
        const drawCalls = meshes + world + points + instanced + surfaces;
        const materialCount = Array.isArray(bundle && bundle.materials) ? bundle.materials.length : 0;
        element.textContent =
          "fps " + fps.toFixed(0) + "  ms " + frameMS.toFixed(1) + "\n" +
          "draw " + drawCalls + "  mat " + materialCount + "\n" +
          "meshV " + Math.floor(sceneNumber(bundle && bundle.worldMeshVertexCount, 0)) +
          "  lineV " + Math.floor(sceneNumber(bundle && bundle.worldVertexCount, 0)) + "\n" +
          String(renderer && (renderer.type || renderer.kind) || "renderer") +
          "  " + Math.floor(sceneNumber(viewport && viewport.cssWidth, 0)) + "x" + Math.floor(sceneNumber(viewport && viewport.cssHeight, 0));
      },
      dispose() {
        if (element.parentNode === mount) {
          mount.removeChild(element);
        }
      },
    };
  }

  function sceneViewportDevicePixelRatio(props, maxDevicePixelRatio) {
    const environment = sceneEnvironmentState();
    const preferred = sceneNumber(
      props && (props.devicePixelRatio || props.pixelRatio),
      sceneNumber(window && window.devicePixelRatio, sceneNumber(environment && environment.devicePixelRatio, 1)),
    );
    return Math.max(1, Math.min(Math.max(1, maxDevicePixelRatio || 1), preferred));
  }

  function sceneViewportFromMount(mount, props, base, canvas, capability) {
    let cssWidth = base.baseWidth;
    let cssHeight = base.baseHeight;
    const useMeasuredHeight = sceneBool(props && (props.fillHeight || props.responsiveHeight), false);
    if (base.responsive) {
      const mountRect = mount && typeof mount.getBoundingClientRect === "function"
        ? mount.getBoundingClientRect()
        : null;
      const canvasRect = canvas && typeof canvas.getBoundingClientRect === "function"
        ? canvas.getBoundingClientRect()
        : null;
      const measuredCanvasWidth = sceneNumber(canvasRect && canvasRect.width, 0);
      const measuredMountWidth = sceneNumber(mountRect && mountRect.width, 0);
      if (measuredCanvasWidth > 0 && (measuredMountWidth <= 0 || measuredCanvasWidth <= measuredMountWidth * 1.5)) {
        cssWidth = measuredCanvasWidth;
      } else if (measuredMountWidth > 0) {
        cssWidth = measuredMountWidth;
      }
      const measuredHeight = measuredCanvasWidth > 0 && (measuredMountWidth <= 0 || measuredCanvasWidth <= measuredMountWidth * 1.5)
        ? sceneNumber(canvasRect && canvasRect.height, 0)
        : sceneNumber(mountRect && mountRect.height, 0);
      if (useMeasuredHeight && measuredHeight > 0) {
        cssHeight = measuredHeight;
      } else if (cssWidth > 0) {
        cssHeight = cssWidth / Math.max(0.0001, base.aspectRatio);
      }
    }
    cssWidth = Math.max(1, Math.round(cssWidth));
    cssHeight = Math.max(1, Math.round(cssHeight));
    const capabilityMaxDevicePixelRatio = defaultSceneMaxDevicePixelRatio(capability);
    const maxDevicePixelRatio = Math.max(
      1,
      base.explicitMaxDevicePixelRatio > 0
        ? Math.min(base.explicitMaxDevicePixelRatio, capabilityMaxDevicePixelRatio)
        : capabilityMaxDevicePixelRatio,
    );
    const devicePixelRatio = sceneViewportDevicePixelRatio(props, maxDevicePixelRatio);
    return {
      cssWidth,
      cssHeight,
      devicePixelRatio,
      pixelWidth: Math.max(1, Math.round(cssWidth * devicePixelRatio)),
      pixelHeight: Math.max(1, Math.round(cssHeight * devicePixelRatio)),
    };
  }

  function sceneViewportChanged(prev, next) {
    if (!prev || !next) {
      return true;
    }
    return prev.cssWidth !== next.cssWidth
      || prev.cssHeight !== next.cssHeight
      || prev.pixelWidth !== next.pixelWidth
      || prev.pixelHeight !== next.pixelHeight
      || Math.abs(sceneNumber(prev.devicePixelRatio, 1) - sceneNumber(next.devicePixelRatio, 1)) > 0.001;
  }

  function sceneViewportEnvironmentSignature(environment) {
    if (!environment || typeof environment !== "object") {
      return "";
    }
    return [
      sceneNumber(environment.devicePixelRatio, 1).toFixed(3),
      Math.round(sceneNumber(environment.viewportWidth, 0)),
      Math.round(sceneNumber(environment.viewportHeight, 0)),
      Math.round(sceneNumber(environment.visualViewportWidth, 0)),
      Math.round(sceneNumber(environment.visualViewportHeight, 0)),
      environment.visualViewportActive ? "1" : "0",
    ].join("|");
  }

  function applySceneViewport(mount, canvas, labelLayer, viewport, base) {
    if (!mount || !canvas || !viewport) {
      return viewport;
    }
    setAttrValue(mount, "data-gosx-scene3d-css-width", viewport.cssWidth);
    setAttrValue(mount, "data-gosx-scene3d-css-height", viewport.cssHeight);
    setAttrValue(mount, "data-gosx-scene3d-pixel-ratio", viewport.devicePixelRatio);
    setStyleValue(mount.style, "--gosx-scene-css-width", viewport.cssWidth + "px");
    setStyleValue(mount.style, "--gosx-scene-css-height", viewport.cssHeight + "px");
    setStyleValue(mount.style, "--gosx-scene-pixel-ratio", String(viewport.devicePixelRatio));
    canvas.width = viewport.pixelWidth;
    canvas.height = viewport.pixelHeight;
    canvas.setAttribute("width", String(viewport.pixelWidth));
    canvas.setAttribute("height", String(viewport.pixelHeight));
    if (labelLayer) {
      const mountRect = typeof mount.getBoundingClientRect === "function" ? mount.getBoundingClientRect() : null;
      const canvasRect = typeof canvas.getBoundingClientRect === "function" ? canvas.getBoundingClientRect() : null;
      const left = mountRect && canvasRect ? Math.max(0, sceneNumber(canvasRect.left, 0) - sceneNumber(mountRect.left, 0)) : 0;
      const top = mountRect && canvasRect ? Math.max(0, sceneNumber(canvasRect.top, 0) - sceneNumber(mountRect.top, 0)) : 0;
      labelLayer.style.left = left + "px";
      labelLayer.style.top = top + "px";
      labelLayer.style.right = "auto";
      labelLayer.style.bottom = "auto";
      labelLayer.style.width = viewport.cssWidth + "px";
      labelLayer.style.height = viewport.cssHeight + "px";
    }
    if (base && !base.responsive) {
      canvas.style.width = viewport.cssWidth + "px";
      canvas.style.height = viewport.cssHeight + "px";
    } else {
      canvas.style.width = "100%";
      canvas.style.height = "auto";
    }
    return viewport;
  }

  function observeSceneViewport(mount, refresh) {
    if (!mount || typeof refresh !== "function") {
      return function() {};
    }
    let resizeObserver = null;
    let windowResizeListener = null;
    let stopEnvironment = null;

    var resizeRefreshPending = false;
    function scheduleResizeRefresh() {
      if (resizeRefreshPending) {
        return;
      }
      resizeRefreshPending = true;
      if (typeof Promise === "function") {
        Promise.resolve().then(function() {
          resizeRefreshPending = false;
          refresh("resize");
        });
      } else {
        resizeRefreshPending = false;
        refresh("resize");
      }
    }

    if (typeof ResizeObserver === "function") {
      resizeObserver = new ResizeObserver(scheduleResizeRefresh);
      if (typeof resizeObserver.observe === "function") {
        resizeObserver.observe(mount);
      }
    } else if (typeof window.addEventListener === "function") {
      windowResizeListener = scheduleResizeRefresh;
      window.addEventListener("resize", windowResizeListener);
    }

    if (window.__gosx.environment && typeof window.__gosx.environment.observe === "function") {
      let environmentSignature = sceneViewportEnvironmentSignature(sceneEnvironmentState());
      stopEnvironment = window.__gosx.environment.observe(function(environment) {
        const nextSignature = sceneViewportEnvironmentSignature(environment);
        if (environmentSignature === nextSignature) {
          return;
        }
        environmentSignature = nextSignature;
        refresh("environment");
      }, { immediate: false });
    }

    return function() {
      if (resizeObserver && typeof resizeObserver.disconnect === "function") {
        resizeObserver.disconnect();
      }
      if (windowResizeListener && typeof window.removeEventListener === "function") {
        window.removeEventListener("resize", windowResizeListener);
      }
      if (typeof stopEnvironment === "function") {
        stopEnvironment();
      }
    };
  }

  function initialSceneLifecycleState() {
    const environment = sceneEnvironmentState();
    return {
      pageVisible: environment ? Boolean(environment.pageVisible) : String(document && document.visibilityState || "visible").toLowerCase() !== "hidden",
      inViewport: true,
    };
  }

  function initialSceneMotionState(props) {
    const respectReducedMotion = sceneBool(props && props.respectReducedMotion, true);
    const environment = sceneEnvironmentState();
    return {
      respectReducedMotion,
      reducedMotion: respectReducedMotion && environment
        ? Boolean(environment.reducedMotion)
        : sceneMediaQueryMatches("(prefers-reduced-motion: reduce)"),
    };
  }

  function applySceneMotionState(mount, motion) {
    if (!mount || !motion) {
      return;
    }
    setAttrValue(mount, "data-gosx-scene3d-reduced-motion", motion.reducedMotion ? "true" : "false");
  }

  function observeSceneMotion(mount, motion, onChange) {
    if (!mount || !motion || typeof onChange !== "function") {
      return function() {};
    }

    applySceneMotionState(mount, motion);
    if (!motion.respectReducedMotion || !(window.__gosx.environment && typeof window.__gosx.environment.observe === "function")) {
      return function() {};
    }

    return window.__gosx.environment.observe(function(environment) {
      const next = Boolean(environment && environment.reducedMotion);
      if (motion.reducedMotion === next) {
        return;
      }
      motion.reducedMotion = next;
      applySceneMotionState(mount, motion);
      onChange("motion");
    }, { immediate: false });
  }

  function applySceneLifecycleState(mount, lifecycle) {
    if (!mount || !lifecycle) {
      return;
    }
    setAttrValue(mount, "data-gosx-scene3d-page-visible", lifecycle.pageVisible ? "true" : "false");
    setAttrValue(mount, "data-gosx-scene3d-in-viewport", lifecycle.inViewport ? "true" : "false");
    setAttrValue(mount, "data-gosx-scene3d-active", lifecycle.pageVisible && lifecycle.inViewport ? "true" : "false");
  }

  function sceneLifecyclePinnedToViewport(mount) {
    if (!mount || typeof window.getComputedStyle !== "function") {
      return false;
    }
    try {
      const position = String(window.getComputedStyle(mount).position || "").toLowerCase();
      return position === "fixed";
    } catch (_error) {
      return false;
    }
  }

  function observeSceneLifecycle(mount, lifecycle, onChange) {
    if (!mount || !lifecycle || typeof onChange !== "function") {
      return function() {};
    }

    let stopIntersection = null;
    let stopEnvironment = null;

    if (sceneLifecyclePinnedToViewport(mount)) {
      lifecycle.inViewport = true;
    } else if (typeof IntersectionObserver === "function") {
      const observer = new IntersectionObserver(function(entries) {
        for (const entry of entries || []) {
          if (!entry || entry.target !== mount) {
            continue;
          }
          const next = entry.isIntersecting !== false && sceneNumber(entry.intersectionRatio, 1) > 0;
          if (lifecycle.inViewport === next) {
            continue;
          }
          lifecycle.inViewport = next;
          applySceneLifecycleState(mount, lifecycle);
          onChange("intersection");
        }
      }, { threshold: [0, 0.01, 0.25] });
      if (typeof observer.observe === "function") {
        observer.observe(mount);
      }
      stopIntersection = function() {
        if (typeof observer.disconnect === "function") {
          observer.disconnect();
        }
      };
    }

    if (window.__gosx.environment && typeof window.__gosx.environment.observe === "function") {
      stopEnvironment = window.__gosx.environment.observe(function(environment) {
        const next = Boolean(environment && environment.pageVisible);
        if (lifecycle.pageVisible === next) {
          return;
        }
        lifecycle.pageVisible = next;
        applySceneLifecycleState(mount, lifecycle);
        onChange("visibility");
      }, { immediate: false });
    }

    applySceneLifecycleState(mount, lifecycle);
    return function() {
      if (stopIntersection) {
        stopIntersection();
      }
      if (typeof stopEnvironment === "function") {
        stopEnvironment();
      }
    };
  }

  function sceneLabelLayoutKey(label) {
    return [
      gosxTextLayoutRevision(),
      label.text,
      label.font,
      sceneNumber(label.maxWidth, 180),
      Math.max(0, Math.floor(sceneNumber(label.maxLines, 0))),
      normalizeTextLayoutOverflow(label.overflow),
      normalizeSceneLabelWhiteSpace(label.whiteSpace),
      sceneNumber(label.lineHeight, 18),
      normalizeSceneLabelAlign(label.textAlign),
    ].join("\n");
  }

  function sceneMeasureTextWidth(font, text) {
    if (typeof window.__gosx_measure_text_batch !== "function") {
      return String(text || "").length * 8;
    }
    try {
      const raw = window.__gosx_measure_text_batch(font, JSON.stringify([String(text || "")]));
      const widths = typeof raw === "string" ? JSON.parse(raw) : raw;
      return Array.isArray(widths) && widths.length > 0 ? sceneNumber(widths[0], String(text || "").length * 8) : String(text || "").length * 8;
    } catch (_error) {
      return String(text || "").length * 8;
    }
  }

  function fallbackSceneLabelLayout(label) {
    return layoutBrowserText(
      String(label.text || ""),
      label.font,
      sceneNumber(label.maxWidth, 180),
      normalizeSceneLabelWhiteSpace(label.whiteSpace),
      sceneNumber(label.lineHeight, 18),
      {
        maxLines: Math.max(0, Math.floor(sceneNumber(label.maxLines, 0))),
        overflow: normalizeTextLayoutOverflow(label.overflow),
      },
    );
  }

  function layoutSceneLabel(label, layoutCache) {
    const revision = gosxTextLayoutRevision();
    if (layoutCache.__gosxRevision !== revision) {
      layoutCache.clear();
      layoutCache.__gosxRevision = revision;
    }
    const cacheKey = sceneLabelLayoutKey(label);
    if (layoutCache.has(cacheKey)) {
      return {
        key: cacheKey,
        value: layoutCache.get(cacheKey),
      };
    }

    let layout = null;
    if (typeof window.__gosx_text_layout === "function") {
      try {
        layout = window.__gosx_text_layout(
          label.text,
          label.font,
          sceneNumber(label.maxWidth, 180),
          normalizeSceneLabelWhiteSpace(label.whiteSpace),
          sceneNumber(label.lineHeight, 18),
          {
            maxLines: Math.max(0, Math.floor(sceneNumber(label.maxLines, 0))),
            overflow: normalizeTextLayoutOverflow(label.overflow),
          },
        );
      } catch (error) {
        console.error("[gosx] scene label layout failed:", error);
      }
    }

    if (!layout || !Array.isArray(layout.lines)) {
      layout = fallbackSceneLabelLayout(label);
    }
    if (layoutCache.size >= sceneLabelLayoutCacheLimit) {
      const oldest = layoutCache.keys().next();
      if (!oldest.done) {
        layoutCache.delete(oldest.value);
      }
    }
    layoutCache.set(cacheKey, layout);
    return {
      key: cacheKey,
      value: layout,
    };
  }

  const sceneLabelPaddingX = 10;
  const sceneLabelPaddingY = 8;

  function sceneLabelBoxMetrics(label, layout) {
    const contentWidth = Math.max(
      1,
      Math.min(
        sceneNumber(label.maxWidth, 180),
        Math.max(1, Math.ceil(sceneNumber(layout && layout.maxLineWidth, 0) || sceneMeasureTextWidth(label.font, label.text)))
      )
    );
    const contentHeight = Math.max(
      sceneNumber(label.lineHeight, 18),
      Math.ceil(sceneNumber(layout && layout.height, sceneNumber(label.lineHeight, 18)))
    );
    return {
      contentWidth,
      contentHeight,
      totalWidth: contentWidth + (sceneLabelPaddingX * 2),
      totalHeight: contentHeight + (sceneLabelPaddingY * 2),
      maxTotalWidth: Math.max(contentWidth + (sceneLabelPaddingX * 2), sceneNumber(label.maxWidth, 180) + (sceneLabelPaddingX * 2)),
    };
  }

  function sceneLabelBounds(label, metrics) {
    const anchorX = sceneNumber(label.anchorX, 0.5);
    const anchorY = sceneNumber(label.anchorY, 1);
    const anchorPointX = sceneNumber(label.position && label.position.x, 0) + sceneNumber(label.offsetX, 0);
    const anchorPointY = sceneNumber(label.position && label.position.y, 0) + sceneNumber(label.offsetY, 0);
    const left = anchorPointX - (anchorX * metrics.totalWidth);
    const top = anchorPointY - (anchorY * metrics.totalHeight);
    return {
      left,
      top,
      right: left + metrics.totalWidth,
      bottom: top + metrics.totalHeight,
      anchor: { x: anchorPointX, y: anchorPointY },
      center: { x: left + (metrics.totalWidth / 2), y: top + (metrics.totalHeight / 2) },
    };
  }

  function sceneRectArea(box) {
    if (!box) {
      return 0;
    }
    return Math.max(0, box.right - box.left) * Math.max(0, box.bottom - box.top);
  }

  function sceneRectOverlapArea(a, b) {
    if (!a || !b) {
      return 0;
    }
    const overlapX = Math.max(0, Math.min(a.right, b.maxX == null ? b.right : b.maxX) - Math.max(a.left, b.minX == null ? b.left : b.minX));
    const overlapY = Math.max(0, Math.min(a.bottom, b.maxY == null ? b.bottom : b.maxY) - Math.max(a.top, b.minY == null ? b.top : b.minY));
    return overlapX * overlapY;
  }

  function sceneRectsIntersect(a, b) {
    return sceneRectOverlapArea(a, b) > 0;
  }

  function sceneBoundsContainPoint(bounds, point) {
    if (!bounds || !point) {
      return false;
    }
    return point.x >= bounds.minX && point.x <= bounds.maxX && point.y >= bounds.minY && point.y <= bounds.maxY;
  }

  function buildSceneLabelOccluders(bundle, width, height) {
    if (!bundle || !bundle.camera || !Array.isArray(bundle.objects) || !bundle.objects.length) {
      return [];
    }
    const occluders = [];
    for (const object of bundle.objects) {
      if (!object || object.viewCulled) {
        continue;
      }
      const segments = sceneProjectedObjectSegments(bundle, object, width, height);
      if (!segments.length) {
        continue;
      }
      const bounds = sceneProjectedSegmentsBounds(segments);
      if (!bounds) {
        continue;
      }
      occluders.push({
        depth: sceneNumber(object.depthCenter, sceneObjectDepthCenter(object, bundle.camera)),
        bounds,
        hull: sceneProjectedObjectHull(segments),
      });
    }
    occluders.sort(function(a, b) {
      return a.depth - b.depth;
    });
    return occluders;
  }

  function sceneLabelOccluded(entry, occluders) {
    return sceneOverlayOccluded(entry, occluders, entry && entry.label && entry.label.occlude);
  }

  function sceneOverlayOccluded(entry, occluders, occlude) {
    if (!entry || !occlude || !Array.isArray(occluders) || !occluders.length) {
      return false;
    }
    const overlayDepth = sceneNumber(entry && entry.depth, 0);
    for (const occluder of occluders) {
      if (occluder.depth > overlayDepth + 0.05) {
        continue;
      }
      if (!sceneRectsIntersect(entry.box, occluder.bounds)) {
        continue;
      }
      if (scenePointInPolygon(entry.box.anchor, occluder.hull) || sceneBoundsContainPoint(occluder.bounds, entry.box.anchor)) {
        return true;
      }
      if (scenePointInPolygon(entry.box.center, occluder.hull)) {
        return true;
      }
      const overlapRatio = sceneRectOverlapArea(entry.box, occluder.bounds) / Math.max(1, sceneRectArea(entry.box));
      if (overlapRatio >= 0.28) {
        return true;
      }
    }
    return false;
  }

  function sceneLabelPriorityCompare(a, b) {
    const priorityDiff = sceneNumber(b && b.label && b.label.priority, 0) - sceneNumber(a && a.label && a.label.priority, 0);
    if (Math.abs(priorityDiff) > 0.001) {
      return priorityDiff;
    }
    const depthDiff = sceneNumber(a && a.label && a.label.depth, 0) - sceneNumber(b && b.label && b.label.depth, 0);
    if (Math.abs(depthDiff) > 0.001) {
      return depthDiff;
    }
    return sceneNumber(a && a.order, 0) - sceneNumber(b && b.order, 0);
  }

  function prepareSceneLabelEntries(bundle, layoutCache, width, height) {
    const labels = bundle && Array.isArray(bundle.labels) ? bundle.labels : [];
    const occluders = buildSceneLabelOccluders(bundle, width, height);
    const entries = [];
    for (let index = 0; index < labels.length; index += 1) {
      const label = labels[index];
      if (!label || typeof label.text !== "string" || label.text.trim() === "") {
        continue;
      }
      const layout = layoutSceneLabel(label, layoutCache);
      const metrics = sceneLabelBoxMetrics(label, layout.value);
      const box = sceneLabelBounds(label, metrics);
      entries.push({
        id: label.id || ("scene-label-" + index),
        order: index,
        label,
        depth: sceneNumber(label.depth, 0),
        layoutKey: layout.key,
        layout: layout.value,
        metrics,
        box,
        occluded: false,
        hidden: false,
      });
    }

    const sorted = entries.slice().sort(sceneLabelPriorityCompare);
    const occupied = [];
    for (const entry of sorted) {
      entry.occluded = sceneLabelOccluded(entry, occluders);
      if (entry.occluded) {
        entry.hidden = true;
        continue;
      }
      if (normalizeSceneLabelCollision(entry.label.collision) !== "allow") {
        for (const prior of occupied) {
          if (sceneRectsIntersect(entry.box, prior)) {
            entry.hidden = true;
            break;
          }
        }
      }
      if (!entry.hidden) {
        occupied.push(entry.box);
      }
    }

    return entries;
  }

  function sceneSpriteBounds(sprite) {
    const anchorX = sceneNumber(sprite.anchorX, 0.5);
    const anchorY = sceneNumber(sprite.anchorY, 0.5);
    const spriteWidth = Math.max(1, sceneNumber(sprite.width, 1));
    const spriteHeight = Math.max(1, sceneNumber(sprite.height, 1));
    const anchorPointX = sceneNumber(sprite.position && sprite.position.x, 0) + sceneNumber(sprite.offsetX, 0);
    const anchorPointY = sceneNumber(sprite.position && sprite.position.y, 0) + sceneNumber(sprite.offsetY, 0);
    const left = anchorPointX - (anchorX * spriteWidth);
    const top = anchorPointY - (anchorY * spriteHeight);
    return {
      left,
      top,
      right: left + spriteWidth,
      bottom: top + spriteHeight,
      anchor: { x: anchorPointX, y: anchorPointY },
      center: { x: left + (spriteWidth / 2), y: top + (spriteHeight / 2) },
    };
  }

  function sceneSpritePriorityCompare(a, b) {
    const priorityDiff = sceneNumber(b && b.sprite && b.sprite.priority, 0) - sceneNumber(a && a.sprite && a.sprite.priority, 0);
    if (Math.abs(priorityDiff) > 0.001) {
      return priorityDiff;
    }
    const depthDiff = sceneNumber(a && a.sprite && a.sprite.depth, 0) - sceneNumber(b && b.sprite && b.sprite.depth, 0);
    if (Math.abs(depthDiff) > 0.001) {
      return depthDiff;
    }
    return sceneNumber(a && a.order, 0) - sceneNumber(b && b.order, 0);
  }

  function prepareSceneSpriteEntries(bundle, width, height) {
    const sprites = bundle && Array.isArray(bundle.sprites) ? bundle.sprites : [];
    const occluders = buildSceneLabelOccluders(bundle, width, height);
    const entries = [];
    for (let index = 0; index < sprites.length; index += 1) {
      const sprite = sprites[index];
      if (!sprite || typeof sprite.src !== "string" || sprite.src.trim() === "") {
        continue;
      }
      const box = sceneSpriteBounds(sprite);
      entries.push({
        id: sprite.id || ("scene-sprite-" + index),
        order: index,
        sprite,
        depth: sceneNumber(sprite.depth, 0),
        box,
        occluded: false,
        hidden: false,
      });
    }
    const sorted = entries.slice().sort(sceneSpritePriorityCompare);
    for (const entry of sorted) {
      entry.occluded = sceneOverlayOccluded(entry, occluders, entry.sprite && entry.sprite.occlude);
      if (entry.occluded) {
        entry.hidden = true;
      }
    }
    return entries;
  }

  function renderSceneLabelElement(element, label, layoutKey, layout, metrics, box, hidden, occluded) {
    const align = normalizeSceneLabelAlign(label.textAlign);
    const whiteSpace = normalizeSceneLabelWhiteSpace(label.whiteSpace);
    const zIndex = Math.max(1, 1000 + Math.round(sceneNumber(label.priority, 0) * 10) - Math.round(sceneNumber(label.depth, 0) * 10));

    element.setAttribute("data-gosx-scene-label", label.id || "");
    setAttrValue(element, "aria-hidden", "true");
    setAttrValue(element, "class", label.className ? ("gosx-scene-label " + label.className) : "gosx-scene-label");
    setAttrValue(element, "data-gosx-scene-label-collision", normalizeSceneLabelCollision(label.collision));
    setAttrValue(element, "data-gosx-scene-label-occlude", label.occlude ? "true" : "false");
    setAttrValue(element, "data-gosx-scene-label-occluded", occluded ? "true" : "false");
    setAttrValue(element, "data-gosx-scene-label-visibility", hidden ? "hidden" : "visible");
    setAttrValue(element, "data-gosx-scene-label-priority", sceneNumber(label.priority, 0));
    setAttrValue(element, "data-gosx-scene-label-depth", sceneNumber(label.depth, 0));
    setAttrValue(element, "data-gosx-scene-label-truncated", layout && layout.truncated ? "true" : "false");

    applyTextLayoutPresentation(element, {
      font: label.font,
      whiteSpace: whiteSpace,
      lineHeight: sceneNumber(label.lineHeight, 18),
      maxLines: Math.max(0, Math.floor(sceneNumber(label.maxLines, 0))),
      overflow: normalizeTextLayoutOverflow(label.overflow),
      maxWidth: sceneNumber(label.maxWidth, 180),
    }, layout, {
      role: "label",
      surface: "scene3d",
      state: "ready",
      align: align,
      revision: gosxTextLayoutRevision(),
    });

    setStyleValue(element.style, "--gosx-scene-label-left", box.anchor.x + "px");
    setStyleValue(element.style, "--gosx-scene-label-top", box.anchor.y + "px");
    setStyleValue(element.style, "--gosx-scene-label-anchor-x", String(sceneNumber(label.anchorX, 0.5)));
    setStyleValue(element.style, "--gosx-scene-label-anchor-y", String(sceneNumber(label.anchorY, 1)));
    setStyleValue(element.style, "--gosx-scene-label-width", metrics.totalWidth + "px");
    setStyleValue(element.style, "--gosx-scene-label-max-width", metrics.maxTotalWidth + "px");
    setStyleValue(element.style, "--gosx-scene-label-height", metrics.totalHeight + "px");
    setStyleValue(element.style, "--gosx-scene-label-line-height", sceneNumber(label.lineHeight, 18) + "px");
    setStyleValue(element.style, "--gosx-scene-label-align", align);
    setStyleValue(element.style, "--gosx-scene-label-white-space", whiteSpace);
    setStyleValue(element.style, "--gosx-scene-label-font", label.font || '600 13px "IBM Plex Sans", "Segoe UI", sans-serif');
    setStyleValue(element.style, "--gosx-scene-label-color", label.color || "#ecf7ff");
    setStyleValue(element.style, "--gosx-scene-label-background", label.background || "rgba(8, 21, 31, 0.82)");
    setStyleValue(element.style, "--gosx-scene-label-border-color", label.borderColor || "rgba(141, 225, 255, 0.24)");
    setStyleValue(element.style, "--gosx-scene-label-z-index", String(zIndex));
    setStyleValue(element.style, "--gosx-scene-label-depth", String(sceneNumber(label.depth, 0)));
    element.__gosxTextLayout = layout;

    if (element.__gosxLayoutKey === layoutKey) {
      return;
    }

    clearChildren(element);
    const lines = Array.isArray(layout.lines) && layout.lines.length > 0 ? layout.lines : [{ text: label.text }];
    for (const line of lines) {
      const lineElement = document.createElement("div");
      lineElement.setAttribute("data-gosx-scene-label-line", "");
      lineElement.textContent = line && typeof line.text === "string" && line.text !== "" ? line.text : "\u00a0";
      if (whiteSpace !== "normal") {
        lineElement.style.whiteSpace = whiteSpace;
      }
      element.appendChild(lineElement);
    }
    element.__gosxLayoutKey = layoutKey;
  }

  function renderSceneLabels(layer, bundle, layoutCache, elements, width, height) {
    if (!layer) {
      return;
    }

    const labels = prepareSceneLabelEntries(bundle, layoutCache, width, height);
    const active = new Set();

    for (const entry of labels) {
      const id = entry.id;
      active.add(id);
      let element = elements.get(id);
      if (!element) {
        element = document.createElement("div");
        layer.appendChild(element);
        elements.set(id, element);
      }
      renderSceneLabelElement(element, entry.label, entry.layoutKey, entry.layout, entry.metrics, entry.box, entry.hidden, entry.occluded);
    }

    for (const [id, element] of elements.entries()) {
      if (active.has(id)) {
        continue;
      }
      if (element.parentNode === layer) {
        layer.removeChild(element);
      }
      elements.delete(id);
    }
  }

  function renderSceneSpriteElement(element, sprite, box, hidden, occluded) {
    const zIndex = Math.max(1, 1000 + Math.round(sceneNumber(sprite.priority, 0) * 10) - Math.round(sceneNumber(sprite.depth, 0) * 10));
    element.setAttribute("data-gosx-scene-sprite", sprite.id || "");
    setAttrValue(element, "aria-hidden", "true");
    setAttrValue(element, "class", sprite.className ? ("gosx-scene-sprite " + sprite.className) : "gosx-scene-sprite");
    setAttrValue(element, "data-gosx-scene-sprite-fit", normalizeSceneSpriteFit(sprite.fit));
    setAttrValue(element, "data-gosx-scene-sprite-occlude", sprite.occlude ? "true" : "false");
    setAttrValue(element, "data-gosx-scene-sprite-occluded", occluded ? "true" : "false");
    setAttrValue(element, "data-gosx-scene-sprite-visibility", hidden ? "hidden" : "visible");
    setAttrValue(element, "data-gosx-scene-sprite-priority", sceneNumber(sprite.priority, 0));
    setAttrValue(element, "data-gosx-scene-sprite-depth", sceneNumber(sprite.depth, 0));
    setStyleValue(element.style, "--gosx-scene-sprite-left", box.anchor.x + "px");
    setStyleValue(element.style, "--gosx-scene-sprite-top", box.anchor.y + "px");
    setStyleValue(element.style, "--gosx-scene-sprite-anchor-x", String(sceneNumber(sprite.anchorX, 0.5)));
    setStyleValue(element.style, "--gosx-scene-sprite-anchor-y", String(sceneNumber(sprite.anchorY, 0.5)));
    setStyleValue(element.style, "--gosx-scene-sprite-width", Math.max(1, sceneNumber(sprite.width, 1)) + "px");
    setStyleValue(element.style, "--gosx-scene-sprite-height", Math.max(1, sceneNumber(sprite.height, 1)) + "px");
    setStyleValue(element.style, "--gosx-scene-sprite-opacity", String(clamp01(sceneNumber(sprite.opacity, 1))));
    setStyleValue(element.style, "--gosx-scene-sprite-fit", normalizeSceneSpriteFit(sprite.fit));
    setStyleValue(element.style, "--gosx-scene-sprite-z-index", String(zIndex));
    setStyleValue(element.style, "--gosx-scene-sprite-depth", String(sceneNumber(sprite.depth, 0)));

    let image = element.firstChild;
    if (!image || image.tagName !== "IMG") {
      clearChildren(element);
      image = document.createElement("img");
      image.setAttribute("draggable", "false");
      image.setAttribute("alt", "");
      image.setAttribute("aria-hidden", "true");
      element.appendChild(image);
    }
    setAttrValue(image, "src", sprite.src || "");
    setStyleValue(image.style, "objectFit", normalizeSceneSpriteFit(sprite.fit) === "fill" ? "fill" : normalizeSceneSpriteFit(sprite.fit));
  }

  function renderSceneSprites(layer, bundle, elements, width, height) {
    if (!layer) {
      return;
    }

    const sprites = prepareSceneSpriteEntries(bundle, width, height);
    const active = new Set();
    for (const entry of sprites) {
      const id = entry.id;
      active.add(id);
      let element = elements.get(id);
      if (!element) {
        element = document.createElement("div");
        layer.appendChild(element);
        elements.set(id, element);
      }
      renderSceneSpriteElement(element, entry.sprite, entry.box, entry.hidden, entry.occluded);
    }
    for (const [id, element] of elements.entries()) {
      if (active.has(id)) {
        continue;
      }
      if (element.parentNode === layer) {
        layer.removeChild(element);
      }
      elements.delete(id);
    }
  }

  function sceneHTMLBounds(entry) {
    const anchorX = sceneNumber(entry.anchorX, 0.5);
    const anchorY = sceneNumber(entry.anchorY, 0.5);
    const htmlWidth = Math.max(1, sceneNumber(entry.width, 1));
    const htmlHeight = Math.max(1, sceneNumber(entry.height, 1));
    const anchorPointX = sceneNumber(entry.position && entry.position.x, 0) + sceneNumber(entry.offsetX, 0);
    const anchorPointY = sceneNumber(entry.position && entry.position.y, 0) + sceneNumber(entry.offsetY, 0);
    const left = anchorPointX - (anchorX * htmlWidth);
    const top = anchorPointY - (anchorY * htmlHeight);
    return {
      left,
      top,
      right: left + htmlWidth,
      bottom: top + htmlHeight,
      anchor: { x: anchorPointX, y: anchorPointY },
      center: { x: left + (htmlWidth / 2), y: top + (htmlHeight / 2) },
    };
  }

  function sceneHTMLPriorityCompare(a, b) {
    const priorityDiff = sceneNumber(b && b.html && b.html.priority, 0) - sceneNumber(a && a.html && a.html.priority, 0);
    if (Math.abs(priorityDiff) > 0.001) {
      return priorityDiff;
    }
    const depthDiff = sceneNumber(a && a.html && a.html.depth, 0) - sceneNumber(b && b.html && b.html.depth, 0);
    if (Math.abs(depthDiff) > 0.001) {
      return depthDiff;
    }
    return sceneNumber(a && a.order, 0) - sceneNumber(b && b.order, 0);
  }

  function prepareSceneHTMLEntries(bundle, width, height) {
    const htmlEntries = bundle && Array.isArray(bundle.html) ? bundle.html : [];
    const occluders = buildSceneLabelOccluders(bundle, width, height);
    const entries = [];
    for (let index = 0; index < htmlEntries.length; index += 1) {
      const htmlEntry = htmlEntries[index];
      if (!htmlEntry || typeof htmlEntry.html !== "string" || htmlEntry.html.trim() === "") {
        continue;
      }
      const box = sceneHTMLBounds(htmlEntry);
      entries.push({
        id: htmlEntry.id || ("scene-html-" + index),
        order: index,
        html: htmlEntry,
        depth: sceneNumber(htmlEntry.depth, 0),
        box,
        occluded: false,
        hidden: false,
      });
    }
    const sorted = entries.slice().sort(sceneHTMLPriorityCompare);
    for (const entry of sorted) {
      entry.occluded = sceneOverlayOccluded(entry, occluders, entry.html && entry.html.occlude);
      if (entry.occluded) {
        entry.hidden = true;
      }
    }
    return entries;
  }

  function renderSceneHTMLElement(element, htmlEntry, box, hidden, occluded) {
    const zIndex = Math.max(1, 1000 + Math.round(sceneNumber(htmlEntry.priority, 0) * 10) - Math.round(sceneNumber(htmlEntry.depth, 0) * 10));
    element.setAttribute("data-gosx-scene-html", htmlEntry.id || "");
    setAttrValue(element, "class", htmlEntry.className ? ("gosx-scene-html " + htmlEntry.className) : "gosx-scene-html");
    setAttrValue(element, "data-gosx-scene-html-occlude", htmlEntry.occlude ? "true" : "false");
    setAttrValue(element, "data-gosx-scene-html-occluded", occluded ? "true" : "false");
    setAttrValue(element, "data-gosx-scene-html-visibility", hidden ? "hidden" : "visible");
    setAttrValue(element, "aria-hidden", hidden ? "true" : "false");
    setAttrValue(element, "data-gosx-scene-html-priority", sceneNumber(htmlEntry.priority, 0));
    setAttrValue(element, "data-gosx-scene-html-depth", sceneNumber(htmlEntry.depth, 0));
    setAttrValue(element, "data-gosx-scene-html-pointer-events", normalizeSceneHTMLPointerEvents(htmlEntry.pointerEvents, "none"));
    setStyleValue(element.style, "--gosx-scene-html-left", box.anchor.x + "px");
    setStyleValue(element.style, "--gosx-scene-html-top", box.anchor.y + "px");
    setStyleValue(element.style, "--gosx-scene-html-anchor-x", String(sceneNumber(htmlEntry.anchorX, 0.5)));
    setStyleValue(element.style, "--gosx-scene-html-anchor-y", String(sceneNumber(htmlEntry.anchorY, 0.5)));
    setStyleValue(element.style, "--gosx-scene-html-width", Math.max(1, sceneNumber(htmlEntry.width, 1)) + "px");
    setStyleValue(element.style, "--gosx-scene-html-min-height", Math.max(1, sceneNumber(htmlEntry.height, 1)) + "px");
    setStyleValue(element.style, "--gosx-scene-html-opacity", String(clamp01(sceneNumber(htmlEntry.opacity, 1))));
    setStyleValue(element.style, "--gosx-scene-html-z-index", String(zIndex));
    setStyleValue(element.style, "--gosx-scene-html-depth", String(sceneNumber(htmlEntry.depth, 0)));
    setStyleValue(element.style, "--gosx-scene-html-pointer-events", normalizeSceneHTMLPointerEvents(htmlEntry.pointerEvents, "none"));
    if (element.__gosxHTMLMarkup !== htmlEntry.html) {
      element.innerHTML = htmlEntry.html;
      element.__gosxHTMLMarkup = htmlEntry.html;
    }
  }

  function renderSceneHTML(layer, bundle, elements, width, height) {
    if (!layer) {
      return;
    }
    const entries = prepareSceneHTMLEntries(bundle, width, height);
    setAttrValue(layer, "aria-hidden", entries.length > 0 ? "false" : "true");
    const active = new Set();
    for (const entry of entries) {
      const id = entry.id;
      active.add(id);
      let element = elements.get(id);
      if (!element) {
        element = document.createElement("div");
        layer.appendChild(element);
        elements.set(id, element);
      }
      renderSceneHTMLElement(element, entry.html, entry.box, entry.hidden, entry.occluded);
    }
    for (const [id, element] of elements.entries()) {
      if (active.has(id)) {
        continue;
      }
      if (element.parentNode === layer) {
        layer.removeChild(element);
      }
      elements.delete(id);
    }
  }

  function normalizeSceneControlsMode(value) {
    switch (String(value || "").trim().toLowerCase()) {
      case "orbit":
        return "orbit";
      case "first-person":
      case "firstperson":
      case "fps":
        return "first-person";
      case "fly":
      case "free":
      case "free-camera":
        return "fly";
      default:
        return "";
    }
  }

  function sceneControlsTarget(props) {
    const raw = props && props.controlTarget && typeof props.controlTarget === "object" ? props.controlTarget : null;
    return {
      x: sceneNumber(raw && raw.x, 0),
      y: sceneNumber(raw && raw.y, 0),
      z: sceneNumber(raw && raw.z, 0),
    };
  }

  function sceneControlsRotateSpeed(props) {
    return Math.max(0.1, sceneNumber(props && props.controlRotateSpeed, 1));
  }

  function sceneControlsZoomSpeed(props) {
    return Math.max(0.05, sceneNumber(props && props.controlZoomSpeed, 1));
  }

  function sceneControlsLookSpeed(props) {
    return Math.max(0.05, sceneNumber(props && props.controlLookSpeed, sceneNumber(props && props.controlRotateSpeed, 1)));
  }

  function sceneControlsMoveSpeed(props) {
    return Math.max(0.01, sceneNumber(props && props.controlMoveSpeed, 4));
  }

  function scenePointerLockRequested(props) {
    return sceneBool(props && props.pointerLock, false);
  }

  function scenePointerLockElement() {
    if (typeof document === "undefined" || !document) {
      return null;
    }
    return document.pointerLockElement ||
      document.mozPointerLockElement ||
      document.webkitPointerLockElement ||
      null;
  }

  function scenePointerLockActive(canvas) {
    return Boolean(canvas && scenePointerLockElement() === canvas);
  }

  function sceneRequestPointerLock(canvas) {
    if (!canvas || typeof canvas.requestPointerLock !== "function") {
      return false;
    }
    try {
      canvas.requestPointerLock({ unadjustedMovement: true });
      return true;
    } catch (_unadjustedError) {
      try {
        canvas.requestPointerLock();
        return true;
      } catch (_error) {
        return false;
      }
    }
  }

  function sceneExitPointerLock(canvas) {
    if (!scenePointerLockActive(canvas)) {
      return;
    }
    const exit = document.exitPointerLock || document.mozExitPointerLock || document.webkitExitPointerLock;
    if (typeof exit !== "function") {
      return;
    }
    try {
      exit.call(document);
    } catch (_error) {}
  }

  function sceneWorldCameraPosition(camera) {
    const normalized = sceneRenderCamera(camera);
    return {
      x: normalized.x,
      y: normalized.y,
      z: -normalized.z,
    };
  }

  function sceneFlyStateFromCamera(camera) {
    const normalized = sceneRenderCamera(camera);
    return {
      position: sceneWorldCameraPosition(normalized),
      yaw: sceneNumber(normalized.rotationY, 0),
      pitch: sceneClamp(sceneNumber(normalized.rotationX, 0), -1.52, 1.52),
      kind: normalized.kind,
      fov: normalized.fov,
      left: normalized.left,
      right: normalized.right,
      top: normalized.top,
      bottom: normalized.bottom,
      zoom: normalized.zoom,
      near: normalized.near,
      far: normalized.far,
    };
  }

  function sceneFlyCamera(state, fallbackCamera) {
    const base = sceneRenderCamera(fallbackCamera);
    const fly = state || sceneFlyStateFromCamera(base);
    const position = fly.position || { x: 0, y: 0, z: -6 };
    return {
      x: sceneNumber(position.x, base.x),
      y: sceneNumber(position.y, base.y),
      z: -sceneNumber(position.z, -base.z),
      kind: base.kind,
      rotationX: sceneClamp(sceneNumber(fly.pitch, base.rotationX), -1.52, 1.52),
      rotationY: sceneNumber(fly.yaw, base.rotationY),
      rotationZ: 0,
      fov: sceneNumber(fly.fov, base.fov),
      left: sceneNumber(fly.left, base.left),
      right: sceneNumber(fly.right, base.right),
      top: sceneNumber(fly.top, base.top),
      bottom: sceneNumber(fly.bottom, base.bottom),
      zoom: sceneNumber(fly.zoom, base.zoom),
      near: sceneNumber(fly.near, base.near),
      far: sceneNumber(fly.far, base.far),
    };
  }

  function sceneOrbitStateFromCamera(camera, target) {
    const normalized = sceneRenderCamera(camera);
    const worldPosition = sceneWorldCameraPosition(normalized);
    const orbitTarget = target || { x: 0, y: 0, z: 0 };
    const offsetX = worldPosition.x - sceneNumber(orbitTarget.x, 0);
    const offsetY = worldPosition.y - sceneNumber(orbitTarget.y, 0);
    const offsetZ = worldPosition.z - sceneNumber(orbitTarget.z, 0);
    const radius = Math.max(0.6, Math.hypot(offsetX, offsetY, offsetZ));
    return {
      target: {
        x: sceneNumber(orbitTarget.x, 0),
        y: sceneNumber(orbitTarget.y, 0),
        z: sceneNumber(orbitTarget.z, 0),
      },
      radius,
      yaw: Math.atan2(offsetX, -offsetZ),
      pitch: Math.asin(sceneClamp(offsetY / radius, -0.98, 0.98)),
      kind: normalized.kind,
      fov: normalized.fov,
      left: normalized.left,
      right: normalized.right,
      top: normalized.top,
      bottom: normalized.bottom,
      zoom: normalized.zoom,
      near: normalized.near,
      far: normalized.far,
    };
  }

  function sceneOrbitCamera(state, fallbackCamera) {
    const base = sceneRenderCamera(fallbackCamera);
    const orbit = state || sceneOrbitStateFromCamera(base, { x: 0, y: 0, z: 0 });
    const radius = Math.max(0.6, sceneNumber(orbit.radius, 6));
    const pitch = sceneClamp(sceneNumber(orbit.pitch, 0), -1.4, 1.4);
    const yaw = sceneNumber(orbit.yaw, 0);
    const target = orbit.target || { x: 0, y: 0, z: 0 };
    const cosPitch = Math.cos(pitch);
    const worldPosition = {
      x: sceneNumber(target.x, 0) + Math.sin(yaw) * cosPitch * radius,
      y: sceneNumber(target.y, 0) + Math.sin(pitch) * radius,
      z: sceneNumber(target.z, 0) - Math.cos(yaw) * cosPitch * radius,
    };
    const forward = {
      x: sceneNumber(target.x, 0) - worldPosition.x,
      y: sceneNumber(target.y, 0) - worldPosition.y,
      z: sceneNumber(target.z, 0) - worldPosition.z,
    };
    const horizontal = Math.max(0.0001, Math.hypot(forward.x, forward.z));
    return {
      x: worldPosition.x,
      y: worldPosition.y,
      z: -worldPosition.z,
      kind: base.kind,
      rotationX: -Math.atan2(forward.y, horizontal),
      rotationY: Math.atan2(forward.x, forward.z),
      rotationZ: 0,
      fov: sceneNumber(orbit.fov, base.fov),
      left: sceneNumber(orbit.left, base.left),
      right: sceneNumber(orbit.right, base.right),
      top: sceneNumber(orbit.top, base.top),
      bottom: sceneNumber(orbit.bottom, base.bottom),
      zoom: sceneNumber(orbit.zoom, base.zoom),
      near: sceneNumber(orbit.near, base.near),
      far: sceneNumber(orbit.far, base.far),
    };
  }

  function createSceneControls(props) {
    const mode = normalizeSceneControlsMode(props && props.controls);
    if (!mode) {
      return null;
    }
    return {
      mode,
      active: false,
      touched: false,
      pointerId: null,
      lastX: 0,
      lastY: 0,
      rotateSpeed: sceneControlsRotateSpeed(props),
      zoomSpeed: sceneControlsZoomSpeed(props),
      lookSpeed: sceneControlsLookSpeed(props),
      moveSpeed: sceneControlsMoveSpeed(props),
      pointerLock: mode !== "orbit" && scenePointerLockRequested(props),
      pointerLocked: false,
      orbit: null,
      fly: null,
      keys: new Set(),
      target: sceneControlsTarget(props),
    };
  }

  function syncSceneControlsFromCamera(controls, camera) {
    if (!controls || controls.active || controls.touched) {
      return;
    }
    if (controls.mode === "orbit") {
      controls.orbit = sceneOrbitStateFromCamera(camera, controls.target);
    } else if (controls.mode === "first-person" || controls.mode === "fly") {
      controls.fly = sceneFlyStateFromCamera(camera);
    }
  }

  function sceneScrollViewportHeight() {
    const scrollingElement = document.scrollingElement || document.documentElement || document.body;
    const visualViewport = window.visualViewport;
    return Math.max(1, sceneNumber(
      visualViewport && visualViewport.height,
      sceneNumber(window.innerHeight, sceneNumber(scrollingElement && scrollingElement.clientHeight, 0)),
    ));
  }

  function sceneScrollTop() {
    const scrollingElement = document.scrollingElement || document.documentElement || document.body;
    const visualViewport = window.visualViewport;
    const visualViewportTop = sceneNumber(visualViewport && visualViewport.pageTop, NaN);
    if (Number.isFinite(visualViewportTop)) {
      return Math.max(0, visualViewportTop);
    }
    return Math.max(0, sceneNumber(
      window.scrollY,
      sceneNumber(window.pageYOffset, sceneNumber(scrollingElement && scrollingElement.scrollTop, 0)),
    ));
  }

  function sceneScrollMax() {
    const scrollingElement = document.scrollingElement || document.documentElement || document.body;
    const scrollHeight = Math.max(
      sceneNumber(scrollingElement && scrollingElement.scrollHeight, 0),
      sceneNumber(document.documentElement && document.documentElement.scrollHeight, 0),
      sceneNumber(document.body && document.body.scrollHeight, 0),
    );
    return Math.max(1, scrollHeight - sceneScrollViewportHeight());
  }

  function sceneUpdateScrollCameraMetrics(scrollCamera, includeMax, activeInput) {
    if (!scrollCamera) {
      return;
    }
    scrollCamera._scrollTop = sceneScrollTop();
    if (includeMax || !Number.isFinite(sceneNumber(scrollCamera._scrollMax, NaN))) {
      scrollCamera._scrollMax = sceneScrollMax();
    }
    if (activeInput) {
      scrollCamera._activeInputUntil = sceneNowMilliseconds() + 180;
    }
  }

  function sceneAdvanceScrollCamera(scrollCamera) {
    if (!scrollCamera || scrollCamera.start === scrollCamera.end) {
      return;
    }
    const scrollTop = sceneNumber(scrollCamera._scrollTop, 0);
    const scrollMax = Math.max(1, sceneNumber(scrollCamera._scrollMax, 1));
    scrollCamera._progress = Math.pow(Math.min(1, Math.max(0, scrollTop / scrollMax)), 0.5);
    var target = scrollCamera._progress || 0;
    var current = sceneNumber(scrollCamera._smoothProgress, target);
    if (sceneNumber(scrollCamera._activeInputUntil, 0) >= sceneNowMilliseconds()) {
      current = target;
    } else if (Math.abs(target - current) < 0.0005) {
      current = target;
    } else {
      current += (target - current) * 0.08;
    }
    scrollCamera._smoothProgress = current;
  }

  function sceneCurrentControlCamera(controls, sourceCamera, scrollCamera) {
    var cam;
    if (controls && controls.mode === "orbit") {
      syncSceneControlsFromCamera(controls, sourceCamera);
      cam = controls.orbit ? sceneOrbitCamera(controls.orbit, sourceCamera) : sceneRenderCamera(sourceCamera);
    } else if (controls && (controls.mode === "first-person" || controls.mode === "fly")) {
      syncSceneControlsFromCamera(controls, sourceCamera);
      cam = controls.fly ? sceneFlyCamera(controls.fly, sourceCamera) : sceneRenderCamera(sourceCamera);
    } else {
      cam = sceneRenderCamera(sourceCamera);
    }
    if (scrollCamera && scrollCamera.start !== scrollCamera.end) {
      var progress = sceneNumber(scrollCamera._smoothProgress, sceneNumber(scrollCamera._progress, 0));
      cam.z = scrollCamera.start + progress * (scrollCamera.end - scrollCamera.start);
    }
    return cam;
  }

  function sceneBundleWithCameraOverride(bundle, camera) {
    if (!bundle) {
      return bundle;
    }
    const targetCamera = sceneRenderCamera(camera);
    const sourceCamera = sceneRenderCamera(bundle.camera);
    if (sceneCameraEquivalent(targetCamera, sourceCamera)) {
      return bundle;
    }
    return Object.assign({}, bundle, {
      camera: targetCamera,
      sourceCamera: sourceCamera,
    });
  }

  function sceneControlsMetrics(readViewport, props) {
    const viewport = typeof readViewport === "function" ? readViewport() : null;
    return {
      width: Math.max(1, sceneViewportValue(viewport, "cssWidth", sceneNumber(props && props.width, 720))),
      height: Math.max(1, sceneViewportValue(viewport, "cssHeight", sceneNumber(props && props.height, 420))),
    };
  }

  function syncSceneControlsFromSource(controls, readSourceCamera) {
    const sourceCamera = typeof readSourceCamera === "function" ? readSourceCamera() : null;
    syncSceneControlsFromCamera(controls, sourceCamera);
  }

  function sceneOrbitStartDrag(controls, canvas, props, readViewport, readSourceCamera, attachDocumentListeners, event) {
    if (controls.active || !scenePointerCanStartDrag(controls, event)) {
      return;
    }
    syncSceneControlsFromSource(controls, readSourceCamera);
    controls.active = true;
    controls.touched = true;
    controls.pointerId = event.pointerId;
    const metrics = sceneControlsMetrics(readViewport, props);
    const point = sceneLocalPointerPoint(event, canvas, metrics.width, metrics.height);
    controls.lastX = point.x;
    controls.lastY = point.y;
    canvas.style.cursor = "grabbing";
    attachDocumentListeners();
    if (typeof canvas.setPointerCapture === "function" && event.pointerId != null) {
      canvas.setPointerCapture(event.pointerId);
    }
    if (typeof event.preventDefault === "function") {
      event.preventDefault();
    }
    if (typeof event.stopPropagation === "function") {
      event.stopPropagation();
    }
  }

  function sceneOrbitMoveDrag(controls, canvas, props, readViewport, readSourceCamera, scheduleRender, event) {
    if (!sceneDragMatchesActivePointer(controls, event)) {
      return;
    }
    const metrics = sceneControlsMetrics(readViewport, props);
    const sample = sceneLocalPointerSample(event, canvas, metrics.width, metrics.height, controls, "move");
    if (!controls.orbit) {
      syncSceneControlsFromSource(controls, readSourceCamera);
    }
    controls.orbit.yaw += (sample.deltaX / Math.max(metrics.width, 1)) * Math.PI * controls.rotateSpeed;
    controls.orbit.pitch = sceneClamp(
      controls.orbit.pitch + (sample.deltaY / Math.max(metrics.height, 1)) * Math.PI * controls.rotateSpeed,
      -1.4,
      1.4,
    );
    if (typeof event.preventDefault === "function") {
      event.preventDefault();
    }
    if (typeof event.stopPropagation === "function") {
      event.stopPropagation();
    }
    scheduleRender("controls");
  }

  function sceneOrbitFinishDrag(controls, canvas, detachDocumentListeners, event) {
    if (!sceneDragMatchesActivePointer(controls, event)) {
      return;
    }
    const pointerId = controls.pointerId;
    controls.active = false;
    controls.pointerId = null;
    canvas.style.cursor = "grab";
    detachDocumentListeners();
    if (pointerId != null && typeof canvas.releasePointerCapture === "function") {
      try {
        canvas.releasePointerCapture(pointerId);
      } catch (_error) {}
    }
    if (event && typeof event.preventDefault === "function") {
      event.preventDefault();
    }
    if (event && typeof event.stopPropagation === "function") {
      event.stopPropagation();
    }
  }

  function sceneOrbitApplyWheel(controls, readSourceCamera, scheduleRender, event) {
    syncSceneControlsFromSource(controls, readSourceCamera);
    controls.touched = true;
    controls.orbit.radius = sceneClamp(
      controls.orbit.radius * Math.exp(sceneNumber(event && event.deltaY, 0) * 0.001 * controls.zoomSpeed),
      0.6,
      256,
    );
    if (event && typeof event.preventDefault === "function") {
      event.preventDefault();
    }
    if (event && typeof event.stopPropagation === "function") {
      event.stopPropagation();
    }
    scheduleRender("controls");
  }

  function sceneFlyEnsureState(controls, readSourceCamera) {
    if (!controls.fly) {
      syncSceneControlsFromSource(controls, readSourceCamera);
    }
    if (!controls.fly) {
      controls.fly = sceneFlyStateFromCamera(null);
    }
    if (!controls.fly.position) {
      controls.fly.position = { x: 0, y: 0, z: -6 };
    }
    return controls.fly;
  }

  function sceneFlyStartDrag(controls, canvas, props, readViewport, readSourceCamera, attachDocumentListeners, event) {
    if (controls.active || !scenePointerCanStartDrag(controls, event)) {
      return;
    }
    sceneFlyEnsureState(controls, readSourceCamera);
    controls.active = true;
    controls.touched = true;
    controls.pointerId = event.pointerId;
    const metrics = sceneControlsMetrics(readViewport, props);
    const point = sceneLocalPointerPoint(event, canvas, metrics.width, metrics.height);
    controls.lastX = point.x;
    controls.lastY = point.y;
    canvas.style.cursor = "grabbing";
    if (typeof canvas.focus === "function") {
      canvas.focus({ preventScroll: true });
    }
    attachDocumentListeners();
    if (controls.pointerLock) {
      sceneRequestPointerLock(canvas);
      controls.pointerLocked = scenePointerLockActive(canvas);
    }
    if (typeof canvas.setPointerCapture === "function" && event.pointerId != null) {
      canvas.setPointerCapture(event.pointerId);
    }
    if (typeof event.preventDefault === "function") {
      event.preventDefault();
    }
    if (typeof event.stopPropagation === "function") {
      event.stopPropagation();
    }
  }

  function sceneFlyMoveDrag(controls, canvas, props, readViewport, readSourceCamera, scheduleRender, event) {
    if (!sceneDragMatchesActivePointer(controls, event)) {
      return;
    }
    const metrics = sceneControlsMetrics(readViewport, props);
    const pointerLocked = controls.pointerLock && scenePointerLockActive(canvas);
    controls.pointerLocked = pointerLocked;
    const sample = pointerLocked ? {
      deltaX: sceneNumber(event && event.movementX, 0),
      deltaY: sceneNumber(event && event.movementY, 0),
    } : sceneLocalPointerSample(event, canvas, metrics.width, metrics.height, controls, "move");
    const fly = sceneFlyEnsureState(controls, readSourceCamera);
    fly.yaw += (sample.deltaX / Math.max(metrics.width, 1)) * Math.PI * controls.lookSpeed;
    fly.pitch = sceneClamp(
      fly.pitch + (sample.deltaY / Math.max(metrics.height, 1)) * Math.PI * controls.lookSpeed,
      -1.52,
      1.52,
    );
    if (typeof event.preventDefault === "function") {
      event.preventDefault();
    }
    if (typeof event.stopPropagation === "function") {
      event.stopPropagation();
    }
    scheduleRender("controls");
  }

  function sceneFlyFinishDrag(controls, canvas, detachDocumentListeners, event) {
    if (!sceneDragMatchesActivePointer(controls, event)) {
      return;
    }
    if (controls.pointerLock && scenePointerLockActive(canvas) && event && event.type !== "pointerlockchange") {
      if (typeof event.preventDefault === "function") {
        event.preventDefault();
      }
      if (typeof event.stopPropagation === "function") {
        event.stopPropagation();
      }
      return;
    }
    const pointerId = controls.pointerId;
    controls.active = false;
    controls.pointerId = null;
    controls.pointerLocked = false;
    canvas.style.cursor = "crosshair";
    detachDocumentListeners();
    if (pointerId != null && typeof canvas.releasePointerCapture === "function") {
      try {
        canvas.releasePointerCapture(pointerId);
      } catch (_error) {}
    }
    if (event && typeof event.preventDefault === "function") {
      event.preventDefault();
    }
    if (event && typeof event.stopPropagation === "function") {
      event.stopPropagation();
    }
  }

  function sceneFlyKeyCode(event) {
    const code = String(event && (event.code || event.key) || "").toLowerCase();
    switch (code) {
      case "keyw":
      case "w":
      case "arrowup":
        return "forward";
      case "keys":
      case "s":
      case "arrowdown":
        return "back";
      case "keya":
      case "a":
      case "arrowleft":
        return "left";
      case "keyd":
      case "d":
      case "arrowright":
        return "right";
      case "space":
      case " ":
        return "up";
      case "shiftleft":
      case "shiftright":
      case "controlleft":
      case "controlright":
        return "down";
      default:
        return "";
    }
  }

  function sceneFlyApplyMovement(controls, readSourceCamera, deltaSeconds) {
    if (!controls || !controls.keys || controls.keys.size === 0) {
      return false;
    }
    const fly = sceneFlyEnsureState(controls, readSourceCamera);
    const speed = controls.moveSpeed * Math.max(0.001, deltaSeconds || 1 / 60);
    const yaw = sceneNumber(fly.yaw, 0);
    const pitch = controls.mode === "fly" ? sceneNumber(fly.pitch, 0) : 0;
    const cosPitch = Math.cos(pitch);
    const forward = {
      x: Math.sin(yaw) * cosPitch,
      y: -Math.sin(pitch),
      z: -Math.cos(yaw) * cosPitch,
    };
    const right = { x: Math.cos(yaw), y: 0, z: Math.sin(yaw) };
    let dx = 0;
    let dy = 0;
    let dz = 0;
    if (controls.keys.has("forward")) {
      dx += forward.x; dy += forward.y; dz += forward.z;
    }
    if (controls.keys.has("back")) {
      dx -= forward.x; dy -= forward.y; dz -= forward.z;
    }
    if (controls.keys.has("right")) {
      dx += right.x; dz += right.z;
    }
    if (controls.keys.has("left")) {
      dx -= right.x; dz -= right.z;
    }
    if (controls.keys.has("up")) {
      dy += 1;
    }
    if (controls.keys.has("down")) {
      dy -= 1;
    }
    const length = Math.hypot(dx, dy, dz);
    if (length <= 0.0001) {
      return false;
    }
    fly.position.x += (dx / length) * speed;
    fly.position.y += (dy / length) * speed;
    fly.position.z += (dz / length) * speed;
    controls.touched = true;
    return true;
  }

  function setupSceneBuiltInControls(canvas, props, readViewport, readSourceCamera, scheduleRender) {
    const controls = createSceneControls(props);
    if (!canvas || !controls) {
      return {
        controller: controls,
        dispose() {},
      };
    }

    let documentListenersAttached = false;
    let flyFrame = 0;
    let flyLastFrameMS = 0;
    const flyMode = controls.mode === "first-person" || controls.mode === "fly";
    canvas.style.cursor = flyMode ? "crosshair" : "grab";
    canvas.style.touchAction = "none";
    if (flyMode && !canvas.hasAttribute("tabindex")) {
      canvas.setAttribute("tabindex", "0");
    }

    function onPointerLockChange(event) {
      if (!flyMode || !controls.pointerLock) {
        return;
      }
      const locked = scenePointerLockActive(canvas);
      controls.pointerLocked = locked;
      if (!locked && controls.active) {
        sceneFlyFinishDrag(controls, canvas, detachDocumentListeners, event || { type: "pointerlockchange" });
      }
    }

    function attachDocumentListeners() {
      if (documentListenersAttached) {
        return;
      }
      documentListenersAttached = true;
      document.addEventListener("pointermove", onPointerMove);
      document.addEventListener("pointerup", finishPointerDrag);
      document.addEventListener("pointercancel", finishPointerDrag);
    }

    function detachDocumentListeners() {
      if (!documentListenersAttached) {
        return;
      }
      documentListenersAttached = false;
      document.removeEventListener("pointermove", onPointerMove);
      document.removeEventListener("pointerup", finishPointerDrag);
      document.removeEventListener("pointercancel", finishPointerDrag);
    }

    function onPointerDown(event) {
      if (flyMode) {
        sceneFlyStartDrag(controls, canvas, props, readViewport, readSourceCamera, attachDocumentListeners, event);
      } else {
        sceneOrbitStartDrag(controls, canvas, props, readViewport, readSourceCamera, attachDocumentListeners, event);
      }
    }

    function onPointerMove(event) {
      if (flyMode) {
        sceneFlyMoveDrag(controls, canvas, props, readViewport, readSourceCamera, scheduleRender, event);
      } else {
        sceneOrbitMoveDrag(controls, canvas, props, readViewport, readSourceCamera, scheduleRender, event);
      }
    }

    function finishPointerDrag(event) {
      if (flyMode) {
        sceneFlyFinishDrag(controls, canvas, detachDocumentListeners, event);
      } else {
        sceneOrbitFinishDrag(controls, canvas, detachDocumentListeners, event);
      }
    }

    function onWheel(event) {
      if (!flyMode) {
        sceneOrbitApplyWheel(controls, readSourceCamera, scheduleRender, event);
      }
    }

    function scheduleFlyMovement() {
      if (!flyMode || flyFrame || controls.keys.size === 0) {
        return;
      }
      flyLastFrameMS = sceneNowMilliseconds();
      const step = function(now) {
        flyFrame = 0;
        const current = sceneNumber(now, sceneNowMilliseconds());
        const delta = Math.min(0.05, Math.max(0.001, (current - flyLastFrameMS) / 1000));
        flyLastFrameMS = current;
        if (sceneFlyApplyMovement(controls, readSourceCamera, delta)) {
          scheduleRender("controls");
        }
        if (controls.keys.size > 0) {
          flyFrame = requestAnimationFrame(step);
        }
      };
      flyFrame = requestAnimationFrame(step);
    }

    function onKeyDown(event) {
      if (!flyMode || (document.activeElement !== canvas && !controls.touched)) {
        return;
      }
      const key = sceneFlyKeyCode(event);
      if (!key) {
        return;
      }
      controls.keys.add(key);
      sceneFlyApplyMovement(controls, readSourceCamera, 1 / 60);
      scheduleFlyMovement();
      scheduleRender("controls");
      if (typeof event.preventDefault === "function") {
        event.preventDefault();
      }
    }

    function onKeyUp(event) {
      if (!flyMode) {
        return;
      }
      const key = sceneFlyKeyCode(event);
      if (!key) {
        return;
      }
      controls.keys.delete(key);
      if (typeof event.preventDefault === "function") {
        event.preventDefault();
      }
    }

    canvas.addEventListener("pointerdown", onPointerDown);
    canvas.addEventListener("pointermove", onPointerMove);
    canvas.addEventListener("pointerup", finishPointerDrag);
    canvas.addEventListener("pointercancel", finishPointerDrag);
    canvas.addEventListener("lostpointercapture", finishPointerDrag);
    canvas.addEventListener("wheel", onWheel);
    if (flyMode) {
      document.addEventListener("keydown", onKeyDown);
      document.addEventListener("keyup", onKeyUp);
      if (controls.pointerLock) {
        document.addEventListener("pointerlockchange", onPointerLockChange);
        document.addEventListener("mozpointerlockchange", onPointerLockChange);
        document.addEventListener("webkitpointerlockchange", onPointerLockChange);
      }
    }

    return {
      controller: controls,
      dispose() {
        detachDocumentListeners();
        if (flyFrame) {
          cancelAnimationFrame(flyFrame);
          flyFrame = 0;
        }
        canvas.removeEventListener("pointerdown", onPointerDown);
        canvas.removeEventListener("pointermove", onPointerMove);
        canvas.removeEventListener("pointerup", finishPointerDrag);
        canvas.removeEventListener("pointercancel", finishPointerDrag);
        canvas.removeEventListener("lostpointercapture", finishPointerDrag);
        canvas.removeEventListener("wheel", onWheel);
        if (flyMode) {
          sceneExitPointerLock(canvas);
          document.removeEventListener("keydown", onKeyDown);
          document.removeEventListener("keyup", onKeyUp);
          if (controls.pointerLock) {
            document.removeEventListener("pointerlockchange", onPointerLockChange);
            document.removeEventListener("mozpointerlockchange", onPointerLockChange);
            document.removeEventListener("webkitpointerlockchange", onPointerLockChange);
          }
        }
      },
    };
  }

  window.__gosx_register_engine_factory("GoSXScene3D", async function(ctx) {
    if (!ctx.mount || typeof document.createElement !== "function") {
      console.warn("[gosx] Scene3D requires a mount element");
      return {};
    }

    const props = ctx.props || {};
    const capability = sceneCapabilityProfile(props);
    const viewportBase = sceneViewportBase(props);
    const sceneState = createSceneState(props);
    const sceneModelHydration = hydrateSceneStateModels(sceneState, props);
    const runtimeScene = ctx.runtimeMode === "shared" && Boolean(ctx.programRef);
    const lifecycle = initialSceneLifecycleState();
    const motion = initialSceneMotionState(props);
    let sceneCSSAnimationUntil = 0;
    let lastModelAnimationTimeSeconds = null;

    function sceneShouldAnimate() {
      if (motion.reducedMotion) {
        return false;
      }
      if (ctx.mount && ctx.mount.__gosxScene3DCSSDynamic && Date.now() < sceneCSSAnimationUntil) {
        return true;
      }
      if (sceneHasActiveTransitions(sceneState)) {
        return true;
      }
      if (runtimeScene || sceneBool(props.autoRotate, false)) {
        return true;
      }
      if (Array.isArray(sceneState.computeParticles) && sceneState.computeParticles.length > 0) {
        return true;
      }
      if (sceneHasActiveModelAnimations(sceneState)) {
        return true;
      }
      if (Array.isArray(sceneState.points) && sceneState.points.some(function(p) {
        return sceneNumber(p.spinX, 0) !== 0 || sceneNumber(p.spinY, 0) !== 0 || sceneNumber(p.spinZ, 0) !== 0;
      })) {
        return true;
      }
      return sceneStateObjects(sceneState).some(sceneObjectAnimated) ||
        sceneStateLabels(sceneState).some(sceneLabelAnimated) ||
        sceneStateSprites(sceneState).some(sceneSpriteAnimated) ||
        sceneStateHTML(sceneState).some(sceneHTMLAnimated);
    }

    ctx.mount.__gosxScene3DCSSVarTransition = sceneExtractCSSVarTransitionTiming(props);

    clearChildren(ctx.mount);
    ctx.mount.setAttribute("data-gosx-scene3d-mounted", "true");
    ctx.mount.setAttribute("aria-label", props.ariaLabel || props.label || "Interactive GoSX 3D scene");
    setAttrValue(ctx.mount, "data-gosx-scene3d-controls", normalizeSceneControlsMode(props.controls));
    setAttrValue(ctx.mount, "data-gosx-scene3d-pick-signals", scenePickSignalNamespace(props));
    setAttrValue(ctx.mount, "data-gosx-scene3d-event-signals", sceneEventSignalNamespace(props));
    applySceneCapabilityState(ctx.mount, props, capability);
    if (!ctx.mount.style.position) {
      ctx.mount.style.position = "relative";
    }
    const canvas = document.createElement("canvas");
    canvas.setAttribute("data-gosx-scene3d-canvas", "true");
    canvas.setAttribute("role", "img");
    canvas.setAttribute("aria-label", props.label || "Interactive GoSX 3D scene");
    canvas.style.maxWidth = "100%";
    canvas.style.borderRadius = "inherit";
    canvas.width = viewportBase.baseWidth;
    canvas.height = viewportBase.baseHeight;
    canvas.setAttribute("width", String(viewportBase.baseWidth));
    canvas.setAttribute("height", String(viewportBase.baseHeight));
    ctx.mount.appendChild(canvas);

    const labelLayer = document.createElement("div");
    labelLayer.setAttribute("data-gosx-scene3d-label-layer", "true");
    labelLayer.setAttribute("aria-hidden", "true");
    ctx.mount.appendChild(labelLayer);
    const statsOverlay = createSceneStatsOverlay(ctx.mount, sceneBool(props.stats, false));

    const sentinelLayer = document.createElement("div");
    sentinelLayer.setAttribute("data-gosx-scene-node-layer", "true");
    sentinelLayer.setAttribute("aria-hidden", "true");
    sentinelLayer.style.position = "absolute";
    sentinelLayer.style.inset = "0";
    sentinelLayer.style.width = "0";
    sentinelLayer.style.height = "0";
    sentinelLayer.style.overflow = "visible";
    sentinelLayer.style.pointerEvents = "none";
    canvas.appendChild(sentinelLayer);

    const sceneNodeSentinels = new Map();
    ctx.mount.__gosxScene3DSentinels = sceneNodeSentinels;
    ctx.mount.__gosxScene3DCSSDynamic = false;
    ctx.mount.__gosxScene3DCSSRevision = 1;
    ctx.mount.__gosxScene3DCSSAnimationUntil = 0;
    applyScenePostFXState(ctx.mount, sceneState);

    let viewport = applySceneViewport(ctx.mount, canvas, labelLayer, sceneViewportFromMount(ctx.mount, props, viewportBase, canvas, capability), viewportBase);

    await ensurePreferredWebGPUBackend(props, capability);
    const initialRenderer = createSceneRenderer(canvas, props, capability);
    if (!initialRenderer || !initialRenderer.renderer) {
      console.warn("[gosx] Scene3D could not acquire a renderer");
      const unsupportedReason = sceneRequiresWebGL(props) ? "webgl-required" : "renderer-unavailable";
      applySceneRendererState(ctx.mount, { kind: "unsupported" }, unsupportedReason);
      setAttrValue(ctx.mount, "data-gosx-scene3d-ready", "false");
      if (canvas.parentNode === ctx.mount) {
        ctx.mount.removeChild(canvas);
      }
      if (labelLayer.parentNode === ctx.mount) {
        ctx.mount.removeChild(labelLayer);
      }
      if (statsOverlay) {
        statsOverlay.dispose();
      }
      if (sentinelLayer.parentNode === ctx.mount) {
        sentinelLayer.parentNode.removeChild(sentinelLayer);
      }
      delete ctx.mount.__gosxScene3DSentinels;
      delete ctx.mount.__gosxScene3DCSSDynamic;
      delete ctx.mount.__gosxScene3DCSSRevision;
      delete ctx.mount.__gosxScene3DCSSAnimationUntil;
      showSceneRequiredRendererMessage(ctx.mount, props, unsupportedReason);
      return {
        dispose() {
          const unsupported = ctx.mount.querySelector
            ? ctx.mount.querySelector("[data-gosx-scene3d-unsupported]")
            : null;
          if (unsupported && unsupported.parentNode === ctx.mount) {
            ctx.mount.removeChild(unsupported);
          }
        },
      };
    }
    let renderer = initialRenderer.renderer;
    applySceneRendererState(ctx.mount, renderer, initialRenderer.fallbackReason || "");
    let latestBundle = null;
    const labelLayoutCache = new Map();
    const labelElements = new Map();
    const spriteElements = new Map();
    const htmlElements = new Map();
    let labelRefreshHandle = null;

    function syncSceneNodeSentinels(bundle) {
      const next = new Set();
      collectSceneNodeSentinelIDs(next, bundle && bundle.meshObjects);
      collectSceneNodeSentinelIDs(next, bundle && bundle.objects);
      collectSceneNodeSentinelIDs(next, bundle && bundle.points);
      collectSceneNodeSentinelIDs(next, bundle && bundle.instancedMeshes);
      collectSceneNodeSentinelIDs(next, bundle && bundle.computeParticles);
      collectSceneNodeSentinelIDs(next, bundle && bundle.lights);
      collectSceneNodeSentinelIDs(next, bundle && bundle.labels);
      collectSceneNodeSentinelIDs(next, bundle && bundle.sprites);
      collectSceneNodeSentinelIDs(next, bundle && bundle.html);
      next.forEach(function(id) {
        if (sceneNodeSentinels.has(id)) {
          return;
        }
        const sentinel = document.createElement("div");
        sentinel.setAttribute("data-gosx-scene-node", id);
        sentinel.setAttribute("aria-hidden", "true");
        sentinel.style.position = "absolute";
        sentinel.style.left = "0";
        sentinel.style.top = "0";
        sentinel.style.width = "1px";
        sentinel.style.height = "1px";
        sentinel.style.opacity = "0";
        sentinel.style.pointerEvents = "auto";
        sentinelLayer.appendChild(sentinel);
        sceneNodeSentinels.set(id, sentinel);
      });
      sceneNodeSentinels.forEach(function(sentinel, id) {
        if (next.has(id)) {
          return;
        }
        if (sentinel.parentNode === sentinelLayer) {
          sentinelLayer.removeChild(sentinel);
        }
        sceneNodeSentinels.delete(id);
      });
    }

    function collectSceneNodeSentinelIDs(target, entries) {
      if (!Array.isArray(entries)) {
        return;
      }
      for (let index = 0; index < entries.length; index += 1) {
        const entry = entries[index];
        const id = entry && entry.id;
        if (id != null && String(id).trim() !== "") {
          target.add(String(id));
        }
      }
    }

    const releaseTextLayoutListener = onTextLayoutInvalidated(function() {
      if (disposed || !latestBundle || !sceneCanRender()) {
        return;
      }
      if (labelRefreshHandle != null) {
        return;
      }
      labelRefreshHandle = engineFrame(function() {
        labelRefreshHandle = null;
        if (disposed || !latestBundle) {
          return;
        }
        renderSceneLabels(labelLayer, latestBundle, labelLayoutCache, labelElements, viewport.cssWidth, viewport.cssHeight);
        renderSceneSprites(labelLayer, latestBundle, spriteElements, viewport.cssWidth, viewport.cssHeight);
        renderSceneHTML(labelLayer, latestBundle, htmlElements, viewport.cssWidth, viewport.cssHeight);
      });
    });

    let frameHandle = null;
    let scheduledRenderHandle = null;
    let disposed = false;

    let idleContextTimer = null;
    let contextVoluntarilyLost = false;
    let voluntaryLoseContextExtension = null;

    function scheduleIdleContextRelease() {
      clearIdleContextRelease();
      if (disposed || contextVoluntarilyLost) return;
    }

    function clearIdleContextRelease() {
      if (idleContextTimer != null) {
        clearTimeout(idleContextTimer);
        idleContextTimer = null;
      }
    }

    const WEBGL_VOLUNTARY_RESTORE_WATCHDOG_MS = 2000;
    let voluntaryRestoreWatchdogTimer = null;
    let voluntaryRestorePending = false;

    function clearVoluntaryRestoreWatchdog() {
      if (voluntaryRestoreWatchdogTimer != null) {
        clearTimeout(voluntaryRestoreWatchdogTimer);
        voluntaryRestoreWatchdogTimer = null;
      }
      voluntaryRestorePending = false;
    }

    function restoreVoluntarilyLostContext() {
      if (!contextVoluntarilyLost) return;
      contextVoluntarilyLost = false;
      voluntaryRestorePending = true;
      let requested = false;
      let restoreExt = voluntaryLoseContextExtension;
      voluntaryLoseContextExtension = null;
      try {
        if (!restoreExt) {
          const gl = canvas.getContext("webgl2") || canvas.getContext("webgl");
          restoreExt = gl && typeof gl.getExtension === "function"
            ? gl.getExtension("WEBGL_lose_context")
            : null;
        }
        if (restoreExt && typeof restoreExt.restoreContext === "function") {
          restoreExt.restoreContext();
          requested = true;
        }
      } catch (_e) { /* let the browser handle it */ }
      gosxSceneEmit("info", "webgl-voluntary-restore-requested", {
        requested: requested,
      });
      if (voluntaryRestoreWatchdogTimer != null) {
        clearTimeout(voluntaryRestoreWatchdogTimer);
      }
      voluntaryRestoreWatchdogTimer = setTimeout(function () {
        voluntaryRestoreWatchdogTimer = null;
        if (!voluntaryRestorePending || disposed) {
          return;
        }
        voluntaryRestorePending = false;
        gosxSceneEmit("warn", "webgl-voluntary-restore-watchdog", {
          rendererKind: renderer && renderer.kind ? renderer.kind : "",
          forcing: true,
        });
        if (!renderer || renderer.kind === "webgl") {
          return;
        }
        const swapped = restoreSceneWebGLRenderer("webgl-voluntary-restore-forced");
        if (swapped) {
          viewportDirty = true;
          scheduleRender("webgl-voluntary-restore-forced");
        }
        gosxSceneEmit(swapped ? "info" : "error", "webgl-voluntary-restore-forced", {
          swapped: swapped,
        });
      }, WEBGL_VOLUNTARY_RESTORE_WATCHDOG_MS);
    }

    let viewportDirty = true;

    function scheduleNextAnimationFrame() {
      if (disposed) return;
      if (frameHandle != null) return;
      if (!sceneWantsAnimation()) return;
      frameHandle = engineFrame(function(now) {
        frameHandle = null;
        renderFrame(now);
      });
    }

    let sceneRendererRecentlySwapped = false;
    let sceneRendererLastSwapReason = "";

    function swapRenderer(nextRenderer, fallbackReason) {
      if (!nextRenderer) {
        return false;
      }
      const previous = renderer;
      renderer = nextRenderer;
      applySceneRendererState(ctx.mount, renderer, fallbackReason);
      if (previous && previous !== renderer && typeof previous.dispose === "function") {
        previous.dispose();
      }
      sceneRendererRecentlySwapped = true;
      sceneRendererLastSwapReason = fallbackReason || "";
      gosxSceneEmit("info", "renderer-swap", {
        from: previous && previous.kind ? previous.kind : "",
        to: nextRenderer.kind || "",
        reason: fallbackReason || "",
      });
      return true;
    }

    function fallbackSceneRenderer(reason) {
      if (sceneRequiresWebGL(props)) {
        gosxSceneEmit("warn", "renderer-fallback-disabled", { reason: reason || "" });
        applySceneRendererState(ctx.mount, renderer, reason || "webgl-required");
        return false;
      }
      const ctx2d = typeof canvas.getContext === "function" ? canvas.getContext("2d") : null;
      if (!ctx2d) {
        gosxSceneEmit("warn", "renderer-fallback-unavailable", { reason: reason || "" });
        return false;
      }
      return swapRenderer(createSceneCanvasRenderer(ctx2d, canvas), reason || "webgl-unavailable");
    }

    function ensureRendererCanCoverBundle(bundle) {
      if (!renderer || !bundle) {
        return true;
      }
      let feature = "";
      if (typeof renderer.supportsBundle === "function" && renderer.supportsBundle(bundle) === false) {
        feature = "backend-declared";
      }
      if (!feature) {
        return true;
      }
      gosxSceneEmit("warn", "renderer-feature-gap", {
        rendererKind: renderer.kind || "",
        feature,
      });
      return fallbackSceneRenderer("webgpu-feature-gap");
    }

    function renderLatestSceneBundle(reason) {
      if (disposed || !latestBundle || !renderer || typeof renderer.render !== "function" || !sceneCanRender()) {
        return false;
      }
      if (!ensureRendererCanCoverBundle(latestBundle)) {
        return false;
      }
      recordScenePerfCounter("render:" + (reason || "restore"));
      syncSceneNodeSentinels(latestBundle);
      renderer.render(latestBundle, viewport);
      emitRendererWarmup(reason, latestBundle);
      maybeEmitRenderEmpty(latestBundle);
      renderSceneLabels(labelLayer, latestBundle, labelLayoutCache, labelElements, viewport.cssWidth, viewport.cssHeight);
      renderSceneSprites(labelLayer, latestBundle, spriteElements, viewport.cssWidth, viewport.cssHeight);
      renderSceneHTML(labelLayer, latestBundle, htmlElements, viewport.cssWidth, viewport.cssHeight);
      return true;
    }

    function emitRendererWarmup(reason, bundle) {
      gosxSceneEmit("info", "renderer-warmup", {
        rendererKind: renderer && renderer.kind ? renderer.kind : "",
        reason: reason || "",
        bundleMeshObjects: Array.isArray(bundle && bundle.meshObjects) ? bundle.meshObjects.length : 0,
        bundleInstancedMeshes: Array.isArray(bundle && bundle.instancedMeshes) ? bundle.instancedMeshes.length : 0,
        bundlePoints: Array.isArray(bundle && bundle.points) ? bundle.points.length : 0,
        bundleLights: Array.isArray(bundle && bundle.lights) ? bundle.lights.length : 0,
        bundleLabels: Array.isArray(bundle && bundle.labels) ? bundle.labels.length : 0,
        bundleSprites: Array.isArray(bundle && bundle.sprites) ? bundle.sprites.length : 0,
        bundleSurfaces: Array.isArray(bundle && bundle.surfaces) ? bundle.surfaces.length : 0,
        bundleComputeParticles: Array.isArray(bundle && bundle.computeParticles) ? bundle.computeParticles.length : 0,
        bundleWorldVertexCount: Number((bundle && bundle.worldVertexCount) || 0),
        bundleVertexCount: Number((bundle && bundle.vertexCount) || 0),
        bundleHasPostFX: Boolean(bundle && bundle.postEffects && Object.keys(bundle.postEffects).length > 0),
      });
    }

    function restoreSceneWebGLRenderer(reason) {
      const webglPreference = sceneCapabilityWebGLPreference(props, capability);
      if (!(webglPreference === "prefer" || webglPreference === "force")) {
        return false;
      }
      const restoredRenderer = createSceneRenderer(canvas, props, capability);
      const webglRenderer = restoredRenderer && restoredRenderer.renderer;
      if (!webglRenderer || webglRenderer.kind !== "webgl") {
        if (webglRenderer && typeof webglRenderer.dispose === "function") {
          webglRenderer.dispose();
        }
        return false;
      }
      if (!swapRenderer(webglRenderer, reason || restoredRenderer.fallbackReason || "")) {
        return false;
      }
      renderLatestSceneBundle(reason || "webgl-restore");
      return true;
    }

    const sceneRendererLostStub = {
      kind: "lost",
      render: function () {},
      dispose: function () {},
    };

    function onWebGLContextLost(event) {
      if (!renderer || renderer.kind !== "webgl") {
        return;
      }
      if (event && typeof event.preventDefault === "function") {
        event.preventDefault();
      }
      gosxSceneEmit("warn", "webgl-context-lost", {
        voluntary: contextVoluntarilyLost === true,
      });
      try {
        if (typeof renderer.dispose === "function") {
          renderer.dispose();
        }
      } catch (_err) {
        /* dispose errors on a lost context are expected */
      }
      renderer = sceneRendererLostStub;
      applySceneRendererState(ctx.mount, renderer, "webgl-context-lost");
      const swapped = fallbackSceneRenderer("webgl-context-lost");
      scheduleRender("webgl-context-lost");
      if (!swapped) {
        gosxSceneEmit("warn", "webgl-context-lost-no-fallback", {});
      }
    }

    function onWebGLContextRestored() {
      const voluntary = contextVoluntarilyLost === true;
      const watchdogPending = voluntaryRestorePending === true;
      contextVoluntarilyLost = false;
      clearVoluntaryRestoreWatchdog();
      const swapped = restoreSceneWebGLRenderer("");
      gosxSceneEmit(swapped ? "info" : "warn", "webgl-context-restored", {
        swapped: swapped,
        voluntary: voluntary,
        watchdogPending: watchdogPending,
      });
      if (swapped) {
        viewportDirty = true;
        scheduleRender("webgl-context-restored");
      }
    }

    canvas.addEventListener("webglcontextlost", onWebGLContextLost);
    canvas.addEventListener("webglcontextrestored", onWebGLContextRestored);

    function sceneCanRender() {
      return lifecycle.pageVisible && lifecycle.inViewport;
    }

    function sceneWantsAnimation() {
      return sceneShouldAnimate() && sceneCanRender();
    }

    function cancelFrame() {
      if (frameHandle != null) {
        cancelEngineFrame(frameHandle);
        frameHandle = null;
      }
    }

    function cancelScheduledRender() {
      if (scheduledRenderHandle != null) {
        cancelEngineFrame(scheduledRenderHandle);
        scheduledRenderHandle = null;
      }
    }

    function recordScenePerfCounter(name) {
      if (!(typeof window !== "undefined" && window.__gosx_scene3d_perf === true)) {
        return;
      }
      const key = String(name || "unknown");
      const counters = ctx.mount.__gosxScene3DScheduleCounts || Object.create(null);
      counters[key] = (counters[key] || 0) + 1;
      ctx.mount.__gosxScene3DScheduleCounts = counters;
    }

    function scheduleRender(reason) {
      if (disposed) {
        return;
      }
      recordScenePerfCounter("schedule:" + (reason || "refresh"));
      if (scheduledRenderHandle != null) {
        recordScenePerfCounter("coalesced:" + (reason || "refresh"));
        return;
      }
      scheduledRenderHandle = engineFrame(function(now) {
        scheduledRenderHandle = null;
        if (disposed) {
          return;
        }
        if (!sceneCanRender()) {
          cancelFrame();
          return;
        }
        cancelFrame();
        renderFrame(typeof now === "number" ? now : 0, reason || "refresh");
      });
    }

    function scheduleRenderWithViewport(reason) {
      viewportDirty = true;
      scheduleRender(reason);
    }

    function markSceneCSSInvalidated(reason) {
      const revision = Number(ctx.mount && ctx.mount.__gosxScene3DCSSRevision);
      ctx.mount.__gosxScene3DCSSRevision = Number.isFinite(revision) ? revision + 1 : 1;
      const transitionWindow = Math.max(
        sceneCSSTransitionWindowMillis(ctx.mount),
        sceneCSSTransitionWindowMillis(document && document.documentElement)
      );
      if (transitionWindow > 0) {
        sceneCSSAnimationUntil = Date.now() + transitionWindow;
      }
      ctx.mount.__gosxScene3DCSSAnimationUntil = sceneCSSAnimationUntil;
      scheduleRender(reason || "css");
    }

    function sceneCSSTransitionWindowMillis(element) {
      if (!element || typeof window.getComputedStyle !== "function") {
        return 0;
      }
      let style = null;
      try {
        style = window.getComputedStyle(element);
      } catch (_error) {
        style = null;
      }
      if (!style) {
        return 0;
      }
      const durations = sceneCSSParseTimeList(style.transitionDuration || (typeof style.getPropertyValue === "function" ? style.getPropertyValue("transition-duration") : ""));
      const delays = sceneCSSParseTimeList(style.transitionDelay || (typeof style.getPropertyValue === "function" ? style.getPropertyValue("transition-delay") : ""));
      const length = Math.max(durations.length, delays.length);
      let max = 0;
      for (let index = 0; index < length; index += 1) {
        const duration = durations[index % Math.max(1, durations.length)] || 0;
        const delay = delays[index % Math.max(1, delays.length)] || 0;
        max = Math.max(max, duration + delay);
      }
      return max > 0 ? max + 80 : 0;
    }

    function sceneCSSParseTimeList(value) {
      return String(value || "").split(",").map(function(part) {
        const text = part.trim().toLowerCase();
        if (!text) {
          return 0;
        }
        const number = Number.parseFloat(text);
        if (!Number.isFinite(number)) {
          return 0;
        }
        return text.endsWith("ms") ? number : number * 1000;
      });
    }

    function sceneCSSExternalStyleSignatureFromText(value) {
      const items = [];
      const parts = String(value || "").split(";");
      for (let index = 0; index < parts.length; index += 1) {
        const part = parts[index];
        const colon = part.indexOf(":");
        if (colon < 0) {
          continue;
        }
        const name = part.slice(0, colon).trim();
        if (!name || name.indexOf("--gosx-") === 0) {
          continue;
        }
        items.push(name + ":" + part.slice(colon + 1).trim());
      }
      items.sort();
      return items.join(";");
    }

    function sceneCSSExternalStyleSignature(element) {
      const style = element && element.style;
      if (!style) {
        return "";
      }
      const items = [];
      if (typeof style.length === "number" && typeof style.getPropertyValue === "function") {
        for (let index = 0; index < style.length; index += 1) {
          const name = style[index];
          if (!name || String(name).indexOf("--gosx-") === 0) {
            continue;
          }
          items.push(String(name) + ":" + String(style.getPropertyValue(name) || "").trim());
        }
        items.sort();
        return items.join(";");
      }
      return sceneCSSExternalStyleSignatureFromText(style.cssText || "");
    }

    function sceneCSSMutationShouldInvalidate(records) {
      let sawRecord = false;
      for (let index = 0; index < (records || []).length; index += 1) {
        const record = records[index];
        if (!record || record.type !== "attributes") {
          continue;
        }
        sawRecord = true;
        const attributeName = String(record.attributeName || "");
        if (attributeName === "class") {
          return true;
        }
        if (attributeName !== "style") {
          return true;
        }
        const previous = sceneCSSExternalStyleSignatureFromText(record.oldValue || "");
        const current = sceneCSSExternalStyleSignature(record.target);
        if (previous !== current) {
          return true;
        }
      }
      return !sawRecord;
    }

    function observeSceneCSSInvalidation() {
      const releases = [];
      if (typeof MutationObserver === "function") {
        const observer = new MutationObserver(function(records) {
          if (!sceneCSSMutationShouldInvalidate(records)) {
            return;
          }
          markSceneCSSInvalidated("css");
        });
        observer.observe(ctx.mount, {
          attributes: true,
          attributeFilter: ["class", "style"],
          attributeOldValue: true,
          subtree: false,
        });
        if (document && document.documentElement && document.documentElement !== ctx.mount) {
          observer.observe(document.documentElement, {
            attributes: true,
            attributeFilter: ["class", "style"],
            attributeOldValue: true,
            subtree: false,
          });
        }
        releases.push(function() { observer.disconnect(); });
      }
      if (typeof window.matchMedia === "function") {
        const queries = [
          "(prefers-color-scheme: dark)",
          "(prefers-reduced-motion: reduce)",
          "(prefers-contrast: more)",
          "(prefers-reduced-data: reduce)",
        ];
        for (let index = 0; index < queries.length; index += 1) {
          const query = window.matchMedia(queries[index]);
          const listener = function() {
            markSceneCSSInvalidated("css-media");
          };
          if (query && typeof query.addEventListener === "function") {
            query.addEventListener("change", listener);
            releases.push(function(q, l) {
              return function() { q.removeEventListener("change", l); };
            }(query, listener));
          } else if (query && typeof query.addListener === "function") {
            query.addListener(listener);
            releases.push(function(q, l) {
              return function() { q.removeListener(l); };
            }(query, listener));
          }
        }
      }
      return function releaseSceneCSSInvalidation() {
        for (let index = 0; index < releases.length; index += 1) {
          releases[index]();
        }
      };
    }

    function readSceneSourceCamera() {
      if (latestBundle && latestBundle.sourceCamera) {
        return latestBundle.sourceCamera;
      }
      if (latestBundle && latestBundle.camera) {
        return latestBundle.camera;
      }
      return sceneState.camera;
    }

    const sceneControlHandle = setupSceneBuiltInControls(canvas, props, function() {
      return viewport;
    }, readSceneSourceCamera, scheduleRender);
    const dragHandle = sceneControlHandle.controller
      ? { dispose() {} }
      : setupSceneDragInteractions(canvas, props, function() {
        return viewport;
      }, function() {
        return latestBundle;
      });
    const pickHandle = setupScenePickInteractions(canvas, props, function() {
      return viewport;
    }, function() {
      return latestBundle;
    }, function(detail) {
      ctx.emit("scene-interaction", detail);
    });
    let pendingMotionData = null;
    let pendingMotionHandle = null;

    function applySceneHubEvent(eventName, data, reason) {
      const cameraChanged = sceneApplyCameraLiveEvent(sceneState, data);
      const modelChanged = sceneApplyModelLiveEvent(sceneState, eventName, data);
      const liveChanged = sceneApplyLiveEvent(sceneState, eventName, data, motion.reducedMotion, sceneNowMilliseconds());
      if (cameraChanged || modelChanged || liveChanged) {
        scheduleRender(reason || "hub-event");
      }
    }

    function flushPendingMotionEvent() {
      pendingMotionHandle = null;
      if (disposed || !pendingMotionData) {
        pendingMotionData = null;
        return;
      }
      const data = pendingMotionData;
      pendingMotionData = null;
      applySceneHubEvent("motion", data, "hub-motion");
    }

    const sceneHubListener = function(event) {
      if (disposed) {
        return;
      }
      const detail = event && event.detail && typeof event.detail === "object" ? event.detail : null;
      if (!detail || typeof detail.event !== "string") {
        return;
      }
      if (detail.event === "motion") {
        pendingMotionData = detail.data;
        if (pendingMotionHandle == null) {
          pendingMotionHandle = engineFrame(flushPendingMotionEvent);
        }
        return;
      }
      applySceneHubEvent(detail.event, detail.data, "hub-event");
    };
    document.addEventListener("gosx:hub:event", sceneHubListener);

    const releaseViewportObserver = observeSceneViewport(ctx.mount, function(reason) {
      sceneUpdateScrollCameraMetrics(sceneState._scrollCamera, true);
      scheduleRenderWithViewport(reason);
    });
    const releaseCapabilityObserver = observeSceneCapability(ctx.mount, props, capability, function(reason) {
      viewportDirty = true;
      const desiredFallback = sceneRendererFallbackReason(props, capability, renderer && renderer.kind);
      const webglPreference = sceneCapabilityWebGLPreference(props, capability);
      if (renderer && renderer.kind === "webgl" && !(webglPreference === "prefer" || webglPreference === "force")) {
        fallbackSceneRenderer(desiredFallback || "environment-constrained");
      } else if (renderer && renderer.kind !== "webgl" && (webglPreference === "prefer" || webglPreference === "force")) {
        if (!restoreSceneWebGLRenderer("")) {
          applySceneRendererState(ctx.mount, renderer, desiredFallback);
        }
      } else {
        applySceneRendererState(ctx.mount, renderer, desiredFallback);
      }
      scheduleRender(reason || "capability");
    });
    const releaseLifecycleObserver = observeSceneLifecycle(ctx.mount, lifecycle, function(reason) {
      if (!sceneCanRender()) {
        cancelFrame();
        cancelScheduledRender();
        if (labelRefreshHandle != null) {
          cancelEngineFrame(labelRefreshHandle);
          labelRefreshHandle = null;
        }
        scheduleIdleContextRelease();
        return;
      }
      clearIdleContextRelease();
      if (contextVoluntarilyLost) {
        restoreVoluntarilyLostContext();
        return;
      }
      scheduleRenderWithViewport(reason || "lifecycle");
    });
    const releaseMotionObserver = observeSceneMotion(ctx.mount, motion, function(reason) {
      cancelFrame();
      cancelScheduledRender();
      scheduleRenderWithViewport(reason || "motion");
    });
    const releaseSceneCSSObserver = observeSceneCSSInvalidation();

    if (runtimeScene) {
      if (ctx.runtime && ctx.runtime.available()) {
        applySceneCommands(sceneState, await ctx.runtime.hydrateFromProgramRef());
      } else {
        console.warn("[gosx] Scene3D runtime requested but shared engine runtime is unavailable");
      }
    }

    function renderFrame(now, reason) {
      if (disposed) return;
      const frameStart = typeof performance !== "undefined" && performance.now ? performance.now() : Date.now();
      const perfEnabled = typeof window !== "undefined" && window.__gosx_scene3d_perf === true;
      recordScenePerfCounter("render:" + (reason || "animation"));
      if (viewportDirty) {
        const nextViewport = sceneViewportFromMount(ctx.mount, props, viewportBase, canvas, capability);
        viewport = applySceneViewport(ctx.mount, canvas, labelLayer, nextViewport, viewportBase);
        viewportDirty = false;
      }
      if (!sceneCanRender()) {
        cancelFrame();
        return;
      }
      sceneAdvanceScrollCamera(sceneState._scrollCamera);
      const timeSeconds = now / 1000;
      const modelAnimationDelta = lastModelAnimationTimeSeconds == null
        ? 0
        : Math.max(0, Math.min(0.1, timeSeconds - lastModelAnimationTimeSeconds));
      lastModelAnimationTimeSeconds = timeSeconds;
      if (perfEnabled) performance.mark("scene3d-model-animations-start");
      sceneAdvanceModelAnimations(sceneState, modelAnimationDelta);
      if (perfEnabled) {
        performance.mark("scene3d-model-animations-end");
        performance.measure("scene3d-model-animations", "scene3d-model-animations-start", "scene3d-model-animations-end");
        performance.clearMarks("scene3d-model-animations-start");
        performance.clearMarks("scene3d-model-animations-end");
      }
      if (runtimeScene && ctx.runtime && typeof ctx.runtime.renderFrame === "function") {
        const runtimeBundle = ctx.runtime.renderFrame(timeSeconds, viewport.cssWidth, viewport.cssHeight);
        if (runtimeBundle) {
          const effectiveBundle = sceneBundleWithCameraOverride(
            runtimeBundle,
            sceneCurrentControlCamera(sceneControlHandle.controller, runtimeBundle.camera || sceneState.camera, sceneState._scrollCamera),
          );
          latestBundle = effectiveBundle;
          if (!ensureRendererCanCoverBundle(effectiveBundle)) {
            scheduleNextAnimationFrame();
            return;
          }
          syncSceneNodeSentinels(effectiveBundle);
          renderer.render(effectiveBundle, viewport);
          renderSceneLabels(labelLayer, effectiveBundle, labelLayoutCache, labelElements, viewport.cssWidth, viewport.cssHeight);
          renderSceneSprites(labelLayer, effectiveBundle, spriteElements, viewport.cssWidth, viewport.cssHeight);
          renderSceneHTML(labelLayer, effectiveBundle, htmlElements, viewport.cssWidth, viewport.cssHeight);
          if (statsOverlay) {
            statsOverlay.update(effectiveBundle, frameStart, renderer, viewport);
          }
          scheduleNextAnimationFrame();
          return;
        }
      }
      if (runtimeScene && ctx.runtime) {
        applySceneCommands(sceneState, ctx.runtime.tick());
      }
      sceneAdvanceTransitions(sceneState, now);
      if (typeof sceneApplyLOD === "function" && props.compression && props.compression.lod) {
        var cam = sceneCurrentControlCamera(sceneControlHandle.controller, sceneState.camera, sceneState._scrollCamera);
        var camX = cam.x || 0, camY = cam.y || 0, camZ = cam.z || 0;
        for (var li = 0; li < sceneState.points.length; li++) {
          sceneApplyLOD(sceneState.points[li], camX, camY, camZ);
        }
      }
      if (perfEnabled) performance.mark("scene3d-bundle-start");
      latestBundle = createSceneRenderBundle(
        viewport.cssWidth,
        viewport.cssHeight,
        sceneState.background,
        sceneCurrentControlCamera(sceneControlHandle.controller, sceneState.camera, sceneState._scrollCamera),
        sceneStateObjectsWithMaterials(sceneState),
        sceneStateLabels(sceneState),
        sceneStateSprites(sceneState),
        sceneStateHTML(sceneState),
        sceneStateLights(sceneState),
        sceneState.environment,
        timeSeconds,
        sceneStatePointsWithMaterials(sceneState),
        sceneState.instancedMeshes,
        sceneState.computeParticles,
        sceneState.postEffects,
        sceneState.postFXMaxPixels,
      );
      if (perfEnabled) {
        performance.mark("scene3d-bundle-end");
        performance.measure("scene3d-bundle", "scene3d-bundle-start", "scene3d-bundle-end");
        performance.clearMarks("scene3d-bundle-start");
        performance.clearMarks("scene3d-bundle-end");
      }
      if (!ensureRendererCanCoverBundle(latestBundle)) {
        scheduleNextAnimationFrame();
        return;
      }
      syncSceneNodeSentinels(latestBundle);
      renderer.render(latestBundle, viewport);
      maybeEmitRenderEmpty(latestBundle);
      renderSceneLabels(labelLayer, latestBundle, labelLayoutCache, labelElements, viewport.cssWidth, viewport.cssHeight);
      renderSceneSprites(labelLayer, latestBundle, spriteElements, viewport.cssWidth, viewport.cssHeight);
      renderSceneHTML(labelLayer, latestBundle, htmlElements, viewport.cssWidth, viewport.cssHeight);
      if (statsOverlay) {
        statsOverlay.update(latestBundle, frameStart, renderer, viewport);
      }
      scheduleNextAnimationFrame();
    }

    function maybeEmitRenderEmpty(bundle) {
      if (!sceneRendererRecentlySwapped) {
        return;
      }
      sceneRendererRecentlySwapped = false;
      const reason = sceneRendererLastSwapReason;
      sceneRendererLastSwapReason = "";
      const bundleVerts = Number((bundle && bundle.vertexCount) || 0);
      const worldVerts = Number((bundle && bundle.worldVertexCount) || 0);
      const surfaceCount = Array.isArray(bundle && bundle.surfaces) ? bundle.surfaces.length : 0;
      const bundleMeshObjects = Array.isArray(bundle && bundle.meshObjects) ? bundle.meshObjects.length : 0;
      const bundleInstancedMeshes = Array.isArray(bundle && bundle.instancedMeshes) ? bundle.instancedMeshes.length : 0;
      if (bundleVerts > 0 || worldVerts > 0 || surfaceCount > 0
          || bundleMeshObjects > 0 || bundleInstancedMeshes > 0) {
        scheduleCanvasBlankProbe(reason, {
          bundleMeshObjects,
          bundleInstancedMeshes,
          bundleVerts: bundleVerts + worldVerts,
        });
        return;
      }
      const pointCount = Array.isArray(sceneState.points) ? sceneState.points.length : 0;
      const objectCount = (sceneState.meshObjects ? sceneState.meshObjects.length : 0)
        + (Array.isArray(sceneState.objects) ? sceneState.objects.length : 0);
      const instanceCount = Array.isArray(sceneState.instancedMeshes) ? sceneState.instancedMeshes.length : 0;
      if (pointCount + objectCount + instanceCount === 0) {
        return;
      }
      gosxSceneEmit("error", "render-empty", {
        rendererKind: renderer && renderer.kind ? renderer.kind : "",
        lastSwapReason: reason,
        scenePoints: pointCount,
        sceneObjects: objectCount,
        sceneInstances: instanceCount,
      });
    }

    function scheduleCanvasBlankProbe(reason, stats) {
      if (typeof window === "undefined" || !window.__gosx_telemetry_config
          || window.__gosx_telemetry_config.probeCanvasBlank !== true
          || window.__gosx_telemetry_config.allowCanvasReadbackProbe !== true) {
        return;
      }
      if (typeof window.requestAnimationFrame !== "function") {
        return;
      }
      window.requestAnimationFrame(function () {
        window.requestAnimationFrame(function () {
          if (disposed || !renderer || renderer.kind !== "webgl") {
            return;
          }
          if (typeof canvas.toBlob !== "function") {
            return;
          }
          canvas.toBlob(function (blob) {
            if (disposed || !renderer || renderer.kind !== "webgl") {
              return;
            }
            const kCanvasBlankPNGBytesThreshold = 1800;
            const byteSize = blob && typeof blob.size === "number" ? blob.size : 0;
            if (byteSize > kCanvasBlankPNGBytesThreshold) {
              return;
            }
            const gl = typeof canvas.getContext === "function"
              ? (canvas.getContext("webgl2") || canvas.getContext("webgl"))
              : null;
            gosxSceneEmit("error", "render-canvas-blank", {
              rendererKind: renderer && renderer.kind ? renderer.kind : "",
              lastSwapReason: reason || "",
              bundleMeshObjects: stats ? stats.bundleMeshObjects : 0,
              bundleInstancedMeshes: stats ? stats.bundleInstancedMeshes : 0,
              bundleVerts: stats ? stats.bundleVerts : 0,
              canvasPngBytes: byteSize,
              canvasPngThreshold: kCanvasBlankPNGBytesThreshold,
              glError: gl && typeof gl.getError === "function" ? gl.getError() : 0,
            });
          }, "image/png");
        });
      });
    }

    await sceneModelHydration;
    scenePrimeInitialTransitions(sceneState, motion.reducedMotion, 0);

    function scheduleInitialRender() {
      if (disposed) return;
      Promise.resolve().then(function() {
        if (!disposed) renderFrame(0);
      });
    }
    scheduleInitialRender();

    if (typeof sceneUpgradeProgressive === "function" && props.compression && props.compression.progressive) {
      scheduleSceneIdleTask(function() {
        sceneUpgradeProgressive(props);
        if (sceneWantsAnimation()) {
        } else {
          renderFrame(0);
        }
      }, sceneCompressionProgressiveDelay(props));
    }

    if (Array.isArray(sceneState._deferredPostEffects) && sceneState._deferredPostEffects.length > 0) {
      scheduleSceneIdleTask(function() {
        sceneState.postEffects = sceneState._deferredPostEffects;
        sceneState._deferredPostEffects = null;
        applyScenePostFXState(ctx.mount, sceneState);
        if (sceneWantsAnimation()) {
        } else {
          renderFrame(0);
        }
      }, sceneDeferredPostFXDelay(props));
    }

    setAttrValue(ctx.mount, "data-gosx-scene3d-ready", "true");
    ctx.emit("mounted", {
      width: viewport.cssWidth,
      height: viewport.cssHeight,
      objects: sceneStateObjects(sceneState).length,
      labels: sceneStateLabels(sceneState).length,
      sprites: sceneStateSprites(sceneState).length,
      html: sceneStateHTML(sceneState).length,
      lights: sceneStateLights(sceneState).length,
      models: sceneModels(props).length,
    });

    var scrollHandler = null;
    var visualViewportScrollHandler = null;
    if (sceneState._scrollCamera) {
      sceneState._scrollCamera._progress = 0;
      sceneState._scrollCamera._smoothProgress = 0;
      sceneUpdateScrollCameraMetrics(sceneState._scrollCamera, true);
      scrollHandler = function() {
        sceneUpdateScrollCameraMetrics(sceneState._scrollCamera, false, true);
        scheduleRender("scroll");
      };
      window.addEventListener("scroll", scrollHandler, { passive: true });
      var isTouchDevice =
        (typeof navigator !== "undefined" && navigator.maxTouchPoints > 0) ||
        ("ontouchstart" in window);
      if (
        isTouchDevice &&
        window.visualViewport &&
        typeof window.visualViewport.addEventListener === "function"
      ) {
        visualViewportScrollHandler = function() {
          sceneUpdateScrollCameraMetrics(sceneState._scrollCamera, true, true);
          scheduleRender("visual-viewport");
        };
        window.visualViewport.addEventListener("scroll", visualViewportScrollHandler, { passive: true });
        window.visualViewport.addEventListener("resize", visualViewportScrollHandler, { passive: true });
      }
      sceneAdvanceScrollCamera(sceneState._scrollCamera);
    }

    return {
      applyCommands(commands) {
        applySceneCommands(sceneState, commands);
        scheduleRender("commands");
      },
      dispose() {
        disposed = true;
        clearIdleContextRelease();
        clearVoluntaryRestoreWatchdog();
        if (scrollHandler) {
          window.removeEventListener("scroll", scrollHandler);
        }
        if (visualViewportScrollHandler && window.visualViewport && typeof window.visualViewport.removeEventListener === "function") {
          window.visualViewport.removeEventListener("scroll", visualViewportScrollHandler);
          window.visualViewport.removeEventListener("resize", visualViewportScrollHandler);
        }
        canvas.removeEventListener("webglcontextlost", onWebGLContextLost);
        canvas.removeEventListener("webglcontextrestored", onWebGLContextRestored);
        document.removeEventListener("gosx:hub:event", sceneHubListener);
        releaseViewportObserver();
        releaseCapabilityObserver();
        releaseLifecycleObserver();
        releaseMotionObserver();
        releaseSceneCSSObserver();
        releaseTextLayoutListener();
        dragHandle.dispose();
        pickHandle.dispose();
        sceneControlHandle.dispose();
        renderer.dispose();
        cancelFrame();
        cancelScheduledRender();
        if (pendingMotionHandle != null) {
          cancelEngineFrame(pendingMotionHandle);
          pendingMotionHandle = null;
        }
        if (labelRefreshHandle != null) {
          cancelEngineFrame(labelRefreshHandle);
        }
        if (canvas.parentNode === ctx.mount) {
          ctx.mount.removeChild(canvas);
        }
        if (labelLayer.parentNode === ctx.mount) {
          ctx.mount.removeChild(labelLayer);
        }
        if (statsOverlay) {
          statsOverlay.dispose();
        }
        if (sentinelLayer.parentNode === ctx.mount) {
          ctx.mount.removeChild(sentinelLayer);
        }
        delete ctx.mount.__gosxScene3DSentinels;
        delete ctx.mount.__gosxScene3DCSSDynamic;
        delete ctx.mount.__gosxScene3DCSSRevision;
        delete ctx.mount.__gosxScene3DCSSAnimationUntil;
      },
    };
  });

  window.__gosx_scene3d_available = true;
  if (typeof window.__gosx_scene3d_loaded === "function") {
    window.__gosx_scene3d_loaded();
  }
})();
