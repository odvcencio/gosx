(function() {
  "use strict";

  const GOSX_VERSION = "0.11.0";

  const engineFactories = window.__gosx_engine_factories || Object.create(null);
  window.__gosx_engine_factories = engineFactories;
  window.__gosx_register_engine_factory = function(name, factory) {
    if (!name || typeof factory !== "function") {
      console.error("[gosx] invalid engine factory registration");
      return;
    }
    engineFactories[name] = factory;
  };

  document.addEventListener("DOMContentLoaded", function() {
    window.__gosx_register_engine_factory = function(name) {
      console.error("[gosx] engine factory registration is closed after init:", name);
    };
    Object.freeze(engineFactories);
  });

  window.__gosx = {
    version: GOSX_VERSION,
    islands: new Map(),   // islandID -> { component, listeners, root }
    computeIslands: new Map(), // compute island ID -> { component }
    engines: new Map(),   // engineID -> { component, kind, mount, handle }
    hubs: new Map(),      // hubID -> { entry, socket, reconnectTimer }
    textLayouts: new Map(), // textLayoutID -> { element, result, config }
    sharedSignals: {
      values: new Map(),
      subscribers: new Map(),
      nextID: 0,
    },
    input: {
      pending: null,
      frameHandle: 0,
      providers: Object.create(null),
    },
    ready: false,
  };

  function gosxSharedSignalStore() {
    const current = window.__gosx && window.__gosx.sharedSignals;
    if (current && current.values instanceof Map && current.subscribers instanceof Map) {
      return current;
    }
    const store = {
      values: new Map(),
      subscribers: new Map(),
      nextID: 0,
    };
    if (window.__gosx) {
      window.__gosx.sharedSignals = store;
    }
    return store;
  }

  function parseSharedSignalJSON(valueJSON, fallback) {
    if (typeof valueJSON !== "string" || valueJSON === "") {
      return fallback;
    }
    if (valueJSON.startsWith("error:")) {
      return fallback;
    }
    try {
      return JSON.parse(valueJSON);
    } catch (_error) {
      return fallback;
    }
  }

  function gosxReadSharedSignal(name, fallback) {
    const signalName = String(name || "").trim();
    if (!signalName) {
      return fallback;
    }
    const store = gosxSharedSignalStore();
    if (store.values.has(signalName)) {
      return store.values.get(signalName);
    }
    const getter = window.__gosx_get_shared_signal;
    if (typeof getter !== "function") {
      return fallback;
    }
    try {
      const value = parseSharedSignalJSON(getter(signalName), fallback);
      store.values.set(signalName, value);
      return value;
    } catch (_error) {
      return fallback;
    }
  }

  function gosxNotifySharedSignal(name, valueJSON) {
    const signalName = String(name || "").trim();
    if (!signalName) {
      return null;
    }
    const store = gosxSharedSignalStore();
    const value = parseSharedSignalJSON(valueJSON, null);
    store.values.set(signalName, value);
    const listeners = store.subscribers.get(signalName);
    if (!listeners) {
      return null;
    }
    for (const entry of Array.from(listeners.values())) {
      try {
        entry(value, signalName);
      } catch (error) {
        console.error("[gosx] shared signal subscriber failed:", error);
      }
    }
    return null;
  }

  function gosxSubscribeSharedSignal(name, listener, options) {
    const signalName = String(name || "").trim();
    if (!signalName || typeof listener !== "function") {
      return function() {};
    }
    const store = gosxSharedSignalStore();
    let listeners = store.subscribers.get(signalName);
    if (!listeners) {
      listeners = new Map();
      store.subscribers.set(signalName, listeners);
    }
    store.nextID += 1;
    const id = "shared-signal-" + store.nextID;
    listeners.set(id, listener);
    if (!options || options.immediate !== false) {
      listener(gosxReadSharedSignal(signalName, null), signalName);
    }
    return function() {
      const current = store.subscribers.get(signalName);
      if (!current) {
        return;
      }
      current.delete(id);
      if (current.size === 0) {
        store.subscribers.delete(signalName);
      }
    };
  }

  function setSharedSignalJSON(name, valueJSON) {
    const signalName = String(name || "").trim();
    if (!signalName) {
      return null;
    }

    const setSharedSignal = window.__gosx_set_shared_signal;
    if (typeof setSharedSignal === "function") {
      try {
        const result = setSharedSignal(signalName, valueJSON);
        if (typeof result === "string" && result !== "") {
          console.error("[gosx] shared signal update error (" + signalName + "):", result);
          gosxNotifySharedSignal(signalName, valueJSON);
        }
        return result;
      } catch (error) {
        console.error("[gosx] shared signal update error (" + signalName + "):", error);
      }
    }

    gosxNotifySharedSignal(signalName, valueJSON);
    return null;
  }

  function setSharedSignalValue(name, value) {
    return setSharedSignalJSON(name, JSON.stringify(value == null ? null : value));
  }

  window.__gosx_notify_shared_signal = gosxNotifySharedSignal;

  function gosxIssueStore() {
    if (!window.__gosx.issues || !Array.isArray(window.__gosx.issues.entries)) {
      window.__gosx.issues = {
        nextID: 0,
        entries: [],
      };
    }
    return window.__gosx.issues;
  }

  function gosxCloneIssue(issue) {
    return Object.assign({}, issue || {});
  }

  function gosxIssueText(value) {
    const text = String(value == null ? "" : value).trim();
    return text === "[object Object]" ? "" : text;
  }

  function gosxIssueMessage(issue) {
    const message = gosxIssueText(issue && issue.message);
    if (message) {
      return message;
    }
    const errorMessage = gosxIssueText(issue && issue.error && issue.error.message);
    if (errorMessage) {
      return errorMessage;
    }
    const errorText = gosxIssueText(issue && issue.error);
    if (errorText) {
      return errorText;
    }
    return "runtime failure";
  }

  function gosxMarkIssueElement(element, issue) {
    if (!element || typeof element.setAttribute !== "function") {
      return;
    }
    element.setAttribute("data-gosx-runtime-state", "error");
    element.setAttribute("data-gosx-runtime-issue", issue.type);
    if (issue.fallback) {
      element.setAttribute("data-gosx-fallback-active", issue.fallback);
    }
  }

  function gosxClearIssueState(element) {
    if (!element || typeof element.removeAttribute !== "function") {
      return;
    }
    element.setAttribute("data-gosx-runtime-state", "ready");
    element.removeAttribute("data-gosx-runtime-issue");
    element.removeAttribute("data-gosx-fallback-active");
  }

  function gosxReportRuntimeIssue(issue) {
    const store = gosxIssueStore();
    store.nextID += 1;
    const entry = {
      id: "gosx-issue-" + store.nextID,
      scope: gosxIssueText(issue && issue.scope) || "runtime",
      type: gosxIssueText(issue && issue.type) || "runtime",
      severity: gosxIssueText(issue && issue.severity) || "error",
      message: gosxIssueMessage(issue),
      component: gosxIssueText(issue && issue.component),
      ref: gosxIssueText(issue && issue.ref),
      source: gosxIssueText(issue && issue.source),
      phase: gosxIssueText(issue && issue.phase),
      fallback: gosxIssueText(issue && issue.fallback) || "server",
      elementID: gosxIssueText(issue && issue.element && issue.element.id),
      timestamp: Date.now(),
    };
    store.entries.push(entry);
    if (store.entries.length > 100) {
      store.entries.splice(0, store.entries.length - 100);
    }
    gosxMarkIssueElement(issue && issue.element, entry);
    if (document && typeof document.dispatchEvent === "function" && typeof CustomEvent === "function") {
      document.dispatchEvent(new CustomEvent("gosx:error", {
        detail: { issue: gosxCloneIssue(entry) },
      }));
    }
    return gosxCloneIssue(entry);
  }

  function gosxListIssues() {
    return gosxIssueStore().entries.map(gosxCloneIssue);
  }

  window.__gosx.reportIssue = gosxReportRuntimeIssue;
  window.__gosx.listIssues = gosxListIssues;
  window.__gosx.clearIssueState = gosxClearIssueState;

  const textMeasureCache = new Map();
  const textMeasureCacheLimit = 4096;
  const sceneLabelLayoutCacheLimit = 512;
  const textLayoutCache = new Map();
  const textLayoutCacheLimit = 1024;
  const textLayoutMetricsCache = new Map();
  const textLayoutMetricsCacheLimit = 1024;
  const textLayoutRangesCache = new Map();
  const textLayoutRangesCacheLimit = 1024;
  const TEXT_LAYOUT_ATTR = "data-gosx-text-layout";
  const TEXT_LAYOUT_ID_ATTR = "data-gosx-text-layout-id";
  const TEXT_LAYOUT_ROLE_ATTR = "data-gosx-text-layout-role";
  const TEXT_LAYOUT_SURFACE_ATTR = "data-gosx-text-layout-surface";
  const TEXT_LAYOUT_STATE_ATTR = "data-gosx-text-layout-state";
  const TEXT_LAYOUT_STYLE_ATTR = "data-gosx-text-layout-styles";
  const MANAGED_TEXT_LAYOUT_MUTATION_ATTRS = [
    "align",
    "data-gosx-text-layout-align",
    "data-gosx-text-layout-direction",
    "data-gosx-text-layout-font",
    "data-gosx-text-layout-locale",
    "data-gosx-text-layout-line-height",
    "data-gosx-text-layout-max-lines",
    "data-gosx-text-layout-max-width",
    "data-gosx-text-layout-observe",
    "data-gosx-text-layout-overflow",
    "data-gosx-text-layout-source",
    "data-gosx-text-layout-white-space",
    "dir",
    "lang",
  ];
  const textLayoutInvalidationListeners = new Set();
  const textLayoutRecordsByElement = new Map();
  let textMeasureContext = null;
  let textLayoutRevision = 0;
  let textLayoutFontObserverInstalled = false;
  let nextManagedTextLayoutID = 0;
  let textLayoutExternalImpl = typeof window.__gosx_text_layout === "function" ? window.__gosx_text_layout : null;
  let textLayoutMetricsExternalImpl = typeof window.__gosx_text_layout_metrics === "function" ? window.__gosx_text_layout_metrics : null;
  let textLayoutRangesExternalImpl = typeof window.__gosx_text_layout_ranges === "function" ? window.__gosx_text_layout_ranges : null;

  function gosxTextMeasureContext() {
    if (textMeasureContext) {
      return textMeasureContext;
    }
    const canvas = document.createElement("canvas");
    if (!canvas || typeof canvas.getContext !== "function") {
      return null;
    }
    textMeasureContext = canvas.getContext("2d");
    return textMeasureContext;
  }

  function gosxTextLayoutRevision() {
    return textLayoutRevision;
  }

  function invalidateTextLayoutCaches() {
    textLayoutRevision += 1;
    textMeasureCache.clear();
    textLayoutCache.clear();
    textLayoutMetricsCache.clear();
    textLayoutRangesCache.clear();
    for (const listener of Array.from(textLayoutInvalidationListeners)) {
      try {
        listener(textLayoutRevision);
      } catch (error) {
        console.error("[gosx] text layout invalidation listener failed:", error);
      }
    }
  }

  function onTextLayoutInvalidated(listener) {
    if (typeof listener !== "function") {
      return function() {};
    }
    textLayoutInvalidationListeners.add(listener);
    return function() {
      textLayoutInvalidationListeners.delete(listener);
    };
  }

  function installTextLayoutFontObserver() {
    if (textLayoutFontObserverInstalled) {
      return;
    }
    textLayoutFontObserverInstalled = true;

    const fonts = document.fonts;
    if (!fonts || typeof fonts !== "object") {
      return;
    }

    const onFontMetricsChanged = function() {
      invalidateTextLayoutCaches();
    };

    if (typeof fonts.addEventListener === "function") {
      fonts.addEventListener("loadingdone", onFontMetricsChanged);
      fonts.addEventListener("loadingerror", onFontMetricsChanged);
    }

    if (fonts.ready && typeof fonts.ready.then === "function") {
      fonts.ready.then(onFontMetricsChanged, function() {});
    }
  }

  window.__gosx_measure_text_batch = function(font, textsJSON) {
    let texts = textsJSON;
    if (typeof textsJSON === "string") {
      try {
        texts = JSON.parse(textsJSON);
      } catch (e) {
        console.error("[gosx] invalid text measurement payload:", e);
        return JSON.stringify([]);
      }
    }
    if (!Array.isArray(texts)) {
      return JSON.stringify([]);
    }

    const ctx = gosxTextMeasureContext();
    if (!ctx || typeof ctx.measureText !== "function") {
      return JSON.stringify(texts.map(function(value) {
        const text = value == null ? "" : String(value);
        return text.length;
      }));
    }

    if (font) {
      ctx.font = String(font);
    }

    const fontKey = font ? String(font) : "";
    const widths = texts.map(function(value) {
      const text = value == null ? "" : String(value);
      const cacheKey = fontKey + "\n" + text;
      if (textMeasureCache.has(cacheKey)) {
        return textMeasureCache.get(cacheKey);
      }
      const metrics = ctx.measureText(text);
      const width = metrics && typeof metrics.width === "number" ? metrics.width : 0;
      if (textMeasureCache.size >= textMeasureCacheLimit) {
        textMeasureCache.clear();
      }
      textMeasureCache.set(cacheKey, width);
      return width;
    });

    return JSON.stringify(widths);
  };

  window.__gosx_segment_words = function(text) {
    return JSON.stringify(segmentBrowserWordRun(text));
  };

  function normalizeTextLayoutWhiteSpace(value) {
    const mode = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (mode) {
      case "pre-wrap":
        return "pre-wrap";
      case "pre":
        return "pre";
      default:
        return "normal";
    }
  }

  function normalizeTextLayoutAlign(value) {
    const mode = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (mode) {
      case "left":
      case "right":
      case "center":
      case "justify":
      case "start":
      case "end":
        return mode;
      default:
        return "";
    }
  }

  function normalizeTextLayoutNewlines(text) {
    return String(text == null ? "" : text).replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  }

  function textLayoutCodePointByteLength(codePoint) {
    if (codePoint <= 0x7F) return 1;
    if (codePoint <= 0x7FF) return 2;
    if (codePoint <= 0xFFFF) return 3;
    return 4;
  }

  function textLayoutIsWhitespace(char) {
    return /\s/u.test(char);
  }

  function textLayoutIsCJK(codePoint) {
    return (
      (codePoint >= 0x3400 && codePoint <= 0x4DBF) ||
      (codePoint >= 0x4E00 && codePoint <= 0x9FFF) ||
      (codePoint >= 0x3040 && codePoint <= 0x309F) ||
      (codePoint >= 0x30A0 && codePoint <= 0x30FF) ||
      (codePoint >= 0xAC00 && codePoint <= 0xD7AF)
    );
  }

  const textLayoutGraphemeSegmenters = new Map();
  const textLayoutWordSegmenters = new Map();

  function normalizeTextLayoutLocale(value) {
    const locale = typeof value === "string" ? value.trim() : "";
    if (!locale) {
      return "";
    }
    return locale.replace(/_/g, "-");
  }

  function textLayoutMakeSegmenter(granularity, locale) {
    if (!(typeof Intl === "object" && Intl && typeof Intl.Segmenter === "function")) {
      return null;
    }
    const normalizedLocale = normalizeTextLayoutLocale(locale);
    try {
      return new Intl.Segmenter(normalizedLocale || undefined, { granularity });
    } catch (_error) {
      try {
        return new Intl.Segmenter(undefined, { granularity });
      } catch (_error2) {
        return null;
      }
    }
  }

  function gosxTextLayoutGraphemeSegmenter(locale) {
    const key = normalizeTextLayoutLocale(locale);
    if (textLayoutGraphemeSegmenters.has(key)) {
      return textLayoutGraphemeSegmenters.get(key);
    }
    const segmenter = textLayoutMakeSegmenter("grapheme", key);
    textLayoutGraphemeSegmenters.set(key, segmenter || false);
    return segmenter;
  }

  function gosxTextLayoutWordSegmenter(locale) {
    const key = normalizeTextLayoutLocale(locale);
    if (textLayoutWordSegmenters.has(key)) {
      return textLayoutWordSegmenters.get(key);
    }
    const segmenter = textLayoutMakeSegmenter("word", key);
    textLayoutWordSegmenters.set(key, segmenter || false);
    return segmenter;
  }

  function normalizeTextLayoutWritingMode(value) {
    const mode = typeof value === "string" ? value.trim().toLowerCase() : "";
    switch (mode) {
      case "vertical-rl":
      case "vertical-lr":
      case "sideways-rl":
      case "sideways-lr":
      case "horizontal-tb":
        return mode;
      default:
        return "";
    }
  }

  function textLayoutIsVerticalWritingMode(value) {
    const mode = normalizeTextLayoutWritingMode(value);
    return mode === "vertical-rl" || mode === "vertical-lr" || mode === "sideways-rl" || mode === "sideways-lr";
  }

  function textLayoutRuneCount(text) {
    return Array.from(String(text || "")).length;
  }

  function textLayoutByteLength(text) {
    let total = 0;
    for (const char of Array.from(String(text || ""))) {
      total += textLayoutCodePointByteLength(char.codePointAt(0));
    }
    return total;
  }

  function textLayoutLineEndProhibited(text) {
    const value = String(text || "");
    if (value === "") {
      return false;
    }
    for (const char of value) {
      switch (char) {
        case "\"":
        case "“":
        case "‘":
        case "«":
        case "‹":
        case "(":
        case "[":
        case "{":
        case "（":
        case "【":
        case "「":
        case "『":
        case "《":
        case "〈":
        case "〔":
        case "〖":
        case "〘":
        case "〚":
          break;
        default:
          return false;
      }
    }
    return true;
  }

  function segmentBrowserWordRun(text, locale) {
    const value = String(text || "");
    if (value === "") {
      return [];
    }
    const segmenter = gosxTextLayoutWordSegmenter(locale);
    if (segmenter) {
      const segments = [];
      for (const entry of segmenter.segment(value)) {
        segments.push(entry.segment);
      }
      if (segments.length > 0) {
        return segments;
      }
    }
    return Array.from(value);
  }

  function appendPreparedWordRun(tokens, text, byteStart, runeStart, locale) {
    const value = String(text || "");
    if (value === "") {
      return;
    }

    const segments = segmentBrowserWordRun(value, locale);
    let byteOffset = byteStart;
    let runeOffset = runeStart;
    let pending = null;
    let emitted = false;

    function emit(token, breakBefore) {
      if (breakBefore && emitted) {
        tokens.push({
          kind: "break",
          text: "",
          byteStart: token.byteStart,
          byteEnd: token.byteStart,
          runeStart: token.runeStart,
          runeEnd: token.runeStart,
        });
      }
      tokens.push(token);
      emitted = true;
    }

    function appendPending(token) {
      if (!pending) {
        pending = token;
        return;
      }
      pending.text += token.text;
      pending.byteEnd = token.byteEnd;
      pending.runeEnd = token.runeEnd;
    }

    for (const segment of segments) {
      const token = {
        kind: "word",
        text: segment,
        byteStart: byteOffset,
        byteEnd: byteOffset + textLayoutByteLength(segment),
        runeStart: runeOffset,
        runeEnd: runeOffset + textLayoutRuneCount(segment),
      };
      byteOffset = token.byteEnd;
      runeOffset = token.runeEnd;

      if (textLayoutLineEndProhibited(token.text)) {
        appendPending(token);
        continue;
      }
      if (browserTextLayoutLineStartProhibited(token.text)) {
        const previous = tokens.length > 0 ? tokens[tokens.length - 1] : null;
        if (previous && previous.kind === "word") {
          previous.text += token.text;
          previous.byteEnd = token.byteEnd;
          previous.runeEnd = token.runeEnd;
          emitted = true;
          continue;
        }
        if (pending) {
          appendPending(token);
          continue;
        }
        emit(token, emitted);
        continue;
      }

      if (pending) {
        token.text = pending.text + token.text;
        token.byteStart = pending.byteStart;
        token.runeStart = pending.runeStart;
        pending = null;
      }
      emit(token, emitted);
    }

    if (pending) {
      emit(pending, emitted);
    }
  }

  function splitPreparedTextLayoutToken(token, locale) {
    if (!token || token.kind === "newline" || token.kind === "tab" || token.kind === "soft-hyphen" || token.kind === "break" || !token.text) {
      return [token];
    }

    const graphemes = [];
    const segmenter = gosxTextLayoutGraphemeSegmenter(locale);
    if (segmenter) {
      for (const entry of segmenter.segment(token.text)) {
        graphemes.push(entry.segment);
      }
    } else {
      graphemes.push(...Array.from(token.text));
    }

    if (graphemes.length <= 1) {
      return [token];
    }

    const expanded = [];
    let byteOffset = token.byteStart;
    let runeOffset = token.runeStart;
    for (const grapheme of graphemes) {
      const runeLen = Array.from(grapheme).length;
      let byteLen = 0;
      for (const char of Array.from(grapheme)) {
        byteLen += textLayoutCodePointByteLength(char.codePointAt(0));
      }
      expanded.push({
        kind: token.kind,
        text: grapheme,
        byteStart: byteOffset,
        byteEnd: byteOffset + byteLen,
        runeStart: runeOffset,
        runeEnd: runeOffset + runeLen,
      });
      byteOffset += byteLen;
      runeOffset += runeLen;
    }
    return expanded;
  }

  function prepareBrowserTextLayout(text, whiteSpace, tabSize, locale) {
    const source = normalizeTextLayoutNewlines(text);
    const ws = normalizeTextLayoutWhiteSpace(whiteSpace);
    const normalizedLocale = normalizeTextLayoutLocale(locale);
    const tokens = [];
    const resolvedTabSize = Math.max(1, Math.floor(sceneNumber(tabSize, 8)));

    let word = "";
    let spaces = "";
    let wordByteStart = -1;
    let wordByteEnd = 0;
    let wordRuneStart = -1;
    let wordRuneEnd = 0;
    let spaceByteStart = -1;
    let spaceByteEnd = 0;
    let spaceRuneStart = -1;
    let spaceRuneEnd = 0;

    function flushWord() {
      if (!word) {
        return;
      }
      appendPreparedWordRun(tokens, word, wordByteStart, wordRuneStart, locale);
      word = "";
      wordByteStart = -1;
      wordByteEnd = 0;
      wordRuneStart = -1;
      wordRuneEnd = 0;
    }

    function flushSpaces() {
      if (!spaces) {
        return;
      }
      tokens.push({
        kind: "space",
        text: spaces,
        byteStart: spaceByteStart,
        byteEnd: spaceByteEnd,
        runeStart: spaceRuneStart,
        runeEnd: spaceRuneEnd,
      });
      spaces = "";
      spaceByteStart = -1;
      spaceByteEnd = 0;
      spaceRuneStart = -1;
      spaceRuneEnd = 0;
    }

    function appendCollapsedSpace(byteStart, byteEnd, runeStart, runeEnd) {
      flushWord();
      if (tokens.length === 0) {
        return;
      }
      const previous = tokens[tokens.length - 1];
      if (previous.kind === "space") {
        previous.byteEnd = byteEnd;
        previous.runeEnd = runeEnd;
        return;
      }
      tokens.push({
        kind: "space",
        text: " ",
        byteStart,
        byteEnd,
        runeStart,
        runeEnd,
      });
    }

    let runeIndex = 0;
    let byteOffset = 0;
    for (const char of source) {
      const codePoint = char.codePointAt(0);
      const byteStart = byteOffset;
      const byteEnd = byteStart + textLayoutCodePointByteLength(codePoint);
      const runeStart = runeIndex;
      const runeEnd = runeIndex + 1;

      if (char === "\n") {
        if (ws === "normal") {
          appendCollapsedSpace(byteStart, byteEnd, runeStart, runeEnd);
        } else {
          flushWord();
          flushSpaces();
          tokens.push({
            kind: "newline",
            text: "\n",
            byteStart,
            byteEnd,
            runeStart,
            runeEnd,
          });
        }
      } else if (char === "\t") {
        if (ws === "normal") {
          appendCollapsedSpace(byteStart, byteEnd, runeStart, runeEnd);
        } else {
          flushWord();
          flushSpaces();
          tokens.push({
            kind: "tab",
            text: "\t",
            byteStart,
            byteEnd,
            runeStart,
            runeEnd,
          });
        }
      } else if (char === "\u00ad") {
        flushWord();
        flushSpaces();
        tokens.push({
          kind: "soft-hyphen",
          text: "\u00ad",
          byteStart,
          byteEnd,
          runeStart,
          runeEnd,
        });
      } else if (char === "\u200b") {
        flushWord();
        flushSpaces();
        tokens.push({
          kind: "break",
          text: "\u200b",
          byteStart,
          byteEnd,
          runeStart,
          runeEnd,
        });
      } else if (textLayoutIsWhitespace(char)) {
        if (ws === "normal") {
          appendCollapsedSpace(byteStart, byteEnd, runeStart, runeEnd);
        } else {
          flushWord();
          if (spaceByteStart < 0) {
            spaceByteStart = byteStart;
            spaceRuneStart = runeStart;
          }
          spaceByteEnd = byteEnd;
          spaceRuneEnd = runeEnd;
          spaces += char;
        }
      } else {
        flushSpaces();
        if (wordByteStart < 0) {
          wordByteStart = byteStart;
          wordRuneStart = runeStart;
        }
        wordByteEnd = byteEnd;
        wordRuneEnd = runeEnd;
        word += char;
      }

      runeIndex += 1;
      byteOffset = byteEnd;
    }

    flushWord();
    flushSpaces();

    return {
      source,
      byteLen: byteOffset,
      runeCount: runeIndex,
      whiteSpace: ws,
      locale: normalizedLocale,
      tabSize: resolvedTabSize,
      tokens,
    };
  }

  function measurePreparedBrowserTextLayout(prepared, font) {
    const expandedTokens = [];
    for (const token of prepared.tokens) {
      expandedTokens.push(...splitPreparedTextLayoutToken(token, prepared.locale));
    }
    const measured = {
      source: prepared.source,
      byteLen: prepared.byteLen,
      runeCount: prepared.runeCount,
      whiteSpace: prepared.whiteSpace,
      tabSize: Math.max(1, Math.floor(sceneNumber(prepared.tabSize, 8))),
      locale: normalizeTextLayoutLocale(prepared.locale),
      spaceWidth: 0,
      hyphenWidth: 0,
      ellipsisWidth: 0,
      font: typeof font === "string" ? font : "",
      tokens: expandedTokens.map(function(token) {
        return Object.assign({ width: 0 }, token);
      }),
    };

    const texts = [];
    const indexes = [];
    let needSpaceWidth = false;
    let needHyphenWidth = false;
    let needEllipsisWidth = true;
    for (let i = 0; i < measured.tokens.length; i += 1) {
      if (measured.tokens[i].kind === "newline" || measured.tokens[i].kind === "tab" || measured.tokens[i].kind === "soft-hyphen" || measured.tokens[i].kind === "break") {
        if (measured.tokens[i].kind === "tab") {
          needSpaceWidth = true;
        }
        if (measured.tokens[i].kind === "soft-hyphen") {
          needHyphenWidth = true;
        }
        continue;
      }
      texts.push(measured.tokens[i].text);
      indexes.push(i);
    }
    let spaceIndex = -1;
    let hyphenIndex = -1;
    let ellipsisIndex = -1;
    if (needSpaceWidth) {
      spaceIndex = texts.length;
      texts.push(" ");
    }
    if (needHyphenWidth) {
      hyphenIndex = texts.length;
      texts.push("-");
    }
    if (needEllipsisWidth) {
      ellipsisIndex = texts.length;
      texts.push("…");
    }

    if (texts.length === 0) {
      return measured;
    }

    let widths = [];
    try {
      const raw = window.__gosx_measure_text_batch(measured.font, JSON.stringify(texts));
      widths = typeof raw === "string" ? JSON.parse(raw) : raw;
    } catch (_error) {
      widths = texts.map(function(value) {
        return String(value || "").length * 8;
      });
    }

    if (!Array.isArray(widths) || widths.length !== texts.length) {
      widths = texts.map(function(value) {
        return String(value || "").length * 8;
      });
    }

    for (let i = 0; i < widths.length; i += 1) {
      if (i < indexes.length) {
        measured.tokens[indexes[i]].width = sceneNumber(widths[i], 0);
      }
    }
    if (spaceIndex >= 0 && spaceIndex < widths.length) {
      measured.spaceWidth = sceneNumber(widths[spaceIndex], 0);
    }
    if (hyphenIndex >= 0 && hyphenIndex < widths.length) {
      measured.hyphenWidth = sceneNumber(widths[hyphenIndex], 0);
    }
    if (ellipsisIndex >= 0 && ellipsisIndex < widths.length) {
      measured.ellipsisWidth = sceneNumber(widths[ellipsisIndex], 0);
    }

    return measured;
  }

  function browserTextLayoutLineText(measured, start, end, softBreak) {
    const tokens = measured.tokens;
    let textEnd = end;
    if (normalizeTextLayoutWhiteSpace(measured.whiteSpace) === "normal") {
      while (textEnd > start && tokens[textEnd - 1].kind === "space") {
        textEnd -= 1;
      }
    }
    let text = "";
    for (let i = start; i < textEnd && i < tokens.length; i += 1) {
      if (tokens[i].kind === "newline" || tokens[i].kind === "soft-hyphen" || tokens[i].kind === "break") {
        continue;
      }
      text += tokens[i].text;
    }
    if (softBreak) {
      text += "-";
    }
    return text;
  }

  function browserTextLayoutTabAdvance(measured, lineWidth) {
    const tabSize = Math.max(1, Math.floor(sceneNumber(measured.tabSize, 8)));
    const spaceWidth = Math.max(1, sceneNumber(measured.spaceWidth, 1));
    const tabStop = tabSize * spaceWidth;
    const remainder = lineWidth % tabStop;
    if (Math.abs(remainder) <= 1e-6) {
      return tabStop;
    }
    return tabStop - remainder;
  }

  function browserTextLayoutHyphenAdvance(measured) {
    return Math.max(1, sceneNumber(measured.hyphenWidth, 1));
  }

  function browserTextLayoutTokenProgressWidth(measured, lineWidth, token) {
    switch (token.kind) {
      case "tab":
        return browserTextLayoutTabAdvance(measured, lineWidth);
      case "soft-hyphen":
      case "break":
      case "newline":
        return 0;
      default:
        return sceneNumber(token.width, 0);
    }
  }

  function browserTextLayoutTokenFitAdvance(measured, lineWidth, token) {
    switch (token.kind) {
      case "space":
        return normalizeTextLayoutWhiteSpace(measured.whiteSpace) === "normal" ? 0 : sceneNumber(token.width, 0);
      case "tab":
        return 0;
      case "soft-hyphen":
        return browserTextLayoutHyphenAdvance(measured);
      case "break":
      case "newline":
        return 0;
      default:
        return sceneNumber(token.width, 0);
    }
  }

  function browserTextLayoutTokenPaintAdvance(measured, lineWidth, token, softBreak) {
    switch (token.kind) {
      case "space":
        return normalizeTextLayoutWhiteSpace(measured.whiteSpace) === "normal" ? 0 : sceneNumber(token.width, 0);
      case "tab":
        return browserTextLayoutTabAdvance(measured, lineWidth);
      case "soft-hyphen":
        return softBreak ? browserTextLayoutHyphenAdvance(measured) : 0;
      case "break":
      case "newline":
        return 0;
      default:
        return sceneNumber(token.width, 0);
    }
  }

  function browserTextLayoutCanBreakAfter(token) {
    return token.kind === "space" || token.kind === "tab" || token.kind === "soft-hyphen" || token.kind === "break";
  }

  function browserTextLayoutLineStartProhibited(text) {
    const value = String(text || "");
    if (value === "") {
      return false;
    }
    for (const char of value) {
      switch (char) {
        case ".":
        case ",":
        case "!":
        case "?":
        case ":":
        case ";":
        case ")":
        case "]":
        case "}":
        case "%":
        case "\"":
        case "”":
        case "’":
        case "»":
        case "›":
        case "…":
        case "、":
        case "。":
        case "，":
        case "．":
        case "！":
        case "？":
        case "：":
        case "；":
        case "）":
        case "】":
        case "」":
        case "』":
        case "》":
        case "〉":
        case "〕":
        case "〗":
        case "〙":
        case "〛":
        case "ー":
        case "々":
        case "ゝ":
        case "ゞ":
        case "ヽ":
        case "ヾ":
          break;
        default:
          return false;
      }
    }
    return true;
  }

  function browserTextLayoutRangeWidth(measured, start, end, softBreak) {
    let progress = 0;
    let display = 0;
    for (let i = start; i < end && i < measured.tokens.length; i += 1) {
      const token = measured.tokens[i];
      const before = progress;
      progress += browserTextLayoutTokenProgressWidth(measured, progress, token);
      display = before + browserTextLayoutTokenPaintAdvance(measured, before, token, softBreak && i === end - 1 && token.kind === "soft-hyphen");
    }
    return display;
  }

  function buildBrowserTextLayoutRecord(measured, start, end, hardBreak, softBreak, width, includeText) {
    const tokens = measured.tokens;
    const line = {
      start,
      end,
      byteStart: 0,
      byteEnd: 0,
      runeStart: 0,
      runeEnd: 0,
      width: width == null ? browserTextLayoutRangeWidth(measured, start, end, softBreak) : width,
      hardBreak: Boolean(hardBreak),
      softBreak: Boolean(softBreak),
    };
    if (includeText) {
      line.text = browserTextLayoutLineText(measured, start, end, softBreak);
    }
    if (start < end && start < tokens.length) {
      line.byteStart = tokens[start].byteStart;
      line.byteEnd = tokens[end - 1].byteEnd;
      line.runeStart = tokens[start].runeStart;
      line.runeEnd = tokens[end - 1].runeEnd;
    }
    return line;
  }

  function buildBrowserTextLayoutLine(measured, start, end, hardBreak, softBreak, width) {
    return buildBrowserTextLayoutRecord(measured, start, end, hardBreak, softBreak, width, true);
  }

  function buildBrowserTextLayoutRange(measured, start, end, hardBreak, softBreak, width) {
    return buildBrowserTextLayoutRecord(measured, start, end, hardBreak, softBreak, width, false);
  }

  function emptyBrowserTextLayoutLineAtIndex(tokens, index, hardBreak) {
    const line = {
      start: index,
      end: index,
      byteStart: 0,
      byteEnd: 0,
      runeStart: 0,
      runeEnd: 0,
      width: 0,
      text: "",
      hardBreak: Boolean(hardBreak),
      softBreak: false,
    };
    if (index >= 0 && index < tokens.length) {
      line.byteStart = tokens[index].byteStart;
      line.byteEnd = tokens[index].byteStart;
      line.runeStart = tokens[index].runeStart;
      line.runeEnd = tokens[index].runeStart;
    }
    return line;
  }

  function emptyBrowserTextLayoutLineAtEnd(measured) {
    return {
      start: measured.tokens.length,
      end: measured.tokens.length,
      byteStart: measured.byteLen,
      byteEnd: measured.byteLen,
      runeStart: measured.runeCount,
      runeEnd: measured.runeCount,
      width: 0,
      text: "",
      hardBreak: false,
      softBreak: false,
    };
  }

  function browserTextLayoutEllipsisAdvance(measured) {
    return Math.max(0, sceneNumber(measured && measured.ellipsisWidth, 1)) || 1;
  }

  function trimBrowserTextLayoutDisplayEnd(measured, start, end) {
    if (normalizeTextLayoutWhiteSpace(measured.whiteSpace) !== "normal") {
      return end;
    }
    while (end > start && measured.tokens[end - 1].kind === "space") {
      end -= 1;
    }
    return end;
  }

  function hasMoreBrowserTextLayoutContent(measured, next) {
    if (next < measured.tokens.length) {
      return true;
    }
    return measured.tokens.length > 0 && measured.tokens[measured.tokens.length - 1].kind === "newline";
  }

  function clampBrowserTextLayoutLine(line, measured, maxWidth, overflow, includeText) {
    const clamped = Object.assign({}, line, {
      truncated: true,
      ellipsis: false,
      hardBreak: false,
      softBreak: false,
    });
    if (normalizeTextLayoutOverflow(overflow) !== "ellipsis") {
      return clamped;
    }

    const ellipsisWidth = browserTextLayoutEllipsisAdvance(measured);
    if (!(maxWidth > 0)) {
      clamped.ellipsis = true;
      clamped.width += ellipsisWidth;
      if (includeText) {
        clamped.text = String(clamped.text || "") + "…";
      }
      return clamped;
    }

    const allowedWidth = maxWidth - ellipsisWidth;
    let end = trimBrowserTextLayoutDisplayEnd(measured, clamped.start, clamped.end);
    while (end > clamped.start && browserTextLayoutRangeWidth(measured, clamped.start, end, false) > allowedWidth) {
      end -= 1;
      end = trimBrowserTextLayoutDisplayEnd(measured, clamped.start, end);
    }

    clamped.end = end;
    clamped.ellipsis = true;
    if (end > clamped.start) {
      clamped.byteEnd = measured.tokens[end - 1].byteEnd;
      clamped.runeEnd = measured.tokens[end - 1].runeEnd;
      clamped.width = Math.min(maxWidth, browserTextLayoutRangeWidth(measured, clamped.start, end, false) + ellipsisWidth);
      if (includeText) {
        clamped.text = browserTextLayoutLineText(measured, clamped.start, end, false) + "…";
      }
      return clamped;
    }

    clamped.byteEnd = clamped.byteStart;
    clamped.runeEnd = clamped.runeStart;
    clamped.width = Math.min(maxWidth, ellipsisWidth);
    if (includeText) {
      clamped.text = "…";
    }
    return clamped;
  }

  function normalizeBrowserTextLayoutLineStart(measured, start) {
    const whiteSpace = normalizeTextLayoutWhiteSpace(measured.whiteSpace);
    while (start < measured.tokens.length) {
      const kind = measured.tokens[start].kind;
      if (kind === "soft-hyphen" || kind === "break") {
        start += 1;
        continue;
      }
      if (kind === "space" && whiteSpace === "normal") {
        start += 1;
        continue;
      }
      break;
    }
    return start;
  }

  function normalizeBrowserTextLayoutNextStart(measured, start) {
    return normalizeBrowserTextLayoutLineStart(measured, start);
  }

  function layoutBrowserPreLine(measured, start) {
    const tokens = measured.tokens;
    for (let i = start; i < tokens.length; i += 1) {
      if (tokens[i].kind === "newline") {
        return [buildBrowserTextLayoutLine(measured, start, i, true, false), i + 1];
      }
    }
    return [buildBrowserTextLayoutLine(measured, start, tokens.length, false, false), tokens.length];
  }

  function layoutBrowserPreLineRange(measured, start) {
    const tokens = measured.tokens;
    for (let i = start; i < tokens.length; i += 1) {
      if (tokens[i].kind === "newline") {
        return [buildBrowserTextLayoutRange(measured, start, i, true, false), i + 1];
      }
    }
    return [buildBrowserTextLayoutRange(measured, start, tokens.length, false, false), tokens.length];
  }

  function layoutBrowserWrappedLine(measured, start, whiteSpace, maxWidth) {
    const tokens = measured.tokens;
    let lineWidth = 0;
    let lastBreak = -1;
    let lastBreakWidth = 0;
    let lastBreakSoft = false;

    for (let i = start; i < tokens.length; i += 1) {
      const token = tokens[i];
      if (token.kind === "newline") {
        return [buildBrowserTextLayoutLine(measured, start, i, true, false), i + 1];
      }

      const tokenWidth = browserTextLayoutTokenProgressWidth(measured, lineWidth, token);
      const fitAdvance = browserTextLayoutTokenFitAdvance(measured, lineWidth, token);
      const paintAdvance = browserTextLayoutTokenPaintAdvance(measured, lineWidth, token, token.kind === "soft-hyphen");

      if (browserTextLayoutCanBreakAfter(token)) {
        lastBreak = i + 1;
        lastBreakWidth = lineWidth + paintAdvance;
        lastBreakSoft = token.kind === "soft-hyphen";
      }

      const candidateWidth = lineWidth + tokenWidth;
      if (maxWidth > 0 && candidateWidth > maxWidth) {
        if (browserTextLayoutCanBreakAfter(token) && lineWidth + fitAdvance <= maxWidth) {
          return [
            buildBrowserTextLayoutLine(measured, start, i + 1, false, token.kind === "soft-hyphen"),
            normalizeBrowserTextLayoutNextStart(measured, i + 1),
          ];
        }
        if (lastBreak > start) {
          return [
            buildBrowserTextLayoutLine(measured, start, lastBreak, false, lastBreakSoft, lastBreakWidth),
            normalizeBrowserTextLayoutNextStart(measured, lastBreak),
          ];
        }
        if (i > start && textLayoutLineEndProhibited(tokens[i - 1].text)) {
          return [
            buildBrowserTextLayoutLine(measured, start, i + 1, false, false),
            normalizeBrowserTextLayoutNextStart(measured, i + 1),
          ];
        }
        if (lineWidth > 0 && browserTextLayoutLineStartProhibited(token.text)) {
          return [
            buildBrowserTextLayoutLine(measured, start, i + 1, false, false),
            normalizeBrowserTextLayoutNextStart(measured, i + 1),
          ];
        }
        if (lineWidth === 0) {
          return [
            buildBrowserTextLayoutLine(measured, start, i + 1, false, false),
            normalizeBrowserTextLayoutNextStart(measured, i + 1),
          ];
        }
        return [
          buildBrowserTextLayoutLine(measured, start, i, false, false),
          normalizeBrowserTextLayoutNextStart(measured, i),
        ];
      }

      lineWidth = candidateWidth;
    }

    return [buildBrowserTextLayoutLine(measured, start, tokens.length, false, false), tokens.length];
  }

  function layoutBrowserWrappedLineRange(measured, start, whiteSpace, maxWidth) {
    const tokens = measured.tokens;
    let lineWidth = 0;
    let lastBreak = -1;
    let lastBreakWidth = 0;
    let lastBreakSoft = false;

    for (let i = start; i < tokens.length; i += 1) {
      const token = tokens[i];
      if (token.kind === "newline") {
        return [buildBrowserTextLayoutRange(measured, start, i, true, false), i + 1];
      }

      const tokenWidth = browserTextLayoutTokenProgressWidth(measured, lineWidth, token);
      const fitAdvance = browserTextLayoutTokenFitAdvance(measured, lineWidth, token);
      const paintAdvance = browserTextLayoutTokenPaintAdvance(measured, lineWidth, token, token.kind === "soft-hyphen");

      if (browserTextLayoutCanBreakAfter(token)) {
        lastBreak = i + 1;
        lastBreakWidth = lineWidth + paintAdvance;
        lastBreakSoft = token.kind === "soft-hyphen";
      }

      const candidateWidth = lineWidth + tokenWidth;
      if (maxWidth > 0 && candidateWidth > maxWidth) {
        if (browserTextLayoutCanBreakAfter(token) && lineWidth + fitAdvance <= maxWidth) {
          return [
            buildBrowserTextLayoutRange(measured, start, i + 1, false, token.kind === "soft-hyphen"),
            normalizeBrowserTextLayoutNextStart(measured, i + 1),
          ];
        }
        if (lastBreak > start) {
          return [
            buildBrowserTextLayoutRange(measured, start, lastBreak, false, lastBreakSoft, lastBreakWidth),
            normalizeBrowserTextLayoutNextStart(measured, lastBreak),
          ];
        }
        if (i > start && textLayoutLineEndProhibited(tokens[i - 1].text)) {
          return [
            buildBrowserTextLayoutRange(measured, start, i + 1, false, false),
            normalizeBrowserTextLayoutNextStart(measured, i + 1),
          ];
        }
        if (lineWidth > 0 && browserTextLayoutLineStartProhibited(token.text)) {
          return [
            buildBrowserTextLayoutRange(measured, start, i + 1, false, false),
            normalizeBrowserTextLayoutNextStart(measured, i + 1),
          ];
        }
        if (lineWidth === 0) {
          return [
            buildBrowserTextLayoutRange(measured, start, i + 1, false, false),
            normalizeBrowserTextLayoutNextStart(measured, i + 1),
          ];
        }
        return [
          buildBrowserTextLayoutRange(measured, start, i, false, false),
          normalizeBrowserTextLayoutNextStart(measured, i),
        ];
      }

      lineWidth = candidateWidth;
    }

    return [buildBrowserTextLayoutRange(measured, start, tokens.length, false, false), tokens.length];
  }

  function layoutBrowserTextNextLine(measured, start, maxWidth) {
    const tokens = measured.tokens;
    if (start < 0) {
      start = 0;
    }
    if (start >= tokens.length) {
      return [emptyBrowserTextLayoutLineAtEnd(measured), tokens.length];
    }

    const whiteSpace = normalizeTextLayoutWhiteSpace(measured.whiteSpace);
    let lineStart = normalizeBrowserTextLayoutLineStart(measured, start);
    if (lineStart >= tokens.length) {
      return [emptyBrowserTextLayoutLineAtEnd(measured), tokens.length];
    }

    if (tokens[lineStart].kind === "newline") {
      return [emptyBrowserTextLayoutLineAtIndex(tokens, lineStart, true), lineStart + 1];
    }

    if (whiteSpace === "pre") {
      return layoutBrowserPreLine(measured, lineStart);
    }
    return layoutBrowserWrappedLine(measured, lineStart, whiteSpace, Math.max(0, sceneNumber(maxWidth, 0)));
  }

  function layoutBrowserTextNextRange(measured, start, maxWidth) {
    const tokens = measured.tokens;
    if (start < 0) {
      start = 0;
    }
    if (start >= tokens.length) {
      return [emptyBrowserTextLayoutLineAtEnd(measured), tokens.length];
    }

    const whiteSpace = normalizeTextLayoutWhiteSpace(measured.whiteSpace);
    let lineStart = normalizeBrowserTextLayoutLineStart(measured, start);
    if (lineStart >= tokens.length) {
      return [emptyBrowserTextLayoutLineAtEnd(measured), tokens.length];
    }

    if (tokens[lineStart].kind === "newline") {
      return [emptyBrowserTextLayoutLineAtIndex(tokens, lineStart, true), lineStart + 1];
    }

    if (whiteSpace === "pre") {
      return layoutBrowserPreLineRange(measured, lineStart);
    }
    return layoutBrowserWrappedLineRange(measured, lineStart, whiteSpace, Math.max(0, sceneNumber(maxWidth, 0)));
  }

  function layoutBrowserText(text, font, maxWidth, whiteSpace, lineHeight, options) {
    const normalizedOptions = normalizeTextLayoutRunOptions(options);
    const prepared = prepareBrowserTextLayout(text, whiteSpace, 8, normalizedOptions.locale);
    const measured = measurePreparedBrowserTextLayout(prepared, font);
    const resolvedLineHeight = Math.max(1, sceneNumber(lineHeight, 1));

    if (measured.tokens.length === 0) {
      return {
        lines: [{
          start: 0,
          end: 0,
          byteStart: measured.byteLen,
          byteEnd: measured.byteLen,
          runeStart: measured.runeCount,
          runeEnd: measured.runeCount,
          width: 0,
          text: "",
          hardBreak: false,
        }],
        lineCount: 1,
        height: resolvedLineHeight,
        maxLineWidth: 0,
        byteLen: measured.byteLen,
        runeCount: measured.runeCount,
        truncated: false,
      };
    }

    const lines = [];
    let truncated = false;
    let count = 0;
    for (let start = 0; start < measured.tokens.length;) {
      const nextLine = layoutBrowserTextNextLine(measured, start, maxWidth);
      let line = nextLine[0];
      count += 1;
      if (normalizedOptions.maxLines > 0 && count === normalizedOptions.maxLines && hasMoreBrowserTextLayoutContent(measured, nextLine[1])) {
        line = clampBrowserTextLayoutLine(line, measured, Math.max(0, sceneNumber(maxWidth, 0)), normalizedOptions.overflow, true);
        truncated = true;
        lines.push(line);
        break;
      }
      lines.push(line);
      start = nextLine[1] > start ? nextLine[1] : start + 1;
    }

    if (!truncated && measured.tokens[measured.tokens.length - 1].kind === "newline" && !(normalizedOptions.maxLines > 0 && lines.length >= normalizedOptions.maxLines)) {
      lines.push(emptyBrowserTextLayoutLineAtEnd(measured));
    }

    let maxLineWidth = 0;
    for (const line of lines) {
      if (line.width > maxLineWidth) {
        maxLineWidth = line.width;
      }
    }

    return {
      lines,
      lineCount: lines.length,
      height: lines.length * resolvedLineHeight,
      maxLineWidth,
      byteLen: measured.byteLen,
      runeCount: measured.runeCount,
      truncated,
    };
  }

  function layoutBrowserTextRanges(text, font, maxWidth, whiteSpace, lineHeight, options) {
    const normalizedOptions = normalizeTextLayoutRunOptions(options);
    const prepared = prepareBrowserTextLayout(text, whiteSpace, 8, normalizedOptions.locale);
    const measured = measurePreparedBrowserTextLayout(prepared, font);
    const resolvedLineHeight = Math.max(1, sceneNumber(lineHeight, 1));

    if (measured.tokens.length === 0) {
      return {
        lines: [{
          start: 0,
          end: 0,
          byteStart: measured.byteLen,
          byteEnd: measured.byteLen,
          runeStart: measured.runeCount,
          runeEnd: measured.runeCount,
          width: 0,
          hardBreak: false,
          softBreak: false,
        }],
        lineCount: 1,
        height: resolvedLineHeight,
        maxLineWidth: 0,
        byteLen: measured.byteLen,
        runeCount: measured.runeCount,
        truncated: false,
      };
    }

    const lines = [];
    let truncated = false;
    let count = 0;
    for (let start = 0; start < measured.tokens.length;) {
      const nextLine = layoutBrowserTextNextRange(measured, start, maxWidth);
      let line = nextLine[0];
      count += 1;
      if (normalizedOptions.maxLines > 0 && count === normalizedOptions.maxLines && hasMoreBrowserTextLayoutContent(measured, nextLine[1])) {
        line = clampBrowserTextLayoutLine(line, measured, Math.max(0, sceneNumber(maxWidth, 0)), normalizedOptions.overflow, false);
        truncated = true;
        lines.push(line);
        break;
      }
      lines.push(line);
      start = nextLine[1] > start ? nextLine[1] : start + 1;
    }

    if (!truncated && measured.tokens[measured.tokens.length - 1].kind === "newline" && !(normalizedOptions.maxLines > 0 && lines.length >= normalizedOptions.maxLines)) {
      lines.push(emptyBrowserTextLayoutLineAtEnd(measured));
    }

    let maxLineWidth = 0;
    for (const line of lines) {
      if (line.width > maxLineWidth) {
        maxLineWidth = line.width;
      }
    }

    return {
      lines,
      lineCount: lines.length,
      height: lines.length * resolvedLineHeight,
      maxLineWidth,
      byteLen: measured.byteLen,
      runeCount: measured.runeCount,
      truncated,
    };
  }

  function adoptTextLayoutImpl(candidate) {
    if (typeof candidate !== "function" || candidate === gosxTextLayout) {
      return;
    }
    if (textLayoutExternalImpl === candidate) {
      return;
    }
    textLayoutExternalImpl = candidate;
    invalidateTextLayoutCaches();
  }

  function adoptTextLayoutMetricsImpl(candidate) {
    if (typeof candidate !== "function" || candidate === gosxTextLayoutMetrics) {
      return;
    }
    if (textLayoutMetricsExternalImpl === candidate) {
      return;
    }
    textLayoutMetricsExternalImpl = candidate;
    invalidateTextLayoutCaches();
  }

  function adoptTextLayoutRangesImpl(candidate) {
    if (typeof candidate !== "function" || candidate === gosxTextLayoutRanges) {
      return;
    }
    if (textLayoutRangesExternalImpl === candidate) {
      return;
    }
    textLayoutRangesExternalImpl = candidate;
    invalidateTextLayoutCaches();
  }

  function currentTextLayoutImpl() {
    return typeof textLayoutExternalImpl === "function" ? textLayoutExternalImpl : null;
  }

  function normalizeTextLayoutOverflow(value) {
    const mode = typeof value === "string" ? value.trim().toLowerCase() : "";
    return mode === "ellipsis" ? "ellipsis" : "clip";
  }

  function normalizeTextLayoutRunOptions(options) {
    const input = options && typeof options === "object" ? options : {};
    return {
      maxLines: Math.max(0, Math.floor(sceneNumber(input.maxLines, 0))),
      overflow: normalizeTextLayoutOverflow(input.overflow),
      locale: normalizeTextLayoutLocale(input.locale),
    };
  }

  function textLayoutCacheKey(text, font, maxWidth, whiteSpace, lineHeight, options) {
    const normalized = normalizeTextLayoutRunOptions(options);
    return [
      gosxTextLayoutRevision(),
      String(text == null ? "" : text),
      String(font == null ? "" : font),
      sceneNumber(maxWidth, 0),
      normalizeTextLayoutWhiteSpace(whiteSpace),
      sceneNumber(lineHeight, 1),
      normalized.maxLines,
      normalized.overflow,
      normalized.locale,
      currentTextLayoutImpl() ? "external" : "browser",
    ].join("\n");
  }

  function textLayoutMetricsCacheKey(text, font, maxWidth, whiteSpace, lineHeight, options) {
    const normalized = normalizeTextLayoutRunOptions(options);
    return [
      gosxTextLayoutRevision(),
      String(text == null ? "" : text),
      String(font == null ? "" : font),
      sceneNumber(maxWidth, 0),
      normalizeTextLayoutWhiteSpace(whiteSpace),
      sceneNumber(lineHeight, 1),
      normalized.maxLines,
      normalized.overflow,
      normalized.locale,
      textLayoutMetricsExternalImpl ? "external" : "derived",
    ].join("\n");
  }

  function textLayoutRangesCacheKey(text, font, maxWidth, whiteSpace, lineHeight, options) {
    const normalized = normalizeTextLayoutRunOptions(options);
    return [
      gosxTextLayoutRevision(),
      String(text == null ? "" : text),
      String(font == null ? "" : font),
      sceneNumber(maxWidth, 0),
      normalizeTextLayoutWhiteSpace(whiteSpace),
      sceneNumber(lineHeight, 1),
      normalized.maxLines,
      normalized.overflow,
      normalized.locale,
      textLayoutRangesExternalImpl ? "external" : "browser",
    ].join("\n");
  }

  function normalizeTextLayoutLine(line, index, textByteLen, textRuneCount) {
    const item = line && typeof line === "object" ? line : {};
    const start = Math.max(0, Math.floor(sceneNumber(item.start, index)));
    const end = Math.max(start, Math.floor(sceneNumber(item.end, start)));
    const byteStart = Math.max(0, Math.floor(sceneNumber(item.byteStart, 0)));
    const byteEnd = Math.max(byteStart, Math.floor(sceneNumber(item.byteEnd, byteStart)));
    const runeStart = Math.max(0, Math.floor(sceneNumber(item.runeStart, 0)));
    const runeEnd = Math.max(runeStart, Math.floor(sceneNumber(item.runeEnd, runeStart)));
    return {
      start,
      end,
      byteStart: Math.min(byteStart, textByteLen),
      byteEnd: Math.min(byteEnd, textByteLen),
      runeStart: Math.min(runeStart, textRuneCount),
      runeEnd: Math.min(runeEnd, textRuneCount),
      width: Math.max(0, sceneNumber(item.width, 0)),
      text: typeof item.text === "string" ? item.text : "",
      hardBreak: Boolean(item.hardBreak),
      softBreak: Boolean(item.softBreak),
      truncated: Boolean(item.truncated),
      ellipsis: Boolean(item.ellipsis),
    };
  }

  function normalizeTextLayoutRange(line, index, textByteLen, textRuneCount) {
    const item = line && typeof line === "object" ? line : {};
    const start = Math.max(0, Math.floor(sceneNumber(item.start, index)));
    const end = Math.max(start, Math.floor(sceneNumber(item.end, start)));
    const byteStart = Math.max(0, Math.floor(sceneNumber(item.byteStart, 0)));
    const byteEnd = Math.max(byteStart, Math.floor(sceneNumber(item.byteEnd, byteStart)));
    const runeStart = Math.max(0, Math.floor(sceneNumber(item.runeStart, 0)));
    const runeEnd = Math.max(runeStart, Math.floor(sceneNumber(item.runeEnd, runeStart)));
    return {
      start,
      end,
      byteStart: Math.min(byteStart, textByteLen),
      byteEnd: Math.min(byteEnd, textByteLen),
      runeStart: Math.min(runeStart, textRuneCount),
      runeEnd: Math.min(runeEnd, textRuneCount),
      width: Math.max(0, sceneNumber(item.width, 0)),
      hardBreak: Boolean(item.hardBreak),
      softBreak: Boolean(item.softBreak),
      truncated: Boolean(item.truncated),
      ellipsis: Boolean(item.ellipsis),
    };
  }

  function normalizeTextLayoutResult(result, text, lineHeight) {
    const source = normalizeTextLayoutNewlines(text);
    const graphemes = Array.from(source);
    const runeCount = graphemes.length;
    const byteLen = graphemes.reduce(function(total, char) {
        return total + textLayoutCodePointByteLength(char.codePointAt(0));
      }, 0);
    const lines = Array.isArray(result && result.lines)
      ? result.lines.map(function(line, index) {
          return normalizeTextLayoutLine(line, index, byteLen, runeCount);
        })
      : [];

    return {
      lines,
      lineCount: Math.max(lines.length, Math.floor(sceneNumber(result && result.lineCount, lines.length))),
      height: Math.max(0, sceneNumber(result && result.height, lines.length * Math.max(1, sceneNumber(lineHeight, 1)))),
      maxLineWidth: Math.max(0, sceneNumber(result && result.maxLineWidth, 0)),
      byteLen: Math.max(0, Math.min(byteLen, Math.floor(sceneNumber(result && result.byteLen, byteLen)))),
      runeCount: Math.max(0, Math.min(runeCount, Math.floor(sceneNumber(result && result.runeCount, runeCount)))),
      truncated: Boolean(result && result.truncated) || lines.some(function(line) { return line.truncated; }),
    };
  }

  function normalizeTextLayoutRangeResult(result, text, lineHeight) {
    const source = normalizeTextLayoutNewlines(text);
    const graphemes = Array.from(source);
    const runeCount = graphemes.length;
    const byteLen = graphemes.reduce(function(total, char) {
      return total + textLayoutCodePointByteLength(char.codePointAt(0));
    }, 0);
    const lines = Array.isArray(result && result.lines)
      ? result.lines.map(function(line, index) {
          return normalizeTextLayoutRange(line, index, byteLen, runeCount);
        })
      : [];

    return {
      lines,
      lineCount: Math.max(lines.length, Math.floor(sceneNumber(result && result.lineCount, lines.length))),
      height: Math.max(0, sceneNumber(result && result.height, lines.length * Math.max(1, sceneNumber(lineHeight, 1)))),
      maxLineWidth: Math.max(0, sceneNumber(result && result.maxLineWidth, 0)),
      byteLen: Math.max(0, Math.min(byteLen, Math.floor(sceneNumber(result && result.byteLen, byteLen)))),
      runeCount: Math.max(0, Math.min(runeCount, Math.floor(sceneNumber(result && result.runeCount, runeCount)))),
      truncated: Boolean(result && result.truncated) || lines.some(function(line) { return line.truncated; }),
    };
  }

  function gosxTextLayout(text, font, maxWidth, whiteSpace, lineHeight, options) {
    const normalizedOptions = normalizeTextLayoutRunOptions(options);
    const cacheKey = textLayoutCacheKey(text, font, maxWidth, whiteSpace, lineHeight, normalizedOptions);
    if (textLayoutCache.has(cacheKey)) {
      return textLayoutCache.get(cacheKey);
    }

    const impl = currentTextLayoutImpl();
    let result = null;
    if (impl) {
      try {
        result = impl(text, font, maxWidth, whiteSpace, lineHeight, normalizedOptions);
      } catch (error) {
        console.error("[gosx] text layout implementation failed:", error);
      }
    }
    if (!result || !Array.isArray(result.lines)) {
      result = layoutBrowserText(text, font, maxWidth, whiteSpace, lineHeight, normalizedOptions);
    }
    result = normalizeTextLayoutResult(result, text, lineHeight);

    if (textLayoutCache.size >= textLayoutCacheLimit) {
      const oldest = textLayoutCache.keys().next();
      if (!oldest.done) {
        textLayoutCache.delete(oldest.value);
      }
    }
    textLayoutCache.set(cacheKey, result);
    return result;
  }

  function gosxTextLayoutMetrics(text, font, maxWidth, whiteSpace, lineHeight, options) {
    const normalizedOptions = normalizeTextLayoutRunOptions(options);
    const cacheKey = textLayoutMetricsCacheKey(text, font, maxWidth, whiteSpace, lineHeight, normalizedOptions);
    if (textLayoutMetricsCache.has(cacheKey)) {
      return textLayoutMetricsCache.get(cacheKey);
    }

    let result = null;
    if (typeof textLayoutMetricsExternalImpl === "function") {
      try {
        result = textLayoutMetricsExternalImpl(text, font, maxWidth, whiteSpace, lineHeight, normalizedOptions);
      } catch (error) {
        console.error("[gosx] text layout metrics implementation failed:", error);
      }
    }
    if (!result || typeof result !== "object") {
      const ranges = gosxTextLayoutRanges(text, font, maxWidth, whiteSpace, lineHeight, normalizedOptions);
      result = {
        lineCount: ranges.lineCount,
        height: ranges.height,
        maxLineWidth: ranges.maxLineWidth,
        byteLen: ranges.byteLen,
        runeCount: ranges.runeCount,
        truncated: ranges.truncated,
      };
    } else {
      const normalized = normalizeTextLayoutResult({
        lineCount: result.lineCount,
        height: result.height,
        maxLineWidth: result.maxLineWidth,
        byteLen: result.byteLen,
        runeCount: result.runeCount,
        truncated: result.truncated,
        lines: [],
      }, text, lineHeight);
      result = {
        lineCount: normalized.lineCount,
        height: normalized.height,
        maxLineWidth: normalized.maxLineWidth,
        byteLen: normalized.byteLen,
        runeCount: normalized.runeCount,
        truncated: normalized.truncated,
      };
    }

    if (textLayoutMetricsCache.size >= textLayoutMetricsCacheLimit) {
      const oldest = textLayoutMetricsCache.keys().next();
      if (!oldest.done) {
        textLayoutMetricsCache.delete(oldest.value);
      }
    }
    textLayoutMetricsCache.set(cacheKey, result);
    return result;
  }

  function gosxTextLayoutRanges(text, font, maxWidth, whiteSpace, lineHeight, options) {
    const normalizedOptions = normalizeTextLayoutRunOptions(options);
    const cacheKey = textLayoutRangesCacheKey(text, font, maxWidth, whiteSpace, lineHeight, normalizedOptions);
    if (textLayoutRangesCache.has(cacheKey)) {
      return textLayoutRangesCache.get(cacheKey);
    }

    let result = null;
    if (typeof textLayoutRangesExternalImpl === "function") {
      try {
        result = textLayoutRangesExternalImpl(text, font, maxWidth, whiteSpace, lineHeight, normalizedOptions);
      } catch (error) {
        console.error("[gosx] text layout ranges implementation failed:", error);
      }
    }
    if (!result || !Array.isArray(result.lines)) {
      result = layoutBrowserTextRanges(text, font, maxWidth, whiteSpace, lineHeight, normalizedOptions);
    }
    result = normalizeTextLayoutRangeResult(result, text, lineHeight);

    if (textLayoutRangesCache.size >= textLayoutRangesCacheLimit) {
      const oldest = textLayoutRangesCache.keys().next();
      if (!oldest.done) {
        textLayoutRangesCache.delete(oldest.value);
      }
    }
    textLayoutRangesCache.set(cacheKey, result);
    return result;
  }

  window.__gosx_text_layout = gosxTextLayout;
  window.__gosx_text_layout_metrics = gosxTextLayoutMetrics;
  window.__gosx_text_layout_ranges = gosxTextLayoutRanges;
  installTextLayoutFontObserver();
  installTextLayoutSurfaceStyles();

  function textLayoutNumberValue(value, fallback) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
  }

  function textLayoutLengthValue(value, fallback) {
    if (typeof value === "number" && Number.isFinite(value)) {
      return value;
    }
    if (typeof value === "string") {
      const trimmed = value.trim().toLowerCase();
      if (!trimmed || trimmed === "none" || trimmed === "auto" || trimmed === "normal" || trimmed === "unset") {
        return fallback;
      }
      const parsed = Number.parseFloat(trimmed);
      return Number.isFinite(parsed) ? parsed : fallback;
    }
    return textLayoutNumberValue(value, fallback);
  }

  function textLayoutComputedStyle(element) {
    if (!element || typeof window.getComputedStyle !== "function") {
      return null;
    }
    try {
      return window.getComputedStyle(element);
    } catch (_error) {
      return null;
    }
  }

  function textLayoutComputedStyleValue(style, propertyName) {
    if (!style || !propertyName) {
      return "";
    }
    if (typeof style.getPropertyValue === "function") {
      const propertyValue = style.getPropertyValue(propertyName);
      if (typeof propertyValue === "string" && propertyValue.trim() !== "") {
        return propertyValue.trim();
      }
    }
    const camelName = propertyName.replace(/-([a-z])/g, function(_match, letter) {
      return String(letter || "").toUpperCase();
    });
    const value = style[camelName];
    return typeof value === "string" ? value.trim() : "";
  }

  function textLayoutComputedLineHeight(style, fallback) {
    const explicit = textLayoutLengthValue(
      textLayoutComputedStyleValue(style, "--gosx-text-layout-line-height")
      || textLayoutComputedStyleValue(style, "line-height"),
      NaN
    );
    if (Number.isFinite(explicit) && explicit > 0) {
      return explicit;
    }
    const fontSize = textLayoutLengthValue(textLayoutComputedStyleValue(style, "font-size"), fallback);
    return Math.max(1, fontSize * 1.35);
  }

  function textLayoutLogicalInlineSize(width, height, writingMode) {
    return textLayoutIsVerticalWritingMode(writingMode) ? Math.max(0, sceneNumber(height, 0)) : Math.max(0, sceneNumber(width, 0));
  }

  function textLayoutLogicalBlockSize(width, height, writingMode) {
    return textLayoutIsVerticalWritingMode(writingMode) ? Math.max(0, sceneNumber(width, 0)) : Math.max(0, sceneNumber(height, 0));
  }

  function textLayoutComputedMaxLines(style) {
    return Math.max(0, Math.floor(textLayoutLengthValue(
      textLayoutComputedStyleValue(style, "--gosx-text-layout-max-lines")
      || textLayoutComputedStyleValue(style, "-webkit-line-clamp")
      || textLayoutComputedStyleValue(style, "line-clamp"),
      0
    )));
  }

  function setStyleValue(style, name, value) {
    if (!style || typeof name !== "string") {
      return;
    }
    const next = String(value);
    if (typeof style.setProperty === "function") {
      if (typeof style.getPropertyValue === "function" && style.getPropertyValue(name) === next) {
        return;
      }
      style.setProperty(name, next);
      return;
    }
    if (style[name] === next) {
      return;
    }
    style[name] = next;
  }

  function clearStyleValue(style, name) {
    if (!style || typeof name !== "string") {
      return;
    }
    if (typeof style.removeProperty === "function") {
      if (typeof style.getPropertyValue === "function" && !style.getPropertyValue(name)) {
        return;
      }
      style.removeProperty(name);
      return;
    }
    if (style[name] == null || style[name] === "") {
      return;
    }
    delete style[name];
  }

  function setAttrValue(element, name, value) {
    if (!element || typeof element.setAttribute !== "function" || typeof name !== "string" || !name) {
      return;
    }
    if (value == null || value === "") {
      if (typeof element.removeAttribute === "function") {
        if (!element.hasAttribute || !element.hasAttribute(name)) {
          return;
        }
        element.removeAttribute(name);
      }
      return;
    }
    const next = String(value);
    if (typeof element.getAttribute === "function" && element.getAttribute(name) === next) {
      return;
    }
    element.setAttribute(name, next);
  }

  function installTextLayoutSurfaceStyles() {
    if (!document || !document.head || typeof document.createElement !== "function") {
      return;
    }
    const headChildren = document.head.children || document.head.childNodes || [];
    for (const child of headChildren) {
      if (hasAttributeName(child, TEXT_LAYOUT_STYLE_ATTR)) {
        return;
      }
    }

    const style = document.createElement("style");
    style.setAttribute(TEXT_LAYOUT_STYLE_ATTR, "true");
    style.setAttribute("data-gosx-css-layer", "runtime");
    style.setAttribute("data-gosx-css-owner", "gosx-bootstrap");
    style.setAttribute("data-gosx-css-source", "gosx-runtime");
    style.textContent = [
      '[data-gosx-scene3d-mounted="true"] {',
      '  position: relative;',
      '  max-inline-size: 100%;',
      '  contain: layout paint style;',
      '}',
      '[data-gosx-scene3d-mounted="true"][data-gosx-scene3d-active="true"] {',
      '  --gosx-scene-active: 1;',
      '}',
      '[data-gosx-scene3d-mounted="true"][data-gosx-scene3d-active="false"] {',
      '  --gosx-scene-active: 0;',
      '}',
      '[data-gosx-scene3d-mounted="true"][data-gosx-scene3d-reduced-motion="true"] {',
      '  --gosx-scene-reduced-motion: 1;',
      '}',
      '[data-gosx-scene3d-canvas="true"] {',
      '  display: block;',
      '  inline-size: 100%;',
      '  block-size: auto;',
      '  max-inline-size: 100%;',
      '  border-radius: inherit;',
      '}',
      '[data-gosx-text-layout-role="block"] {',
      '  box-sizing: border-box;',
      '  min-block-size: var(--gosx-text-layout-height, auto);',
      '  white-space: var(--gosx-text-layout-white-space-mode, normal);',
      '  text-align: var(--gosx-text-layout-align, start);',
      '}',
      '[data-gosx-text-layout-role="block"][data-gosx-text-layout-max-width] {',
      '  max-inline-size: min(100%, var(--gosx-text-layout-max-width, 100%));',
      '}',
      '[data-gosx-text-layout-role="block"][data-gosx-text-layout-state="hint"] {',
      '  min-block-size: var(--gosx-text-layout-height-hint, var(--gosx-text-layout-height, auto));',
      '}',
      '[data-gosx-text-layout-role="block"][data-gosx-text-layout-state="truncated"] {',
      '  --gosx-text-layout-is-truncated: 1;',
      '}',
      '[data-gosx-text-layout-role="block"][data-gosx-text-layout-max-lines] {',
      '  overflow: hidden;',
      '}',
      '[data-gosx-text-layout-role="block"][data-gosx-text-layout-max-lines][data-gosx-text-layout-overflow="clip"] {',
      '  max-block-size: var(--gosx-text-layout-max-height, none);',
      '}',
      '[data-gosx-text-layout-role="block"][data-gosx-text-layout-max-lines][data-gosx-text-layout-overflow="ellipsis"] {',
      '  display: -webkit-box;',
      '  -webkit-box-orient: vertical;',
      '  -webkit-line-clamp: var(--gosx-text-layout-max-lines);',
      '}',
      '[data-gosx-scene3d-label-layer="true"] {',
      '  position: absolute;',
      '  inset: 0;',
      '  pointer-events: none;',
      '  overflow: hidden;',
      '  border-radius: inherit;',
      '}',
      '[data-gosx-scene-label] {',
      '  position: absolute;',
      '  box-sizing: border-box;',
      '  pointer-events: none;',
      '  left: var(--gosx-scene-label-left, 0px);',
      '  top: var(--gosx-scene-label-top, 0px);',
      '  width: var(--gosx-scene-label-width, auto);',
      '  max-width: var(--gosx-scene-label-max-width, none);',
      '  min-block-size: var(--gosx-scene-label-height, auto);',
      '  padding: 8px 10px;',
      '  border-radius: var(--gosx-scene-label-radius, 12px);',
      '  border: 1px solid var(--gosx-scene-label-border-color, var(--color-scene-line, rgba(141, 225, 255, 0.24)));',
      '  background: var(--gosx-scene-label-background, var(--color-scene-surface-glass-strong, rgba(8, 21, 31, 0.82)));',
      '  color: var(--gosx-scene-label-color, var(--color-ink-inverse, #ecf7ff));',
      '  font: var(--gosx-scene-label-font, 600 13px "IBM Plex Sans", "Segoe UI", sans-serif);',
      '  line-height: var(--gosx-scene-label-line-height, 18px);',
      '  text-align: var(--gosx-scene-label-align, center);',
      '  box-shadow: 0 14px 32px var(--gosx-scene-label-shadow, rgba(3, 10, 16, 0.28));',
      '  backdrop-filter: blur(var(--gosx-scene-label-blur, 10px));',
      '  -webkit-backdrop-filter: blur(var(--gosx-scene-label-blur, 10px));',
      '  will-change: left, top, transform;',
      '  z-index: var(--gosx-scene-label-z-index, 1);',
      '  opacity: var(--gosx-scene-label-opacity, 1);',
      '  transform: translate(calc(var(--gosx-scene-label-anchor-x, 0.5) * -100%), calc(var(--gosx-scene-label-anchor-y, 1) * -100%));',
      '  transition:',
      '    opacity var(--motion-fast, 180ms) var(--ease-out, cubic-bezier(0.16, 1, 0.3, 1)),',
      '    transform var(--motion-fast, 180ms) var(--ease-out, cubic-bezier(0.16, 1, 0.3, 1));',
      '}',
      '[data-gosx-scene-label][data-gosx-scene-label-visibility="hidden"] {',
      '  opacity: 0;',
      '  visibility: hidden;',
      '}',
      '[data-gosx-scene-label][data-gosx-scene-label-occluded="true"] {',
      '  --gosx-scene-label-opacity: 0.52;',
      '}',
      '[data-gosx-scene3d-mounted="true"][data-gosx-scene3d-active="false"] [data-gosx-scene-label] {',
      '  transition: none;',
      '}',
      '[data-gosx-scene3d-mounted="true"][data-gosx-scene3d-reduced-motion="true"] [data-gosx-scene-label] {',
      '  transition: none;',
      '}',
      '[data-gosx-scene-label-line] {',
      '  display: block;',
      '  white-space: var(--gosx-scene-label-white-space, normal);',
      '}',
      '[data-gosx-scene-sprite] {',
      '  position: absolute;',
      '  left: var(--gosx-scene-sprite-left, 0px);',
      '  top: var(--gosx-scene-sprite-top, 0px);',
      '  width: var(--gosx-scene-sprite-width, 1px);',
      '  height: var(--gosx-scene-sprite-height, 1px);',
      '  pointer-events: none;',
      '  opacity: var(--gosx-scene-sprite-opacity, 1);',
      '  z-index: var(--gosx-scene-sprite-z-index, 1);',
      '  transform: translate(calc(var(--gosx-scene-sprite-anchor-x, 0.5) * -100%), calc(var(--gosx-scene-sprite-anchor-y, 0.5) * -100%));',
      '  will-change: left, top, transform, opacity;',
      '  transition:',
      '    opacity var(--motion-fast, 180ms) var(--ease-out, cubic-bezier(0.16, 1, 0.3, 1)),',
      '    transform var(--motion-fast, 180ms) var(--ease-out, cubic-bezier(0.16, 1, 0.3, 1));',
      '}',
      '[data-gosx-scene-sprite][data-gosx-scene-sprite-visibility="hidden"] {',
      '  opacity: 0;',
      '  visibility: hidden;',
      '}',
      '[data-gosx-scene-sprite][data-gosx-scene-sprite-occluded="true"] {',
      '  --gosx-scene-sprite-opacity: 0.42;',
      '}',
      '[data-gosx-scene-sprite] > img {',
      '  display: block;',
      '  inline-size: 100%;',
      '  block-size: 100%;',
      '  object-fit: var(--gosx-scene-sprite-fit, contain);',
      '  user-select: none;',
      '  -webkit-user-drag: none;',
      '  filter: drop-shadow(0 14px 32px rgba(3, 10, 16, 0.28));',
      '}',
      '[data-gosx-scene-html] {',
      '  position: absolute;',
      '  left: var(--gosx-scene-html-left, 0px);',
      '  top: var(--gosx-scene-html-top, 0px);',
      '  width: var(--gosx-scene-html-width, auto);',
      '  min-block-size: var(--gosx-scene-html-min-height, auto);',
      '  box-sizing: border-box;',
      '  contain: layout paint;',
      '  pointer-events: var(--gosx-scene-html-pointer-events, none);',
      '  opacity: var(--gosx-scene-html-opacity, 1);',
      '  z-index: var(--gosx-scene-html-z-index, 1);',
      '  transform: translate(calc(var(--gosx-scene-html-anchor-x, 0.5) * -100%), calc(var(--gosx-scene-html-anchor-y, 0.5) * -100%));',
      '  will-change: left, top, transform, opacity;',
      '  transition:',
      '    opacity var(--motion-fast, 180ms) var(--ease-out, cubic-bezier(0.16, 1, 0.3, 1)),',
      '    transform var(--motion-fast, 180ms) var(--ease-out, cubic-bezier(0.16, 1, 0.3, 1));',
      '}',
      '[data-gosx-scene-html][data-gosx-scene-html-visibility="hidden"] {',
      '  opacity: 0;',
      '  visibility: hidden;',
      '}',
      '[data-gosx-scene-html][data-gosx-scene-html-occluded="true"] {',
      '  --gosx-scene-html-opacity: 0.42;',
      '}',
      '[data-gosx-scene3d-mounted="true"][data-gosx-scene3d-active="false"] [data-gosx-scene-sprite],',
      '[data-gosx-scene3d-mounted="true"][data-gosx-scene3d-reduced-motion="true"] [data-gosx-scene-sprite],',
      '[data-gosx-scene3d-mounted="true"][data-gosx-scene3d-active="false"] [data-gosx-scene-html],',
      '[data-gosx-scene3d-mounted="true"][data-gosx-scene3d-reduced-motion="true"] [data-gosx-scene-html] {',
      '  transition: none;',
      '}',
    ].join("\\n");
    document.head.appendChild(style);
  }

  function applyTextLayoutPresentation(element, config, result, meta) {
    if (!element) {
      return;
    }
    const options = meta && typeof meta === "object" ? meta : {};
    const role = typeof options.role === "string" && options.role ? options.role : "block";
    const surface = typeof options.surface === "string" && options.surface ? options.surface : "dom";
    const state = typeof options.state === "string" && options.state ? options.state : (result ? "ready" : "pending");
    const align = normalizeTextLayoutAlign(options.align || (config && config.align));
    const revision = Number.isFinite(options.revision) ? options.revision : gosxTextLayoutRevision();
    const font = config && typeof config.font === "string" ? config.font : "";
    const locale = normalizeTextLayoutLocale(config && config.locale);
    const direction = config && typeof config.direction === "string" ? String(config.direction).trim().toLowerCase() : "";
    const writingMode = normalizeTextLayoutWritingMode(config && config.writingMode);
    const whiteSpace = normalizeTextLayoutWhiteSpace(config && config.whiteSpace);
    const lineHeight = Math.max(1, textLayoutNumberValue(config && config.lineHeight, 16));
    const maxLines = Math.max(0, Math.floor(textLayoutNumberValue(config && config.maxLines, 0)));
    const overflow = normalizeTextLayoutOverflow(config && config.overflow);
    const maxWidth = textLayoutNumberValue(config && config.maxWidth, 0);
    const inlineSize = Math.max(0, textLayoutNumberValue(config && config.inlineSize, 0));
    const blockSize = Math.max(0, textLayoutNumberValue(config && config.blockSize, 0));
    const ready = Boolean(result);
    const effectiveState = ready && result && result.truncated ? "truncated" : state;

    setAttrValue(element, TEXT_LAYOUT_ROLE_ATTR, role);
    setAttrValue(element, TEXT_LAYOUT_SURFACE_ATTR, surface);
    setAttrValue(element, TEXT_LAYOUT_STATE_ATTR, effectiveState);
    setAttrValue(element, "data-gosx-text-layout-ready", ready ? "true" : "false");
    setAttrValue(element, "data-gosx-text-layout-font", font);
    setAttrValue(element, "data-gosx-text-layout-locale", locale);
    setAttrValue(element, "data-gosx-text-layout-direction", direction);
    setAttrValue(element, "data-gosx-text-layout-writing-mode", writingMode);
    setAttrValue(element, "data-gosx-text-layout-white-space", whiteSpace === "normal" ? "" : whiteSpace);
    setAttrValue(element, "data-gosx-text-layout-align", align);
    setAttrValue(element, "data-gosx-text-layout-line-height", lineHeight > 0 ? lineHeight : "");
    setAttrValue(element, "data-gosx-text-layout-max-lines", maxLines > 0 ? maxLines : "");
    setAttrValue(element, "data-gosx-text-layout-overflow", maxLines > 0 ? overflow : "");
    setAttrValue(element, "data-gosx-text-layout-revision", revision);
    setAttrValue(element, "data-gosx-text-layout-inline-size", inlineSize > 0 ? inlineSize : "");
    setAttrValue(element, "data-gosx-text-layout-block-size", blockSize > 0 ? blockSize : "");

    setStyleValue(element.style, "--gosx-text-layout-ready", ready ? "1" : "0");
    setStyleValue(element.style, "--gosx-text-layout-line-height", lineHeight + "px");
    setStyleValue(element.style, "--gosx-text-layout-white-space-mode", whiteSpace);
    if (direction) {
      setStyleValue(element.style, "--gosx-text-layout-direction", direction);
    } else {
      clearStyleValue(element.style, "--gosx-text-layout-direction");
    }
    if (writingMode) {
      setStyleValue(element.style, "--gosx-text-layout-writing-mode", writingMode);
    } else {
      clearStyleValue(element.style, "--gosx-text-layout-writing-mode");
    }
    if (inlineSize > 0) {
      setStyleValue(element.style, "--gosx-text-layout-inline-size", inlineSize + "px");
    } else {
      clearStyleValue(element.style, "--gosx-text-layout-inline-size");
    }
    if (blockSize > 0) {
      setStyleValue(element.style, "--gosx-text-layout-block-size", blockSize + "px");
    } else {
      clearStyleValue(element.style, "--gosx-text-layout-block-size");
    }
    if (align) {
      setStyleValue(element.style, "--gosx-text-layout-align", align);
    } else {
      clearStyleValue(element.style, "--gosx-text-layout-align");
    }
    if (maxLines > 0) {
      setStyleValue(element.style, "--gosx-text-layout-max-lines", String(maxLines));
      setStyleValue(element.style, "--gosx-text-layout-max-height", (lineHeight * maxLines) + "px");
    } else {
      clearStyleValue(element.style, "--gosx-text-layout-max-lines");
      clearStyleValue(element.style, "--gosx-text-layout-max-height");
    }
    setStyleValue(element.style, "--gosx-text-layout-overflow", overflow);
    if (maxWidth > 0 && maxWidth < Number.MAX_SAFE_INTEGER) {
      setAttrValue(element, "data-gosx-text-layout-max-width", maxWidth);
      setAttrValue(element, "data-gosx-text-layout-max-inline-size", maxWidth);
      setStyleValue(element.style, "--gosx-text-layout-width", maxWidth + "px");
      setStyleValue(element.style, "--gosx-text-layout-max-width", maxWidth + "px");
      setStyleValue(element.style, "--gosx-text-layout-max-inline-size", maxWidth + "px");
    } else {
      setAttrValue(element, "data-gosx-text-layout-max-width", "");
      setAttrValue(element, "data-gosx-text-layout-max-inline-size", "");
      clearStyleValue(element.style, "--gosx-text-layout-width");
      clearStyleValue(element.style, "--gosx-text-layout-max-width");
      clearStyleValue(element.style, "--gosx-text-layout-max-inline-size");
    }

    if (!result || typeof result !== "object") {
      setAttrValue(element, "data-gosx-text-layout-truncated", "");
      clearStyleValue(element.style, "--gosx-text-layout-truncated");
      return;
    }

    setAttrValue(element, "data-gosx-text-layout-line-count", result.lineCount);
    setAttrValue(element, "data-gosx-text-layout-height", result.height);
    setAttrValue(element, "data-gosx-text-layout-max-line-width", result.maxLineWidth);
    setAttrValue(element, "data-gosx-text-layout-byte-length", result.byteLen);
    setAttrValue(element, "data-gosx-text-layout-rune-count", result.runeCount);
    setAttrValue(element, "data-gosx-text-layout-truncated", result.truncated ? "true" : "false");

    setStyleValue(element.style, "--gosx-text-layout-height", result.height + "px");
    setStyleValue(element.style, "--gosx-text-layout-line-count", String(result.lineCount));
    setStyleValue(element.style, "--gosx-text-layout-max-line-width", result.maxLineWidth + "px");
    setStyleValue(element.style, "--gosx-text-layout-byte-length", String(result.byteLen));
    setStyleValue(element.style, "--gosx-text-layout-rune-count", String(result.runeCount));
    setStyleValue(element.style, "--gosx-text-layout-truncated", result.truncated ? "1" : "0");
  }

  function textLayoutElementID(element) {
    if (!element || typeof element.getAttribute !== "function") {
      return "";
    }
    const existing = element.getAttribute(TEXT_LAYOUT_ID_ATTR);
    if (existing) {
      return existing;
    }
    const derived = element.id ? ("gosx-text-layout:" + element.id) : ("gosx-text-layout-" + (++nextManagedTextLayoutID));
    if (typeof element.setAttribute === "function") {
      element.setAttribute(TEXT_LAYOUT_ID_ATTR, derived);
    }
    return derived;
  }

  function walkElementTree(root, visit) {
    if (!root) {
      return;
    }
    if (root.nodeType === 1) {
      visit(root);
    }
    const children = root.children || root.childNodes || [];
    for (const child of children) {
      if (child && child.nodeType === 1) {
        walkElementTree(child, visit);
      }
    }
  }

  function collectManagedTextLayoutElements(root) {
    const elements = [];
    walkElementTree(root, function(element) {
      if (hasAttributeName(element, TEXT_LAYOUT_ATTR)) {
        elements.push(element);
      }
    });
    return elements;
  }

  function normalizeManagedTextLayoutConfig(element, options) {
    const config = options && typeof options === "object" ? options : {};
    const hasOwn = Object.prototype.hasOwnProperty;
    const presentation = window.__gosx.presentation && typeof window.__gosx.presentation.read === "function"
      ? window.__gosx.presentation.read(element)
      : null;
    const computed = presentation && presentation.style ? presentation.style : textLayoutComputedStyle(element);
    const locale = normalizeTextLayoutLocale(
      hasOwn.call(config, "locale")
        ? config.locale
        : (
          textLayoutComputedStyleValue(computed, "--gosx-text-layout-locale")
          || (presentation && presentation.lang)
          || (element.getAttribute && element.getAttribute("data-gosx-text-layout-locale"))
          || (element.getAttribute && element.getAttribute("lang"))
        )
    );
    const direction = (function() {
      const value = hasOwn.call(config, "direction")
        ? config.direction
        : (
          textLayoutComputedStyleValue(computed, "--gosx-text-layout-direction")
          || (presentation && presentation.direction)
          || textLayoutComputedStyleValue(computed, "direction")
          || (element.getAttribute && element.getAttribute("data-gosx-text-layout-direction"))
          || (element.getAttribute && element.getAttribute("dir"))
        );
      switch (String(value || "").trim().toLowerCase()) {
        case "ltr":
        case "rtl":
        case "auto":
          return String(value).trim().toLowerCase();
        default:
          return "";
      }
    })();
    const writingMode = normalizeTextLayoutWritingMode(
      hasOwn.call(config, "writingMode")
        ? config.writingMode
        : (
          textLayoutComputedStyleValue(computed, "--gosx-text-layout-writing-mode")
          || (presentation && presentation.writingMode)
          || textLayoutComputedStyleValue(computed, "writing-mode")
        )
    );
    const inlineSize = Math.max(0, textLayoutLengthValue(
      hasOwn.call(config, "inlineSize")
        ? config.inlineSize
        : (presentation && presentation.inlineSize),
      0
    ));
    const blockSize = Math.max(0, textLayoutLengthValue(
      hasOwn.call(config, "blockSize")
        ? config.blockSize
        : (presentation && presentation.blockSize),
      0
    ));
    const font = hasOwn.call(config, "font")
      ? String(config.font == null ? "" : config.font)
      : String(
        textLayoutComputedStyleValue(computed, "--gosx-text-layout-font")
        || textLayoutComputedStyleValue(computed, "font")
        || (element.getAttribute && element.getAttribute("data-gosx-text-layout-font"))
        || ""
      );
    const align = normalizeTextLayoutAlign(
      hasOwn.call(config, "align")
        ? config.align
        : (
          textLayoutComputedStyleValue(computed, "--gosx-text-layout-align")
          || (presentation && presentation.textAlign)
          || textLayoutComputedStyleValue(computed, "text-align")
          || (element.getAttribute && element.getAttribute("data-gosx-text-layout-align"))
          || (element.getAttribute && element.getAttribute("align"))
        )
    );
    const whiteSpace = normalizeTextLayoutWhiteSpace(
      hasOwn.call(config, "whiteSpace")
        ? config.whiteSpace
        : (
          textLayoutComputedStyleValue(computed, "--gosx-text-layout-white-space")
          || (presentation && presentation.whiteSpace)
          || textLayoutComputedStyleValue(computed, "white-space")
          || (element.getAttribute && element.getAttribute("data-gosx-text-layout-white-space"))
        )
    );
    const lineHeight = Math.max(1, textLayoutLengthValue(
      hasOwn.call(config, "lineHeight")
        ? config.lineHeight
        : (
          (presentation && presentation.lineHeight)
          || textLayoutComputedLineHeight(computed, NaN)
          || (element.getAttribute && element.getAttribute("data-gosx-text-layout-line-height"))
          || 16
        ),
      16
    ));
    const maxLines = Math.max(0, Math.floor(textLayoutNumberValue(
      hasOwn.call(config, "maxLines")
        ? config.maxLines
        : (
          textLayoutComputedMaxLines(computed)
          || (element.getAttribute && element.getAttribute("data-gosx-text-layout-max-lines"))
        ),
      0
    )));
    let maxWidth = textLayoutLengthValue(
      hasOwn.call(config, "maxWidth")
        ? config.maxWidth
        : (
          textLayoutComputedStyleValue(computed, "--gosx-text-layout-max-inline-size")
          || textLayoutComputedStyleValue(computed, "max-inline-size")
          || textLayoutComputedStyleValue(computed, "--gosx-text-layout-max-width")
          || (presentation && presentation.maxInlineSize)
          || (presentation && presentation.maxWidth)
          || textLayoutComputedStyleValue(computed, "max-width")
          || (element.getAttribute && element.getAttribute("data-gosx-text-layout-max-width"))
        ),
      0
    );
    if (!(maxWidth > 0) && presentation) {
      maxWidth = textLayoutNumberValue(presentation.inlineSize, 0);
    }
    if (!(maxWidth > 0) && inlineSize > 0) {
      maxWidth = inlineSize;
    }
    if (!(maxWidth > 0) && element && typeof element.getBoundingClientRect === "function") {
      const rect = element.getBoundingClientRect();
      maxWidth = textLayoutLogicalInlineSize(rect && rect.width, rect && rect.height, writingMode);
    }
    if (!(maxWidth > 0) && element) {
      maxWidth = textLayoutLogicalInlineSize(
        element.clientWidth || element.offsetWidth || element.width,
        element.clientHeight || element.offsetHeight || element.height,
        writingMode
      );
    }
    if (!(maxWidth > 0)) {
      maxWidth = Number.MAX_SAFE_INTEGER;
    }
    const observe = hasOwn.call(config, "observe")
      ? Boolean(config.observe)
      : String((element.getAttribute && element.getAttribute("data-gosx-text-layout-observe")) || "true").toLowerCase() !== "false";
    const sourceText = hasOwn.call(config, "text")
      ? String(config.text == null ? "" : config.text)
      : String((element.getAttribute && element.getAttribute("data-gosx-text-layout-source")) || element.textContent || "");

    return {
      font,
      whiteSpace,
      align,
      lineHeight,
      maxLines,
      locale,
      direction,
      writingMode,
      inlineSize,
      blockSize,
      overflow: normalizeTextLayoutOverflow(
        hasOwn.call(config, "overflow")
          ? config.overflow
          : (
            textLayoutComputedStyleValue(computed, "--gosx-text-layout-overflow")
            || (textLayoutComputedStyleValue(computed, "text-overflow") === "ellipsis" ? "ellipsis" : "")
            || (element.getAttribute && element.getAttribute("data-gosx-text-layout-overflow"))
          )
      ),
      maxWidth,
      observe,
      text: sourceText,
      heightHint: Math.max(0, textLayoutNumberValue(element.getAttribute && element.getAttribute("data-gosx-text-layout-height-hint"), 0)),
      lineCountHint: Math.max(0, Math.floor(textLayoutNumberValue(element.getAttribute && element.getAttribute("data-gosx-text-layout-line-count-hint"), 0))),
    };
  }

  function applyManagedTextLayoutHint(element, config) {
    if (!element) {
      return;
    }
    applyTextLayoutPresentation(element, config, null, {
      role: "block",
      surface: "dom",
      state: (config.heightHint > 0 || config.lineCountHint > 0) ? "hint" : "pending",
      revision: gosxTextLayoutRevision(),
    });
    if (config.heightHint > 0) {
      setStyleValue(element.style, "--gosx-text-layout-height-hint", config.heightHint + "px");
      setStyleValue(element.style, "--gosx-text-layout-height", config.heightHint + "px");
      setAttrValue(element, "data-gosx-text-layout-height-hint", config.heightHint);
    }
    if (config.lineCountHint > 0) {
      setStyleValue(element.style, "--gosx-text-layout-line-count-hint", String(config.lineCountHint));
      setStyleValue(element.style, "--gosx-text-layout-line-count", String(config.lineCountHint));
      setAttrValue(element, "data-gosx-text-layout-line-count-hint", config.lineCountHint);
    }
  }

  function dispatchManagedTextLayoutEvent(record, reason) {
    if (!record || typeof CustomEvent !== "function") {
      return;
    }
    const detail = {
      id: record.id,
      element: record.element,
      reason: reason || "refresh",
      revision: gosxTextLayoutRevision(),
      config: record.config,
      result: record.result,
    };
    const event = new CustomEvent("gosx:textlayout", { detail });
    if (record.element && typeof record.element.dispatchEvent === "function") {
      record.element.dispatchEvent(event);
    }
    if (typeof document.dispatchEvent === "function") {
      document.dispatchEvent(new CustomEvent("gosx:textlayout", { detail }));
    }
  }

  function applyManagedTextLayoutResult(record, config, result, reason) {
    const element = record.element;
    record.config = config;
    record.result = result;
    if (!element) {
      return result;
    }
    applyTextLayoutPresentation(element, config, result, {
      role: "block",
      surface: "dom",
      state: "ready",
      revision: gosxTextLayoutRevision(),
    });
    element.__gosxTextLayout = result;

    if (typeof record.onUpdate === "function") {
      try {
        record.onUpdate(result, config);
      } catch (error) {
        console.error("[gosx] text layout onUpdate failed:", error);
      }
    }

    window.__gosx.textLayouts.set(record.id, {
      element,
      config,
      result,
    });
    dispatchManagedTextLayoutEvent(record, reason);
    return result;
  }

  function refreshManagedTextLayoutRecord(record, reason) {
    if (!record || !record.element) {
      return null;
    }
    const config = normalizeManagedTextLayoutConfig(record.element, record.options);
    const layoutKey = [
      gosxTextLayoutRevision(),
      config.text,
      config.font,
      config.locale,
      config.direction,
      config.writingMode,
      config.align,
      config.whiteSpace,
      config.lineHeight,
      config.maxLines,
      config.overflow,
      config.maxWidth,
      config.inlineSize,
      config.blockSize,
    ].join("\n");
    if (layoutKey === record.layoutKey && record.result) {
      return record.result;
    }
    record.layoutKey = layoutKey;
    const result = gosxTextLayoutRanges(config.text, config.font, config.maxWidth, config.whiteSpace, config.lineHeight, {
      maxLines: config.maxLines,
      overflow: config.overflow,
    });
    return applyManagedTextLayoutResult(record, config, result, reason);
  }

  function disconnectManagedTextLayoutObservers(record) {
    if (!record) {
      return;
    }
    gosxCancelInvalidation(record);
    if (record.resizeObserver && typeof record.resizeObserver.disconnect === "function") {
      record.resizeObserver.disconnect();
      record.resizeObserver = null;
    }
    if (record.mutationObserver && typeof record.mutationObserver.disconnect === "function") {
      record.mutationObserver.disconnect();
      record.mutationObserver = null;
    }
    if (record.windowResizeListener && typeof window.removeEventListener === "function") {
      window.removeEventListener("resize", record.windowResizeListener);
      record.windowResizeListener = null;
    }
    if (typeof record.stopPresentation === "function") {
      record.stopPresentation();
      record.stopPresentation = null;
    }
    if (typeof record.stopInvalidation === "function") {
      record.stopInvalidation();
      record.stopInvalidation = null;
    }
  }

  function scheduleManagedTextLayoutRefresh(record, reason) {
    if (!record) {
      return;
    }
    gosxScheduleVisualInvalidation(record, reason || "textlayout", function(nextReason) {
      refreshManagedTextLayoutRecord(record, nextReason);
    });
  }

  function connectManagedTextLayoutMutationObserver(record) {
    if (!record || record.mutationObserver || typeof MutationObserver !== "function" || !record.element) {
      return;
    }
    record.mutationObserver = new MutationObserver(function(records) {
      for (const mutation of records || []) {
        const target = mutation && mutation.target;
        if (!target || target === record.element || mutation.type !== "attributes") {
          scheduleManagedTextLayoutRefresh(record, "mutation");
          return;
        }
      }
    });
    if (typeof record.mutationObserver.observe === "function") {
      record.mutationObserver.observe(record.element, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true,
        attributeFilter: MANAGED_TEXT_LAYOUT_MUTATION_ATTRS,
      });
    }
  }

  function disposeManagedTextLayout(target) {
    let record = null;
    if (typeof target === "string") {
      const current = window.__gosx.textLayouts.get(target);
      if (current && current.element) {
        record = textLayoutRecordsByElement.get(current.element) || null;
      }
    } else if (target) {
      record = textLayoutRecordsByElement.get(target) || null;
    }
    if (!record) {
      return;
    }
    disconnectManagedTextLayoutObservers(record);
    if (record.element) {
      textLayoutRecordsByElement.delete(record.element);
      record.element.__gosxTextLayout = null;
    }
    window.__gosx.textLayouts.delete(record.id);
  }

  function observeManagedTextLayout(element, options) {
    if (!element || typeof element !== "object") {
      return { refresh: function() { return null; }, dispose: function() {} };
    }

    const existing = textLayoutRecordsByElement.get(element);
    if (existing) {
      if (options && typeof options === "object") {
        disposeManagedTextLayout(element);
      } else {
        refreshManagedTextLayoutRecord(existing, "observe");
        return {
          id: existing.id,
          element: existing.element,
          refresh: function(reason) {
            return refreshManagedTextLayoutRecord(existing, reason || "manual");
          },
          read: function() {
            return existing.result;
          },
          dispose: function() {
            disposeManagedTextLayout(existing.element);
          },
        };
      }
    }

    const record = {
      id: textLayoutElementID(element),
      element,
      options: options && typeof options === "object" ? Object.assign({}, options) : {},
      result: null,
      config: null,
      layoutKey: "",
      onUpdate: options && typeof options.onUpdate === "function" ? options.onUpdate : null,
      resizeObserver: null,
      mutationObserver: null,
      windowResizeListener: null,
      stopInvalidation: null,
      stopPresentation: null,
    };

    textLayoutRecordsByElement.set(element, record);
    applyManagedTextLayoutHint(element, normalizeManagedTextLayoutConfig(element, record.options));
    refreshManagedTextLayoutRecord(record, "mount");

    if (record.config && record.config.observe) {
      record.stopInvalidation = onTextLayoutInvalidated(function() {
        scheduleManagedTextLayoutRefresh(record, "invalidate");
      });

      if (window.__gosx.presentation && typeof window.__gosx.presentation.observe === "function") {
        record.stopPresentation = window.__gosx.presentation.observe(element, function() {
          scheduleManagedTextLayoutRefresh(record, "presentation");
        }, { immediate: false });
      } else if (typeof ResizeObserver === "function") {
        record.resizeObserver = new ResizeObserver(function() {
          scheduleManagedTextLayoutRefresh(record, "resize");
        });
        if (typeof record.resizeObserver.observe === "function") {
          record.resizeObserver.observe(element);
        }
      } else if (typeof window.addEventListener === "function") {
        record.windowResizeListener = function() {
          scheduleManagedTextLayoutRefresh(record, "resize");
        };
        window.addEventListener("resize", record.windowResizeListener);
      }
      connectManagedTextLayoutMutationObserver(record);
    }

    return {
      id: record.id,
      element,
      refresh: function(reason) {
        return refreshManagedTextLayoutRecord(record, reason || "manual");
      },
      read: function() {
        return record.result;
      },
      dispose: function() {
        disposeManagedTextLayout(element);
      },
    };
  }

  function mountManagedTextLayouts(root) {
    const targetRoot = root || document.body || document.documentElement;
    const elements = collectManagedTextLayoutElements(targetRoot);
    for (const element of elements) {
      observeManagedTextLayout(element);
    }
  }

  function refreshManagedTextLayouts() {
    for (const snapshot of Array.from(window.__gosx.textLayouts.values())) {
      if (snapshot && snapshot.element) {
        const record = textLayoutRecordsByElement.get(snapshot.element);
        if (record) {
          refreshManagedTextLayoutRecord(record, "refresh");
        }
      }
    }
  }

  function disposeManagedTextLayouts() {
    for (const id of Array.from(window.__gosx.textLayouts.keys())) {
      disposeManagedTextLayout(id);
    }
  }

  window.__gosx.textLayout = {
    layout: gosxTextLayout,
    metrics: gosxTextLayoutMetrics,
    ranges: gosxTextLayoutRanges,
    revision: gosxTextLayoutRevision,
    observe: observeManagedTextLayout,
    mountAll: mountManagedTextLayouts,
    refresh(target) {
      if (target) {
        const handle = observeManagedTextLayout(target);
        return handle.refresh("manual");
      }
      refreshManagedTextLayouts();
      return null;
    },
    read(element) {
      const record = element ? textLayoutRecordsByElement.get(element) : null;
      if (record) {
        return record.result;
      }
      return element && element.__gosxTextLayout ? element.__gosxTextLayout : null;
    },
    dispose: disposeManagedTextLayout,
  };

  window.__gosx_runtime_api = {
    setAttrValue,
    setStyleValue,
    gosxSubscribeSharedSignal,
    setSharedSignalValue,
    gosxTextLayoutRevision,
    normalizeTextLayoutOverflow,
    layoutBrowserText,
    applyTextLayoutPresentation,
    onTextLayoutInvalidated,
  };

  const GOSX_TELEMETRY_ENDPOINT = "/_gosx/client-events";
  const GOSX_TELEMETRY_FLUSH_MS_DEFAULT = 2000;
  const GOSX_TELEMETRY_BATCH_MAX_DEFAULT = 20;
  const GOSX_TELEMETRY_QUEUE_MAX_DEFAULT = 200;
  const GOSX_TELEMETRY_LEVELS = { debug: 1, info: 1, warn: 1, error: 1 };

  function gosxTelemetryConfig() {
    const cfg = (typeof window !== "undefined" && window.__gosx_telemetry_config) || {};
    const rawFlushInterval = Number(cfg.flushInterval);
    return {
      endpoint: typeof cfg.endpoint === "string" && cfg.endpoint ? cfg.endpoint : GOSX_TELEMETRY_ENDPOINT,
      flushInterval: Math.max(0, Number.isFinite(rawFlushInterval) ? rawFlushInterval : GOSX_TELEMETRY_FLUSH_MS_DEFAULT),
      maxBatch: Math.max(1, Number(cfg.maxBatch) || GOSX_TELEMETRY_BATCH_MAX_DEFAULT),
      maxQueue: Math.max(1, Number(cfg.maxQueue) || GOSX_TELEMETRY_QUEUE_MAX_DEFAULT),
      enabled: cfg.enabled !== false,
    };
  }

  function gosxTelemetrySessionID() {
    const alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";
    let out = "s_";
    for (let i = 0; i < 10; i += 1) {
      out += alphabet[Math.floor(Math.random() * alphabet.length)];
    }
    return out;
  }

  function gosxTelemetryNormalizeLevel(level) {
    const key = String(level || "").toLowerCase();
    return GOSX_TELEMETRY_LEVELS[key] ? key : "info";
  }

  function gosxTelemetryCurrentURL() {
    try {
      if (typeof window !== "undefined" && window.location && window.location.pathname) {
        return String(window.location.pathname);
      }
    } catch (_err) {
      /* fall through */
    }
    return "";
  }

  function gosxTelemetryUserAgent() {
    try {
      if (typeof window !== "undefined" && window.navigator && typeof window.navigator.userAgent === "string") {
        return String(window.navigator.userAgent);
      }
    } catch (_err) {
      /* fall through */
    }
    return "";
  }

  function gosxInstallTelemetry() {
    if (typeof window === "undefined") {
      return;
    }
    if (window.__gosx_telemetry_installed) {
      return;
    }
    window.__gosx_telemetry_installed = true;

    const cfg = gosxTelemetryConfig();

    if (!cfg.enabled) {
      window.__gosx_emit = function () {};
      window.__gosx_telemetry_flush = function () {};
      return;
    }

    const sid = gosxTelemetrySessionID();
    const queue = [];
    let flushTimer = null;
    let uaSent = false;

    function emit(level, category, message, fields) {
      if (queue.length >= cfg.maxQueue) {
        return;
      }
      const event = {
        ts: Date.now(),
        lvl: gosxTelemetryNormalizeLevel(level),
        cat: typeof category === "string" && category ? category : "unknown",
        msg: typeof message === "string" ? message : String(message == null ? "" : message),
        url: gosxTelemetryCurrentURL(),
      };
      if (!uaSent) {
        event.ua = gosxTelemetryUserAgent();
        uaSent = true;
      }
      if (fields && typeof fields === "object") {
        event.fields = fields;
      }
      queue.push(event);
      scheduleFlush();
    }

    function scheduleFlush() {
      if (flushTimer != null || queue.length === 0) {
        return;
      }
      const delay = Math.max(0, cfg.flushInterval);
      flushTimer = setTimeout(function () {
        flushTimer = null;
        flushBatch(false);
      }, delay);
    }

    function clearFlushTimer() {
      if (flushTimer != null) {
        clearTimeout(flushTimer);
        flushTimer = null;
      }
    }

    function buildPayload(batch) {
      return JSON.stringify({
        sid: sid,
        sent_at: Date.now(),
        events: batch,
      });
    }

    function flushBatch(preferBeacon) {
      clearFlushTimer();
      if (queue.length === 0) {
        return;
      }
      const batch = queue.splice(0, cfg.maxBatch);
      const body = buildPayload(batch);

      if (preferBeacon) {
        try {
          const nav = window.navigator;
          if (nav && typeof nav.sendBeacon === "function") {
            if (nav.sendBeacon(cfg.endpoint, body)) {
              return;
            }
          }
        } catch (_err) {
          /* fall through to fetch */
        }
      }

      try {
        if (typeof window.fetch === "function") {
          const result = window.fetch(cfg.endpoint, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: body,
            keepalive: true,
            credentials: "omit",
          });
          if (result && typeof result.catch === "function") {
            result.catch(function () { /* swallow — telemetry must never surface to users */ });
          }
        }
      } catch (_err) {
        /* swallow */
      }

      if (queue.length > 0) {
        scheduleFlush();
      }
    }

    try {
      window.addEventListener("error", function (event) {
        emit("error", "runtime", (event && event.message) || "uncaught error", {
          filename: (event && event.filename) || "",
          lineno: (event && event.lineno) || 0,
          colno: (event && event.colno) || 0,
          stack: (event && event.error && event.error.stack) || "",
        });
      });
      window.addEventListener("unhandledrejection", function (event) {
        const reason = event && event.reason;
        const message = (reason && reason.message) || (typeof reason === "string" ? reason : "unhandledrejection");
        emit("error", "runtime", String(message), {
          stack: (reason && reason.stack) || "",
        });
      });
    } catch (_err) {
      /* older environments may not support addEventListener on window — skip */
    }

    try {
      if (typeof document !== "undefined" && typeof document.addEventListener === "function") {
        document.addEventListener("visibilitychange", function () {
          if (document.visibilityState === "hidden") {
            flushBatch(true);
          }
        });
      }
    } catch (_err) {
      /* skip */
    }

    window.__gosx_emit = emit;
    window.__gosx_telemetry_flush = function (opts) {
      flushBatch(Boolean(opts && opts.beacon));
    };
    window.__gosx_telemetry_session = function () {
      return sid;
    };
  }

  gosxInstallTelemetry();

  const gosxEnvironmentListeners = new Set();
  const gosxDocumentListeners = new Set();
  const gosxPresentationRecordsByElement = new Map();
  let gosxEnvironmentState = null;
  let gosxDocumentState = null;
  let gosxEnvironmentObserversInstalled = false;
  let gosxDocumentObserversInstalled = false;
  const GOSX_DOCUMENT_CSS_LAYERS = ["global", "layout", "page", "runtime"];
  const GOSX_DOCUMENT_ENHANCEMENT_LAYERS = ["html", "bootstrap", "runtime"];
  const gosxStateInvalidations = new Map();
  const gosxVisualInvalidations = new Map();
  let gosxStateInvalidationScheduled = false;
  let gosxVisualInvalidationScheduled = false;
  let gosxVisualInvalidationHandle = 0;
  const GOSX_MOTION_ATTR = "data-gosx-motion";
  const GOSX_MOTION_MUTATION_ATTRS = [
    GOSX_MOTION_ATTR,
    "data-gosx-motion-preset",
    "data-gosx-motion-trigger",
    "data-gosx-motion-duration",
    "data-gosx-motion-delay",
    "data-gosx-motion-easing",
    "data-gosx-motion-distance",
    "data-gosx-motion-respect-reduced",
  ];
  const gosxManagedMotionRecordsByElement = new Map();
  let gosxManagedMotionObserver = null;
  let gosxManagedMotionNextID = 0;
  let gosxPresentationResizeObserver = null;
  let gosxPresentationMutationObserver = null;
  let gosxPresentationStopEnvironment = null;
  let gosxPresentationStopDocument = null;
  const GOSX_PRESENTATION_MUTATION_ATTRS = ["class", "style", "dir", "lang", "hidden"];
  const gosxAppliedEnhancementKindAttrs = new Set();

  function gosxArrayFrom(listLike) {
    return Array.prototype.slice.call(listLike || []);
  }

  function gosxMergedReason(current, next) {
    const value = String(next || "").trim();
    if (!value) {
      return current || "";
    }
    if (!current) {
      return value;
    }
    const parts = current.split("|");
    if (parts.includes(value)) {
      return current;
    }
    parts.push(value);
    return parts.join("|");
  }

  function gosxScheduleStateInvalidation(key, reason, callback) {
    if (!key || typeof callback !== "function") {
      return;
    }
    const entry = gosxStateInvalidations.get(key) || { callback: null, reason: "" };
    entry.callback = callback;
    entry.reason = gosxMergedReason(entry.reason, reason || "state");
    gosxStateInvalidations.set(key, entry);
    if (gosxStateInvalidationScheduled) {
      return;
    }
    gosxStateInvalidationScheduled = true;
    const flush = function() {
      gosxStateInvalidationScheduled = false;
      const pending = Array.from(gosxStateInvalidations.values());
      gosxStateInvalidations.clear();
      for (const item of pending) {
        if (!item || typeof item.callback !== "function") {
          continue;
        }
        item.callback(item.reason || "state");
      }
    };
    if (typeof queueMicrotask === "function") {
      queueMicrotask(flush);
      return;
    }
    Promise.resolve().then(flush);
  }

  function gosxScheduleVisualInvalidation(key, reason, callback) {
    if (!key || typeof callback !== "function") {
      return;
    }
    const entry = gosxVisualInvalidations.get(key) || { callback: null, reason: "" };
    entry.callback = callback;
    entry.reason = gosxMergedReason(entry.reason, reason || "visual");
    gosxVisualInvalidations.set(key, entry);
    if (gosxVisualInvalidationScheduled) {
      return;
    }
    gosxVisualInvalidationScheduled = true;
    const flush = function(frameTime) {
      gosxVisualInvalidationScheduled = false;
      gosxVisualInvalidationHandle = 0;
      while (gosxVisualInvalidations.size > 0) {
        const pending = Array.from(gosxVisualInvalidations.values());
        gosxVisualInvalidations.clear();
        for (const item of pending) {
          if (!item || typeof item.callback !== "function") {
            continue;
          }
          item.callback(item.reason || "visual", frameTime);
        }
      }
    };
    if (typeof requestAnimationFrame === "function") {
      gosxVisualInvalidationHandle = requestAnimationFrame(flush);
      return;
    }
    gosxVisualInvalidationHandle = setTimeout(function() {
      flush(Date.now());
    }, 0);
  }

  function gosxCancelInvalidation(key) {
    if (!key) {
      return;
    }
    gosxStateInvalidations.delete(key);
    gosxVisualInvalidations.delete(key);
  }

  function gosxManagedMotionElements(root) {
    const elements = [];
    walkElementTree(root, function(element) {
      if (element && typeof element.hasAttribute === "function" && element.hasAttribute(GOSX_MOTION_ATTR)) {
        elements.push(element);
      }
    });
    return elements;
  }

  function gosxMotionStringAttr(element, name, fallback) {
    const value = element && typeof element.getAttribute === "function"
      ? String(element.getAttribute(name) || "").trim()
      : "";
    return value || fallback;
  }

  function gosxMotionBoolAttr(element, name, fallback) {
    const value = gosxMotionStringAttr(element, name, "");
    if (!value) {
      return fallback;
    }
    switch (value.toLowerCase()) {
      case "false":
      case "0":
      case "off":
      case "no":
        return false;
      default:
        return true;
    }
  }

  function normalizeGosxMotionPreset(value) {
    switch (String(value || "").trim().toLowerCase()) {
      case "slide-up":
      case "slide-down":
      case "slide-left":
      case "slide-right":
      case "zoom-in":
        return String(value).trim().toLowerCase();
      default:
        return "fade";
    }
  }

  function normalizeGosxMotionTrigger(value) {
    switch (String(value || "").trim().toLowerCase()) {
      case "view":
        return "view";
      default:
        return "load";
    }
  }

  function gosxManagedMotionConfig(element) {
    return {
      preset: normalizeGosxMotionPreset(gosxMotionStringAttr(element, "data-gosx-motion-preset", "fade")),
      trigger: normalizeGosxMotionTrigger(gosxMotionStringAttr(element, "data-gosx-motion-trigger", "load")),
      duration: Math.max(1, Math.round(gosxNumber(gosxMotionStringAttr(element, "data-gosx-motion-duration", 220), 220))),
      delay: Math.max(0, Math.round(gosxNumber(gosxMotionStringAttr(element, "data-gosx-motion-delay", 0), 0))),
      easing: gosxMotionStringAttr(element, "data-gosx-motion-easing", "cubic-bezier(0.16, 1, 0.3, 1)"),
      distance: Math.max(0, gosxNumber(gosxMotionStringAttr(element, "data-gosx-motion-distance", 18), 18)),
      respectReducedMotion: gosxMotionBoolAttr(element, "data-gosx-motion-respect-reduced", true),
    };
  }

  function gosxManagedMotionReduced(config) {
    if (!config || !config.respectReducedMotion) {
      return false;
    }
    const environment = gosxEnvironmentState || refreshGosxEnvironmentState("motion");
    return Boolean(environment && environment.reducedMotion);
  }

  function gosxManagedMotionKeyframes(config) {
    const distance = Math.max(0, gosxNumber(config && config.distance, 18));
    switch (config && config.preset) {
      case "slide-up":
        return [
          { opacity: 0, transform: "translate3d(0, " + distance + "px, 0)" },
          { opacity: 1, transform: "translate3d(0, 0, 0)" },
        ];
      case "slide-down":
        return [
          { opacity: 0, transform: "translate3d(0, -" + distance + "px, 0)" },
          { opacity: 1, transform: "translate3d(0, 0, 0)" },
        ];
      case "slide-left":
        return [
          { opacity: 0, transform: "translate3d(" + distance + "px, 0, 0)" },
          { opacity: 1, transform: "translate3d(0, 0, 0)" },
        ];
      case "slide-right":
        return [
          { opacity: 0, transform: "translate3d(-" + distance + "px, 0, 0)" },
          { opacity: 1, transform: "translate3d(0, 0, 0)" },
        ];
      case "zoom-in": {
        const scale = Math.max(0.72, 1 - (Math.min(distance, 64) / 200));
        return [
          { opacity: 0, transform: "scale(" + scale + ")" },
          { opacity: 1, transform: "scale(1)" },
        ];
      }
      default:
        return [
          { opacity: 0 },
          { opacity: 1 },
        ];
    }
  }

  function gosxManagedMotionState(record, state) {
    if (!record || !record.element) {
      return;
    }
    setAttrValue(record.element, "data-gosx-motion-state", state || "idle");
  }

  function cancelManagedMotionAnimation(record) {
    if (!record || !record.animation || typeof record.animation.cancel !== "function") {
      record.animation = null;
      return;
    }
    try {
      record.animation.cancel();
    } catch (_error) {
    }
    record.animation = null;
  }

  function playManagedMotion(record, reason) {
    if (!record || !record.element || record.played) {
      return;
    }
    record.config = gosxManagedMotionConfig(record.element);
    if (gosxManagedMotionReduced(record.config)) {
      record.played = true;
      gosxManagedMotionState(record, "reduced");
      return;
    }
    record.played = true;
    gosxManagedMotionState(record, "running");
    cancelManagedMotionAnimation(record);
    if (typeof record.element.animate !== "function") {
      gosxManagedMotionState(record, "finished");
      return;
    }
    const animation = record.element.animate(gosxManagedMotionKeyframes(record.config), {
      duration: record.config.duration,
      delay: record.config.delay,
      easing: record.config.easing,
      fill: "both",
    });
    record.animation = animation || null;
    if (animation && animation.finished && typeof animation.finished.then === "function") {
      animation.finished.then(function() {
        if (record.animation !== animation) {
          return;
        }
        record.animation = null;
        gosxManagedMotionState(record, "finished");
      }, function() {
        if (record.animation !== animation) {
          return;
        }
        record.animation = null;
        gosxManagedMotionState(record, "idle");
      });
      return;
    }
    gosxManagedMotionState(record, "finished");
  }

  function connectManagedMotion(record) {
    if (!record || !record.element) {
      return;
    }
    if (record.stopTrigger) {
      record.stopTrigger();
      record.stopTrigger = null;
    }
    if (record.config.trigger === "view" && typeof IntersectionObserver === "function") {
      const observer = new IntersectionObserver(function(entries) {
        for (const entry of entries || []) {
          if (!entry || entry.target !== record.element) {
            continue;
          }
          if (entry.isIntersecting !== false && gosxNumber(entry.intersectionRatio, 1) > 0) {
            playManagedMotion(record, "view");
          }
        }
      }, { threshold: [0, 0.01, 0.2] });
      observer.observe(record.element);
      record.stopTrigger = function() {
        observer.disconnect();
      };
      return;
    }
    gosxScheduleVisualInvalidation(record.key, "motion-load", function(nextReason) {
      playManagedMotion(record, nextReason || "load");
    });
  }

  function observeManagedMotion(element) {
    if (!element) {
      return null;
    }
    let record = gosxManagedMotionRecordsByElement.get(element);
    if (record) {
      record.config = gosxManagedMotionConfig(element);
      if (!record.played) {
        connectManagedMotion(record);
      }
      return record;
    }
    gosxManagedMotionNextID += 1;
    record = {
      key: "motion:" + gosxManagedMotionNextID,
      element: element,
      config: gosxManagedMotionConfig(element),
      played: false,
      animation: null,
      stopTrigger: null,
    };
    gosxManagedMotionRecordsByElement.set(element, record);
    gosxManagedMotionState(record, "idle");
    connectManagedMotion(record);
    return record;
  }

  function disposeManagedMotionElement(element) {
    const record = element ? gosxManagedMotionRecordsByElement.get(element) : null;
    if (!record) {
      return;
    }
    gosxCancelInvalidation(record.key);
    if (record.stopTrigger) {
      record.stopTrigger();
      record.stopTrigger = null;
    }
    cancelManagedMotionAnimation(record);
    gosxManagedMotionRecordsByElement.delete(element);
  }

  function installManagedMotionObserver(root) {
    if (gosxManagedMotionObserver || typeof MutationObserver !== "function" || !root) {
      return;
    }
    gosxManagedMotionObserver = new MutationObserver(function(records) {
      for (const record of records || []) {
        if (!record) {
          continue;
        }
        if (record.type === "attributes" && record.target && record.attributeName && GOSX_MOTION_MUTATION_ATTRS.includes(record.attributeName)) {
          if (record.target.hasAttribute && record.target.hasAttribute(GOSX_MOTION_ATTR)) {
            observeManagedMotion(record.target);
          } else {
            disposeManagedMotionElement(record.target);
          }
        }
        for (const node of gosxArrayFrom(record.addedNodes)) {
          if (node && node.nodeType === 1) {
            mountManagedMotion(node);
          }
        }
        for (const node of gosxArrayFrom(record.removedNodes)) {
          if (!node || node.nodeType !== 1) {
            continue;
          }
          for (const element of gosxManagedMotionElements(node)) {
            disposeManagedMotionElement(element);
          }
        }
      }
    });
    gosxManagedMotionObserver.observe(root, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: GOSX_MOTION_MUTATION_ATTRS,
    });
  }

  function mountManagedMotion(root) {
    const targetRoot = root || document.body || document.documentElement;
    for (const element of gosxManagedMotionElements(targetRoot)) {
      observeManagedMotion(element);
    }
    installManagedMotionObserver(document.body || document.documentElement);
  }

  function disposeManagedMotion() {
    if (gosxManagedMotionObserver) {
      gosxManagedMotionObserver.disconnect();
      gosxManagedMotionObserver = null;
    }
    for (const element of Array.from(gosxManagedMotionRecordsByElement.keys())) {
      disposeManagedMotionElement(element);
    }
  }

  window.__gosx.motion = {
    mountAll: mountManagedMotion,
    observe: observeManagedMotion,
    dispose: disposeManagedMotionElement,
  };

  function gosxMediaQueryList(query) {
    if (!query || typeof window.matchMedia !== "function") {
      return null;
    }
    try {
      return window.matchMedia(query);
    } catch (_error) {
      return null;
    }
  }

  function gosxMediaQueryMatches(query) {
    const media = gosxMediaQueryList(query);
    return Boolean(media && media.matches);
  }

  function gosxNavigatorConnection() {
    const navigatorRef = window && window.navigator ? window.navigator : null;
    if (!navigatorRef || typeof navigatorRef !== "object") {
      return null;
    }
    return navigatorRef.connection || navigatorRef.mozConnection || navigatorRef.webkitConnection || null;
  }

  function gosxNumber(value, fallback) {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
  }

  const gosxAudioState = {
    clips: new Map(),
    buses: new Map([["master", { id: "master", volume: 1, muted: false }]]),
    handles: new Map(),
    nextHandle: 0,
    context: null,
  };

  function gosxAudioClamp01(value, fallback) {
    return Math.max(0, Math.min(1, gosxNumber(value, fallback)));
  }

  function gosxAudioContextConstructor() {
    return (window && (window.AudioContext || window.webkitAudioContext)) || null;
  }

  function gosxAudioEnsureContext() {
    const Ctor = gosxAudioContextConstructor();
    if (!Ctor) {
      return null;
    }
    if (!gosxAudioState.context) {
      try {
        gosxAudioState.context = new Ctor();
      } catch (_error) {
        gosxAudioState.context = null;
      }
    }
    return gosxAudioState.context;
  }

  function gosxAudioNormalizeBus(raw) {
    const item = raw && typeof raw === "object" ? raw : {};
    const id = String(item.id || "").trim();
    if (!id) {
      return null;
    }
    return {
      id,
      parent: String(item.parent || "").trim(),
      volume: gosxAudioClamp01(item.volume, 1),
      muted: Boolean(item.muted),
    };
  }

  function gosxAudioNormalizeClip(raw, index) {
    const item = raw && typeof raw === "object" ? raw : {};
    const id = String(item.id || item.name || ("clip-" + index)).trim();
    const src = String(item.uri || item.src || item.url || "").trim();
    if (!id || !src) {
      return null;
    }
    return {
      id,
      src,
      contentType: String(item.contentType || item.type || "").trim(),
      bus: String(item.bus || "master").trim() || "master",
      preload: Boolean(item.preload),
      loop: Boolean(item.loop),
      volume: gosxAudioClamp01(item.volume, 1),
      rate: Math.max(0.05, gosxNumber(item.rate, 1)),
      metadata: item.metadata && typeof item.metadata === "object" ? Object.assign({}, item.metadata) : {},
      _bufferPromise: null,
    };
  }

  function gosxAudioRegisterBus(raw) {
    const bus = gosxAudioNormalizeBus(raw);
    if (!bus) {
      return null;
    }
    gosxAudioState.buses.set(bus.id, bus);
    return bus;
  }

  function gosxAudioRegisterClip(raw, index) {
    const clip = gosxAudioNormalizeClip(raw, index || 0);
    if (!clip) {
      return null;
    }
    const previous = gosxAudioState.clips.get(clip.id);
    if (previous && previous._bufferPromise && previous.src === clip.src) {
      clip._bufferPromise = previous._bufferPromise;
    }
    gosxAudioState.clips.set(clip.id, clip);
    return clip;
  }

  function gosxAudioRegisterManifest(manifest) {
    const raw = manifest && typeof manifest === "object" ? manifest : {};
    if (Array.isArray(raw.buses)) {
      raw.buses.forEach(gosxAudioRegisterBus);
    }
    if (Object.prototype.hasOwnProperty.call(raw, "masterVolume")) {
      gosxAudioRegisterBus({ id: "master", volume: raw.masterVolume, muted: Boolean(raw.muted) });
    }
    if (Array.isArray(raw.clips)) {
      raw.clips.forEach(gosxAudioRegisterClip);
    }
    return gosxAudioSnapshot();
  }

  function gosxAudioResolveClip(idOrSrc, options) {
    if (idOrSrc && typeof idOrSrc === "object") {
      return gosxAudioRegisterClip(idOrSrc, gosxAudioState.clips.size);
    }
    const key = String(idOrSrc || "").trim();
    if (!key) {
      return null;
    }
    if (gosxAudioState.clips.has(key)) {
      return gosxAudioState.clips.get(key);
    }
    return gosxAudioRegisterClip(Object.assign({}, options || {}, { id: key, src: key }), gosxAudioState.clips.size);
  }

  function gosxAudioBusVolume(busID) {
    const bus = gosxAudioState.buses.get(String(busID || "master").trim() || "master") || gosxAudioState.buses.get("master");
    const master = gosxAudioState.buses.get("master") || { volume: 1, muted: false };
    if ((bus && bus.muted) || master.muted) {
      return 0;
    }
    const busVolume = bus ? gosxAudioClamp01(bus.volume, 1) : 1;
    return busVolume * gosxAudioClamp01(master.volume, 1);
  }

  function gosxAudioPlaybackVolume(clip, options) {
    const opts = options && typeof options === "object" ? options : {};
    const clipVolume = gosxAudioClamp01(clip && clip.volume, 1);
    const requested = Object.prototype.hasOwnProperty.call(opts, "volume") ? gosxAudioClamp01(opts.volume, 1) : 1;
    return clipVolume * requested * gosxAudioBusVolume(opts.bus || (clip && clip.bus) || "master");
  }

  function gosxAudioVector3(raw) {
    if (Array.isArray(raw)) {
      return {
        x: gosxNumber(raw[0], 0),
        y: gosxNumber(raw[1], 0),
        z: gosxNumber(raw[2], 0),
      };
    }
    if (raw && typeof raw === "object") {
      return {
        x: gosxNumber(raw.x, 0),
        y: gosxNumber(raw.y, 0),
        z: gosxNumber(raw.z, 0),
      };
    }
    return null;
  }

  function gosxAudioSetParam(param, value) {
    if (param && typeof param.setValueAtTime === "function") {
      param.setValueAtTime(value, 0);
      return;
    }
    if (param && Object.prototype.hasOwnProperty.call(param, "value")) {
      param.value = value;
    }
  }

  function gosxAudioApplyPannerPosition(panner, position) {
    if (!panner || !position) {
      return;
    }
    if (typeof panner.setPosition === "function") {
      panner.setPosition(position.x, position.y, position.z);
      return;
    }
    gosxAudioSetParam(panner.positionX, position.x);
    gosxAudioSetParam(panner.positionY, position.y);
    gosxAudioSetParam(panner.positionZ, position.z);
  }

  function gosxAudioCreateSpatialPanner(audioContext, options) {
    const position = gosxAudioVector3(options && options.position);
    if (!position || !audioContext || typeof audioContext.createPanner !== "function") {
      return null;
    }
    const panner = audioContext.createPanner();
    if (!panner) {
      return null;
    }
    panner.panningModel = String(options.panningModel || "HRTF");
    panner.distanceModel = String(options.distanceModel || "inverse");
    panner.refDistance = Math.max(0.001, gosxNumber(options.refDistance, 1));
    panner.maxDistance = Math.max(panner.refDistance, gosxNumber(options.maxDistance, 10000));
    panner.rolloffFactor = Math.max(0, gosxNumber(options.rolloffFactor, 1));
    gosxAudioApplyPannerPosition(panner, position);
    return panner;
  }

  function gosxAudioLoadBuffer(clip) {
    if (!clip) {
      return Promise.resolve(null);
    }
    const audioContext = gosxAudioEnsureContext();
    if (!audioContext || typeof fetch !== "function" || typeof audioContext.decodeAudioData !== "function") {
      return Promise.resolve(null);
    }
    if (!clip._bufferPromise) {
      clip._bufferPromise = fetch(clip.src)
        .then(function(response) {
          if (!response || !response.ok) {
            throw new Error("audio fetch failed: " + clip.src);
          }
          return response.arrayBuffer();
        })
        .then(function(data) {
          return audioContext.decodeAudioData(data);
        });
    }
    return clip._bufferPromise;
  }

  function gosxAudioPreload(idOrSrc, options) {
    const clip = gosxAudioResolveClip(idOrSrc, options);
    return gosxAudioLoadBuffer(clip).then(function() {
      return clip;
    });
  }

  function gosxAudioPlayWebAudio(audioContext, clip, options, handleID) {
    return gosxAudioLoadBuffer(clip).then(function(buffer) {
      if (!buffer || !audioContext || typeof audioContext.createBufferSource !== "function") {
        return null;
      }
      const source = audioContext.createBufferSource();
      source.buffer = buffer;
      source.loop = Boolean((options && options.loop) || clip.loop);
      source.playbackRate.value = Math.max(0.05, gosxNumber(options && options.rate, clip.rate || 1));
      const gain = typeof audioContext.createGain === "function" ? audioContext.createGain() : null;
      if (gain && gain.gain) {
        gain.gain.value = gosxAudioPlaybackVolume(clip, options);
      }
      let tail = gain || source;
      const spatialPanner = gosxAudioCreateSpatialPanner(audioContext, options || {});
      if (spatialPanner) {
        tail.connect(spatialPanner);
        tail = spatialPanner;
      } else if (typeof audioContext.createStereoPanner === "function" && options && Object.prototype.hasOwnProperty.call(options, "pan")) {
        const panner = audioContext.createStereoPanner();
        panner.pan.value = Math.max(-1, Math.min(1, gosxNumber(options.pan, 0)));
        tail.connect(panner);
        tail = panner;
      }
      tail.connect(audioContext.destination);
      source.start(0);
      gosxAudioState.handles.set(handleID, { kind: "webaudio", clip: clip.id, source, gain, panner: spatialPanner, options: Object.assign({}, options || {}) });
      source.onended = function() {
        gosxAudioState.handles.delete(handleID);
      };
      return handleID;
    });
  }

  function gosxAudioPlayElement(clip, options, handleID) {
    if (!document || typeof document.createElement !== "function") {
      return Promise.resolve("");
    }
    const audio = document.createElement("audio");
    audio.src = clip.src;
    audio.loop = Boolean((options && options.loop) || clip.loop);
    audio.volume = gosxAudioPlaybackVolume(clip, options);
    audio.playbackRate = Math.max(0.05, gosxNumber(options && options.rate, clip.rate || 1));
    audio.preload = "auto";
    gosxAudioState.handles.set(handleID, { kind: "element", clip: clip.id, element: audio, options: Object.assign({}, options || {}) });
    if (typeof audio.addEventListener === "function") {
      audio.addEventListener("ended", function() {
        gosxAudioState.handles.delete(handleID);
      });
    }
    const result = typeof audio.play === "function" ? audio.play() : null;
    if (result && typeof result.catch === "function") {
      result.catch(function(error) {
        console.warn("[gosx] audio playback failed", error);
      });
    }
    return Promise.resolve(handleID);
  }

  function gosxAudioPlay(idOrSrc, options) {
    const clip = gosxAudioResolveClip(idOrSrc, options);
    if (!clip) {
      return Promise.resolve("");
    }
    const handleID = String(options && options.handle ? options.handle : "audio-" + (++gosxAudioState.nextHandle));
    const audioContext = gosxAudioEnsureContext();
    if (audioContext && typeof audioContext.createBufferSource === "function") {
      return gosxAudioPlayWebAudio(audioContext, clip, options || {}, handleID).then(function(handle) {
        return handle || gosxAudioPlayElement(clip, options || {}, handleID);
      });
    }
    return gosxAudioPlayElement(clip, options || {}, handleID);
  }

  function gosxAudioStop(target) {
    const key = String(target || "").trim();
    let stopped = false;
    for (const [handleID, handle] of Array.from(gosxAudioState.handles.entries())) {
      if (key && handleID !== key && handle.clip !== key) {
        continue;
      }
      if (handle.source && typeof handle.source.stop === "function") {
        try {
          handle.source.stop(0);
        } catch (_error) {}
      }
      if (handle.element && typeof handle.element.pause === "function") {
        handle.element.pause();
      }
      gosxAudioState.handles.delete(handleID);
      stopped = true;
    }
    return stopped;
  }

  function gosxAudioSetBusVolume(busID, volume) {
    const bus = gosxAudioRegisterBus({ id: busID || "master", volume: volume });
    for (const handle of gosxAudioState.handles.values()) {
      const clip = gosxAudioState.clips.get(handle.clip);
      if (handle.element) {
        handle.element.volume = gosxAudioPlaybackVolume(clip, handle.options);
      }
      if (handle.gain && handle.gain.gain) {
        handle.gain.gain.value = gosxAudioPlaybackVolume(clip, handle.options);
      }
    }
    return bus;
  }

  function gosxAudioSnapshot() {
    return {
      clips: Array.from(gosxAudioState.clips.values()).map(function(clip) {
        return {
          id: clip.id,
          src: clip.src,
          contentType: clip.contentType,
          bus: clip.bus,
          preload: clip.preload,
          loop: clip.loop,
          volume: clip.volume,
          rate: clip.rate,
        };
      }),
      buses: Array.from(gosxAudioState.buses.values()).map(function(bus) {
        return Object.assign({}, bus);
      }),
      handles: Array.from(gosxAudioState.handles.keys()),
    };
  }

  function gosxAudioUnlock() {
    const audioContext = gosxAudioEnsureContext();
    if (audioContext && typeof audioContext.resume === "function") {
      return audioContext.resume();
    }
    return Promise.resolve();
  }

  const gosxAudioAPI = {
    load: function(idOrClip, src, options) {
      if (typeof idOrClip === "string" && typeof src === "string") {
        return gosxAudioRegisterClip(Object.assign({}, options || {}, { id: idOrClip, src: src }), gosxAudioState.clips.size);
      }
      return gosxAudioRegisterClip(idOrClip, gosxAudioState.clips.size);
    },
    preload: gosxAudioPreload,
    play: gosxAudioPlay,
    stop: gosxAudioStop,
    setBusVolume: gosxAudioSetBusVolume,
    registerManifest: gosxAudioRegisterManifest,
    unlock: gosxAudioUnlock,
    snapshot: gosxAudioSnapshot,
  };
  window.__gosx.audio = gosxAudioAPI;
  window.__gosx_audio = gosxAudioAPI;

  function gosxPointerMode() {
    if (gosxMediaQueryMatches("(pointer: fine)")) {
      return "fine";
    }
    if (gosxMediaQueryMatches("(pointer: coarse)") || gosxMediaQueryMatches("(any-pointer: coarse)")) {
      return "coarse";
    }
    return "none";
  }

  function gosxContrastMode() {
    if (gosxMediaQueryMatches("(prefers-contrast: more)")) {
      return "more";
    }
    if (gosxMediaQueryMatches("(prefers-contrast: less)")) {
      return "less";
    }
    return "no-preference";
  }

  function gosxColorSchemeMode() {
    if (gosxMediaQueryMatches("(prefers-color-scheme: dark)")) {
      return "dark";
    }
    if (gosxMediaQueryMatches("(prefers-color-scheme: light)")) {
      return "light";
    }
    return "no-preference";
  }

  function gosxEnvironmentSnapshot() {
    const navigatorRef = window && window.navigator ? window.navigator : {};
    const connection = gosxNavigatorConnection();
    const visualViewport = window.visualViewport || null;
    const pageVisible = String(document && document.visibilityState || "visible").toLowerCase() !== "hidden";
    const coarsePointer = gosxPointerMode() === "coarse";
    const hover = gosxMediaQueryMatches("(hover: hover)") || gosxMediaQueryMatches("(any-hover: hover)");
    const saveData = Boolean(connection && connection.saveData);
    const reducedData = saveData || gosxMediaQueryMatches("(prefers-reduced-data: reduce)");
    const deviceMemory = Math.max(0, gosxNumber(navigatorRef && navigatorRef.deviceMemory, 0));
    const hardwareConcurrency = Math.max(0, Math.floor(gosxNumber(navigatorRef && navigatorRef.hardwareConcurrency, 0)));
    const maxTouchPoints = Math.max(0, Math.floor(gosxNumber(navigatorRef && navigatorRef.maxTouchPoints, 0)));
    const lowPower = reducedData || (coarsePointer && ((deviceMemory > 0 && deviceMemory <= 4) || (hardwareConcurrency > 0 && hardwareConcurrency <= 4)));
    const viewportWidth = Math.max(0, gosxNumber(window.innerWidth, document && document.documentElement && document.documentElement.clientWidth || 0));
    const viewportHeight = Math.max(0, gosxNumber(window.innerHeight, document && document.documentElement && document.documentElement.clientHeight || 0));

    return {
      pageVisible,
      pointer: gosxPointerMode(),
      coarsePointer,
      hover,
      reducedMotion: gosxMediaQueryMatches("(prefers-reduced-motion: reduce)"),
      reducedData,
      saveData,
      contrast: gosxContrastMode(),
      colorScheme: gosxColorSchemeMode(),
      devicePixelRatio: Math.max(1, gosxNumber(window.devicePixelRatio, 1)),
      viewportWidth,
      viewportHeight,
      visualViewportWidth: Math.max(0, gosxNumber(visualViewport && visualViewport.width, viewportWidth)),
      visualViewportHeight: Math.max(0, gosxNumber(visualViewport && visualViewport.height, viewportHeight)),
      visualViewportOffsetLeft: gosxNumber(visualViewport && visualViewport.offsetLeft, 0),
      visualViewportOffsetTop: gosxNumber(visualViewport && visualViewport.offsetTop, 0),
      visualViewportActive: Boolean(visualViewport),
      deviceMemory,
      hardwareConcurrency,
      maxTouchPoints,
      lowPower,
    };
  }

  function gosxEnvironmentChanged(prev, next) {
    if (!prev || !next) {
      return true;
    }
    const keys = Object.keys(next);
    for (const key of keys) {
      if (prev[key] !== next[key]) {
        return true;
      }
    }
    return false;
  }

  function cloneGosxEnvironment(state) {
    return state ? Object.assign({}, state) : null;
  }

  function applyGosxEnvironmentState(state) {
    const root = document.documentElement || document.body;
    const body = document.body || root;
    if (!root || !state) {
      return;
    }
    setAttrValue(root, "data-gosx-env-page-visible", state.pageVisible ? "true" : "false");
    setAttrValue(root, "data-gosx-env-pointer", state.pointer);
    setAttrValue(root, "data-gosx-env-hover", state.hover ? "true" : "false");
    setAttrValue(root, "data-gosx-env-reduced-motion", state.reducedMotion ? "true" : "false");
    setAttrValue(root, "data-gosx-env-reduced-data", state.reducedData ? "true" : "false");
    setAttrValue(root, "data-gosx-env-contrast", state.contrast);
    setAttrValue(root, "data-gosx-env-color-scheme", state.colorScheme);
    setAttrValue(root, "data-gosx-env-low-power", state.lowPower ? "true" : "false");
    setAttrValue(root, "data-gosx-env-visual-viewport", state.visualViewportActive ? "true" : "false");
    setStyleValue(root.style, "--gosx-env-viewport-width", state.viewportWidth + "px");
    setStyleValue(root.style, "--gosx-env-viewport-height", state.viewportHeight + "px");
    setStyleValue(root.style, "--gosx-env-visual-viewport-width", state.visualViewportWidth + "px");
    setStyleValue(root.style, "--gosx-env-visual-viewport-height", state.visualViewportHeight + "px");
    setStyleValue(root.style, "--gosx-env-visual-viewport-offset-left", state.visualViewportOffsetLeft + "px");
    setStyleValue(root.style, "--gosx-env-visual-viewport-offset-top", state.visualViewportOffsetTop + "px");
    setStyleValue(root.style, "--gosx-env-device-pixel-ratio", String(state.devicePixelRatio));
    if (body && body !== root) {
      setAttrValue(body, "data-gosx-env-page-visible", state.pageVisible ? "true" : "false");
      setAttrValue(body, "data-gosx-env-reduced-motion", state.reducedMotion ? "true" : "false");
      setAttrValue(body, "data-gosx-env-reduced-data", state.reducedData ? "true" : "false");
      setAttrValue(body, "data-gosx-env-low-power", state.lowPower ? "true" : "false");
    }
  }

  function dispatchGosxEnvironment(reason) {
    if (typeof CustomEvent !== "function" || !document || typeof document.dispatchEvent !== "function") {
      return;
    }
    document.dispatchEvent(new CustomEvent("gosx:environment", {
      detail: {
        reason: reason || "refresh",
        state: cloneGosxEnvironment(gosxEnvironmentState),
      },
    }));
  }

  function refreshGosxEnvironmentState(reason) {
    const next = gosxEnvironmentSnapshot();
    const changed = gosxEnvironmentChanged(gosxEnvironmentState, next);
    gosxEnvironmentState = next;
    applyGosxEnvironmentState(next);
    if (!changed) {
      return cloneGosxEnvironment(next);
    }
    for (const listener of Array.from(gosxEnvironmentListeners)) {
      try {
        listener(cloneGosxEnvironment(next), reason || "refresh");
      } catch (error) {
        console.error("[gosx] environment listener failed:", error);
      }
    }
    dispatchGosxEnvironment(reason);
    return cloneGosxEnvironment(next);
  }

  function scheduleGosxEnvironmentRefresh(reason) {
    gosxScheduleStateInvalidation("environment", reason || "environment", function(nextReason) {
      refreshGosxEnvironmentState(nextReason);
    });
  }

  function installGosxEnvironmentObservers() {
    if (gosxEnvironmentObserversInstalled) {
      return;
    }
    gosxEnvironmentObserversInstalled = true;

    const refresh = function(reason) {
      scheduleGosxEnvironmentRefresh(reason);
    };

    if (document && typeof document.addEventListener === "function") {
      document.addEventListener("visibilitychange", function() {
        refresh("visibility");
      });
    }
    const passive = { passive: true };
    if (typeof window.addEventListener === "function") {
      window.addEventListener("resize", function() {
        refresh("viewport");
      }, passive);
      window.addEventListener("orientationchange", function() {
        refresh("viewport");
      }, passive);
      window.addEventListener("pageshow", function() {
        refresh("pageshow");
      }, passive);
    }
    if (window.visualViewport && typeof window.visualViewport.addEventListener === "function") {
      window.visualViewport.addEventListener("resize", function() {
        refresh("visual-viewport");
      }, passive);
      window.visualViewport.addEventListener("scroll", function() {
        refresh("visual-viewport");
      }, passive);
    }

    const queries = [
      "(prefers-reduced-motion: reduce)",
      "(prefers-reduced-data: reduce)",
      "(prefers-contrast: more)",
      "(prefers-contrast: less)",
      "(prefers-color-scheme: dark)",
      "(prefers-color-scheme: light)",
      "(pointer: fine)",
      "(pointer: coarse)",
      "(any-pointer: coarse)",
      "(hover: hover)",
      "(any-hover: hover)",
    ];
    for (const query of queries) {
      const media = gosxMediaQueryList(query);
      if (!media) {
        continue;
      }
      const onChange = function() {
        refresh("media");
      };
      if (typeof media.addEventListener === "function") {
        media.addEventListener("change", onChange);
      } else if (typeof media.addListener === "function") {
        media.addListener(onChange);
      }
    }

    const connection = gosxNavigatorConnection();
    if (connection && typeof connection.addEventListener === "function") {
      connection.addEventListener("change", function() {
        refresh("connection");
      });
    }
  }

  function observeGosxEnvironment(listener, options) {
    if (typeof listener !== "function") {
      return function() {};
    }
    installGosxEnvironmentObservers();
    gosxEnvironmentListeners.add(listener);
    if (!gosxEnvironmentState) {
      refreshGosxEnvironmentState("init");
    }
    if (!options || options.immediate !== false) {
      listener(cloneGosxEnvironment(gosxEnvironmentState), "init");
    }
    return function() {
      gosxEnvironmentListeners.delete(listener);
    };
  }

  function gosxManagedHeadMarkers() {
    const children = gosxArrayFrom(document.head && document.head.childNodes);
    let start = null;
    let end = null;
    for (const child of children) {
      if (!child || child.nodeType !== 1) {
        continue;
      }
      if (String(child.tagName || "").toUpperCase() !== "META") {
        continue;
      }
      const name = String(child.getAttribute && child.getAttribute("name") || "");
      if (name === "gosx-head-start") {
        start = child;
      } else if (name === "gosx-head-end") {
        end = child;
      }
    }
    return { start, end };
  }

  function gosxDocumentChildrenBetween(start, end) {
    if (!start || !end || !start.parentNode || start.parentNode !== end.parentNode) {
      return [];
    }
    const children = gosxArrayFrom(start.parentNode.childNodes);
    const startIndex = children.indexOf(start);
    const endIndex = children.indexOf(end);
    if (startIndex < 0 || endIndex <= startIndex) {
      return [];
    }
    return children.slice(startIndex + 1, endIndex);
  }

  function gosxReadDocumentContract() {
    const node = document.getElementById && document.getElementById("gosx-document");
    if (!node) {
      return null;
    }
    try {
      const payload = JSON.parse(String(node.textContent || "{}"));
      return payload && typeof payload === "object" ? payload : null;
    } catch (error) {
      console.error("[gosx] invalid document contract:", error);
      return null;
    }
  }

  function gosxCurrentEnhancementLayer() {
    const hasRuntime = Boolean(
      typeof window.__gosx_hydrate === "function"
      || (window.__gosx && window.__gosx.islands && window.__gosx.islands.size > 0)
      || (window.__gosx && window.__gosx.computeIslands && window.__gosx.computeIslands.size > 0)
      || (window.__gosx && window.__gosx.engines && window.__gosx.engines.size > 0)
      || (window.__gosx && window.__gosx.hubs && window.__gosx.hubs.size > 0)
    );
    return hasRuntime ? "runtime" : "bootstrap";
  }

  function gosxNormalizeDocumentCSSLayer(value, fallback) {
    const layer = String(value || fallback || "global").trim().toLowerCase();
    return GOSX_DOCUMENT_CSS_LAYERS.includes(layer) ? layer : "global";
  }

  function gosxDocumentCSSLayer(node, fallback) {
    const value = String(node && node.getAttribute && node.getAttribute("data-gosx-css-layer") || "").trim();
    return gosxNormalizeDocumentCSSLayer(value, fallback);
  }

  function gosxDocumentCSSOwner(node, fallback) {
    const value = String(node && node.getAttribute && node.getAttribute("data-gosx-css-owner") || "").trim();
    return value || fallback || "document";
  }

  function gosxDocumentCSSSource(node, fallback) {
    const value = String(node && node.getAttribute && node.getAttribute("data-gosx-css-source") || "").trim();
    return value || String(fallback || "");
  }

  function gosxDocumentStyleEntry(node, order, layerFallback, ownerFallback) {
    const file = String(node.getAttribute && node.getAttribute("data-gosx-file-css") || "");
    const scope = String(node.getAttribute && node.getAttribute("data-gosx-file-css-scope") || "");
    return {
      kind: "inline",
      file,
      href: "",
      media: "",
      layer: gosxDocumentCSSLayer(node, layerFallback),
      owner: gosxDocumentCSSOwner(node, ownerFallback),
      source: gosxDocumentCSSSource(node, file),
      order,
      scope,
    };
  }

  function gosxDocumentStylesheetEntry(node, order, layerFallback, ownerFallback) {
    const href = String(node.getAttribute && node.getAttribute("href") || "");
    return {
      kind: "stylesheet",
      file: "",
      href,
      media: String(node.getAttribute && node.getAttribute("media") || ""),
      layer: gosxDocumentCSSLayer(node, layerFallback),
      owner: gosxDocumentCSSOwner(node, ownerFallback),
      source: gosxDocumentCSSSource(node, href),
      order,
      scope: "",
    };
  }

  function gosxDocumentCSSLayerState(layer) {
    return {
      layer,
      count: 0,
      inlineCount: 0,
      stylesheetCount: 0,
      scopedCount: 0,
      owners: [],
      sources: [],
      entries: [],
    };
  }

  function gosxDocumentCSSLayers(entries) {
    const layers = Object.create(null);
    for (const layer of GOSX_DOCUMENT_CSS_LAYERS) {
      layers[layer] = gosxDocumentCSSLayerState(layer);
    }
    for (const entry of entries || []) {
      const layer = gosxNormalizeDocumentCSSLayer(entry && entry.layer, "global");
      const bucket = layers[layer] || gosxDocumentCSSLayerState(layer);
      const item = Object.assign({}, entry, { layer });
      bucket.count += 1;
      if (item.kind === "stylesheet") {
        bucket.stylesheetCount += 1;
      } else {
        bucket.inlineCount += 1;
      }
      if (item.scope) {
        bucket.scopedCount += 1;
      }
      if (item.owner && !bucket.owners.includes(item.owner)) {
        bucket.owners.push(item.owner);
      }
      if (item.source && !bucket.sources.includes(item.source)) {
        bucket.sources.push(item.source);
      }
      bucket.entries.push(item);
      layers[layer] = bucket;
    }
    return layers;
  }

  function gosxWalkDocumentElements(root, visit) {
    if (!root || typeof visit !== "function") {
      return;
    }
    if (root.nodeType === 1) {
      visit(root);
    }
    const children = root.children || root.childNodes || [];
    for (const child of children) {
      if (child && child.nodeType === 1) {
        gosxWalkDocumentElements(child, visit);
      }
    }
  }

  function gosxNormalizeEnhancementLayer(value, fallback) {
    const layer = String(value || fallback || "html").trim().toLowerCase();
    return GOSX_DOCUMENT_ENHANCEMENT_LAYERS.includes(layer) ? layer : "html";
  }

  function gosxDocumentEnhancementLayerState(layer) {
    return {
      layer,
      count: 0,
      kinds: [],
      fallbacks: [],
      entries: [],
    };
  }

  function gosxDocumentEnhancementKindState(kind) {
    return {
      kind,
      count: 0,
      layers: [],
      fallbacks: [],
      entries: [],
    };
  }

  function gosxDocumentEnhancementEntry(node, order) {
    const kind = String(node && node.getAttribute && node.getAttribute("data-gosx-enhance") || "").trim();
    if (!kind) {
      return null;
    }
    const layer = gosxNormalizeEnhancementLayer(node && node.getAttribute && node.getAttribute("data-gosx-enhance-layer"), "html");
    const fallback = String(node && node.getAttribute && node.getAttribute("data-gosx-fallback") || "").trim() || "none";
    return {
      kind,
      layer,
      fallback,
      id: String(node && node.getAttribute && node.getAttribute("id") || ""),
      tag: String(node && node.tagName || "").toLowerCase(),
      engine: String(node && node.getAttribute && node.getAttribute("data-gosx-engine") || ""),
      order,
    };
  }

  function gosxDocumentEnhancements() {
    const entries = [];
    let order = 0;
    gosxWalkDocumentElements(document.body || document.documentElement, function(node) {
      const entry = gosxDocumentEnhancementEntry(node, order);
      if (!entry) {
        return;
      }
      entries.push(entry);
      order += 1;
    });
    const layers = Object.create(null);
    for (const layer of GOSX_DOCUMENT_ENHANCEMENT_LAYERS) {
      layers[layer] = gosxDocumentEnhancementLayerState(layer);
    }
    const kinds = Object.create(null);
    for (const entry of entries) {
      const layerBucket = layers[entry.layer] || gosxDocumentEnhancementLayerState(entry.layer);
      layerBucket.count += 1;
      if (!layerBucket.kinds.includes(entry.kind)) {
        layerBucket.kinds.push(entry.kind);
      }
      if (!layerBucket.fallbacks.includes(entry.fallback)) {
        layerBucket.fallbacks.push(entry.fallback);
      }
      layerBucket.entries.push(Object.assign({}, entry));
      layers[entry.layer] = layerBucket;

      const kindBucket = kinds[entry.kind] || gosxDocumentEnhancementKindState(entry.kind);
      kindBucket.count += 1;
      if (!kindBucket.layers.includes(entry.layer)) {
        kindBucket.layers.push(entry.layer);
      }
      if (!kindBucket.fallbacks.includes(entry.fallback)) {
        kindBucket.fallbacks.push(entry.fallback);
      }
      kindBucket.entries.push(Object.assign({}, entry));
      kinds[entry.kind] = kindBucket;
    }
    return {
      count: entries.length,
      entries,
      layers,
      kinds,
    };
  }

  function gosxDocumentRuntimeAssets(contract, enhancement, layer) {
    const assets = contract && contract.assets && typeof contract.assets === "object" ? contract.assets : {};
    let bootstrapMode = String(assets.bootstrapMode || "").trim().toLowerCase();
    if (!bootstrapMode) {
      bootstrapMode = layer === "runtime" || Boolean(enhancement && enhancement.runtime) ? "full" : (Boolean(enhancement && enhancement.bootstrap) ? "lite" : "none");
    }
    if (bootstrapMode !== "none" && bootstrapMode !== "lite" && bootstrapMode !== "full") {
      bootstrapMode = "none";
    }
    return {
      bootstrapMode,
      manifest: Boolean(assets.manifest),
      runtimePath: String(assets.runtimePath || ""),
      wasmExecPath: String(assets.wasmExecPath || ""),
      patchPath: String(assets.patchPath || ""),
      bootstrapPath: String(assets.bootstrapPath || ""),
      bootstrapFeatureIslandsPath: String(assets.bootstrapFeatureIslandsPath || ""),
      bootstrapFeatureEnginesPath: String(assets.bootstrapFeatureEnginesPath || ""),
      bootstrapFeatureHubsPath: String(assets.bootstrapFeatureHubsPath || ""),
      hlsPath: String(assets.hlsPath || ""),
      islands: Math.max(0, gosxNumber(assets.islands, 0)),
      engines: Math.max(0, gosxNumber(assets.engines, 0)),
      hubs: Math.max(0, gosxNumber(assets.hubs, 0)),
    };
  }

  function gosxEnhancementAttrName(kind) {
    const value = String(kind || "").trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    return value ? "data-gosx-enhancement-" + value + "-count" : "";
  }

  function gosxDocumentHeadAssets() {
    const markers = gosxManagedHeadMarkers();
    const nodes = gosxDocumentChildrenBetween(markers.start, markers.end);
    const ownedCSS = [];
    const stylesheets = [];
    const scripts = [];
    let cssOrder = 0;

    for (const node of nodes) {
      if (!node || node.nodeType !== 1) {
        continue;
      }
      const tagName = String(node.tagName || "").toUpperCase();
      if (tagName === "STYLE") {
        ownedCSS.push(gosxDocumentStyleEntry(
          node,
          gosxNumber(node.getAttribute && node.getAttribute("data-gosx-css-order"), cssOrder),
          "global",
          "document-global"
        ));
        cssOrder += 1;
        continue;
      }
      if (tagName === "LINK" && /\bstylesheet\b/i.test(String(node.getAttribute && node.getAttribute("rel") || ""))) {
        const entry = gosxDocumentStylesheetEntry(node, cssOrder, "global", "document-global");
        stylesheets.push(entry);
        ownedCSS.push(entry);
        cssOrder += 1;
        continue;
      }
      if (tagName === "SCRIPT") {
        scripts.push({
          role: String(node.getAttribute && node.getAttribute("data-gosx-script") || ""),
          navigation: node.hasAttribute && node.hasAttribute("data-gosx-navigation"),
          src: String(node.getAttribute && node.getAttribute("src") || ""),
          inline: !node.getAttribute || !node.getAttribute("src"),
        });
      }
    }

    for (const node of gosxArrayFrom(document.head && document.head.childNodes)) {
      if (!node || node.nodeType !== 1) {
        continue;
      }
      if (String(node.tagName || "").toUpperCase() !== "STYLE") {
        continue;
      }
      if (String(node.getAttribute && node.getAttribute("data-gosx-css-layer") || "") !== "runtime") {
        continue;
      }
      ownedCSS.push(gosxDocumentStyleEntry(node, cssOrder, "runtime", "gosx-bootstrap"));
      cssOrder += 1;
    }

    return {
      managed: Boolean(markers.start && markers.end),
      ownedCSS,
      stylesheets,
      scripts,
    };
  }

  function cloneGosxDocumentState(state) {
    if (!state) {
      return null;
    }
    return {
      page: Object.assign({}, state.page),
      enhancement: Object.assign({}, state.enhancement),
      enhancements: {
        count: state.enhancements.count,
        entries: state.enhancements.entries.map(function(entry) {
          return Object.assign({}, entry);
        }),
        layers: Object.fromEntries(GOSX_DOCUMENT_ENHANCEMENT_LAYERS.map(function(layer) {
          const bucket = state.enhancements.layers[layer] || gosxDocumentEnhancementLayerState(layer);
          return [layer, {
            layer: bucket.layer,
            count: bucket.count,
            kinds: bucket.kinds.slice(),
            fallbacks: bucket.fallbacks.slice(),
            entries: bucket.entries.map(function(entry) {
              return Object.assign({}, entry);
            }),
          }];
        })),
        kinds: Object.fromEntries(Object.keys(state.enhancements.kinds || {}).map(function(kind) {
          const bucket = state.enhancements.kinds[kind] || gosxDocumentEnhancementKindState(kind);
          return [kind, {
            kind: bucket.kind,
            count: bucket.count,
            layers: bucket.layers.slice(),
            fallbacks: bucket.fallbacks.slice(),
            entries: bucket.entries.map(function(entry) {
              return Object.assign({}, entry);
            }),
          }];
        })),
      },
      head: Object.assign({}, state.head),
      css: {
        owned: state.css.owned.map(function(entry) {
          return Object.assign({}, entry);
        }),
        stylesheets: state.css.stylesheets.map(function(entry) {
          return Object.assign({}, entry);
        }),
        layers: Object.fromEntries(GOSX_DOCUMENT_CSS_LAYERS.map(function(layer) {
          const bucket = state.css.layers[layer] || gosxDocumentCSSLayerState(layer);
          return [layer, {
            layer: bucket.layer,
            count: bucket.count,
            inlineCount: bucket.inlineCount,
            stylesheetCount: bucket.stylesheetCount,
            scopedCount: bucket.scopedCount,
            owners: bucket.owners.slice(),
            sources: bucket.sources.slice(),
            entries: bucket.entries.map(function(entry) {
              return Object.assign({}, entry);
            }),
          }];
        })),
      },
      assets: {
        runtime: Object.assign({}, state.assets.runtime),
        scripts: state.assets.scripts.map(function(entry) {
          return Object.assign({}, entry);
        }),
      },
    };
  }

  function gosxReadDocumentState() {
    const contract = gosxReadDocumentContract();
    const page = contract && contract.page && typeof contract.page === "object" ? contract.page : {};
    const enhancement = contract && contract.enhancement && typeof contract.enhancement === "object" ? contract.enhancement : {};
    const assets = gosxDocumentHeadAssets();
    const cssLayers = gosxDocumentCSSLayers(assets.ownedCSS);
    const layer = gosxCurrentEnhancementLayer();
    const runtimeAssets = gosxDocumentRuntimeAssets(contract, enhancement, layer);
    const enhancements = gosxDocumentEnhancements();

    return {
      page: {
        id: typeof page.id === "string" && page.id ? page.id : "gosx-doc-page",
        pattern: typeof page.pattern === "string" ? page.pattern : "",
        path: typeof page.path === "string" && page.path ? page.path : String(window.location && window.location.href || ""),
        title: typeof page.title === "string" && page.title ? page.title : String(document.title || ""),
        status: Number.isFinite(Number(page.status)) ? Number(page.status) : 200,
        requestID: typeof page.requestID === "string" ? page.requestID : "",
      },
      enhancement: {
        layer,
        bootstrap: runtimeAssets.bootstrapMode !== "none" || Boolean(enhancement.bootstrap),
        runtime: runtimeAssets.bootstrapMode === "full" || layer === "runtime" || Boolean(enhancement.runtime),
        navigation: Boolean(enhancement.navigation) || Boolean(window.__gosx_page_nav && typeof window.__gosx_page_nav.navigate === "function"),
        ready: Boolean(window.__gosx && window.__gosx.ready),
      },
      enhancements,
      head: {
        managed: assets.managed,
        ownedCSSCount: assets.ownedCSS.length,
        stylesheetCount: assets.stylesheets.length,
        scriptCount: assets.scripts.length,
      },
      css: {
        owned: assets.ownedCSS,
        stylesheets: assets.stylesheets,
        layers: cssLayers,
      },
      assets: {
        runtime: runtimeAssets,
        scripts: assets.scripts,
      },
    };
  }

  function gosxDocumentChanged(prev, next) {
    return JSON.stringify(prev || null) !== JSON.stringify(next || null);
  }

  function applyGosxDocumentState(state) {
    const root = document.documentElement || document.body;
    const body = document.body || root;
    if (!root || !state) {
      return;
    }
    setAttrValue(root, "data-gosx-document", "true");
    setAttrValue(root, "data-gosx-document-id", state.page.id);
    setAttrValue(root, "data-gosx-route-pattern", state.page.pattern);
    setAttrValue(root, "data-gosx-enhancement-layer", state.enhancement.layer);
    setAttrValue(root, "data-gosx-bootstrap-mode", state.assets && state.assets.runtime ? state.assets.runtime.bootstrapMode : "none");
    setAttrValue(root, "data-gosx-navigation", state.enhancement.navigation ? "true" : "false");
    setAttrValue(root, "data-gosx-runtime-ready", state.enhancement.ready ? "true" : "false");
    setAttrValue(root, "data-gosx-head-managed", state.head.managed ? "true" : "false");
    setAttrValue(root, "data-gosx-enhancement-count", state.enhancements && state.enhancements.count || 0);
    setAttrValue(root, "data-gosx-css-owned-count", state.head.ownedCSSCount);
    setStyleValue(root.style, "--gosx-document-owned-css-count", String(state.head.ownedCSSCount));
    setStyleValue(root.style, "--gosx-document-stylesheet-count", String(state.head.stylesheetCount));
    setStyleValue(root.style, "--gosx-document-enhancement-count", String(state.enhancements && state.enhancements.count || 0));
    for (const layer of GOSX_DOCUMENT_CSS_LAYERS) {
      const count = state.css && state.css.layers && state.css.layers[layer] ? state.css.layers[layer].count : 0;
      setAttrValue(root, "data-gosx-css-" + layer + "-count", count);
      setStyleValue(root.style, "--gosx-document-css-" + layer + "-count", String(count));
    }
    for (const layer of GOSX_DOCUMENT_ENHANCEMENT_LAYERS) {
      const count = state.enhancements && state.enhancements.layers && state.enhancements.layers[layer] ? state.enhancements.layers[layer].count : 0;
      setAttrValue(root, "data-gosx-enhancement-" + layer + "-count", count);
      setStyleValue(root.style, "--gosx-document-enhancement-" + layer + "-count", String(count));
    }
    const nextKindAttrs = new Set();
    for (const kind of Object.keys(state.enhancements && state.enhancements.kinds || {})) {
      const attrName = gosxEnhancementAttrName(kind);
      if (!attrName) {
        continue;
      }
      nextKindAttrs.add(attrName);
      setAttrValue(root, attrName, state.enhancements.kinds[kind].count);
    }
    for (const attrName of Array.from(gosxAppliedEnhancementKindAttrs)) {
      if (nextKindAttrs.has(attrName)) {
        continue;
      }
      setAttrValue(root, attrName, "");
      gosxAppliedEnhancementKindAttrs.delete(attrName);
    }
    for (const attrName of Array.from(nextKindAttrs)) {
      gosxAppliedEnhancementKindAttrs.add(attrName);
    }
    if (body && body !== root) {
      setAttrValue(body, "data-gosx-document-id", state.page.id);
      setAttrValue(body, "data-gosx-enhancement-layer", state.enhancement.layer);
      setAttrValue(body, "data-gosx-bootstrap-mode", state.assets && state.assets.runtime ? state.assets.runtime.bootstrapMode : "none");
      setAttrValue(body, "data-gosx-navigation", state.enhancement.navigation ? "true" : "false");
      setAttrValue(body, "data-gosx-runtime-ready", state.enhancement.ready ? "true" : "false");
      setAttrValue(body, "data-gosx-enhancement-count", state.enhancements && state.enhancements.count || 0);
      for (const layer of GOSX_DOCUMENT_CSS_LAYERS) {
        const count = state.css && state.css.layers && state.css.layers[layer] ? state.css.layers[layer].count : 0;
        setAttrValue(body, "data-gosx-css-" + layer + "-count", count);
      }
      for (const layer of GOSX_DOCUMENT_ENHANCEMENT_LAYERS) {
        const count = state.enhancements && state.enhancements.layers && state.enhancements.layers[layer] ? state.enhancements.layers[layer].count : 0;
        setAttrValue(body, "data-gosx-enhancement-" + layer + "-count", count);
      }
      for (const attrName of Array.from(gosxAppliedEnhancementKindAttrs)) {
        const kindName = attrName.replace(/^data-gosx-enhancement-/, "").replace(/-count$/, "");
        const bucket = state.enhancements && state.enhancements.kinds && state.enhancements.kinds[kindName];
        setAttrValue(body, attrName, bucket ? bucket.count : "");
      }
    }
  }

  function dispatchGosxDocument(reason) {
    if (typeof CustomEvent !== "function" || !document || typeof document.dispatchEvent !== "function") {
      return;
    }
    document.dispatchEvent(new CustomEvent("gosx:document", {
      detail: {
        reason: reason || "refresh",
        state: cloneGosxDocumentState(gosxDocumentState),
      },
    }));
  }

  function refreshGosxDocumentState(reason) {
    const next = gosxReadDocumentState();
    const changed = gosxDocumentChanged(gosxDocumentState, next);
    gosxDocumentState = next;
    applyGosxDocumentState(next);
    if (!changed) {
      return cloneGosxDocumentState(next);
    }
    for (const listener of Array.from(gosxDocumentListeners)) {
      try {
        listener(cloneGosxDocumentState(next), reason || "refresh");
      } catch (error) {
        console.error("[gosx] document listener failed:", error);
      }
    }
    dispatchGosxDocument(reason);
    return cloneGosxDocumentState(next);
  }

  function scheduleGosxDocumentRefresh(reason) {
    gosxScheduleStateInvalidation("document", reason || "refresh", function(nextReason) {
      refreshGosxDocumentState(nextReason);
    });
  }

  function installGosxDocumentObservers() {
    if (gosxDocumentObserversInstalled) {
      return;
    }
    gosxDocumentObserversInstalled = true;
    if (document && typeof document.addEventListener === "function") {
      document.addEventListener("gosx:navigate", function() {
        scheduleGosxDocumentRefresh("navigate");
        scheduleGosxEnvironmentRefresh("navigate");
      });
      document.addEventListener("gosx:ready", function() {
        scheduleGosxDocumentRefresh("ready");
      });
    }
    if (typeof window.addEventListener === "function") {
      window.addEventListener("pageshow", function() {
        scheduleGosxDocumentRefresh("pageshow");
      });
    }
    if (typeof MutationObserver === "function" && document && document.head) {
      const headObserver = new MutationObserver(function() {
        scheduleGosxDocumentRefresh("head-mutation");
      });
      if (typeof headObserver.observe === "function") {
        headObserver.observe(document.head, {
          subtree: true,
          childList: true,
          attributes: true,
          characterData: true,
          attributeFilter: [
            "href",
            "media",
            "rel",
            "name",
            "content",
            "src",
            "data-gosx-css-layer",
            "data-gosx-css-owner",
            "data-gosx-css-source",
            "data-gosx-css-order",
            "data-gosx-css-scope",
            "data-gosx-file-css",
            "data-gosx-file-css-scope",
            "data-gosx-script",
            "data-gosx-navigation",
          ],
        });
      }
    }
  }

  function observeGosxDocument(listener, options) {
    if (typeof listener !== "function") {
      return function() {};
    }
    installGosxDocumentObservers();
    gosxDocumentListeners.add(listener);
    if (!gosxDocumentState) {
      refreshGosxDocumentState("init");
    }
    if (!options || options.immediate !== false) {
      listener(cloneGosxDocumentState(gosxDocumentState), "init");
    }
    return function() {
      gosxDocumentListeners.delete(listener);
    };
  }

  function gosxInheritedElementAttribute(element, name) {
    if (!element || !name) {
      return "";
    }
    let current = element;
    while (current) {
      if (typeof current.getAttribute === "function") {
        const value = String(current.getAttribute(name) || "").trim();
        if (value) {
          return value;
        }
      }
      current = current.parentNode || null;
    }
    if (document && document.documentElement && document.documentElement !== element && typeof document.documentElement.getAttribute === "function") {
      return String(document.documentElement.getAttribute(name) || "").trim();
    }
    return "";
  }

  function gosxPresentationSnapshot(element) {
    if (!element || typeof element !== "object") {
      return null;
    }
    const style = textLayoutComputedStyle(element);
    const rect = element && typeof element.getBoundingClientRect === "function" ? element.getBoundingClientRect() : null;
    const width = Math.max(0, gosxNumber(rect && rect.width, element && (element.clientWidth || element.offsetWidth || element.width) || 0));
    const height = Math.max(0, gosxNumber(rect && rect.height, element && (element.clientHeight || element.offsetHeight || element.height) || 0));
    const lang = gosxInheritedElementAttribute(element, "lang");
    const directionAttr = gosxInheritedElementAttribute(element, "dir");
    const writingMode = normalizeTextLayoutWritingMode(textLayoutComputedStyleValue(style, "writing-mode"));
    const inlineSize = textLayoutLogicalInlineSize(width, height, writingMode);
    const blockSize = textLayoutLogicalBlockSize(width, height, writingMode);
    const maxInlineSize = textLayoutLengthValue(
      textLayoutComputedStyleValue(style, "--gosx-text-layout-max-inline-size")
      || textLayoutComputedStyleValue(style, "max-inline-size")
      || textLayoutComputedStyleValue(style, "--gosx-text-layout-max-width")
      || textLayoutComputedStyleValue(style, "max-width"),
      inlineSize,
    );
    return {
      style,
      width,
      height,
      inlineSize,
      blockSize,
      maxWidth: maxInlineSize > 0 ? maxInlineSize : inlineSize,
      maxInlineSize: maxInlineSize > 0 ? maxInlineSize : inlineSize,
      direction: textLayoutComputedStyleValue(style, "direction") || directionAttr || "",
      writingMode,
      lang,
      font: textLayoutComputedStyleValue(style, "font") || "",
      lineHeight: textLayoutLengthValue(
        textLayoutComputedStyleValue(style, "--gosx-text-layout-line-height")
        || textLayoutComputedStyleValue(style, "line-height"),
        0
      ),
      textAlign: textLayoutComputedStyleValue(style, "text-align") || "",
      whiteSpace: textLayoutComputedStyleValue(style, "white-space") || "",
      display: textLayoutComputedStyleValue(style, "display") || "",
      visibility: textLayoutComputedStyleValue(style, "visibility") || "",
      containerType: textLayoutComputedStyleValue(style, "container-type") || "",
      environment: cloneGosxEnvironment(gosxEnvironmentState || refreshGosxEnvironmentState("presentation")),
    };
  }

  function observeGosxPresentation(element, listener, options) {
    if (!element || typeof listener !== "function") {
      return function() {};
    }
    let record = gosxPresentationRecordsByElement.get(element) || null;
    if (!record) {
      record = {
        element,
        listeners: new Set(),
      };
      gosxPresentationRecordsByElement.set(element, record);
      ensureGosxPresentationObservers();
      if (gosxPresentationResizeObserver && typeof gosxPresentationResizeObserver.observe === "function") {
        gosxPresentationResizeObserver.observe(element);
      }
    }
    record.listeners.add(listener);
    if (!options || options.immediate !== false) {
      listener(gosxPresentationSnapshot(element), "init");
    }
    return function() {
      const current = gosxPresentationRecordsByElement.get(element);
      if (!current) {
        return;
      }
      current.listeners.delete(listener);
      if (current.listeners.size > 0) {
        return;
      }
      gosxCancelInvalidation(current);
      if (gosxPresentationResizeObserver && typeof gosxPresentationResizeObserver.unobserve === "function") {
        gosxPresentationResizeObserver.unobserve(element);
      }
      gosxPresentationRecordsByElement.delete(element);
      teardownGosxPresentationObservers();
    };
  }

  function gosxNotifyPresentationRecord(record, reason) {
    if (!record || !record.element || record.listeners.size === 0) {
      return;
    }
    const snapshot = gosxPresentationSnapshot(record.element);
    for (const listener of Array.from(record.listeners)) {
      try {
        listener(snapshot, reason || "presentation");
      } catch (error) {
        console.error("[gosx] presentation listener failed:", error);
      }
    }
  }

  function gosxSchedulePresentationRecord(record, reason) {
    if (!record) {
      return;
    }
    gosxScheduleVisualInvalidation(record, reason || "presentation", function(nextReason) {
      gosxNotifyPresentationRecord(record, nextReason);
    });
  }

  function gosxSchedulePresentationRefresh(reason) {
    for (const record of Array.from(gosxPresentationRecordsByElement.values())) {
      gosxSchedulePresentationRecord(record, reason || "presentation");
    }
  }

  function gosxPresentationMutationAffectsRecord(record, target) {
    if (!record || !record.element) {
      return false;
    }
    if (!target || target === record.element || target === document.documentElement || target === document.body) {
      return true;
    }
    return typeof target.contains === "function" && target.contains(record.element);
  }

  function ensureGosxPresentationObservers() {
    if (gosxPresentationRecordsByElement.size === 0) {
      return;
    }
    if (!gosxPresentationResizeObserver && typeof ResizeObserver === "function") {
      gosxPresentationResizeObserver = new ResizeObserver(function(entries) {
        for (const entry of entries || []) {
          const record = entry && entry.target ? gosxPresentationRecordsByElement.get(entry.target) : null;
          if (record) {
            gosxSchedulePresentationRecord(record, "presentation-resize");
          }
        }
      });
      for (const record of Array.from(gosxPresentationRecordsByElement.values())) {
        if (record.element && typeof gosxPresentationResizeObserver.observe === "function") {
          gosxPresentationResizeObserver.observe(record.element);
        }
      }
    }
    if (!gosxPresentationStopEnvironment) {
      gosxPresentationStopEnvironment = observeGosxEnvironment(function() {
        gosxSchedulePresentationRefresh("presentation-environment");
      }, { immediate: false });
    }
    if (!gosxPresentationStopDocument) {
      gosxPresentationStopDocument = observeGosxDocument(function() {
        gosxSchedulePresentationRefresh("presentation-document");
      }, { immediate: false });
    }
    if (!gosxPresentationMutationObserver && typeof MutationObserver === "function" && document && document.documentElement) {
      gosxPresentationMutationObserver = new MutationObserver(function(records) {
        const affected = new Set();
        for (const mutation of records || []) {
          const target = mutation && mutation.target;
          for (const record of Array.from(gosxPresentationRecordsByElement.values())) {
            if (gosxPresentationMutationAffectsRecord(record, target)) {
              affected.add(record);
            }
          }
        }
        for (const record of Array.from(affected)) {
          gosxSchedulePresentationRecord(record, "presentation-mutation");
        }
      });
      if (typeof gosxPresentationMutationObserver.observe === "function") {
        gosxPresentationMutationObserver.observe(document.documentElement, {
          subtree: true,
          attributes: true,
          attributeFilter: GOSX_PRESENTATION_MUTATION_ATTRS,
        });
      }
    }
  }

  function teardownGosxPresentationObservers() {
    if (gosxPresentationRecordsByElement.size > 0) {
      return;
    }
    if (gosxPresentationResizeObserver && typeof gosxPresentationResizeObserver.disconnect === "function") {
      gosxPresentationResizeObserver.disconnect();
    }
    gosxPresentationResizeObserver = null;
    if (gosxPresentationMutationObserver && typeof gosxPresentationMutationObserver.disconnect === "function") {
      gosxPresentationMutationObserver.disconnect();
    }
    gosxPresentationMutationObserver = null;
    if (typeof gosxPresentationStopEnvironment === "function") {
      gosxPresentationStopEnvironment();
    }
    gosxPresentationStopEnvironment = null;
    if (typeof gosxPresentationStopDocument === "function") {
      gosxPresentationStopDocument();
    }
    gosxPresentationStopDocument = null;
  }

  window.__gosx.environment = {
    get() {
      if (!gosxEnvironmentState) {
        refreshGosxEnvironmentState("read");
      }
      return cloneGosxEnvironment(gosxEnvironmentState);
    },
    refresh(reason) {
      return refreshGosxEnvironmentState(reason || "manual");
    },
    observe: observeGosxEnvironment,
  };

  window.__gosx.document = {
    get() {
      if (!gosxDocumentState) {
        refreshGosxDocumentState("read");
      }
      return cloneGosxDocumentState(gosxDocumentState);
    },
    refresh(reason) {
      return refreshGosxDocumentState(reason || "manual");
    },
    css(layer) {
      if (!gosxDocumentState) {
        refreshGosxDocumentState("read");
      }
      if (!layer) {
        return cloneGosxDocumentState(gosxDocumentState).css;
      }
      const key = gosxNormalizeDocumentCSSLayer(layer, "global");
      return cloneGosxDocumentState(gosxDocumentState).css.layers[key];
    },
    enhancements(kind) {
      if (!gosxDocumentState) {
        refreshGosxDocumentState("read");
      }
      const snapshot = cloneGosxDocumentState(gosxDocumentState).enhancements;
      if (!kind) {
        return snapshot;
      }
      return snapshot.kinds[String(kind)] || gosxDocumentEnhancementKindState(String(kind));
    },
    observe: observeGosxDocument,
  };

  window.__gosx.presentation = {
    read: gosxPresentationSnapshot,
    observe: observeGosxPresentation,
  };

  installGosxEnvironmentObservers();
  installGosxDocumentObservers();
  refreshGosxEnvironmentState("bootstrap");
  refreshGosxDocumentState("bootstrap");

  let pendingManifest = null;

  function runtimeReady() {
    return (
      typeof window.__gosx_hydrate === "function" ||
      typeof window.__gosx_action === "function" ||
      typeof window.__gosx_set_shared_signal === "function"
    );
  }

  function loadManifest() {
    const el = document.getElementById("gosx-manifest");
    if (!el) return null;

    try {
      return JSON.parse(el.textContent);
    } catch (e) {
      console.error("[gosx] failed to parse manifest:", e);
      if (window.__gosx && typeof window.__gosx.reportIssue === "function") {
        window.__gosx.reportIssue({
          scope: "bootstrap",
          type: "manifest",
          source: "gosx-manifest",
          element: el,
          message: "failed to parse gosx manifest",
          error: e,
          fallback: "server",
        });
      }
      return null;
    }
  }

  async function loadRuntime(runtimeRef) {
    if (typeof Go === "undefined") {
      console.error("[gosx] wasm_exec.js must be loaded before bootstrap.js");
      if (window.__gosx && typeof window.__gosx.reportIssue === "function") {
        window.__gosx.reportIssue({
          scope: "bootstrap",
          type: "runtime",
          source: runtimeRef && runtimeRef.path,
          ref: runtimeRef && runtimeRef.path,
          message: "wasm_exec.js must be loaded before bootstrap.js",
          fallback: "server",
        });
      }
      return;
    }

    const go = new Go();

    try {
      const response = await fetchRuntimeResponse(runtimeRef);
      const result = await instantiateRuntimeModule(response, go.importObject);
      go.run(result.instance);
    } catch (e) {
      console.error("[gosx] failed to load WASM runtime:", e);
      if (window.__gosx && typeof window.__gosx.reportIssue === "function") {
        window.__gosx.reportIssue({
          scope: "bootstrap",
          type: "runtime",
          source: runtimeRef && runtimeRef.path,
          ref: runtimeRef && runtimeRef.path,
          message: "failed to load wasm runtime",
          error: e,
          fallback: "server",
        });
      }
    }
  }

  async function fetchRuntimeResponse(runtimeRef) {
    const response = await fetch(runtimeRef.path);
    if (!response.ok) {
      throw new Error("runtime fetch failed with status " + response.status);
    }
    return response;
  }

  async function instantiateRuntimeModule(response, importObject) {
    if (supportsInstantiateStreaming()) {
      return instantiateRuntimeStreaming(response, importObject);
    }
    return instantiateRuntimeBytes(response, importObject);
  }

  function supportsInstantiateStreaming() {
    return typeof WebAssembly.instantiateStreaming === "function";
  }

  async function instantiateRuntimeStreaming(response, importObject) {
    try {
      return await WebAssembly.instantiateStreaming(response.clone(), importObject);
    } catch (streamErr) {
      return instantiateRuntimeBytes(response, importObject);
    }
  }

  async function instantiateRuntimeBytes(response, importObject) {
    const bytes = await response.arrayBuffer();
    return WebAssembly.instantiate(bytes, importObject);
  }

  async function fetchProgram(programRef, programFormat) {
    try {
      const resp = await fetch(programRef);
      if (!resp.ok) {
        console.error(`[gosx] failed to fetch program ${programRef}: ${resp.status}`);
        return null;
      }

      if (programFormat === "wasm" || programFormat === "bin") {
        return new Uint8Array(await resp.arrayBuffer());
      }
      return await resp.text();
    } catch (e) {
      console.error(`[gosx] error fetching program ${programRef}:`, e);
      return null;
    }
  }

  function inferProgramFormat(entry) {
    if (entry.programFormat) return entry.programFormat;
    if (typeof entry.programRef === "string" && entry.programRef.endsWith(".gxi")) {
      return "bin";
    }
    return "json";
  }

  const loadedScriptTags = new Map();

  function loadScriptTag(src) {
    if (!src) return Promise.resolve();
    if (loadedScriptTags.has(src)) {
      return loadedScriptTags.get(src);
    }
    const promise = new Promise(function(resolve, reject) {
      const script = document.createElement("script");
      script.src = src;
      script.onload = resolve;
      script.onerror = function() {
        reject(new Error("failed to load script: " + src));
      };
      (document.head || document.documentElement).appendChild(script);
    });
    loadedScriptTags.set(src, promise);
    return promise;
  }

  function engineFrame(callback) {
    if (typeof window.requestAnimationFrame === "function") {
      return window.requestAnimationFrame(callback);
    }
    return setTimeout(function() {
      callback(Date.now());
    }, 16);
  }

  function cancelEngineFrame(handle) {
    if (typeof window.cancelAnimationFrame === "function") {
      window.cancelAnimationFrame(handle);
      return;
    }
    clearTimeout(handle);
  }

  function gosxInputState() {
    if (!window.__gosx.input) {
      window.__gosx.input = {
        pending: null,
        frameHandle: 0,
        providers: Object.create(null),
      };
    }
    return window.__gosx.input;
  }

  function queueInputSignal(name, value) {
    if (!name) return;
    const state = gosxInputState();
    if (!state.pending) {
      state.pending = Object.create(null);
    }
    state.pending[name] = value;
    scheduleInputFlush();
  }

  function scheduleInputFlush() {
    const state = gosxInputState();
    if (state.frameHandle) return;
    state.frameHandle = engineFrame(function() {
      state.frameHandle = 0;
      flushInputSignals();
    });
  }

  function flushInputSignals() {
    const state = gosxInputState();
    const payload = state.pending;
    state.pending = null;
    if (!payload) return;

    const setInputBatch = window.__gosx_set_input_batch;
    if (typeof setInputBatch !== "function") {
      for (const [name, value] of Object.entries(payload)) {
        setSharedSignalValue(name, value);
      }
      return;
    }

    try {
      const result = setInputBatch(JSON.stringify(payload));
      if (typeof result === "string" && result !== "") {
        console.error("[gosx] input batch error:", result);
      }
    } catch (e) {
      console.error("[gosx] input batch error:", e);
    }
  }

  function capabilityList(entry) {
    return Array.isArray(entry && entry.capabilities) ? entry.capabilities : [];
  }

  const browserCapabilityCache = Object.create(null);

  function normalizeCapabilityName(value) {
    return String(value == null ? "" : value).trim().toLowerCase();
  }

  function appendCapabilityValues(value, append) {
    if (Array.isArray(value)) {
      for (const item of value) {
        append(item);
      }
      return;
    }
    if (typeof value === "string") {
      for (const item of value.replace(/[,|]/g, " ").split(/\s+/)) {
        append(item);
      }
      return;
    }
    if (value != null) {
      append(value);
    }
  }

  function requiredCapabilityList(entry) {
    const out = [];
    const seen = Object.create(null);
    const append = function(raw) {
      const capability = normalizeCapabilityName(raw);
      if (!capability || seen[capability]) {
        return;
      }
      seen[capability] = true;
      out.push(capability);
    };
    appendCapabilityValues(entry && entry.requiredCapabilities, append);
    appendCapabilityValues(entry && entry.requires, append);
    if (entry && (entry.runtime === "shared" || entry.programRef)) {
      append("wasm");
    }
    return out;
  }

  function runtimeCapabilityStatus(entry) {
    const required = requiredCapabilityList(entry);
    const supported = [];
    const missing = [];
    for (const capability of required) {
      if (browserCapabilitySupported(capability)) {
        supported.push(capability);
      } else {
        missing.push(capability);
      }
    }
    return {
      ok: missing.length === 0,
      requested: capabilityList(entry).slice(),
      required,
      supported,
      missing,
    };
  }

  function engineCapabilityStatus(entry) {
    return runtimeCapabilityStatus(entry);
  }

  function browserCapabilitySupported(capability) {
    const name = normalizeCapabilityName(capability);
    if (!name) {
      return true;
    }
    const dynamicWebGPUFeature = name.indexOf("webgpu:") === 0 || name.indexOf("webgpu-feature:") === 0;
    if (!dynamicWebGPUFeature && Object.prototype.hasOwnProperty.call(browserCapabilityCache, name)) {
      return browserCapabilityCache[name];
    }
    let supported = false;
    try {
      supported = detectBrowserCapability(name);
    } catch (_e) {
      supported = false;
    }
    if (dynamicWebGPUFeature) {
      return Boolean(supported);
    }
    browserCapabilityCache[name] = Boolean(supported);
    return browserCapabilityCache[name];
  }

  function detectBrowserCapability(name) {
    if (name.indexOf("webgpu:adapter-limit:") === 0) {
      return detectWebGPULimitCapability(name.slice("webgpu:adapter-limit:".length), "adapter");
    }
    if (name.indexOf("webgpu:device-limit:") === 0) {
      return detectWebGPULimitCapability(name.slice("webgpu:device-limit:".length), "device");
    }
    if (name.indexOf("webgpu:limit:") === 0) {
      return detectWebGPULimitCapability(name.slice("webgpu:limit:".length), "device");
    }
    if (name.indexOf("webgpu-limit:") === 0) {
      return detectWebGPULimitCapability(name.slice("webgpu-limit:".length), "device");
    }
    if (name.indexOf("webgpu:") === 0) {
      return detectWebGPUFeatureCapability(name.slice("webgpu:".length));
    }
    if (name.indexOf("webgpu-feature:") === 0) {
      return detectWebGPUFeatureCapability(name.slice("webgpu-feature:".length));
    }
    switch (name) {
      case "animation":
        return typeof requestAnimationFrame === "function";
      case "audio":
        return typeof AudioContext === "function" || typeof webkitAudioContext === "function" || canCreateElement("audio");
      case "canvas":
        return canCreateCanvas();
      case "canvas2d":
      case "pixel-surface":
        return canCreateCanvasContext("2d");
      case "compute":
        return browserCapabilitySupported("webgpu") || browserCapabilitySupported("webgl2");
      case "fetch":
        return typeof fetch === "function";
      case "gamepad":
        return Boolean(typeof navigator !== "undefined" && navigator && typeof navigator.getGamepads === "function");
      case "keyboard":
      case "pointer":
        return Boolean(document && typeof document.addEventListener === "function");
      case "pointer-lock":
        return Boolean(
          document &&
          (typeof document.exitPointerLock === "function" || "pointerLockElement" in document) &&
          typeof document.createElement === "function" &&
          typeof document.createElement("canvas").requestPointerLock === "function"
        );
      case "storage":
        return canUseLocalStorage();
      case "text-input":
        return canCreateTextInput();
      case "video":
        return canCreateVideo();
      case "wasm":
        return Boolean(typeof WebAssembly === "object" && WebAssembly && (
          typeof WebAssembly.instantiate === "function" ||
          typeof WebAssembly.instantiateStreaming === "function"
        ));
      case "webgl":
        return canCreateCanvasContext("webgl") || canCreateCanvasContext("experimental-webgl") || canCreateCanvasContext("webgl2");
      case "webgl2":
        return canCreateCanvasContext("webgl2");
      case "webgpu":
        return Boolean(typeof navigator !== "undefined" && navigator && navigator.gpu);
      case "worker":
        return typeof Worker === "function";
      default:
        return false;
    }
  }

  function detectWebGPUFeatureCapability(feature) {
    const normalized = normalizeCapabilityName(feature);
    if (!normalized || !browserCapabilitySupported("webgpu")) {
      return false;
    }
    const diagnostics = typeof window !== "undefined" && typeof window.__gosx_scene3d_webgpu_diagnostics === "function"
      ? window.__gosx_scene3d_webgpu_diagnostics()
      : null;
    if (!diagnostics || diagnostics.ready !== true) {
      return false;
    }
    const deviceFeatures = Array.isArray(diagnostics.deviceFeatures) ? diagnostics.deviceFeatures : [];
    const requestedFeatures = Array.isArray(diagnostics.requestedFeatures) ? diagnostics.requestedFeatures : [];
    return deviceFeatures.indexOf(normalized) >= 0 || requestedFeatures.indexOf(normalized) >= 0;
  }

  function detectWebGPULimitCapability(requirement, scope) {
    if (!browserCapabilitySupported("webgpu")) {
      return false;
    }
    const diagnostics = typeof window !== "undefined" && typeof window.__gosx_scene3d_webgpu_diagnostics === "function"
      ? window.__gosx_scene3d_webgpu_diagnostics()
      : null;
    if (!diagnostics || diagnostics.ready !== true) {
      return false;
    }
    const parsed = parseWebGPULimitRequirement(requirement);
    if (!parsed) {
      return false;
    }
    const primary = scope === "adapter" ? diagnostics.adapterLimits : diagnostics.deviceLimits;
    const fallback = scope === "adapter" ? diagnostics.deviceLimits : diagnostics.adapterLimits;
    let actual = lookupWebGPULimit(primary, parsed.name);
    if (!Number.isFinite(actual)) {
      actual = lookupWebGPULimit(fallback, parsed.name);
    }
    if (!Number.isFinite(actual)) {
      return false;
    }
    switch (parsed.operator) {
      case ">":
        return actual > parsed.value;
      case "<":
        return actual < parsed.value;
      case "<=":
        return actual <= parsed.value;
      case "=":
      case "==":
        return actual === parsed.value;
      case ">=":
      default:
        return actual >= parsed.value;
    }
  }

  function parseWebGPULimitRequirement(requirement) {
    const text = String(requirement || "").trim();
    const match = text.match(/^([a-z0-9_.:-]+)\s*(>=|<=|==|>|<|=|:)\s*([0-9]+(?:\.[0-9]+)?)$/i);
    if (!match) {
      return null;
    }
    const value = Number(match[3]);
    if (!Number.isFinite(value)) {
      return null;
    }
    return {
      name: match[1],
      operator: match[2] === ":" ? ">=" : match[2],
      value,
    };
  }

  function lookupWebGPULimit(limits, name) {
    if (!limits || typeof limits !== "object") {
      return NaN;
    }
    const wanted = normalizeWebGPULimitName(name);
    for (const key of Object.keys(limits)) {
      if (normalizeWebGPULimitName(key) !== wanted) {
        continue;
      }
      const value = Number(limits[key]);
      return Number.isFinite(value) ? value : NaN;
    }
    return NaN;
  }

  function normalizeWebGPULimitName(name) {
    return String(name || "").trim().toLowerCase().replace(/[^a-z0-9]/g, "");
  }

  function canCreateElement(tagName) {
    if (!document || typeof document.createElement !== "function") {
      return false;
    }
    return Boolean(document.createElement(tagName));
  }

  function canCreateCanvas() {
    if (!document || typeof document.createElement !== "function") {
      return false;
    }
    const canvas = document.createElement("canvas");
    return Boolean(canvas && typeof canvas.getContext === "function");
  }

  function canCreateCanvasContext(kind) {
    if (!document || typeof document.createElement !== "function") {
      return false;
    }
    const canvas = document.createElement("canvas");
    if (!canvas || typeof canvas.getContext !== "function") {
      return false;
    }
    return Boolean(canvas.getContext(kind));
  }

  function canCreateTextInput() {
    if (!document || typeof document.createElement !== "function") {
      return false;
    }
    const input = document.createElement("input");
    return Boolean(input && typeof input.focus === "function");
  }

  function canCreateVideo() {
    if (!document || typeof document.createElement !== "function") {
      return false;
    }
    const video = document.createElement("video");
    return Boolean(video && typeof video.canPlayType === "function");
  }

  function canUseLocalStorage() {
    try {
      if (!window || !window.localStorage) {
        return false;
      }
      const key = "__gosx_capability_probe__";
      window.localStorage.setItem(key, "1");
      window.localStorage.removeItem(key);
      return true;
    } catch (_e) {
      return false;
    }
  }

  function applyRuntimeCapabilityState(element, scope, status) {
    if (!element || !status) {
      return;
    }
    const prefix = "data-gosx-" + (scope || "runtime") + "-";
    element.setAttribute(prefix + "capability-state", status.ok ? "ready" : "unsupported");
    element.setAttribute(prefix + "required-capabilities", status.required.join(" "));
    element.setAttribute(prefix + "supported-capabilities", status.supported.join(" "));
    if (status.missing.length > 0) {
      element.setAttribute(prefix + "missing-capabilities", status.missing.join(" "));
    } else if (typeof element.removeAttribute === "function") {
      element.removeAttribute(prefix + "missing-capabilities");
    }
  }

  function activateInputProviders(entry) {
    for (const capability of capabilityList(entry)) {
      activateInputProvider(capability, entry);
    }
  }

  function activateInputProvider(capability, entry) {
    const state = gosxInputState();
    const current = state.providers[capability];
    if (current) {
      current.refCount += 1;
      return;
    }

    const provider = createInputProvider(capability, entry);
    if (!provider) {
      return;
    }

    provider.refCount = 1;
    state.providers[capability] = provider;
  }

  function releaseInputProviders(record) {
    for (const capability of capabilityList(record)) {
      releaseInputProvider(capability);
    }
  }

  function releaseInputProvider(capability) {
    const state = gosxInputState();
    const provider = state.providers[capability];
    if (!provider) return;

    provider.refCount -= 1;
    if (provider.refCount > 0) {
      return;
    }

    if (typeof provider.dispose === "function") {
      provider.dispose();
    }
    delete state.providers[capability];
  }

  function createInputProvider(capability, entry) {
    switch (capability) {
      case "keyboard":
        return createKeyboardInputProvider();
      case "pointer":
        return createPointerInputProvider();
      case "gamepad":
        return createGamepadInputProvider();
      case "text-input":
        return createTextInputProvider(entry);
      default:
        return null;
    }
  }

  function createKeyboardInputProvider() {
    const pressed = new Set();

    function onKey(event) {
      const key = normalizeKeyName(event);
      if (!key) return;
      const active = event.type === "keydown";
      if (active) {
        pressed.add(key);
      } else {
        pressed.delete(key);
      }
      queueInputSignal("$input.key." + key, active);
    }

    function onBlur() {
      for (const key of Array.from(pressed)) {
        queueInputSignal("$input.key." + key, false);
      }
      pressed.clear();
    }

    return bindInputProviderListeners([
      [document, "keydown", onKey],
      [document, "keyup", onKey],
      [window, "blur", onBlur],
    ]);
  }

  function createPointerInputProvider() {
    const state = { lastX: null, lastY: null };

    function publishPointer(event) {
      publishPointerSignals(resolvePointerSample(event, state), event);
    }

    function onBlur() {
      resetPointerSignals();
    }

    return bindInputProviderListeners([
      [document, "pointermove", publishPointer],
      [document, "pointerdown", publishPointer],
      [document, "pointerup", publishPointer],
      [window, "blur", onBlur],
    ]);
  }

  function createGamepadInputProvider() {
    let active = true;
    let frameHandle = 0;

    function pollGamepad() {
      if (!active) return;
      const navigatorRef = window.navigator;
      if (navigatorRef && typeof navigatorRef.getGamepads === "function") {
        const pads = navigatorRef.getGamepads() || [];
        let connected = 0;
        for (let i = 0; i < 2; i++) {
          const pad = pads[i];
          if (pad && pad.connected !== false) {
            connected += 1;
            publishGamepadSignals(pad, i);
          } else {
            queueInputSignal("$input.gamepad" + i + ".connected", false);
          }
        }
        queueInputSignal("$input.gamepad.count", connected);
      }
      frameHandle = engineFrame(pollGamepad);
    }

    frameHandle = engineFrame(pollGamepad);

    return {
      dispose() {
        active = false;
        if (frameHandle) {
          cancelEngineFrame(frameHandle);
          frameHandle = 0;
        }
      },
    };
  }

  function createTextInputProvider(entry) {
    var inputEl = null;
    var mount = null;
    var unsubCursorRect = null;
    var unsubClipboard = null;
    var viewportListener = null;

    var mountID = entry && (entry.mountId || entry.id);
    mount = mountID ? document.getElementById(mountID) : null;
    if (!mount) {
      mount = document.body;
    }

    inputEl = document.createElement("div");
    inputEl.contentEditable = "true";
    inputEl.setAttribute("role", "textbox");
    inputEl.setAttribute("aria-multiline", "true");
    inputEl.style.cssText = "position:absolute;opacity:0;width:1px;height:1em;overflow:hidden;white-space:pre;pointer-events:none;z-index:-1";
    if (!mount.style.position || mount.style.position === "static") {
      mount.style.position = "relative";
    }
    mount.appendChild(inputEl);

    function focusInput(e) {
      if (e.target !== inputEl) inputEl.focus();
    }

    mount.addEventListener("mousedown", focusInput);
    mount.addEventListener("touchstart", focusInput);

    inputEl.addEventListener("beforeinput", function(e) {
      var type = e.inputType;
      if (type === "insertText" || type === "insertReplacementText") {
        e.preventDefault();
        if (e.data) queueInputSignal("$input.text.inserted", e.data);
      } else if (type === "insertFromPaste") {
        e.preventDefault();
        var text = e.dataTransfer ? e.dataTransfer.getData("text/plain") : "";
        if (text) queueInputSignal("$input.clipboard.paste", text);
      } else if (type === "deleteContentBackward") {
        e.preventDefault();
        queueInputSignal("$input.command", "delete_backward");
      } else if (type === "deleteContentForward") {
        e.preventDefault();
        queueInputSignal("$input.command", "delete_forward");
      } else if (type === "insertLineBreak" || type === "insertParagraph") {
        e.preventDefault();
        queueInputSignal("$input.command", "newline");
      }
      requestAnimationFrame(function() { if (inputEl) inputEl.textContent = ""; });
    });

    inputEl.addEventListener("compositionstart", function() {
      queueInputSignal("$input.text.composition_active", true);
    });
    inputEl.addEventListener("compositionupdate", function(e) {
      queueInputSignal("$input.text.composing", e.data || "");
    });
    inputEl.addEventListener("compositionend", function(e) {
      queueInputSignal("$input.text.composition_active", false);
      queueInputSignal("$input.text.composing", "");
      if (e.data) queueInputSignal("$input.text.inserted", e.data);
    });

    inputEl.addEventListener("keydown", function(e) {
      if (e.isComposing) return;
      var mod = e.metaKey || e.ctrlKey;
      var shift = e.shiftKey;
      var command = null;

      switch (e.key) {
        case "ArrowUp":    command = shift ? "select_up" : "move_up"; break;
        case "ArrowDown":  command = shift ? "select_down" : "move_down"; break;
        case "ArrowLeft":  command = shift ? "select_left" : "move_left"; break;
        case "ArrowRight": command = shift ? "select_right" : "move_right"; break;
        case "Home":       command = shift ? "select_line_start" : "move_line_start"; break;
        case "End":        command = shift ? "select_line_end" : "move_line_end"; break;
        case "Tab":        command = shift ? "dedent" : "indent"; break;
        case "Escape":     command = "escape"; break;
      }

      if (!command && mod) {
        switch (e.key.toLowerCase()) {
          case "z": command = shift ? "redo" : "undo"; break;
          case "a": command = "select_all"; break;
          case "s": command = "save"; break;
          case "b": command = "bold"; break;
          case "i": command = "italic"; break;
        }
      }

      if (command) {
        e.preventDefault();
        queueInputSignal("$input.command", command);
      }
    });

    mount.addEventListener("dragover", function(e) { e.preventDefault(); });
    mount.addEventListener("drop", function(e) {
      e.preventDefault();
      var files = e.dataTransfer ? e.dataTransfer.files : null;
      if (files && files.length > 0) {
        var file = files[0];
        if (file.type.startsWith("image/")) {
          var reader = new FileReader();
          reader.onload = function() {
            queueInputSignal("$editor.file_drop", JSON.stringify({
              name: file.name, type: file.type, size: file.size, data: reader.result
            }));
          };
          reader.readAsDataURL(file);
        }
      }
    });

    if (window.visualViewport) {
      viewportListener = function() {
        var kh = window.innerHeight - window.visualViewport.height;
        queueInputSignal("$input.keyboard_height", Math.max(0, kh));
      };
      window.visualViewport.addEventListener("resize", viewportListener, { passive: true });
    }

    unsubCursorRect = gosxSubscribeSharedSignal("$editor.cursor_rect", function(rect) {
      if (!inputEl) return;
      var r = typeof rect === "string" ? JSON.parse(rect) : rect;
      if (r) {
        inputEl.style.left = (r.x || 0) + "px";
        inputEl.style.top = (r.y || 0) + "px";
        inputEl.style.height = (r.height || 20) + "px";
      }
    });

    unsubClipboard = gosxSubscribeSharedSignal("$editor.clipboard_content", function(text) {
      if (!inputEl || !text) return;
      inputEl.textContent = text;
      var range = document.createRange();
      range.selectNodeContents(inputEl);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    });

    inputEl.focus();

    return {
      dispose: function() {
        if (unsubCursorRect) { unsubCursorRect(); unsubCursorRect = null; }
        if (unsubClipboard) { unsubClipboard(); unsubClipboard = null; }
        if (viewportListener && window.visualViewport) {
          window.visualViewport.removeEventListener("resize", viewportListener);
          viewportListener = null;
        }
        if (mount) {
          mount.removeEventListener("mousedown", focusInput);
          mount.removeEventListener("touchstart", focusInput);
        }
        if (inputEl && inputEl.parentNode) {
          inputEl.parentNode.removeChild(inputEl);
        }
        inputEl = null;
        mount = null;
      },
    };
  }

  function bindInputProviderListeners(bindings) {
    for (const binding of bindings) {
      binding[0].addEventListener(binding[1], binding[2]);
    }
    return {
      dispose() {
        for (const binding of bindings) {
          binding[0].removeEventListener(binding[1], binding[2]);
        }
      },
    };
  }

  function normalizeKeyName(event) {
    const raw = event && (event.key || event.code);
    if (!raw) return "";
    return String(raw).trim().toLowerCase();
  }

  function resolvePointerSample(event, state) {
    const previousX = state.lastX == null ? 0 : state.lastX;
    const previousY = state.lastY == null ? 0 : state.lastY;
    const x = sceneNumber(event && event.clientX, previousX);
    const y = sceneNumber(event && event.clientY, previousY);
    const sample = {
      x,
      y,
      deltaX: sceneNumber(event && event.movementX, state.lastX == null ? 0 : x - previousX),
      deltaY: sceneNumber(event && event.movementY, state.lastY == null ? 0 : y - previousY),
      buttons: event && typeof event.buttons !== "undefined" ? sceneNumber(event.buttons, 0) : null,
      button: event && typeof event.button === "number" ? event.button : null,
      active: event ? event.type !== "pointerup" : false,
    };
    state.lastX = x;
    state.lastY = y;
    return sample;
  }

  function publishPointerSignals(sample, event) {
    queueInputSignal("$input.pointer.x", sample.x);
    queueInputSignal("$input.pointer.y", sample.y);
    queueInputSignal("$input.pointer.deltaX", sample.deltaX);
    queueInputSignal("$input.pointer.deltaY", sample.deltaY);
    if (sample.buttons != null) {
      queueInputSignal("$input.pointer.buttons", sample.buttons);
    }
    if (sample.button != null) {
      queueInputSignal("$input.pointer.button" + sample.button, sample.active);
    }
  }

  function resetPointerSignals() {
    queueInputSignal("$input.pointer.deltaX", 0);
    queueInputSignal("$input.pointer.deltaY", 0);
    queueInputSignal("$input.pointer.buttons", 0);
  }

  function publishGamepadSignals(pad, slot) {
    const prefix = "$input.gamepad" + Math.max(0, Math.floor(sceneNumber(slot, 0)));
    const axes = Array.isArray(pad.axes) ? pad.axes : [];
    queueInputSignal(prefix + ".connected", true);
    queueInputSignal(prefix + ".leftX", sceneNumber(axes[0], 0));
    queueInputSignal(prefix + ".leftY", sceneNumber(axes[1], 0));
    queueInputSignal(prefix + ".rightX", sceneNumber(axes[2], 0));
    queueInputSignal(prefix + ".rightY", sceneNumber(axes[3], 0));
    queueInputSignal(prefix + ".dpadUp", gamepadButtonPressed(pad, 12));
    queueInputSignal(prefix + ".dpadDown", gamepadButtonPressed(pad, 13));
    queueInputSignal(prefix + ".dpadLeft", gamepadButtonPressed(pad, 14));
    queueInputSignal(prefix + ".dpadRight", gamepadButtonPressed(pad, 15));
    queueInputSignal(prefix + ".buttonA", gamepadButtonPressed(pad, 0));
    queueInputSignal(prefix + ".buttonB", gamepadButtonPressed(pad, 1));
    queueInputSignal(prefix + ".buttonX", gamepadButtonPressed(pad, 2));
    queueInputSignal(prefix + ".buttonY", gamepadButtonPressed(pad, 3));
    queueInputSignal(prefix + ".buttonLB", gamepadButtonPressed(pad, 4));
    queueInputSignal(prefix + ".buttonRB", gamepadButtonPressed(pad, 5));
  }

  function gamepadButtonPressed(pad, index) {
    return Boolean(pad && pad.buttons && pad.buttons[index] && pad.buttons[index].pressed);
  }

  function sceneNumber(value, fallback) {
    const num = Number(value);
    return Number.isFinite(num) ? num : fallback;
  }

  function sceneBool(value, fallback) {
    if (typeof value === "boolean") return value;
    if (typeof value === "string") {
      const lowered = value.trim().toLowerCase();
      if (lowered === "true") return true;
      if (lowered === "false") return false;
    }
    return fallback;
  }

  function clearChildren(node) {
    while (node && node.firstChild) {
      node.removeChild(node.firstChild);
    }
  }

  const bootstrapFeatureFactories = window.__gosx_bootstrap_features || Object.create(null);
  const activeBootstrapFeatures = new Map();
  let pendingFeatureLoad = Promise.resolve([]);

  window.__gosx_bootstrap_features = bootstrapFeatureFactories;
  window.__gosx_register_bootstrap_feature = function(name, factory) {
    const featureName = String(name || "").trim();
    if (!featureName || typeof factory !== "function") {
      console.error("[gosx] invalid bootstrap feature registration");
      return;
    }
    bootstrapFeatureFactories[featureName] = factory;
  };

  function hasAttributeName(el, attr) {
    return Boolean(el && el.hasAttribute && el.hasAttribute(attr));
  }

  function bootstrapFeatureAPI() {
    return {
      engineFactories,
      fetchProgram,
      inferProgramFormat,
      engineFrame,
      cancelEngineFrame,
      capabilityList,
      requiredCapabilityList,
      runtimeCapabilityStatus,
      engineCapabilityStatus,
      browserCapabilitySupported,
      applyRuntimeCapabilityState,
      activateInputProviders,
      releaseInputProviders,
      clearChildren,
      sceneNumber,
      sceneBool,
      gosxReadSharedSignal,
      gosxNotifySharedSignal,
      gosxSubscribeSharedSignal,
      setSharedSignalJSON,
      setSharedSignalValue,
    };
  }

  function runtimeFeatureAssets() {
    if (window.__gosx && window.__gosx.document && typeof window.__gosx.document.get === "function") {
      const state = window.__gosx.document.get();
      if (state && state.assets && state.assets.runtime) {
        return state.assets.runtime;
      }
    }
    return {};
  }

  function runtimeFeaturePreloadPath(fileName) {
    const head = document && document.head;
    const nodes = head && head.children ? Array.from(head.children) : [];
    for (const node of nodes) {
      if (!node || String(node.tagName || "").toUpperCase() !== "LINK") {
        continue;
      }
      const rel = String((node.getAttribute && node.getAttribute("rel")) || node.rel || "").toLowerCase();
      const as = String((node.getAttribute && node.getAttribute("as")) || node.as || "").toLowerCase();
      const href = String((node.getAttribute && node.getAttribute("href")) || node.href || "");
      if (rel === "preload" && as === "script" && href.includes(fileName)) {
        return href;
      }
    }
    return "";
  }

  function bootstrapFeatureURL(name) {
    const assets = runtimeFeatureAssets();
    switch (name) {
      case "islands":
        return String(assets.bootstrapFeatureIslandsPath || runtimeFeaturePreloadPath("bootstrap-feature-islands") || "/gosx/bootstrap-feature-islands.js").trim();
      case "engines":
        return String(assets.bootstrapFeatureEnginesPath || runtimeFeaturePreloadPath("bootstrap-feature-engines") || "/gosx/bootstrap-feature-engines.js").trim();
      case "hubs":
        return String(assets.bootstrapFeatureHubsPath || runtimeFeaturePreloadPath("bootstrap-feature-hubs") || "/gosx/bootstrap-feature-hubs.js").trim();
      case "scene3d":
        return assets && assets.bootstrapFeatureScene3dPath;
      default:
        return "";
    }
  }

  async function ensureBootstrapFeature(name) {
    if (activeBootstrapFeatures.has(name)) {
      return activeBootstrapFeatures.get(name);
    }

    if (name === "scene3d") {
      if (!window.__gosx_scene3d_available) {
        await new Promise(function(resolve) {
          if (window.__gosx_scene3d_available) { resolve(); return; }
          var prev = window.__gosx_scene3d_loaded;
          window.__gosx_scene3d_loaded = function() {
            if (typeof prev === "function") { prev(); }
            resolve();
          };
        });
      }
      var scene3dFeature = { name: "scene3d" };
      activeBootstrapFeatures.set(name, scene3dFeature);
      return scene3dFeature;
    }

    let factory = bootstrapFeatureFactories[name];
    if (!factory) {
      const jsRef = bootstrapFeatureURL(name);
      if (!jsRef) {
        return null;
      }
      await loadScriptTag(jsRef);
      factory = bootstrapFeatureFactories[name];
    }

    if (typeof factory !== "function") {
      console.error("[gosx] missing bootstrap feature:", name);
      return null;
    }

    try {
      const feature = factory(bootstrapFeatureAPI()) || {};
      activeBootstrapFeatures.set(name, feature);
      return feature;
    } catch (error) {
      console.error("[gosx] failed to initialize bootstrap feature " + name + ":", error);
      return null;
    }
  }

  function manifestFeatureNames(manifest) {
    const names = [];
    if (manifestHasEntries(manifest, "engines")) {
      names.push("engines");
      for (var i = 0; i < manifest.engines.length; i++) {
        if (manifest.engines[i].component === "GoSXScene3D") {
          names.push("scene3d");
          break;
        }
      }
    }
    if (manifestHasEntries(manifest, "hubs")) {
      names.push("hubs");
    }
    if (manifestHasEntries(manifest, "islands") || manifestHasEntries(manifest, "computeIslands")) {
      names.push("islands");
    }
    return names;
  }

  function manifestHasEntries(manifest, key) {
    return Boolean(manifest && manifest[key] && manifest[key].length > 0);
  }

  function manifestNeedsWASMRuntime(manifest) {
    return manifestHasEntries(manifest, "islands") || manifestHasEntries(manifest, "computeIslands") || manifestNeedsSharedEngineRuntime(manifest);
  }

  function manifestNeedsSharedEngineRuntime(manifest) {
    if (!manifestHasEntries(manifest, "engines")) {
      return false;
    }
    return manifest.engines.some(function(entry) {
      return entry && entry.runtime === "shared";
    });
  }

  function setSharedSignalJSON(name, valueJSON) {
    const signalName = String(name || "").trim();
    if (!signalName) {
      return null;
    }

    const setSharedSignal = window.__gosx_set_shared_signal;
    if (typeof setSharedSignal === "function") {
      try {
        const result = setSharedSignal(signalName, valueJSON);
        if (typeof result === "string" && result !== "") {
          console.error("[gosx] shared signal update error (" + signalName + "):", result);
          gosxNotifySharedSignal(signalName, valueJSON);
        }
        return result;
      } catch (error) {
        console.error("[gosx] shared signal update error (" + signalName + "):", error);
      }
    }

    gosxNotifySharedSignal(signalName, valueJSON);
    return null;
  }

  function setSharedSignalValue(name, value) {
    return setSharedSignalJSON(name, JSON.stringify(value == null ? null : value));
  }

  function ensureManifestFeatures(manifest) {
    const names = manifestFeatureNames(manifest);
    if (names.length === 0) {
      return Promise.resolve([]);
    }
    return Promise.all(names.map(function(name) {
      return ensureBootstrapFeature(name);
    })).then(function(features) {
      return features.filter(Boolean);
    });
  }

  async function runRuntimeReadyForPendingManifest() {
    if (typeof window.__gosx_text_layout === "function" && window.__gosx_text_layout !== gosxTextLayout) {
      adoptTextLayoutImpl(window.__gosx_text_layout);
      window.__gosx_text_layout = gosxTextLayout;
    }
    if (typeof window.__gosx_text_layout_metrics === "function" && window.__gosx_text_layout_metrics !== gosxTextLayoutMetrics) {
      adoptTextLayoutMetricsImpl(window.__gosx_text_layout_metrics);
      window.__gosx_text_layout_metrics = gosxTextLayoutMetrics;
    }
    if (typeof window.__gosx_text_layout_ranges === "function" && window.__gosx_text_layout_ranges !== gosxTextLayoutRanges) {
      adoptTextLayoutRangesImpl(window.__gosx_text_layout_ranges);
      window.__gosx_text_layout_ranges = gosxTextLayoutRanges;
    }
    refreshManagedTextLayouts();
    refreshGosxDocumentState("runtime-ready");
    refreshGosxEnvironmentState("runtime-ready");
    if (!pendingManifest) {
      window.__gosx.ready = true;
      refreshGosxDocumentState("ready");
      return;
    }

    const manifest = pendingManifest;
    const features = await pendingFeatureLoad;
    await Promise.all(features.map(function(feature) {
      if (!feature || typeof feature.runtimeReady !== "function") {
        return null;
      }
      return feature.runtimeReady(manifest);
    }));
    window.__gosx.ready = true;
    refreshGosxDocumentState("ready");
    document.dispatchEvent(new CustomEvent("gosx:ready"));
  }

  window.__gosx_runtime_ready = function() {
    runRuntimeReadyForPendingManifest().catch(function(error) {
      console.error("[gosx] bootstrap failed:", error);
      window.__gosx.ready = true;
      refreshGosxDocumentState("ready");
    });
  };

  async function disposePage() {
    for (const feature of Array.from(activeBootstrapFeatures.values())) {
      if (feature && typeof feature.disposePage === "function") {
        feature.disposePage();
      }
    }
    disposeManagedMotion();
    disposeManagedTextLayouts();
    pendingManifest = null;
    pendingFeatureLoad = Promise.resolve([]);
    window.__gosx.ready = false;
  }

  async function bootstrapPage() {
    refreshGosxEnvironmentState("bootstrap-page");
    refreshGosxDocumentState("bootstrap-page");
    mountManagedMotion(document.body || document.documentElement);
    mountManagedTextLayouts(document.body || document.documentElement);

    const manifest = loadManifest();
    if (!manifest) {
      pendingManifest = null;
      pendingFeatureLoad = Promise.resolve([]);
      window.__gosx.ready = true;
      refreshGosxDocumentState("ready");
      return;
    }

    pendingManifest = manifest;
    pendingFeatureLoad = ensureManifestFeatures(manifest);
    window.__gosx.ready = false;

    if (manifestNeedsWASMRuntime(manifest)) {
      if (!manifest.runtime || !manifest.runtime.path) {
        console.error("[gosx] islands, compute islands, and shared runtime engines require manifest.runtime.path");
        window.__gosx_runtime_ready();
        return;
      }
      if (runtimeReady()) {
        window.__gosx_runtime_ready();
        return;
      }
      await Promise.all([
        pendingFeatureLoad,
        loadRuntime(manifest.runtime),
      ]);
      return;
    }

    await pendingFeatureLoad;
    window.__gosx_runtime_ready();
  }

  window.__gosx_bootstrap_page = bootstrapPage;
  window.__gosx_dispose_page = disposePage;

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bootstrapPage);
  } else {
    bootstrapPage();
  }
})();
