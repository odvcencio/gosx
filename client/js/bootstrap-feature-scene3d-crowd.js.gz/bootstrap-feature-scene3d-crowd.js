const SCENE_CROWD_RECORD_BYTES=32,SCENE_CROWD_BLOCK_SEATS=128,SCENE_CROWD_MAX_SEATS=2e5,SCENE_CROWD_MAX_SECTIONS=1024,SCENE_CROWD_THRESHOLD_ONE=16777216,SCENE_CROWD_ROLL={fill:1,color:2,accent:3,prop:4,variant:5,phase:6,eager:7,yaw:8,jitterX:9,jitterZ:10};function sceneCrowdHash(e){let t=e>>>0;return t^=t>>>16,t=Math.imul(t,2146121005)>>>0,t^=t>>>15,t=Math.imul(t,2221713035)>>>0,t^=t>>>16,t>>>0}function sceneCrowdRoll(e,t){return sceneCrowdHash((e^sceneCrowdHash(t))>>>0)>>>8}function sceneCrowdPieceAt(e,t,o,n){if(!e.corner){n[0]=e.px+e.tx*t+e.nx*o,n[1]=e.pz+e.tz*t+e.nz*o,n[2]=e.nx,n[3]=e.nz;return}const s=e.angle+e.sign*(t/e.radius),r=Math.cos(s),i=Math.sin(s),a=e.radius+o;n[0]=e.cx+a*r,n[1]=e.cz+a*i,n[2]=r,n[3]=i}function sceneCrowdPieceFactor(e,t){return e.corner?(e.radius+t)/e.radius:1}function sceneCrowdPieceSplit(e,t,o){const n=Object.assign({},e);return n.length=o-t,e.corner?n.angle=e.angle+e.sign*(t/e.radius):(n.px=e.px+e.tx*t,n.pz=e.pz+e.tz*t),n}function sceneCrowdNewPiece(e){return Object.assign({corner:!1,base:0,length:0,px:0,pz:0,tx:0,tz:0,nx:0,nz:0,cx:0,cz:0,radius:0,angle:0,sign:1},e)}function sceneCrowdBowlLoop(e){const t=e.halfWidth,o=e.halfDepth,n=e.corner,s=t-n,r=o-n,i=Math.PI/2,a=e.centerX||0,c=e.centerZ||0,f=[sceneCrowdNewPiece({px:a+t,pz:c,tx:0,tz:1,nx:1,nz:0,length:r}),sceneCrowdNewPiece({corner:!0,cx:a+s,cz:c+r,radius:n,angle:0,sign:1,length:i*n}),sceneCrowdNewPiece({px:a+s,pz:c+o,tx:-1,tz:0,nx:0,nz:1,length:2*s}),sceneCrowdNewPiece({corner:!0,cx:a-s,cz:c+r,radius:n,angle:i,sign:1,length:i*n}),sceneCrowdNewPiece({px:a-t,pz:c+r,tx:0,tz:-1,nx:-1,nz:0,length:2*r}),sceneCrowdNewPiece({corner:!0,cx:a-s,cz:c-r,radius:n,angle:Math.PI,sign:1,length:i*n}),sceneCrowdNewPiece({px:a-s,pz:c-o,tx:1,tz:0,nx:0,nz:-1,length:2*s}),sceneCrowdNewPiece({corner:!0,cx:a+s,cz:c-r,radius:n,angle:3*i,sign:1,length:i*n}),sceneCrowdNewPiece({px:a+t,pz:c-r,tx:0,tz:1,nx:1,nz:0,length:r})],l=[];let u=0;for(const d of f)d.length<=1e-9||(d.base=u,u+=d.length,l.push(d));return{pieces:l,total:u}}function sceneCrowdPath(e){if(e.shape==="line"){const c=e.x0||0,f=e.z0||0,l=(e.x1||0)-c,u=(e.z1||0)-f,d=Math.sqrt(l*l+u*u),y=l/d,x=u/d;let _=-x,p=y;const w=c+l/2-(e.facingX||0),m=f+u/2-(e.facingZ||0);return _*w+p*m<0&&(_=-_,p=-p),{pieces:[sceneCrowdNewPiece({px:c,pz:f,tx:y,tz:x,nx:_,nz:p,length:d})],length:d,closed:!1}}if(e.shape==="arc"){const c=e.startAngle||0,f=(e.endAngle||0)-c,l=Math.abs(f)*e.radius;return{pieces:[sceneCrowdNewPiece({corner:!0,cx:e.centerX||0,cz:e.centerZ||0,radius:e.radius,angle:c,sign:f<0?-1:1,length:l})],length:l,closed:!1}}const t=sceneCrowdBowlLoop(e),o=e.loopStart||0,n=e.loopEnd||0;if(o===n)return{pieces:t.pieces,length:t.total,closed:!0};const s=o*t.total;let r=n*t.total;r<=s&&(r+=t.total);const i=[];let a=0;for(let c=0;c<2;c++){const f=c*t.total;for(const l of t.pieces){const u=l.base+f,d=u+l.length,y=Math.max(u,s),x=Math.min(d,r);if(x-y<=1e-9)continue;const _=sceneCrowdPieceSplit(l,y-u,x-u);_.base=a,a+=_.length,i.push(_)}}return{pieces:i,length:a,closed:!1}}function sceneCrowdPathPoint(e,t,o,n,s,r){let i=null,a=0;for(const c of e){const f=Math.max(c.base,t),l=Math.min(c.base+c.length,o);if(l<=f)continue;const u=sceneCrowdPieceFactor(c,s),d=(l-f)*u;if(i=c,a=l-c.base,n<=d){sceneCrowdPieceAt(c,f-c.base+n/u,s,r);return}n-=d}i&&sceneCrowdPieceAt(i,a,s,r)}function sceneCrowdSpans(e,t){let o=0;for(let r=0;r<t.sectionCount;r++)o+=e.sections[t.firstSection+r].span;const n=[0];let s=0;for(let r=0;r<t.sectionCount;r++)s+=e.sections[t.firstSection+r].span,n.push(s/o);return n[t.sectionCount]=1,n}function sceneCrowdSlot(e,t){for(let o=0;o<t.length;o++)if(e<t[o])return o;return 0}function sceneCrowdPropFor(e,t){for(let o=0;o<4;o++)if(e<t[o])return o+1;return 0}function sceneCrowdLayout(e,t){const o={index:0,seat:0,section:0,stand:0,row:0,x:0,y:0,z:0,yaw:0,wave:0,seed:0,color:0,accent:0,prop:0,variant:0,phase:0,eagerness:0},n=new Float64Array(4),s=(e.seed||0)>>>0;let r=0,i=0,a=!1;function c(){const u=sceneCrowdHash(s+Math.imul(r+1,2654435769)>>>0);return r++,u}function f(u,d,y,x,_,p,w,m){const E=e.sections[y];if(sceneCrowdRoll(u,SCENE_CROWD_ROLL.fill)>=E.fill)return;if(i>=2e5){a=!0;return}m+=(sceneCrowdRoll(u,SCENE_CROWD_ROLL.yaw)/16777216-.5)*.14;let v=Math.atan2(w,_)/(2*Math.PI);v<0&&(v+=1),v>=1&&(v=0),o.index=i,o.seat=r-1,o.section=y,o.stand=d,o.row=x,o.x=_,o.y=p,o.z=w,o.yaw=m,o.wave=v,o.seed=u,o.color=sceneCrowdSlot(sceneCrowdRoll(u,SCENE_CROWD_ROLL.color),E.colorThresholds),o.accent=sceneCrowdSlot(sceneCrowdRoll(u,SCENE_CROWD_ROLL.accent),E.accentThresholds),o.prop=sceneCrowdPropFor(sceneCrowdRoll(u,SCENE_CROWD_ROLL.prop),E.propThresholds),o.variant=sceneCrowdRoll(u,SCENE_CROWD_ROLL.variant)>>>16,o.phase=sceneCrowdRoll(u,SCENE_CROWD_ROLL.phase)>>>8,o.eagerness=sceneCrowdRoll(u,SCENE_CROWD_ROLL.eager)>>>16,i++,t(o)}const l=Array.isArray(e.stands)?e.stands:[];for(let u=0;u<l.length&&!a;u++){const d=l[u],y=sceneCrowdSpans(e,d);if(d.shape==="floor"){const w=1/Math.sqrt(d.density),m=Math.floor(2*d.halfWidth/w+1e-9),E=Math.floor(2*d.halfDepth/w+1e-9);if(m<1||E<1)continue;const v=(d.centerX||0)-d.halfWidth+(2*d.halfWidth-m*w)/2,h=(d.centerZ||0)-d.halfDepth+(2*d.halfDepth-E*w)/2;for(let g=0;g<d.sectionCount;g++){const C=Math.floor(y[g]*m+.5),S=Math.floor(y[g+1]*m+.5);for(let b=0;b<E;b++)for(let A=C;A<S;A++){const P=c(),M=(sceneCrowdRoll(P,SCENE_CROWD_ROLL.jitterX)/16777216-.5)*.6,T=(sceneCrowdRoll(P,SCENE_CROWD_ROLL.jitterZ)/16777216-.5)*.6,R=v+(A+.5+M)*w,U=h+(b+.5+T)*w;f(P,u,d.firstSection+g,b,R,d.frontHeight||0,U,Math.atan2((d.facingX||0)-R,(d.facingZ||0)-U))}}continue}const x=sceneCrowdPath(d),_=d.aisleWidth/2,p=d.seatWidth;for(let w=0;w<d.sectionCount;w++){const m=d.firstSection+w,E=y[w]*x.length,v=y[w+1]*x.length,h=!x.closed&&w===0?0:_,g=!x.closed&&w===d.sectionCount-1?0:_;for(let C=0;C<d.rows;C++){const S=(C+.5)*d.rowDepth,b=d.frontHeight+C*d.rowRise;let A=0;for(const R of x.pieces){const U=Math.max(R.base,E),D=Math.min(R.base+R.length,v);D>U&&(A+=(D-U)*sceneCrowdPieceFactor(R,S))}const P=A-h-g,M=Math.floor(P/p+1e-9);if(M<1)continue;const T=h+(P-M*p)/2;for(let R=0;R<M;R++)sceneCrowdPathPoint(x.pieces,E,v,T+(R+.5)*p,S,n),f(c(),u,m,C,n[0],b,n[1],Math.atan2(-n[2],-n[3]))}}}return a?-1:i}function sceneCrowdPack(e){const t=Array.isArray(e.sections)?e.sections.length:0;if(t<1||t>1024)return{error:"crowd has "+t+" sections"};const o=Math.max(0,Math.min(2e5,e.seats|0));let n=Math.max(1,o),s=new ArrayBuffer(n*32),r=new Float32Array(s),i=new Uint16Array(s),a=new Uint8Array(s);const c=[],f=[],l=new Uint32Array(t);let u=0,d=-1,y=0,x=0,_=0,p=0,w=0,m=0;function E(h){if(d<0||h<=u)return;c.push(u,h-u,d);const g=(y+p)/2,C=(x+w)/2,S=(_+m)/2;f.push(g,C+.9,S,Math.hypot(p-g,w-C,m-S)+1.4)}const v=sceneCrowdLayout(e,function(h){const g=h.index;if(g>=n){n*=2;const b=new ArrayBuffer(n*32);new Uint8Array(b).set(a),s=b,r=new Float32Array(s),i=new Uint16Array(s),a=new Uint8Array(s)}h.section!==d||g-u>=128?(E(g),u=g,d=h.section,y=p=h.x,x=w=h.y,_=m=h.z):(h.x<y&&(y=h.x),h.x>p&&(p=h.x),h.y<x&&(x=h.y),h.y>w&&(w=h.y),h.z<_&&(_=h.z),h.z>m&&(m=h.z));const C=g*8;r[C]=h.x,r[C+1]=h.y,r[C+2]=h.z,r[C+3]=h.yaw,r[C+4]=h.wave,i[C*2+10]=h.section,i[C*2+11]=h.phase;const S=g*32;a[S+24]=h.color,a[S+25]=h.accent,a[S+26]=h.prop,a[S+27]=h.variant,a[S+28]=h.eagerness,a[S+29]=0,a[S+30]=0,a[S+31]=0,l[h.section]++});return v<0?{error:"crowd passes 200000 seats"}:(E(v),{count:v,records:new Uint8Array(s,0,v*32),blocks:new Uint32Array(c),spheres:new Float32Array(f),sectionFans:l,mismatch:o!==v})}const SCENE_CROWD_JOINTS=11,SCENE_CROWD_SEGMENTS=24,SCENE_CROWD_VERTEX_BYTES=36,SCENE_CROWD_ACTIONS=[["idle",4,-1],["stand",3,-1],["cheer",.8,.25],["clap",.5,.5],["wave-arms",1.6,-1],["jump",.7,.92],["twirl",.6,-1],["hold-up",2.4,-1],["wave",1,.5]],SCENE_CROWD_WAVE_ACTION=8,SCENE_CROWD_PARENTS=[-1,0,1,1,3,1,5,0,7,0,9],SCENE_CROWD_PIVOTS=[[0,.95,0],[0,.97,0],[0,1.47,0],[.22,1.42,0],[.22,1.13,0],[-.22,1.42,0],[-.22,1.13,0],[.1,.92,0],[.1,.49,0],[-.1,.92,0],[-.1,.49,0]];function sceneCrowdZeroPose(){const e=[];for(let t=0;t<SCENE_CROWD_JOINTS;t++)e.push([0,0,0]);return{root:[0,0,0],angles:e}}function sceneCrowdArms(e,t,o,n,s,r,i){e.angles[3]=[t,0,o],e.angles[4]=[n,0,0],e.angles[5]=[s,0,-r],e.angles[6]=[i,0,0]}function sceneCrowdSit(e){e.root=[0,-.45,-.06],e.angles[7]=[-1.5,0,.04],e.angles[8]=[1.5,0,0],e.angles[9]=[-1.5,0,-.04],e.angles[10]=[1.5,0,0],sceneCrowdArms(e,-.45,.05,-1,-.45,.05,-1)}const SCENE_CROWD_TAU=Math.PI*2;function sceneCrowdActionPose(e,t){const o=sceneCrowdZeroPose(),n=Math.sin(SCENE_CROWD_TAU*t),s=Math.cos(SCENE_CROWD_TAU*t);switch(e){case 0:sceneCrowdSit(o),o.angles[1]=[.02*n,0,.03*Math.sin(SCENE_CROWD_TAU*2*t)],o.angles[2]=[.05*s,.3*n,0];break;case 1:o.root=[.025*n,0,0],o.angles[1]=[0,0,-.04*n],o.angles[2]=[.08*Math.sin(SCENE_CROWD_TAU*2*t),.15*s,0],sceneCrowdArms(o,-.12,.08,-.15,-.12,.08,-.15);break;case 2:{const r=.5+.5*s;o.root=[0,.05*r,0],o.angles[1]=[-.1,0,0],o.angles[2]=[-.25,0,0],sceneCrowdArms(o,-2.55-.35*r,.3,-.9+.8*r,-2.55-.35*r,.3,-.9+.8*r);break}case 3:{const r=.5+.5*s;o.angles[1]=[.05,0,0],sceneCrowdArms(o,-.95,-.15+.5*r,-1,-.95,-.15+.5*r,-1);break}case 4:o.angles[1]=[0,0,.1*n],o.root=[.03*n,0,0],sceneCrowdArms(o,-2.9,.15+.45*n,-.2,-2.9,.15-.45*n,-.2);break;case 5:{let r=0,i=0;t<.15?i=Math.sin(Math.PI*t/.15):t<.92?r=Math.sin(Math.PI*(t-.15)/.77):i=Math.sin(Math.PI*(t-.92)/.08),o.root=[0,.32*r-.14*i,0],o.angles[7]=[-.7*i,0,.03],o.angles[8]=[1.3*i,0,0],o.angles[9]=[-.7*i,0,-.03],o.angles[10]=[1.3*i,0,0],o.angles[1]=[.35*i,0,0],sceneCrowdArms(o,-.6-1.9*r,.25,-.3,-.6-1.9*r,.25,-.3);break}case 6:o.angles[1]=[0,.1*n,0],sceneCrowdArms(o,-.15,.1,-.2,-2.75+.3*s,.35*n,-.25);break;case 7:o.root=[.03*n,0,0],o.angles[1]=[0,0,.05*n],sceneCrowdArms(o,-2.65,.42,-.25,-2.65,.42,-.25);break;default:{const r=Math.sin(Math.PI*Math.min(1,Math.max(0,t))),i=r*r*(3-2*r),a=sceneCrowdZeroPose();sceneCrowdSit(a);const c=sceneCrowdZeroPose();sceneCrowdArms(c,-2.95,.25,-.1,-2.95,.25,-.1),c.angles[2]=[-.2,0,0];for(let f=0;f<3;f++)o.root[f]=a.root[f]+(c.root[f]-a.root[f])*i;for(let f=0;f<SCENE_CROWD_JOINTS;f++)for(let l=0;l<3;l++)o.angles[f][l]=a.angles[f][l]+(c.angles[f][l]-a.angles[f][l])*i}}return o}function sceneCrowdMat(){const e=new Float64Array(16);return e[0]=e[5]=e[10]=e[15]=1,e}function sceneCrowdMul(e,t){const o=new Float64Array(16);for(let n=0;n<4;n++)for(let s=0;s<4;s++)o[n*4+s]=e[s]*t[n*4]+e[4+s]*t[n*4+1]+e[8+s]*t[n*4+2]+e[12+s]*t[n*4+3];return o}function sceneCrowdTRS(e,t,o,n){const s=Math.cos(n[0]),r=Math.sin(n[0]),i=Math.cos(n[1]),a=Math.sin(n[1]),c=Math.cos(n[2]),f=Math.sin(n[2]),l=sceneCrowdMat();return l[0]=i*c,l[1]=i*f,l[2]=-a,l[4]=r*a*c-s*f,l[5]=r*a*f+s*c,l[6]=r*i,l[8]=s*a*c+r*f,l[9]=s*a*f-r*c,l[10]=s*i,l[12]=e,l[13]=t,l[14]=o,l}function sceneCrowdSkinMatrices(e,t){const o=[],n=t/1.75;for(let s=0;s<SCENE_CROWD_JOINTS;s++){const r=SCENE_CROWD_PIVOTS[s],i=SCENE_CROWD_PARENTS[s];let a;if(i<0)a=sceneCrowdTRS((r[0]+e.root[0])*n,(r[1]+e.root[1])*n,(r[2]+e.root[2])*n,e.angles[s]);else{const c=SCENE_CROWD_PIVOTS[i];a=sceneCrowdTRS((r[0]-c[0])*n,(r[1]-c[1])*n,(r[2]-c[2])*n,e.angles[s])}o.push(i<0?a:sceneCrowdMul(o[i],a))}return o.map(function(s,r){const i=sceneCrowdMat();return i[12]=-SCENE_CROWD_PIVOTS[r][0]*n,i[13]=-SCENE_CROWD_PIVOTS[r][1]*n,i[14]=-SCENE_CROWD_PIVOTS[r][2]*n,sceneCrowdMul(s,i)})}function sceneCrowdBake(e){const t=SCENE_CROWD_JOINTS*4,o=1+SCENE_CROWD_ACTIONS.length*(SCENE_CROWD_SEGMENTS+1),n=new Float32Array(t*o*4),s=new Float32Array(SCENE_CROWD_ACTIONS.length*4);function r(i,a){for(let c=0;c<SCENE_CROWD_JOINTS;c++)n.set(a[c],(i*t+c*4)*4)}r(0,sceneCrowdSkinMatrices(sceneCrowdZeroPose(),e));for(let i=0;i<SCENE_CROWD_ACTIONS.length;i++){const a=1+i*(SCENE_CROWD_SEGMENTS+1);s[i*4]=a,s[i*4+1]=SCENE_CROWD_SEGMENTS,s[i*4+2]=SCENE_CROWD_ACTIONS[i][1],s[i*4+3]=SCENE_CROWD_ACTIONS[i][2];for(let c=0;c<=SCENE_CROWD_SEGMENTS;c++){const f=i===SCENE_CROWD_WAVE_ACTION?c/SCENE_CROWD_SEGMENTS:c%SCENE_CROWD_SEGMENTS/SCENE_CROWD_SEGMENTS;r(a+c,sceneCrowdSkinMatrices(sceneCrowdActionPose(i,f),e))}}return{width:t,height:o,data:n,clips:s,segments:SCENE_CROWD_SEGMENTS,actions:SCENE_CROWD_ACTIONS.length}}function sceneCrowdVertex(e,t,o,n,s,r,i,a,c,f){const l=e.v.length/12;return e.v.push(t,o,n,s,r,i,a,255,c,f,0,0),l}function sceneCrowdBox(e,t,o,n,s,r,i){const a=o[0]/2,c=o[1]/2,f=o[2]/2,l=t[0],u=t[1],d=t[2],y=n[0],x=n.length>1?n[1]:n[0];if(!i){const p=e.v.length/12;for(let m=0;m<8;m++){const E=m&1?1:-1,v=m&2?1:-1,h=m&4?1:-1,g=Math.hypot(E*c*f,v*a*f,h*a*c)||1;sceneCrowdVertex(e,l+E*a,u+v*c,d+h*f,E*c*f/g,v*a*f/g,h*a*c/g,v>0?y:x,s,r)}const w=[[0,4,6,2],[1,3,7,5],[0,1,5,4],[2,6,7,3],[0,2,3,1],[4,5,7,6]];for(const m of w)e.i.push(p+m[0],p+m[1],p+m[2],p+m[0],p+m[2],p+m[3]);return}const _=[[[1,0,0],[1,-1,-1],[1,1,-1],[1,1,1],[1,-1,1]],[[-1,0,0],[-1,-1,1],[-1,1,1],[-1,1,-1],[-1,-1,-1]],[[0,1,0],[-1,1,-1],[-1,1,1],[1,1,1],[1,1,-1]],[[0,-1,0],[-1,-1,1],[-1,-1,-1],[1,-1,-1],[1,-1,1]],[[0,0,1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]],[[0,0,-1],[1,-1,-1],[-1,-1,-1],[-1,1,-1],[1,1,-1]]];for(const p of _){const w=p[0],m=e.v.length/12;for(let E=1;E<=4;E++){const v=p[E];sceneCrowdVertex(e,l+v[0]*a,u+v[1]*c,d+v[2]*f,w[0],w[1],w[2],v[1]>0?y:x,s,r)}e.i.push(m,m+1,m+2,m,m+2,m+3)}}function sceneCrowdQuad(e,t,o,n,s,r,i,a,c){const f=i[0],l=i.length>1?i[1]:i[0],u=e.v.length/12;sceneCrowdVertex(e,t,o,r,0,0,1,l,a,c),sceneCrowdVertex(e,n,o,r,0,0,1,l,a,c),sceneCrowdVertex(e,n,s,r,0,0,1,f,a,c),sceneCrowdVertex(e,t,s,r,0,0,1,f,a,c),e.i.push(u,u+1,u+2,u,u+2,u+3)}function sceneCrowdProps(e,t){sceneCrowdBox(e,[-.22,.85,.03],[.06,.1,.03],[6],4,1,t);const o=e.v.length/12;sceneCrowdBox(e,[0,.84,.04],[.42,.13,.02],[6],3,2,t);for(let n=o;n<e.v.length/12;n++)e.v[n*12]>0&&(e.v[n*12+6]=4);sceneCrowdBox(e,[-.22,.68,.03],[.03,.34,.22],[6],3,3,t),sceneCrowdBox(e,[-.22,1.2,.03],[.025,.8,.025],[6],5,4,t),sceneCrowdBox(e,[-.41,1.45,.03],[.36,.24,.015],[6],3,4,t)}function sceneCrowdFinish(e,t,o){const n=t/1.75,s=e.v.length/12,r=new ArrayBuffer(s*SCENE_CROWD_VERTEX_BYTES),i=new Float32Array(r),a=new Uint8Array(r);for(let c=0;c<s;c++){const f=c*12,l=c*9,u=c*SCENE_CROWD_VERTEX_BYTES;i[l]=e.v[f]*n,i[l+1]=e.v[f+1]*n,i[l+2]=e.v[f+2]*n,i[l+3]=e.v[f+3],i[l+4]=e.v[f+4],i[l+5]=e.v[f+5],a[u+24]=e.v[f+6],a[u+25]=0,a[u+26]=0,a[u+27]=0,a[u+28]=255,a[u+29]=0,a[u+30]=0,a[u+31]=0,a[u+32]=e.v[f+8],a[u+33]=e.v[f+9],a[u+34]=0,a[u+35]=0}return{vertices:new Uint8Array(r),indices:new Uint16Array(e.i),vertexCount:s,indexCount:e.i.length,bodyIndexCount:o}}function sceneCrowdMeshes(e){const t={v:[],i:[]};sceneCrowdBox(t,[0,1.2,0],[.38,.5,.22],[1],0,0,!0),sceneCrowdBox(t,[0,1.6,.01],[.2,.24,.22],[2],1,0,!0),sceneCrowdBox(t,[0,1.74,.03],[.23,.06,.27],[2],3,5,!0);for(const a of[1,-1]){const c=a>0?3:5,f=a>0?4:6,l=a>0?7:9,u=a>0?8:10;sceneCrowdBox(t,[.22*a,1.28,0],[.1,.3,.11],[c],0,0,!0),sceneCrowdBox(t,[.22*a,.99,0],[.085,.28,.095],[f],1,0,!0),sceneCrowdBox(t,[.1*a,.71,0],[.15,.44,.16],[l],2,0,!0),sceneCrowdBox(t,[.1*a,.27,0],[.13,.46,.14],[u],2,0,!0),sceneCrowdBox(t,[.1*a,.03,.05],[.12,.06,.24],[u],2,0,!0)}const o=t.i.length;sceneCrowdProps(t,!0);const n={v:[],i:[]};sceneCrowdBox(n,[0,1.2,0],[.38,.5,.22],[1],0,0,!1),sceneCrowdBox(n,[0,1.62,.01],[.21,.27,.23],[2],1,0,!1);for(const a of[1,-1])sceneCrowdBox(n,[.22*a,1.14,0],[.1,.58,.1],a>0?[3,4]:[5,6],0,0,!1);sceneCrowdBox(n,[0,.49,0],[.32,.9,.16],[7,8],2,0,!1);const s=n.i.length;sceneCrowdProps(n,!1);const r={v:[],i:[]};sceneCrowdQuad(r,-.2,.05,.2,1.45,0,[1,8],0,0),sceneCrowdQuad(r,-.11,1.47,.11,1.75,.01,[2],1,0),sceneCrowdQuad(r,.17,.86,.27,1.43,.005,[3,4],0,0),sceneCrowdQuad(r,-.27,.86,-.17,1.43,.005,[5,6],0,0);const i=r.i.length;return sceneCrowdQuad(r,-.6,1.33,-.2,1.6,.02,[6],3,4),sceneCrowdQuad(r,-.3,.76,-.12,.94,.02,[6],4,1),[sceneCrowdFinish(t,e,o),sceneCrowdFinish(n,e,s),sceneCrowdFinish(r,e,i)]}const sceneCrowdMaterialCache=new WeakMap;function sceneCrowdMaterials(e){let t=sceneCrowdMaterialCache.get(e);if(!t){const o=e.material||{};t={fan:Object.assign({materialKind:"standard",color:"#ffffff",roughness:.85,metalness:0},o.fan||{}),props:Object.assign({materialKind:"standard",color:"#ffffff",roughness:.7,metalness:0},o.props||{})},sceneCrowdMaterialCache.set(e,t)}return t}const SCENE_CROWD_SECTION_TEXELS=12,SCENE_CROWD_UNIFORM_VEC4S=32,SCENE_CROWD_MAX_WAVES=4,SCENE_CROWD_CLOCK_SLACK=.25,SCENE_CROWD_FLAG_SYNC=1,SCENE_CROWD_FLAG_NO_WAVE=2,SCENE_CROWD_FLAG_PROPS=4,SCENE_CROWD_FLAG_STANDING=8;function sceneCrowdLinear(e){let t=typeof e=="string"?e.trim().replace(/^#/,""):"";(t.length===3||t.length===4)&&(t=t.slice(0,3).split("").map(function(n){return n+n}).join(""));const o=/^[0-9a-fA-F]{6}/.test(t)?parseInt(t.slice(0,6),16):8421504;return[o>>16&255,o>>8&255,o&255].map(function(n){const s=n/255;return s<=.04045?s/12.92:Math.pow((s+.055)/1.055,2.4)})}const sceneCrowdStores=new WeakMap,sceneCrowdPending=new Map,sceneCrowdClock=new WeakMap;function sceneCrowdMountFor(e){if(e&&typeof e=="object"&&typeof e.getAttribute=="function")return e;const t=typeof e=="string"?e.trim():"";if(!t||typeof document>"u")return null;const o=typeof document.getElementById=="function"?document.getElementById(t):null;if(o)return o;const n=typeof window<"u"&&window.__gosx&&window.__gosx.engines,s=n&&typeof n.get=="function"?n.get(t):null;return s&&s.mount||null}function sceneCrowdStoreMap(e){let t=sceneCrowdStores.get(e);return t||(t=new Map,sceneCrowdStores.set(e,t)),t}function sceneCrowdInitialSections(e){const t=e.sections||[],o=new Float32Array(t.length*SCENE_CROWD_SECTION_TEXELS*4);for(let n=0;n<t.length;n++){const s=t[n],r=n*SCENE_CROWD_SECTION_TEXELS*4,i=s.action|0;o.set([i,i,-1e6,.4],r);const a=Number(s.excitement)||0,c=SCENE_CROWD_FLAG_PROPS|(s.noWave?SCENE_CROWD_FLAG_NO_WAVE:0)|(s.standing?SCENE_CROWD_FLAG_STANDING:0);o.set([a,a,1,c],r+4),o.set([0,.12,-1e6,.001],r+8),sceneCrowdWritePalette(o,r,s)}return o}function sceneCrowdWritePalette(e,t,o){const n=Array.isArray(o.colors)?o.colors:[],s=Array.isArray(o.accents)?o.accents:[];for(let r=0;r<4;r++)e.set(sceneCrowdLinear(n[Math.min(r,Math.max(0,n.length-1))]||"#888888").concat(1),t+(3+r)*4),e.set(sceneCrowdLinear(s[Math.min(r,Math.max(0,s.length-1))]||"#cccccc").concat(1),t+(7+r)*4)}function sceneCrowdStore(e,t){const o=sceneCrowdStoreMap(e);let n=o.get(t.id);const s=(t.sections||[]).map(function(a){return a.id}).join(`
`);if(!n||n.ids!==s)n={ir:t,ids:s,sections:sceneCrowdInitialSections(t),waves:new Float32Array(SCENE_CROWD_MAX_WAVES*8),version:1,lastNow:0},o.set(t.id,n);else if(n.ir!==t){for(let a=0;a<t.sections.length;a++)sceneCrowdWritePalette(n.sections,a*SCENE_CROWD_SECTION_TEXELS*4,t.sections[a]);n.ir=t,n.version++}const r=e&&e.id,i=r&&sceneCrowdPending.get(r);if(i){sceneCrowdPending.delete(r);for(const a of i)sceneCrowdApplyDecoded(e,a)}return n}function sceneCrowdDecode(e){const t=e instanceof ArrayBuffer?new Uint8Array(e):e;if(!(t instanceof Uint8Array))throw new TypeError("crowd frame must be an ArrayBuffer or Uint8Array");const o=new DataView(t.buffer,t.byteOffset,t.byteLength);let n=0;function s(w){if(n+w>t.length)throw new Error("crowd frame is truncated")}if(s(4),t[0]!==71||t[1]!==83||t[2]!==67||t[3]!==49)throw new Error("not a GSC1 crowd frame");n=4,s(2);const r=o.getUint16(n,!0);n+=2,s(r);const i=new TextDecoder().decode(t.subarray(n,n+r));n+=r,s(10);const a=o.getFloat64(n,!0),c=Number.isFinite(a)?a:0;n+=8;const f=o.getUint16(n,!0);n+=2;const l=[];for(let w=0;w<f;w++){s(42);const m={section:o.getUint16(n,!0),from:t[n+2],to:t[n+3],blendStart:c+o.getFloat32(n+4,!0),blend:o.getFloat32(n+8,!0),excitementFrom:o.getFloat32(n+12,!0),excitementTo:o.getFloat32(n+16,!0),rate:o.getFloat32(n+20,!0),epoch:c+o.getFloat32(n+24,!0),jitter:o.getFloat32(n+28,!0),excitementStart:c+o.getFloat32(n+32,!0),excitementRamp:o.getFloat32(n+36,!0),flags:t[n+40]};if(n+=42,m.from>8||m.to>8)throw new Error("crowd frame names an unknown action");l.push(m)}s(2);const u=t[n],d=t[n+1]===1;if(n+=2,u>SCENE_CROWD_MAX_WAVES)throw new Error("crowd frame has more than four waves");const y=[];for(let w=0;w<u;w++)s(20),y.push({start:c+o.getFloat32(n,!0),origin:o.getFloat32(n+4,!0),speed:o.getFloat32(n+8,!0),width:o.getFloat32(n+12,!0),laps:o.getFloat32(n+16,!0)}),n+=20;s(2);const x=o.getUint16(n,!0);n+=2;const _=[];function p(){s(1);const w=t[n];if(n+=1,w>4)throw new Error("crowd frame palette has more than four colours");s(3*w);const m=[];for(let E=0;E<w;E++,n+=3)m.push("#"+[t[n],t[n+1],t[n+2]].map(function(v){return(v<16?"0":"")+v.toString(16)}).join(""));return w?m:null}for(let w=0;w<x;w++){s(2);const m=o.getUint16(n,!0);n+=2;const E=p(),v=p();_.push({section:m,colors:E,accents:v})}if(n!==t.length)throw new Error("crowd frame has trailing bytes");return{crowd:i,now:c,sections:l,waves:y,replaceWaves:d,palettes:_}}function sceneCrowdOffset(e,t){const o=sceneCrowdClock.get(e)||{scene:0,offset:null},n=o.scene-t;return(o.offset===null||Math.abs(n-o.offset)>SCENE_CROWD_CLOCK_SLACK)&&(o.offset=n),sceneCrowdClock.set(e,o),o.offset}function sceneCrowdApplyDecoded(e,t){const o=sceneCrowdStoreMap(e).get(t.crowd);if(!o)return!1;const n=sceneCrowdOffset(e,t.now),s=o.ir.sections.length;for(const r of t.sections){if(r.section>=s)continue;const i=r.section*SCENE_CROWD_SECTION_TEXELS*4,a=o.sections,c=a[i+7]&(SCENE_CROWD_FLAG_NO_WAVE|SCENE_CROWD_FLAG_STANDING);a[i]=r.from,a[i+1]=r.to,a[i+2]=r.blendStart+n,a[i+3]=Math.max(.001,r.blend),a[i+4]=r.excitementFrom,a[i+5]=r.excitementTo,a[i+6]=r.rate>0?r.rate:1,a[i+7]=c|r.flags&(SCENE_CROWD_FLAG_SYNC|SCENE_CROWD_FLAG_PROPS),a[i+8]=r.epoch+n,a[i+9]=r.jitter,a[i+10]=r.excitementStart+n,a[i+11]=Math.max(.001,r.excitementRamp)}for(const r of t.palettes||[]){if(r.section>=s)continue;const i=r.section*SCENE_CROWD_SECTION_TEXELS*4;r.colors&&r.colors.forEach(function(a,c){o.sections.set(sceneCrowdLinear(a).concat(1),i+(3+c)*4)}),r.accents&&r.accents.forEach(function(a,c){o.sections.set(sceneCrowdLinear(a).concat(1),i+(7+c)*4)})}t.replaceWaves&&o.waves.fill(0);for(const r of t.waves){let i=0;for(let a=0;a<SCENE_CROWD_MAX_WAVES;a++){const c=a*8,f=o.waves[c+3],l=Math.abs(o.waves[c+2]);if(f<=0||l<=0||l*(o.lastNow-o.waves[c])>o.waves[c+4]+f){i=a;break}}o.waves.set([r.start+n,r.origin,r.speed,Math.max(1e-4,r.width),Math.max(1,r.laps),0,0,0],i*8)}return o.version++,!0}function sceneCrowdApply(e,t){const o=t instanceof Uint8Array||t instanceof ArrayBuffer?sceneCrowdDecode(t):t,n=sceneCrowdMountFor(e);if(n&&sceneCrowdStoreMap(n).has(o.crowd))return sceneCrowdApplyDecoded(n,o);const s=n&&n.id||(typeof e=="string"?e.trim():"");if(!s)return!1;const r=sceneCrowdPending.get(s)||[];return r.push(o),sceneCrowdPending.set(s,r.slice(-64)),!1}function sceneCrowdNoteClock(e,t){const o=sceneCrowdClock.get(e)||{scene:0,offset:null};o.scene=t,sceneCrowdClock.set(e,o)}function sceneCrowdModel(e){const t=Number(e.rotation)||0,o=Math.cos(t),n=Math.sin(t);return new Float32Array([o,0,-n,0,0,1,0,0,n,0,o,0,Number(e.x)||0,Number(e.y)||0,Number(e.z)||0,1])}function sceneCrowdUniforms(e,t,o,n,s,r){r.fill(0),r.set(n,0),r[16]=s,r[17]=Number(e.rotation)||0,r[19]=Number(e.material&&e.material.lightGlow)||1.5;const i=e.fan||{},a=Array.isArray(i.skinTones)&&i.skinTones.length?i.skinTones.slice(0,8):["#c68c5f"];r.set(sceneCrowdLinear(i.legs||"#2b2f3a"),20),r[23]=a.length;for(let c=0;c<a.length;c++)r.set(sceneCrowdLinear(a[c]).concat(1),24+c*4);return r.set(o.clips,56),r.set(t.waves,92),r[124]=(e.sections||[]).length,r}function sceneCrowdPlanes(e,t){const o=[0,1,2,3].map(function(s){return[e[s],e[4+s],e[8+s],e[12+s]]}),n=[[0,1],[0,-1],[1,1],[1,-1],[2,1],[2,-1]];for(let s=0;s<6;s++){const r=o[n[s][0]],i=n[s][1],a=o[3][0]+i*r[0],c=o[3][1]+i*r[1],f=o[3][2]+i*r[2],l=o[3][3]+i*r[3],u=Math.hypot(a,c,f)||1;t[s*4]=a/u,t[s*4+1]=c/u,t[s*4+2]=f/u,t[s*4+3]=l/u}return t}function sceneCrowdSelect(e,t,o,n){const s=o.lod||{},r=t.blocks,i=t.spheres,a=e.model,c=r.length/3;(!e.select||e.select.tiers.length!==c)&&(e.select={tiers:new Int8Array(c),dist:new Float32Array(c),order:[],planes:new Float64Array(24)});const f=e.select,l=sceneCrowdPlanes(n.viewProj,f.planes),u=(Number(o.fan&&o.fan.height)||1.75)*1.06,d=Math.abs(Number(n.proj&&n.proj[5])||1.5),y=Math.max(1,Number(n.height)||1),x=Number(s.fullPixels)||64,_=Number(s.lowPixels)||20,p=Number(s.maxFull)||8e3,w=n.camera||{},m=Number(w.x)||0,E=Number(w.y)||0,v=Number(w.z)||0,h=[];for(let b=0;b<c;b++){const A=i[b*4],P=i[b*4+1],M=i[b*4+2],T=i[b*4+3],R=a[0]*A+a[8]*M+a[12],U=P+a[13],D=a[2]*A+a[10]*M+a[14];let N=!0;for(let k=0;k<6&&N;k++)N=l[k*4]*R+l[k*4+1]*U+l[k*4+2]*D+l[k*4+3]>-T;if(!N){f.tiers[b]=-1;continue}const z=Math.max(.5,Math.hypot(R-m,U-E,D-v)-T),B=u*d*y/(2*z);f.dist[b]=z,f.tiers[b]=B>=x?0:B>=_?1:2,f.tiers[b]===0&&h.push(b)}let g=0;for(const b of h)g+=r[b*3+1];if(g>p){h.sort(function(A,P){return f.dist[A]-f.dist[P]});let b=0;for(const A of h)b+r[A*3+1]>p?f.tiers[A]=1:b+=r[A*3+1]}const C=[[],[],[]],S=[0,0,0];for(let b=0;b<c;b++){const A=f.tiers[b];if(A<0)continue;const P=r[b*3],M=r[b*3+1],T=C[A];S[A]+=M,T.length&&T[T.length-2]+T[T.length-1]===P?T[T.length-1]+=M:T.push(P,M)}return{ranges:C,fans:S}}function sceneCrowdLevels(e,t){const o=sceneCrowdMountFor(e),n=o&&sceneCrowdStoreMap(o).get(t);if(!n)return null;const s=[.08,.3,1,.65,.75,.9,.7,.45,.85],r=n.lastNow,i=[];let a=0,c=0;for(let f=0;f<n.ir.sections.length;f++){const l=f*SCENE_CROWD_SECTION_TEXELS*4,u=n.sections,d=Math.min(1,Math.max(0,(r-u[l+10])/Math.max(.001,u[l+11]))),y=u[l+4]+(u[l+5]-u[l+4])*d,x=n.fans?n.fans[f]:0;i.push({id:n.ir.sections[f].id,action:SCENE_CROWD_ACTIONS[u[l+1]|0][0],excitement:y,fans:x}),a+=x,c+=x*y*s[u[l+1]|0]}return{now:r,loudness:a?c/a:0,sections:i}}const SCENE_CROWD_GLSL_VERTEX=`#version 300 es
precision highp float;
precision highp int;
layout(location = 0) in vec3 a_position;
layout(location = 1) in vec3 a_normal;
layout(location = 2) in uvec4 a_joints;
layout(location = 3) in vec4 a_weights;
layout(location = 4) in uvec4 a_part;
layout(location = 5) in vec4 a_seat;
layout(location = 6) in float a_wave;
layout(location = 7) in uvec2 a_ids;
layout(location = 8) in uvec4 a_look;
layout(location = 9) in uvec4 a_extra;
uniform mat4 u_viewMatrix;
uniform mat4 u_projectionMatrix;
uniform vec3 u_cameraPosition;
uniform vec4 u_crowd[32];
uniform highp sampler2D u_crowdPalette;
uniform highp sampler2D u_crowdSections;
out vec3 v_worldPosition;
out vec3 v_normal;
out vec2 v_uv;
out vec3 v_tangent;
out vec3 v_bitangent;
flat out vec4 v_instanceColor;
flat out vec4 v_crowdGlow;
vec4 crowdSection(int s, int t) { return texelFetch(u_crowdSections, ivec2(t, s), 0); }
mat4 crowdJoint(int j, int row) {
  int x = j * 4;
  return mat4(texelFetch(u_crowdPalette, ivec2(x, row), 0), texelFetch(u_crowdPalette, ivec2(x + 1, row), 0),
    texelFetch(u_crowdPalette, ivec2(x + 2, row), 0), texelFetch(u_crowdPalette, ivec2(x + 3, row), 0));
}
mat4 crowdPose(int a, float ph, int j) {
  vec4 clip = u_crowd[14 + a];
  float f = (a == 8 ? clamp(ph, 0.0, 1.0) : fract(ph)) * clip.y;
#if CROWD_TIER > 0
  return crowdJoint(j, int(clip.x + floor(f + 0.5)));
#else
  float f0 = min(floor(f), clip.y - 1.0);
  mat4 m0 = crowdJoint(j, int(clip.x + f0));
  mat4 m1 = crowdJoint(j, int(clip.x + f0) + 1);
  return m0 + (m1 - m0) * (f - f0);
#endif
}
// crowdJoin is how far a fan has joined its section's action (0 idles, 1
// joined). A fan joins once the excitement ramp passes its eagerness, over
// 0.4 seconds, and leaves the same way.
float crowdJoin(vec4 t1, vec4 t2, float eager, float now) {
  float tau = (eager - 64.0) / 192.0;
  bool was = t1.x > tau, is = t1.y > tau;
  if (was == is) return is ? 1.0 : 0.0;
  float crossing = t2.z + (tau - t1.x) / (t1.y - t1.x) * max(t2.w, 0.001);
  float j = clamp((now - crossing) / 0.4, 0.0, 1.0);
  return is ? j : 1.0 - j;
}
float crowdPhase(int a, bool synced, vec4 t1, vec4 t2, float now, float seed, float variant) {
  float cycle = max(u_crowd[14 + a].z, 0.05);
  if (synced) return (now - t2.x) * t1.z / cycle + t2.y * (seed - 0.5);
  return now * t1.z * (0.92 + 0.16 * variant) / cycle + seed;
}
void main() {
  int s = int(a_ids.x);
  vec4 t0 = crowdSection(s, 0), t1 = crowdSection(s, 1), t2 = crowdSection(s, 2);
  int flags = int(t1.w + 0.5);
  float now = u_crowd[4].x;
  float eager = float(a_extra.x);
  float variant = float(a_look.w) / 255.0;
  float seed = float(a_ids.y) / 65536.0;
  int rest = (flags & 8) != 0 ? 1 : 0;
  int fanA = int(t0.x + 0.5), fanB = int(t0.y + 0.5);
  float join = crowdJoin(t1, t2, eager, now);
  join = join * join * (3.0 - 2.0 * join);
  float k = clamp((now - t0.z - eager / 255.0 * 0.6) / max(t0.w, 0.001), 0.0, 1.0);
  k = k * k * (3.0 - 2.0 * k);
  bool synced = (flags & 1) != 0;
  float phA = crowdPhase(fanA, synced, t1, t2, now, seed, variant);
  float phB = crowdPhase(fanB, synced, t1, t2, now, seed, variant);
  float phR = crowdPhase(rest, false, t1, t2, now, seed, variant);
  float waveU = -1.0;
  if ((flags & 2) == 0 && a_extra.x < 246u) {
    for (int w = 0; w < 4; w++) {
      vec4 wa = u_crowd[23 + w * 2], wb = u_crowd[24 + w * 2];
      if (wa.w <= 0.0 || wa.z == 0.0 || now < wa.x || waveU >= 0.0) continue;
      float x = abs(wa.z) * (now - wa.x) - fract(sign(wa.z) * (a_wave - wa.y));
      float u = (x - clamp(floor(x + 0.5), 0.0, wb.x - 1.0)) / wa.w + 0.5;
      if (u > 0.0 && u < 1.0) waveU = u;
    }
  }
  float waveW = waveU < 0.0 ? 0.0 : smoothstep(0.0, 0.2, waveU) * (1.0 - smoothstep(0.8, 1.0, waveU));
  mat4 skin = mat4(0.0);
  for (int i = 0; i < 4; i++) {
    float wt = a_weights[i];
    if (wt <= 0.0) continue;
    int j = int(a_joints[i]);
    mat4 m;
    if (join <= 0.0) m = crowdPose(rest, phR, j);
    else {
      m = crowdPose(fanB, phB, j);
      if (k < 1.0 && fanA != fanB) { mat4 ma = crowdPose(fanA, phA, j); m = ma + (m - ma) * k; }
      if (join < 1.0) { mat4 mr = crowdPose(rest, phR, j); m = mr + (m - mr) * join; }
    }
    if (waveW > 0.0) m = m + (crowdPose(8, waveU, j) - m) * waveW;
    skin += m * wt;
  }
  vec3 local = (skin * vec4(a_position, 1.0)).xyz;
  vec3 n = mat3(skin) * a_normal;
  float scale = 0.94 + 0.12 * float(a_look.w & 15u) / 15.0;
  mat4 model = mat4(u_crowd[0], u_crowd[1], u_crowd[2], u_crowd[3]);
  float yaw = a_seat.w;
#if CROWD_TIER == 2
  vec3 seatWorld = (model * vec4(a_seat.xyz, 1.0)).xyz;
  vec3 toCamera = u_cameraPosition - seatWorld;
  yaw = atan(toCamera.x, toCamera.z) - u_crowd[4].y;
  n = normalize(n + vec3(0.0, 0.6, 0.0));
#endif
  float cy = cos(yaw), sy = sin(yaw);
  vec3 p = vec3(cy * local.x + sy * local.z, local.y, -sy * local.x + cy * local.z) * scale + a_seat.xyz;
  vec3 nr = vec3(cy * n.x + sy * n.z, n.y, -sy * n.x + cy * n.z);
  uint kind = a_part.y;
  bool hidden = kind == 5u ? (a_look.w & 0x90u) != 0x90u : (kind > 0u && (kind != a_look.z || (flags & 4) == 0));
  vec4 world = model * vec4(p, 1.0);
  v_worldPosition = world.xyz;
  v_normal = normalize(mat3(model) * nr);
  v_uv = vec2(0.0);
  v_tangent = normalize(abs(v_normal.y) < 0.9 ? cross(vec3(0.0, 1.0, 0.0), v_normal) : cross(vec3(1.0, 0.0, 0.0), v_normal));
  v_bitangent = cross(v_normal, v_tangent);
  uint slot = a_part.x;
  vec3 color = vec3(0.25, 0.2, 0.15);
  if (slot == 0u) color = crowdSection(s, 3 + int(a_look.x)).rgb;
  else if (slot == 1u) color = u_crowd[6 + int((a_look.w >> 4) & 7u) % max(int(u_crowd[5].w), 1)].rgb;
  else if (slot == 2u) color = u_crowd[5].rgb;
  else if (slot == 3u || slot == 4u) color = crowdSection(s, 7 + int(a_look.y)).rgb;
  v_instanceColor = vec4(color, 1.0);
  float flicker = 0.8 + 0.2 * sin(now * 7.0 + seed * 40.0);
  v_crowdGlow = slot == 4u ? vec4(color * u_crowd[4].w * flicker, 1.0) : vec4(0.0);
  gl_Position = hidden ? vec4(2.0, 2.0, 2.0, 1.0) : u_projectionMatrix * u_viewMatrix * world;
}`;function sceneCrowdFragmentGLSL(e){const t="void gosxApplyCustomFragment(inout vec3 color, inout float opacity, vec3 normal, vec3 worldPosition, vec2 uv) {}";if(e.indexOf(t)<0)throw new Error("crowd: PBR fragment hook missing");return e.replace(t,`flat in vec4 v_crowdGlow;
void gosxApplyCustomFragment(inout vec3 color, inout float opacity, vec3 normal, vec3 worldPosition, vec2 uv) { color += v_crowdGlow.rgb * (u_outputLinear == 1 ? 2.0 : 0.8); }`)}function sceneCrowdGLShader(e,t,o){const n=e.createShader(t);if(e.shaderSource(n,o),e.compileShader(n),!e.getShaderParameter(n,e.COMPILE_STATUS)){const s=e.getShaderInfoLog(n);throw e.deleteShader(n),new Error("crowd shader: "+s)}return n}function sceneCrowdGLProgram(e,t,o,n,s){const r=typeof o.fragment=="function"?o.fragment(s):o.fragment,i=n+"|"+String(r||"");if(e.programs.has(i))return e.programs.get(i);const a=sceneCrowdGLShader(t,t.VERTEX_SHADER,SCENE_CROWD_GLSL_VERTEX.replace("precision highp int;",`precision highp int;
#define CROWD_TIER `+n)),c=sceneCrowdGLShader(t,t.FRAGMENT_SHADER,sceneCrowdFragmentGLSL(String(r||""))),f=t.createProgram();if(t.attachShader(f,a),t.attachShader(f,c),t.linkProgram(f),t.deleteShader(a),t.deleteShader(c),!t.getProgramParameter(f,t.LINK_STATUS)){const d=t.getProgramInfoLog(f);throw t.deleteProgram(f),new Error("crowd program: "+d)}const l=typeof o.uniforms=="function"?o.uniforms(t,f):{};l.crowd=t.getUniformLocation(f,"u_crowd[0]")||t.getUniformLocation(f,"u_crowd"),l.crowdPalette=t.getUniformLocation(f,"u_crowdPalette"),l.crowdSections=t.getUniformLocation(f,"u_crowdSections");const u={program:f,uniforms:l};return e.programs.set(i,u),u}function sceneCrowdGLTexture(e,t,o,n){const s=e.createTexture();return e.bindTexture(e.TEXTURE_2D,s),e.texImage2D(e.TEXTURE_2D,0,e.RGBA32F,t,o,0,e.RGBA,e.FLOAT,n),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.NEAREST),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE),s}function sceneCrowdGLInstanceAttributes(e,t){e.vertexAttribPointer(5,4,e.FLOAT,!1,32,t),e.vertexAttribPointer(6,1,e.FLOAT,!1,32,t+16),e.vertexAttribIPointer(7,2,e.UNSIGNED_SHORT,32,t+20),e.vertexAttribIPointer(8,4,e.UNSIGNED_BYTE,32,t+24),e.vertexAttribIPointer(9,4,e.UNSIGNED_BYTE,32,t+28)}function sceneCrowdGLStatic(e,t,o){if(e.meshes&&e.fanHeight===o)return;if(e.meshes)for(const s of e.meshes)t.deleteBuffer(s.vbo),t.deleteBuffer(s.ibo),t.deleteVertexArray(s.vao);e.palette&&t.deleteTexture(e.palette),e.fanHeight=o,e.bake=sceneCrowdBake(o),e.palette=sceneCrowdGLTexture(t,e.bake.width,e.bake.height,e.bake.data);const n=t.getParameter(t.VERTEX_ARRAY_BINDING);e.meshes=sceneCrowdMeshes(o).map(function(s){const r=t.createVertexArray();t.bindVertexArray(r);const i=t.createBuffer();t.bindBuffer(t.ARRAY_BUFFER,i),t.bufferData(t.ARRAY_BUFFER,s.vertices,t.STATIC_DRAW);for(let c=0;c<5;c++)t.enableVertexAttribArray(c);t.vertexAttribPointer(0,3,t.FLOAT,!1,36,0),t.vertexAttribPointer(1,3,t.FLOAT,!1,36,12),t.vertexAttribIPointer(2,4,t.UNSIGNED_BYTE,36,24),t.vertexAttribPointer(3,4,t.UNSIGNED_BYTE,!0,36,28),t.vertexAttribIPointer(4,4,t.UNSIGNED_BYTE,36,32);const a=t.createBuffer();return t.bindBuffer(t.ELEMENT_ARRAY_BUFFER,a),t.bufferData(t.ELEMENT_ARRAY_BUFFER,s.indices,t.STATIC_DRAW),{vao:r,vbo:i,ibo:a,indexCount:s.indexCount}}),t.bindVertexArray(n)}function sceneCrowdGLCrowd(e,t,o,n){let s=e.crowds.get(o.id);if(!s||s.ir!==o){s&&sceneCrowdGLDisposeCrowd(t,s);const r=sceneCrowdPack(o);if(r.error)throw new Error(r.error);s={ir:o,packed:r,model:sceneCrowdModel(o),version:-1,uniforms:new Float32Array(SCENE_CROWD_UNIFORM_VEC4S*4)},s.instances=t.createBuffer(),t.bindBuffer(t.ARRAY_BUFFER,s.instances),t.bufferData(t.ARRAY_BUFFER,r.records,t.STATIC_DRAW),s.sections=sceneCrowdGLTexture(t,SCENE_CROWD_SECTION_TEXELS,o.sections.length,n.sections),s.version=n.version,n.fans=r.sectionFans,e.crowds.set(o.id,s)}return s.version!==n.version&&(t.bindTexture(t.TEXTURE_2D,s.sections),t.texSubImage2D(t.TEXTURE_2D,0,0,0,SCENE_CROWD_SECTION_TEXELS,o.sections.length,t.RGBA,t.FLOAT,n.sections),s.version=n.version),s}function sceneCrowdGLDisposeCrowd(e,t){t.instances&&e.deleteBuffer(t.instances),t.sections&&e.deleteTexture(t.sections),t.instances=t.sections=null}function sceneCrowdGLDispose(e){const t=sceneCrowdGLResources.get(e);if(t){sceneCrowdGLResources.delete(e);for(const o of t.crowds.values())sceneCrowdGLDisposeCrowd(e,o);for(const o of t.programs.values())e.deleteProgram(o.program);if(t.meshes)for(const o of t.meshes)e.deleteBuffer(o.vbo),e.deleteBuffer(o.ibo),e.deleteVertexArray(o.vao);t.palette&&e.deleteTexture(t.palette)}}const sceneCrowdGLResources=new WeakMap;function sceneCrowdGLDraw(e,t){const o=t.environment&&Array.isArray(t.environment.crowds)?t.environment.crowds:null,n={state:"none",fans:0,full:0,low:0,impostor:0,draws:0,cpuMs:0,error:""},s=typeof performance<"u"?performance.now():0;if(!o||!o.length)return sceneCrowdGLResources.has(e)&&sceneCrowdGLDispose(e),sceneCrowdPublish(t.mount,n),n.state;let r=sceneCrowdGLResources.get(e);if(!r){r={crowds:new Map,programs:new Map,ext:e.getExtension("WEBGL_draw_instanced_base_vertex_base_instance")};const c=e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS),f=e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS);r.units=c-4>=f?[c-4,c-3]:[f-2,f-1],sceneCrowdGLResources.set(e,r)}const i=e.getParameter(e.VERTEX_ARRAY_BINDING),a=e.isEnabled(e.CULL_FACE);try{const c=Number(t.time)||0;sceneCrowdNoteClock(t.mount,c);const f=new Set;for(const l of o){if(!l||!l.id)continue;f.add(l.id);const u=sceneCrowdStore(t.mount,l);u.lastNow=c,sceneCrowdGLStatic(r,e,Number(l.fan&&l.fan.height)||1.75);const d=sceneCrowdGLCrowd(r,e,l,u),y=sceneCrowdSelect(d,d.packed,l,t);n.fans+=d.packed.count,n.full+=y.fans[0],n.low+=y.fans[1],n.impostor+=y.fans[2],sceneCrowdUniforms(l,u,r.bake,d.model,c,d.uniforms);const x=sceneCrowdMaterials(l);for(let _=0;_<3;_++){const p=y.ranges[_];if(!p.length)continue;const w=r.meshes[_];e.bindVertexArray(w.vao),e.bindBuffer(e.ARRAY_BUFFER,d.instances);for(let m=5;m<10;m++)e.enableVertexAttribArray(m),e.vertexAttribDivisor(m,1);r.ext&&sceneCrowdGLInstanceAttributes(e,0);for(const[m,E,v]of[[x.fan,0,w.bodyIndexCount],[x.props,w.bodyIndexCount,w.indexCount-w.bodyIndexCount]]){const h=sceneCrowdGLProgram(r,e,t,_,m),g=h.uniforms;e.useProgram(h.program),typeof t.prepare=="function"&&t.prepare(g,m),typeof t.surface=="function"&&t.surface(h,m),g.receiveShadow&&e.uniform1i(g.receiveShadow,l.receiveShadow===!1?0:1),e.uniform4fv(g.crowd,d.uniforms),e.activeTexture(e.TEXTURE0+r.units[0]),e.bindTexture(e.TEXTURE_2D,r.palette),e.uniform1i(g.crowdPalette,r.units[0]),e.activeTexture(e.TEXTURE0+r.units[1]),e.bindTexture(e.TEXTURE_2D,d.sections),e.uniform1i(g.crowdSections,r.units[1]),e.disable(e.BLEND),e.enable(e.DEPTH_TEST),e.depthMask(!0),e.depthFunc(e.LEQUAL),e.enable(e.CULL_FACE),e.cullFace(e.BACK);for(let C=0;C<p.length;C+=2)r.ext?r.ext.drawElementsInstancedBaseVertexBaseInstanceWEBGL(e.TRIANGLES,v,e.UNSIGNED_SHORT,E*2,p[C+1],0,p[C]):(sceneCrowdGLInstanceAttributes(e,p[C]*32),e.drawElementsInstanced(e.TRIANGLES,v,e.UNSIGNED_SHORT,E*2,p[C+1])),n.draws++}}}for(const l of Array.from(r.crowds.keys()))f.has(l)||(sceneCrowdGLDisposeCrowd(e,r.crowds.get(l)),r.crowds.delete(l));n.state="ready"}catch(c){n.state="failed",n.error=String(c&&c.message||c)}finally{e.bindVertexArray(i),a||e.disable(e.CULL_FACE),e.activeTexture(e.TEXTURE0),t.textureCache&&(t.textureCache._sceneTextureEpoch=(t.textureCache._sceneTextureEpoch||0)+1),t.program&&e.useProgram(t.program),n.cpuMs=typeof performance<"u"?performance.now()-s:0,sceneCrowdPublish(t.mount,n)}return n.state}function sceneCrowdPublish(e,t){const o=typeof window<"u"&&window.__gosx_scene3d_crowd_api;if(o&&(o.stats=t),!e||typeof e.setAttribute!="function")return;const n=t.full+"/"+t.low+"/"+t.impostor,s=t.state+"|"+t.fans+"|"+n+"|"+t.draws+"|"+t.error;e.__gosxCrowdPublished!==s&&(e.__gosxCrowdPublished=s,e.setAttribute("data-gosx-scene3d-crowd",t.state),e.setAttribute("data-gosx-scene3d-crowd-fans",String(t.fans)),e.setAttribute("data-gosx-scene3d-crowd-tiers",n),e.setAttribute("data-gosx-scene3d-crowd-draws",String(t.draws)),t.error?e.setAttribute("data-gosx-scene3d-crowd-error",t.error):typeof e.removeAttribute=="function"&&e.removeAttribute("data-gosx-scene3d-crowd-error"))}function sceneCrowdVertexWGSL(e){return e+`
struct CrowdBlock { v: array<vec4f, 32> };
@group(0) @binding(0) var<uniform> frame: FrameUniforms;
@group(2) @binding(0) var<uniform> crowd: CrowdBlock;
@group(2) @binding(1) var crowdPalette: texture_2d<f32>;
@group(2) @binding(2) var crowdSections: texture_2d<f32>;
override CROWD_TIER: u32 = 0u;
struct CrowdIn {
  @location(0) position: vec3f, @location(1) normal: vec3f, @location(2) joints: vec4<u32>, @location(3) weights: vec4f,
  @location(4) part: vec4<u32>, @location(5) seat: vec4f, @location(6) wave: f32, @location(7) ids: vec2<u32>,
  @location(8) look: vec4<u32>, @location(9) extra: vec4<u32>,
};
struct VertexOutput {
  @builtin(position) clipPos: vec4f,
  @location(0) worldPos: vec3f,
  @location(1) normal: vec3f,
  @location(2) uv: vec2f,
  @location(3) tangent: vec3f,
  @location(4) bitangent: vec3f,
  @location(5) @interpolate(flat) instanceColor: vec4f,
  @location(6) @interpolate(flat) crowdGlow: vec4f,
};
fn crowdSection(s: i32, t: i32) -> vec4f { return textureLoad(crowdSections, vec2i(t, s), 0); }
fn crowdJoint(j: i32, row: i32) -> mat4x4f {
  let x = j * 4;
  return mat4x4f(textureLoad(crowdPalette, vec2i(x, row), 0), textureLoad(crowdPalette, vec2i(x + 1, row), 0),
    textureLoad(crowdPalette, vec2i(x + 2, row), 0), textureLoad(crowdPalette, vec2i(x + 3, row), 0));
}
fn crowdPose(a: i32, ph: f32, j: i32) -> mat4x4f {
  let clip = crowd.v[14 + a];
  var f = fract(ph) * clip.y;
  if (a == 8) { f = clamp(ph, 0.0, 1.0) * clip.y; }
  if (CROWD_TIER > 0u) { return crowdJoint(j, i32(clip.x + floor(f + 0.5))); }
  let f0 = min(floor(f), clip.y - 1.0);
  let m0 = crowdJoint(j, i32(clip.x + f0));
  let m1 = crowdJoint(j, i32(clip.x + f0) + 1);
  return m0 + (m1 - m0) * (f - f0);
}
fn crowdJoin(t1: vec4f, t2: vec4f, eager: f32, now: f32) -> f32 {
  let tau = (eager - 64.0) / 192.0;
  let was = t1.x > tau;
  let is = t1.y > tau;
  if (was == is) { return select(0.0, 1.0, is); }
  let crossing = t2.z + (tau - t1.x) / (t1.y - t1.x) * max(t2.w, 0.001);
  let j = clamp((now - crossing) / 0.4, 0.0, 1.0);
  return select(1.0 - j, j, is);
}
fn crowdPhase(a: i32, synced: bool, t1: vec4f, t2: vec4f, now: f32, seed: f32, variant: f32) -> f32 {
  let cycle = max(crowd.v[14 + a].z, 0.05);
  if (synced) { return (now - t2.x) * t1.z / cycle + t2.y * (seed - 0.5); }
  return now * t1.z * (0.92 + 0.16 * variant) / cycle + seed;
}
@vertex fn vertexMain(in: CrowdIn) -> VertexOutput {
  var out: VertexOutput;
  let s = i32(in.ids.x);
  let t0 = crowdSection(s, 0);
  let t1 = crowdSection(s, 1);
  let t2 = crowdSection(s, 2);
  let flags = i32(t1.w + 0.5);
  let now = crowd.v[4].x;
  let eager = f32(in.extra.x);
  let variant = f32(in.look.w) / 255.0;
  let seed = f32(in.ids.y) / 65536.0;
  let rest = select(0, 1, (flags & 8) != 0);
  let fanA = i32(t0.x + 0.5);
  let fanB = i32(t0.y + 0.5);
  var join = crowdJoin(t1, t2, eager, now);
  join = join * join * (3.0 - 2.0 * join);
  var k = clamp((now - t0.z - eager / 255.0 * 0.6) / max(t0.w, 0.001), 0.0, 1.0);
  k = k * k * (3.0 - 2.0 * k);
  let synced = (flags & 1) != 0;
  let phA = crowdPhase(fanA, synced, t1, t2, now, seed, variant);
  let phB = crowdPhase(fanB, synced, t1, t2, now, seed, variant);
  let phR = crowdPhase(rest, false, t1, t2, now, seed, variant);
  var waveU = -1.0;
  if ((flags & 2) == 0 && in.extra.x < 246u) {
    for (var w = 0; w < 4; w++) {
      let wa = crowd.v[23 + w * 2];
      let wb = crowd.v[24 + w * 2];
      if (wa.w <= 0.0 || wa.z == 0.0 || now < wa.x || waveU >= 0.0) { continue; }
      let x = abs(wa.z) * (now - wa.x) - fract(sign(wa.z) * (in.wave - wa.y));
      let u = (x - clamp(floor(x + 0.5), 0.0, wb.x - 1.0)) / wa.w + 0.5;
      if (u > 0.0 && u < 1.0) { waveU = u; }
    }
  }
  var waveW = 0.0;
  if (waveU >= 0.0) { waveW = smoothstep(0.0, 0.2, waveU) * (1.0 - smoothstep(0.8, 1.0, waveU)); }
  var skin = mat4x4f(vec4f(0.0), vec4f(0.0), vec4f(0.0), vec4f(0.0));
  for (var i = 0; i < 4; i++) {
    let wt = in.weights[i];
    if (wt <= 0.0) { continue; }
    let j = i32(in.joints[i]);
    var m: mat4x4f;
    if (join <= 0.0) { m = crowdPose(rest, phR, j); }
    else {
      m = crowdPose(fanB, phB, j);
      if (k < 1.0 && fanA != fanB) { let ma = crowdPose(fanA, phA, j); m = ma + (m - ma) * k; }
      if (join < 1.0) { let mr = crowdPose(rest, phR, j); m = mr + (m - mr) * join; }
    }
    if (waveW > 0.0) { m = m + (crowdPose(8, waveU, j) - m) * waveW; }
    skin = skin + m * wt;
  }
  let local = (skin * vec4f(in.position, 1.0)).xyz;
  var n = mat3x3f(skin[0].xyz, skin[1].xyz, skin[2].xyz) * in.normal;
  let scale = 0.94 + 0.12 * f32(in.look.w & 15u) / 15.0;
  let model = mat4x4f(crowd.v[0], crowd.v[1], crowd.v[2], crowd.v[3]);
  var yaw = in.seat.w;
  if (CROWD_TIER == 2u) {
    let seatWorld = (model * vec4f(in.seat.xyz, 1.0)).xyz;
    let toCamera = frame.cameraPos - seatWorld;
    yaw = atan2(toCamera.x, toCamera.z) - crowd.v[4].y;
    n = normalize(n + vec3f(0.0, 0.6, 0.0));
  }
  let cy = cos(yaw);
  let sy = sin(yaw);
  let p = vec3f(cy * local.x + sy * local.z, local.y, -sy * local.x + cy * local.z) * scale + in.seat.xyz;
  let nr = vec3f(cy * n.x + sy * n.z, n.y, -sy * n.x + cy * n.z);
  let kind = in.part.y;
  var hidden = kind > 0u && (kind != in.look.z || (flags & 4) == 0);
  if (kind == 5u) { hidden = (in.look.w & 0x90u) != 0x90u; }
  let world = model * vec4f(p, 1.0);
  out.worldPos = world.xyz;
  out.normal = normalize(mat3x3f(model[0].xyz, model[1].xyz, model[2].xyz) * nr);
  out.uv = vec2f(0.0);
  var t = cross(vec3f(1.0, 0.0, 0.0), out.normal);
  if (abs(out.normal.y) < 0.9) { t = cross(vec3f(0.0, 1.0, 0.0), out.normal); }
  out.tangent = normalize(t);
  out.bitangent = cross(out.normal, out.tangent);
  let slot = in.part.x;
  var color = vec3f(0.25, 0.2, 0.15);
  if (slot == 0u) { color = crowdSection(s, 3 + i32(in.look.x)).rgb; }
  else if (slot == 1u) { color = crowd.v[6 + i32((in.look.w >> 4u) & 7u) % max(i32(crowd.v[5].w), 1)].rgb; }
  else if (slot == 2u) { color = crowd.v[5].rgb; }
  else if (slot == 3u || slot == 4u) { color = crowdSection(s, 7 + i32(in.look.y)).rgb; }
  out.instanceColor = vec4f(color, 1.0);
  let flicker = 0.8 + 0.2 * sin(now * 7.0 + seed * 40.0);
  out.crowdGlow = select(vec4f(0.0), vec4f(color * crowd.v[4].w * flicker, 1.0), slot == 4u);
  out.clipPos = frame.projMatrix * frame.viewMatrix * world;
  if (hidden) { out.clipPos = vec4f(2.0, 2.0, 2.0, 1.0); }
  return out;
}`}function sceneCrowdFragmentWGSL(e){const t=/(@location\(5\)\s*@interpolate\(flat\)\s*instanceColor\s*:\s*vec4f\s*,)(\s*\};)/;if(!t.test(e)||e.indexOf("gosxPBRColor(in)")<0)throw new Error("crowd: PBR fragment anchor missing");return e.replace(t,`$1
    @location(6) @interpolate(flat) crowdGlow: vec4f,$2`).split("gosxPBRColor(in)").join("crowdGlowed(in, gosxPBRColor(in))")+`
fn crowdGlowed(in: VertexOutput, c: vec4f) -> vec4f { return vec4f(c.rgb + in.crowdGlow.rgb * select(0.8, 2.0, frame.toneMap == 4u), c.a); }
`}const sceneCrowdGPUResources=new WeakMap;function sceneCrowdGPUStatic(e,t){let o=sceneCrowdGPUResources.get(e);return o&&o.fanHeight===t||(o&&sceneCrowdGPUDispose(e),o={crowds:new Map,pipelines:new Map,fanHeight:t},o.bake=sceneCrowdBake(t),o.palette=e.createTexture({label:"gosx-crowd-palette",size:[o.bake.width,o.bake.height,1],format:"rgba32float",usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST}),e.queue.writeTexture({texture:o.palette},o.bake.data,{bytesPerRow:o.bake.width*16,rowsPerImage:o.bake.height},[o.bake.width,o.bake.height,1]),o.paletteView=o.palette.createView(),o.meshes=sceneCrowdMeshes(t).map(function(n){const s=e.createBuffer({label:"gosx-crowd-mesh",size:Math.ceil(n.vertices.byteLength/4)*4,usage:GPUBufferUsage.VERTEX|GPUBufferUsage.COPY_DST});e.queue.writeBuffer(s,0,n.vertices);const r=n.indices.length%2?Uint16Array.from(Array.from(n.indices).concat([0])):n.indices,i=e.createBuffer({label:"gosx-crowd-index",size:r.byteLength,usage:GPUBufferUsage.INDEX|GPUBufferUsage.COPY_DST});return e.queue.writeBuffer(i,0,r),{vbo:s,ibo:i,indexCount:n.indexCount}}),o.white=e.createTexture({label:"gosx-crowd-white",size:[1,1,1],format:"rgba8unorm",usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST}),e.queue.writeTexture({texture:o.white},new Uint8Array([255,255,255,255]),{bytesPerRow:4},[1,1,1]),o.whiteView=o.white.createView(),o.sampler=e.createSampler({magFilter:"linear",minFilter:"linear"}),o.slot=e.createBuffer({label:"gosx-crowd-object",size:256,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),o.layout=e.createBindGroupLayout({label:"gosx-crowd",entries:[{binding:0,visibility:GPUShaderStage.VERTEX,buffer:{type:"uniform"}},{binding:1,visibility:GPUShaderStage.VERTEX,texture:{sampleType:"unfilterable-float"}},{binding:2,visibility:GPUShaderStage.VERTEX,texture:{sampleType:"unfilterable-float"}}]}),sceneCrowdGPUResources.set(e,o)),o}function sceneCrowdGPUDisposeCrowd(e){for(const t of["instances","uniform","sections"])e[t]&&e[t].destroy(),e[t]=null;for(const t of e.sides||[])t.buffer&&t.buffer.destroy();e.sides=[]}function sceneCrowdGPUMaterial(e,t,o,n,s,r,i){o.sides=o.sides||[];const a=o.sides[s]||(o.sides[s]={}),c=n.material(r,i),f=c&&c.data;if((!a.buffer||a.size!==f.byteLength)&&(a.buffer&&a.buffer.destroy(),a.buffer=t.createBuffer({label:"gosx-crowd-material",size:Math.max(256,f.byteLength),usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),a.size=f.byteLength,a.group=null),t.queue.writeBuffer(a.buffer,0,f),!a.group||a.layout!==n.materialLayout){const l=[{binding:0,resource:{buffer:a.buffer}}];for(let u=0;u<9;u++)l.push({binding:2*u+1,resource:e.whiteView},{binding:2*u+2,resource:e.sampler});l.push({binding:19,resource:{buffer:e.slot,size:112}}),a.group=t.createBindGroup({label:"gosx-crowd-material",layout:n.materialLayout,entries:l}),a.layout=n.materialLayout}return a.group}function sceneCrowdGPUDispose(e){const t=sceneCrowdGPUResources.get(e);if(t){sceneCrowdGPUResources.delete(e);for(const o of t.crowds.values())sceneCrowdGPUDisposeCrowd(o);for(const o of t.meshes||[])o.vbo.destroy(),o.ibo.destroy();for(const o of["palette","white","slot"])t[o]&&t[o].destroy()}}function sceneCrowdGPUCrowd(e,t,o,n,s){let r=e.crowds.get(o.id);if(!r||r.ir!==o){r&&sceneCrowdGPUDisposeCrowd(r);const a=sceneCrowdPack(o);if(a.error)throw new Error(a.error);r={ir:o,packed:a,model:sceneCrowdModel(o),version:-1,uniforms:new Float32Array(SCENE_CROWD_UNIFORM_VEC4S*4)},r.instances=t.createBuffer({label:"gosx-crowd-fans",size:Math.max(32,a.records.byteLength),usage:GPUBufferUsage.VERTEX|GPUBufferUsage.COPY_DST}),t.queue.writeBuffer(r.instances,0,a.records),r.uniform=t.createBuffer({label:"gosx-crowd-uniform",size:r.uniforms.byteLength,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),r.sections=t.createTexture({label:"gosx-crowd-sections",size:[SCENE_CROWD_SECTION_TEXELS,o.sections.length,1],format:"rgba32float",usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST}),r.group=t.createBindGroup({label:"gosx-crowd",layout:e.layout,entries:[{binding:0,resource:{buffer:r.uniform}},{binding:1,resource:e.paletteView},{binding:2,resource:r.sections.createView()}]}),n.fans=a.sectionFans,e.crowds.set(o.id,r)}r.version!==n.version&&(t.queue.writeTexture({texture:r.sections},n.sections,{bytesPerRow:SCENE_CROWD_SECTION_TEXELS*16,rowsPerImage:o.sections.length},[SCENE_CROWD_SECTION_TEXELS,o.sections.length,1]),r.version=n.version);const i=sceneCrowdMaterials(o);return r.fanGroup=sceneCrowdGPUMaterial(e,t,r,s,0,i.fan,o.receiveShadow!==!1),r.propsGroup=sceneCrowdGPUMaterial(e,t,r,s,1,i.props,o.receiveShadow!==!1),r}function sceneCrowdGPUPipeline(e,t,o,n){const s=String((typeof t.fragment=="function"?t.fragment(n):t.fragment)||"");e.fragmentIDs||(e.fragmentIDs=new Map,e.fragmentModules=new Map);let r=e.fragmentIDs.get(s);r===void 0&&(r=e.fragmentIDs.size,e.fragmentIDs.set(s,r));const i=o+"|"+r+"|"+t.format+"|"+t.samples+"|"+(t.specular?1:0);let a=e.pipelines.get(i);if(a)return a;const c=t.device;(!e.vertexModule||e.vertexSource!==t.frameStructs)&&(e.vertexModule=c.createShaderModule({label:"gosx-crowd-vert",code:sceneCrowdVertexWGSL(t.frameStructs)}),e.vertexSource=t.frameStructs);let f=e.fragmentModules.get(r);f||(f=c.createShaderModule({label:"gosx-crowd-frag",code:sceneCrowdFragmentWGSL(s)}),e.fragmentModules.set(r,f));const l=t.specular?[{format:t.format},{format:"rgba16float"}]:[{format:t.format}],u={label:"gosx-crowd-"+o,layout:c.createPipelineLayout({bindGroupLayouts:[t.frameLayout,t.materialLayout,e.layout]}),vertex:{module:e.vertexModule,entryPoint:"vertexMain",constants:{CROWD_TIER:o},buffers:[{arrayStride:SCENE_CROWD_VERTEX_BYTES,stepMode:"vertex",attributes:[{shaderLocation:0,offset:0,format:"float32x3"},{shaderLocation:1,offset:12,format:"float32x3"},{shaderLocation:2,offset:24,format:"uint8x4"},{shaderLocation:3,offset:28,format:"unorm8x4"},{shaderLocation:4,offset:32,format:"uint8x4"}]},{arrayStride:32,stepMode:"instance",attributes:[{shaderLocation:5,offset:0,format:"float32x4"},{shaderLocation:6,offset:16,format:"float32"},{shaderLocation:7,offset:20,format:"uint16x2"},{shaderLocation:8,offset:24,format:"uint8x4"},{shaderLocation:9,offset:28,format:"uint8x4"}]}]},fragment:{module:f,entryPoint:t.specular?"fragmentMainSpecular":"fragmentMain",targets:l},primitive:{topology:"triangle-list",cullMode:"back",frontFace:"ccw"},multisample:{count:Math.max(1,t.samples|0)},depthStencil:{format:"depth24plus",depthWriteEnabled:!0,depthCompare:"less-equal"}};return a=typeof t.create=="function"?t.create(c,"render",u):c.createRenderPipeline(u),e.pipelines.set(i,a),a}function sceneCrowdGPUDraw(e,t){const o=t.environment&&Array.isArray(t.environment.crowds)?t.environment.crowds:null,n={state:"none",fans:0,full:0,low:0,impostor:0,draws:0,cpuMs:0,error:""},s=typeof performance<"u"?performance.now():0;try{if(!o||!o.length)return t.device&&sceneCrowdGPUResources.has(t.device)&&sceneCrowdGPUDispose(t.device),n.state;const r=Number(t.time)||0;sceneCrowdNoteClock(t.mount,r);const i=new Set;n.state="ready";for(const c of o){if(!c||!c.id)continue;i.add(c.id);const f=sceneCrowdStore(t.mount,c);f.lastNow=r;const l=sceneCrowdGPUStatic(t.device,Number(c.fan&&c.fan.height)||1.75),u=sceneCrowdGPUCrowd(l,t.device,c,f,t),d=sceneCrowdSelect(u,u.packed,c,t);n.fans+=u.packed.count,n.full+=d.fans[0],n.low+=d.fans[1],n.impostor+=d.fans[2],t.device.queue.writeBuffer(u.uniform,0,sceneCrowdUniforms(c,f,l.bake,u.model,r,u.uniforms));const y=sceneCrowdMaterials(c);for(let x=0;x<3;x++){const _=d.ranges[x];if(!_.length)continue;const p=l.meshes[x];for(const[w,m,E,v]of[[y.fan,u.fanGroup,0,p.bodyIndexCount],[y.props,u.propsGroup,p.bodyIndexCount,p.indexCount-p.bodyIndexCount]]){const h=sceneCrowdGPUPipeline(l,t,x,w),g=t.validation&&t.validation.get(h);if(g&&!g.ready){n.state="pending";continue}e.setPipeline(g&&g.pipeline||h),e.setBindGroup(0,t.frameGroup),e.setBindGroup(1,m,[0]),e.setBindGroup(2,u.group),e.setVertexBuffer(0,p.vbo),e.setVertexBuffer(1,u.instances),e.setIndexBuffer(p.ibo,"uint16");for(let C=0;C<_.length;C+=2)e.drawIndexed(v,_[C+1],E,0,_[C]),n.draws++}}}const a=sceneCrowdGPUResources.get(t.device);if(a)for(const c of Array.from(a.crowds.keys()))i.has(c)||(sceneCrowdGPUDisposeCrowd(a.crowds.get(c)),a.crowds.delete(c))}catch(r){n.state="failed",n.error=String(r&&r.message||r)}finally{n.cpuMs=typeof performance<"u"?performance.now()-s:0,sceneCrowdPublish(t.mount,n)}return n.state}typeof window<"u"&&(window.__gosx_scene3d_crowd_api={webgl:sceneCrowdGLDraw,webgpu:sceneCrowdGPUDraw,dispose:function(e){e&&(sceneCrowdGLDispose(e),sceneCrowdGPUDispose(e))},apply:sceneCrowdApply,decode:sceneCrowdDecode,levels:sceneCrowdLevels,layout:sceneCrowdLayout,pack:sceneCrowdPack,bake:sceneCrowdBake,meshes:sceneCrowdMeshes,select:sceneCrowdSelect,actions:SCENE_CROWD_ACTIONS.map(function(e){return e[0]}),stats:null});
